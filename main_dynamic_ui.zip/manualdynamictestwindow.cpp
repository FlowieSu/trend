#include "manualdynamictestwindow.h"
#include "ui_manualdynamictestwindow.h"

#include "dynamic_test_controller.h"
#include "dynamic_csv_exporter.h"

#include <QDateTime>
#include <QDir>
#include <QFileDialog>
#include <QHeaderView>
#include <QMessageBox>
#include <QTableWidgetItem>
#include <QVariant>

ManualDynamicTestWindow::ManualDynamicTestWindow(DynamicTestController *controller,
                                                 const QString &productCode1,
                                                 const QString &productCode2,
                                                 QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ManualDynamicTestWindow)
    , m_controller(controller)
{
    ui->setupUi(this);

    qRegisterMetaType<DynamicProductResult>("DynamicProductResult");
    qRegisterMetaType<QVector<DynamicProductResult>>("QVector<DynamicProductResult>");

    initUi(productCode1, productCode2);
    initConnections();

    appendLog("手动动态测试窗口已打开。");
}

ManualDynamicTestWindow::~ManualDynamicTestWindow()
{
    delete ui;
}

void ManualDynamicTestWindow::initUi(const QString &productCode1,
                                     const QString &productCode2)
{
    initChannelCombos();
    initResultTable();

    ui->editProductCode1->setText(productCode1);
    ui->editProductCode2->setText(productCode2);

    ui->lblProduct1Status->setText("位置1：未开始");
    ui->lblProduct2Status->setText("位置2：未开始");
    ui->lblOverallStatus->setText("总结果：-");

    setRunningState(false);
}

void ManualDynamicTestWindow::initChannelCombos()
{
    auto fill = [](QComboBox *combo) {
        combo->clear();
        combo->addItem("0x110 -> 0x201",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel110));
        combo->addItem("0x112 -> 0x301",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel112));
        combo->addItem("0x114 -> 0x401",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel114));
        combo->addItem("0x116 -> 0x501",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel116));
    };

    fill(ui->cmbChannel1);
    fill(ui->cmbChannel2);

    ui->cmbChannel1->setCurrentIndex(0);
    ui->cmbChannel2->setCurrentIndex(1);
}

void ManualDynamicTestWindow::initResultTable()
{
    ui->tblResult->setColumnCount(14);

    QStringList headers;
    headers << "位置"
            << "产品编码"
            << "通道"
            << "发送ID"
            << "接收ID"
            << "进度"
            << "检测项编号"
            << "检测项名称"
            << "合格标准"
            << "标志值"
            << "实测值"
            << "单位"
            << "结果"
            << "备注";

    ui->tblResult->setHorizontalHeaderLabels(headers);
    ui->tblResult->horizontalHeader()->setStretchLastSection(true);
    ui->tblResult->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tblResult->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tblResult->setAlternatingRowColors(true);
}

void ManualDynamicTestWindow::initConnections()
{
    connect(ui->btnStart,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onStartClicked);

    connect(ui->btnStop,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onStopClicked);

    connect(ui->btnSave,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onSaveClicked);

    connect(ui->btnClear,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onClearClicked);

    if (!m_controller) {
        return;
    }

    connect(m_controller,
            &DynamicTestController::logMessage,
            this,
            &ManualDynamicTestWindow::appendLog);

    connect(m_controller,
            &DynamicTestController::productProgressChanged,
            this,
            &ManualDynamicTestWindow::onProductProgressChanged);

    connect(m_controller,
            &DynamicTestController::productFinished,
            this,
            &ManualDynamicTestWindow::onProductFinished);

    connect(m_controller,
            &DynamicTestController::allFinished,
            this,
            &ManualDynamicTestWindow::onAllFinished);
}

void ManualDynamicTestWindow::onStartClicked()
{
    if (!m_controller) {
        QMessageBox::warning(this, "提示", "动态检测控制器为空。");
        return;
    }

    QString productCode1;
    QString productCode2;

    if (!validateProductCodes(&productCode1, &productCode2)) {
        return;
    }

    if (currentChannel1() == currentChannel2()) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能选择同一个 CAN 通道。");
        return;
    }

    const QMessageBox::StandardButton confirm =
            QMessageBox::question(this,
                                  "动态测试确认",
                                  "请确认产品已经安装到位，且可以启动动态检测。是否继续？",
                                  QMessageBox::Yes | QMessageBox::No,
                                  QMessageBox::No);

    if (confirm != QMessageBox::Yes) {
        return;
    }

    clearResultTable();
    m_lastResults.clear();

    ui->lblProduct1Status->setText("位置1：检测中");
    ui->lblProduct2Status->setText("位置2：检测中");
    ui->lblOverallStatus->setText("总结果：检测中");

    setRunningState(true);

    m_controller->startDynamicTestWithChannels(productCode1,
                                               currentChannel1(),
                                               productCode2,
                                               currentChannel2());
}

void ManualDynamicTestWindow::onStopClicked()
{
    if (m_controller) {
        m_controller->requestStop();
    }
}

void ManualDynamicTestWindow::onSaveClicked()
{
    if (m_lastResults.isEmpty()) {
        QMessageBox::information(this, "提示", "当前没有可保存的动态检测结果。");
        return;
    }

    const QString defaultPath =
            DynamicCsvExporter::makeDefaultFileName(defaultResultDir(),
                                                    "manual_dynamic_result");

    const QString filePath =
            QFileDialog::getSaveFileName(this,
                                         "保存手动动态检测结果",
                                         defaultPath,
                                         "CSV 文件 (*.csv)");

    if (filePath.isEmpty()) {
        return;
    }

    QString error;
    if (!DynamicCsvExporter::exportResults(m_lastResults, filePath, &error)) {
        QMessageBox::warning(this, "保存失败", error);
        return;
    }

    appendLog(QString("手动动态检测结果已保存：%1").arg(filePath));
    QMessageBox::information(this, "保存成功", QString("已保存：\n%1").arg(filePath));
}

void ManualDynamicTestWindow::onClearClicked()
{
    clearResultTable();
    m_lastResults.clear();

    ui->lblProduct1Status->setText("位置1：未开始");
    ui->lblProduct2Status->setText("位置2：未开始");
    ui->lblOverallStatus->setText("总结果：-");

    appendLog("手动动态检测显示结果已清空。");
}

void ManualDynamicTestWindow::onProductProgressChanged(int productId,
                                                       int progress,
                                                       int groupCnt)
{
    const QString text =
            QString("位置%1：检测中，进度=%2%，轮询组=%3")
            .arg(productId)
            .arg(progress)
            .arg(groupCnt);

    if (productId == 1) {
        ui->lblProduct1Status->setText(text);
    } else if (productId == 2) {
        ui->lblProduct2Status->setText(text);
    }
}

void ManualDynamicTestWindow::onProductFinished(DynamicProductResult result)
{
    displayProductResult(result);

    if (result.productId == 1) {
        ui->lblProduct1Status->setText(QString("位置1：完成，%1")
                                       .arg(passText(result.pass)));
    } else if (result.productId == 2) {
        ui->lblProduct2Status->setText(QString("位置2：完成，%1")
                                       .arg(passText(result.pass)));
    }
}

void ManualDynamicTestWindow::onAllFinished(bool allPass,
                                            QVector<DynamicProductResult> results)
{
    m_lastResults = results;

    clearResultTable();

    for (const DynamicProductResult &result : results) {
        displayProductResult(result);
    }

    ui->lblOverallStatus->setText(QString("总结果：%1").arg(passText(allPass)));

    setRunningState(false);

    appendLog(QString("手动动态检测结束，总结果：%1。")
              .arg(passText(allPass)));
}

void ManualDynamicTestWindow::appendLog(const QString &message)
{
    const QString timeText =
            QDateTime::currentDateTime().toString("HH:mm:ss.zzz");

    ui->txtLog->append(QString("[%1] %2").arg(timeText, message));
}

DynamicProtocol::DynamicChannel ManualDynamicTestWindow::currentChannel1() const
{
    return static_cast<DynamicProtocol::DynamicChannel>(
                ui->cmbChannel1->currentData().toInt());
}

DynamicProtocol::DynamicChannel ManualDynamicTestWindow::currentChannel2() const
{
    return static_cast<DynamicProtocol::DynamicChannel>(
                ui->cmbChannel2->currentData().toInt());
}

bool ManualDynamicTestWindow::validateProductCodes(QString *productCode1,
                                                   QString *productCode2) const
{
    const QString code1 = ui->editProductCode1->text().trimmed();
    const QString code2 = ui->editProductCode2->text().trimmed();

    if (code1.isEmpty()) {
        QMessageBox::warning(const_cast<ManualDynamicTestWindow *>(this),
                             "提示",
                             "请输入位置1产品编码。");
        return false;
    }

    if (code2.isEmpty()) {
        QMessageBox::warning(const_cast<ManualDynamicTestWindow *>(this),
                             "提示",
                             "请输入位置2产品编码。");
        return false;
    }

    if (productCode1) {
        *productCode1 = code1;
    }

    if (productCode2) {
        *productCode2 = code2;
    }

    return true;
}

void ManualDynamicTestWindow::displayProductResult(const DynamicProductResult &result)
{
    for (const DynamicItemResult &item : result.itemResults) {
        addResultRow(result, item);
    }
}

void ManualDynamicTestWindow::addResultRow(const DynamicProductResult &product,
                                           const DynamicItemResult &item)
{
    const int row = ui->tblResult->rowCount();
    ui->tblResult->insertRow(row);

    auto setItem = [this, row](int column, const QString &text) {
        ui->tblResult->setItem(row, column, new QTableWidgetItem(text));
    };

    setItem(0, QString("位置%1").arg(product.productId));
    setItem(1, product.productCode);
    setItem(2, product.channelName);
    setItem(3, canIdText(product.txId));
    setItem(4, canIdText(product.rxId));
    setItem(5, QString::number(product.detectProgress));
    setItem(6, QString::number(item.itemNo));
    setItem(7, item.itemName);
    setItem(8, item.standardText);
    setItem(9, QString::number(item.flagValue));
    setItem(10, QString::number(item.displayValue, 'f', 3));
    setItem(11, item.unit);
    setItem(12, passText(item.pass));
    setItem(13, item.message);
}

void ManualDynamicTestWindow::clearResultTable()
{
    ui->tblResult->setRowCount(0);
}

void ManualDynamicTestWindow::setRunningState(bool running)
{
    m_running = running;

    ui->btnStart->setEnabled(!running);
    ui->btnStop->setEnabled(running);
    ui->btnSave->setEnabled(!running);
    ui->btnClear->setEnabled(!running);

    ui->editProductCode1->setEnabled(!running);
    ui->editProductCode2->setEnabled(!running);
    ui->cmbChannel1->setEnabled(!running);
    ui->cmbChannel2->setEnabled(!running);
}

QString ManualDynamicTestWindow::defaultResultDir() const
{
    QDir dir(QDir::currentPath());
    if (!dir.exists("results")) {
        dir.mkdir("results");
    }

    return dir.filePath("results");
}

QString ManualDynamicTestWindow::passText(bool pass) const
{
    return pass ? "PASS" : "NG";
}

QString ManualDynamicTestWindow::canIdText(quint32 canId) const
{
    return DynamicProtocol::canIdToString(canId);
}
