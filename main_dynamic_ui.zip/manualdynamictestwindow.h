#ifndef MANUALDYNAMICTESTWINDOW_H
#define MANUALDYNAMICTESTWINDOW_H

#include <QWidget>
#include <QVector>

#include "dynamic_result_types.h"
#include "dynamic_protocol.h"

QT_BEGIN_NAMESPACE
namespace Ui { class ManualDynamicTestWindow; }
QT_END_NAMESPACE

class DynamicTestController;

class ManualDynamicTestWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ManualDynamicTestWindow(DynamicTestController *controller,
                                     const QString &productCode1,
                                     const QString &productCode2,
                                     QWidget *parent = nullptr);
    ~ManualDynamicTestWindow() override;

private slots:
    void onStartClicked();
    void onStopClicked();
    void onSaveClicked();
    void onClearClicked();

    void onProductProgressChanged(int productId,
                                  int progress,
                                  int groupCnt);

    void onProductFinished(DynamicProductResult result);

    void onAllFinished(bool allPass,
                       QVector<DynamicProductResult> results);

    void appendLog(const QString &message);

private:
    void initUi(const QString &productCode1,
                const QString &productCode2);

    void initChannelCombos();
    void initResultTable();
    void initConnections();

    DynamicProtocol::DynamicChannel currentChannel1() const;
    DynamicProtocol::DynamicChannel currentChannel2() const;

    bool validateProductCodes(QString *productCode1,
                              QString *productCode2) const;

    void displayProductResult(const DynamicProductResult &result);
    void addResultRow(const DynamicProductResult &product,
                      const DynamicItemResult &item);

    void clearResultTable();

    void setRunningState(bool running);

    QString defaultResultDir() const;
    QString passText(bool pass) const;
    QString canIdText(quint32 canId) const;

private:
    Ui::ManualDynamicTestWindow *ui = nullptr;

    DynamicTestController *m_controller = nullptr;
    QVector<DynamicProductResult> m_lastResults;

    bool m_running = false;
};

#endif // MANUALDYNAMICTESTWINDOW_H
