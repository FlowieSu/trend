#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "dynamic_test_controller.h"
#include "dynamic_csv_exporter.h"
#include "manualdynamictestwindow.h"

#include <QDateTime>
#include <QDir>
#include <QFileDialog>
#include <QHeaderView>
#include <QMessageBox>
#include <QTableWidgetItem>
#include <QVariant>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_dynamicController(new DynamicTestController(this))
{
    ui->setupUi(this);

    qRegisterMetaType<DynamicItemResult>("DynamicItemResult");
    qRegisterMetaType<DynamicProductResult>("DynamicProductResult");
    qRegisterMetaType<QVector<DynamicProductResult>>("QVector<DynamicProductResult>");
    qRegisterMetaType<ZlgCanOpenConfig>("ZlgCanOpenConfig");

    initUi();
    initConnections();

    appendLog("主界面初始化完成。");
}

MainWindow::~MainWindow()
{
    if (m_dynamicController) {
        m_dynamicController->requestStop();
        m_dynamicController->closeCanDevice();
    }

    delete ui;
}

void MainWindow::initUi()
{
    initCanDeviceTypeCombo();
    initChannelCombos();
    initDynamicResultTable();

    ui->spinDeviceIndex->setRange(0, 16);
    ui->spinChannelIndex->setRange(0, 8);
    ui->spinCanBaudRate->setRange(10000, 1000000);
    ui->spinCanBaudRate->setValue(500000);
    ui->spinCanFdAbit->setRange(10000, 1000000);
    ui->spinCanFdAbit->setValue(500000);
    ui->spinCanFdDbit->setRange(10000, 8000000);
    ui->spinCanFdDbit->setValue(2000000);
    ui->spinTimeout->setRange(10, 600);
    ui->spinTimeout->setValue(180);

    ui->chkExtendedFrame->setChecked(true);
    ui->chkSendAsCanFd->setChecked(false);
    ui->chkReceiveCanFd->setChecked(false);
    ui->chkTerminalResistance->setChecked(false);

    ui->lblCanStatus->setText("CAN：未连接");
    ui->lblProduct1Status->setText("位置1：未开始");
    ui->lblProduct2Status->setText("位置2：未开始");
    ui->lblOverallStatus->setText("总结果：-");

    setCanUiState(false);
    setDynamicRunningState(false);
}

void MainWindow::initCanDeviceTypeCombo()
{
    ui->cmbCanDeviceType->clear();

    ui->cmbCanDeviceType->addItem("USBCANFD-200U",
                                  static_cast<int>(ZlgCanDeviceType::UsbCanFd200U));

    ui->cmbCanDeviceType->addItem("USBCAN-II+",
                                  static_cast<int>(ZlgCanDeviceType::UsbCanIIPlus));
}

void MainWindow::initChannelCombos()
{
    auto fillChannelCombo = [](QComboBox *combo) {
        combo->clear();
        combo->addItem("0x110 -> 0x201",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel110));
        combo->addItem("0x112 -> 0x301",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel112));
        combo->addItem("0x114 -> 0x401",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel114));
        combo->addItem("0x116 -> 0x501",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel116));
    };

    fillChannelCombo(ui->cmbChannel1);
    fillChannelCombo(ui->cmbChannel2);

    ui->cmbChannel1->setCurrentIndex(0);
    ui->cmbChannel2->setCurrentIndex(1);
}

void MainWindow::initDynamicResultTable()
{
    ui->tblDynamicResult->setColumnCount(14);

    QStringList headers;
    headers << "位置"
            << "产品编码"
            << "通道"
            << "发送ID"
            << "接收ID"
            << "进度"
            << "检测项编号"
            << "检测项名称"
            << "合格标准"
            << "标志值"
            << "实测值"
            << "单位"
            << "结果"
            << "备注";

    ui->tblDynamicResult->setHorizontalHeaderLabels(headers);
    ui->tblDynamicResult->horizontalHeader()->setStretchLastSection(true);
    ui->tblDynamicResult->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tblDynamicResult->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tblDynamicResult->setAlternatingRowColors(true);
}

void MainWindow::initConnections()
{
    connect(ui->btnConnectCan,
            &QPushButton::clicked,
            this,
            &MainWindow::onConnectCanClicked);

    connect(ui->btnDisconnectCan,
            &QPushButton::clicked,
            this,
            &MainWindow::onDisconnectCanClicked);

    connect(ui->btnStartDynamic,
            &QPushButton::clicked,
            this,
            &MainWindow::onStartDynamicClicked);

    connect(ui->btnStopDynamic,
            &QPushButton::clicked,
            this,
            &MainWindow::onStopDynamicClicked);

    connect(ui->btnSaveDynamicCsv,
            &QPushButton::clicked,
            this,
            &MainWindow::onSaveDynamicCsvClicked);

    connect(ui->btnClearDynamic,
            &QPushButton::clicked,
            this,
            &MainWindow::onClearDynamicClicked);

    connect(ui->btnOpenManualDynamic,
            &QPushButton::clicked,
            this,
            &MainWindow::onOpenManualDynamicClicked);

    connect(m_dynamicController,
            &DynamicTestController::logMessage,
            this,
            &MainWindow::appendLog);

    connect(m_dynamicController,
            &DynamicTestController::canConnectedChanged,
            this,
            &MainWindow::onCanConnectedChanged);

    connect(m_dynamicController,
            &DynamicTestController::productProgressChanged,
            this,
            &MainWindow::onDynamicProductProgressChanged);

    connect(m_dynamicController,
            &DynamicTestController::productFrameUpdated,
            this,
            &MainWindow::onDynamicProductFrameUpdated);

    connect(m_dynamicController,
            &DynamicTestController::productFinished,
            this,
            &MainWindow::onDynamicProductFinished);

    connect(m_dynamicController,
            &DynamicTestController::allFinished,
            this,
            &MainWindow::onDynamicAllFinished);
}

void MainWindow::onConnectCanClicked()
{
    if (!m_dynamicController) {
        return;
    }

    ZlgCanOpenConfig config = currentCanConfig();

    m_dynamicController->setTimeoutMs(ui->spinTimeout->value() * 1000);

    const bool ok = m_dynamicController->openCanDevice(config);

    if (!ok) {
        QMessageBox::warning(this,
                             "CAN连接失败",
                             "CAN设备打开失败，请检查设备类型、通道、驱动和波特率设置。");
    }
}

void MainWindow::onDisconnectCanClicked()
{
    if (m_dynamicRunning) {
        QMessageBox::warning(this, "提示", "动态检测运行中，请先停止检测。");
        return;
    }

    if (m_dynamicController) {
        m_dynamicController->closeCanDevice();
    }
}

void MainWindow::onStartDynamicClicked()
{
    QString productCode1;
    QString productCode2;

    if (!validateProductCodes(&productCode1, &productCode2)) {
        return;
    }

    if (!m_canConnected) {
        QMessageBox::warning(this, "提示", "请先连接 CAN 设备。");
        return;
    }

    if (currentChannel1() == currentChannel2()) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能选择同一个 CAN 通道。");
        return;
    }

    clearDynamicResultTable();
    m_lastDynamicResults.clear();

    ui->lblProduct1Status->setText("位置1：检测中");
    ui->lblProduct2Status->setText("位置2：检测中");
    ui->lblOverallStatus->setText("总结果：检测中");

    setDynamicRunningState(true);

    m_dynamicController->setTimeoutMs(ui->spinTimeout->value() * 1000);

    m_dynamicController->startDynamicTestWithChannels(productCode1,
                                                      currentChannel1(),
                                                      productCode2,
                                                      currentChannel2());
}

void MainWindow::onStopDynamicClicked()
{
    if (m_dynamicController) {
        m_dynamicController->requestStop();
    }
}

void MainWindow::onSaveDynamicCsvClicked()
{
    if (m_lastDynamicResults.isEmpty()) {
        QMessageBox::information(this, "提示", "当前没有可保存的动态检测结果。");
        return;
    }

    const QString defaultPath =
            DynamicCsvExporter::makeDefaultFileName(defaultResultDir(),
                                                    "dynamic_result");

    const QString filePath =
            QFileDialog::getSaveFileName(this,
                                         "保存动态检测结果",
                                         defaultPath,
                                         "CSV 文件 (*.csv)");

    if (filePath.isEmpty()) {
        return;
    }

    QString error;
    if (!DynamicCsvExporter::exportResults(m_lastDynamicResults, filePath, &error)) {
        QMessageBox::warning(this, "保存失败", error);
        return;
    }

    appendLog(QString("动态检测结果已保存：%1").arg(filePath));
    QMessageBox::information(this, "保存成功", QString("已保存：\n%1").arg(filePath));
}

void MainWindow::onClearDynamicClicked()
{
    clearDynamicResultTable();
    m_lastDynamicResults.clear();

    ui->lblProduct1Status->setText("位置1：未开始");
    ui->lblProduct2Status->setText("位置2：未开始");
    ui->lblOverallStatus->setText("总结果：-");

    appendLog("动态检测显示结果已清空。");
}

void MainWindow::onOpenManualDynamicClicked()
{
    if (m_manualDynamicWindow) {
        m_manualDynamicWindow->show();
        m_manualDynamicWindow->raise();
        m_manualDynamicWindow->activateWindow();
        return;
    }

    QString productCode1 = ui->editProductCode1->text().trimmed();
    QString productCode2 = ui->editProductCode2->text().trimmed();

    m_manualDynamicWindow = new ManualDynamicTestWindow(m_dynamicController,
                                                        productCode1,
                                                        productCode2,
                                                        nullptr);

    m_manualDynamicWindow->setAttribute(Qt::WA_DeleteOnClose);
    m_manualDynamicWindow->setWindowTitle("手动动态测试");

    connect(m_manualDynamicWindow,
            &QObject::destroyed,
            this,
            [this]() {
                m_manualDynamicWindow = nullptr;
            });

    m_manualDynamicWindow->show();
    m_manualDynamicWindow->raise();
    m_manualDynamicWindow->activateWindow();
}

void MainWindow::onCanConnectedChanged(bool connected)
{
    m_canConnected = connected;

    ui->lblCanStatus->setText(connected ? "CAN：已连接" : "CAN：未连接");

    setCanUiState(connected);
}

void MainWindow::onDynamicProductProgressChanged(int productId,
                                                 int progress,
                                                 int groupCnt)
{
    const QString text =
            QString("位置%1：检测中，进度=%2%，轮询组=%3")
            .arg(productId)
            .arg(progress)
            .arg(groupCnt);

    if (productId == 1) {
        ui->lblProduct1Status->setText(text);
    } else if (productId == 2) {
        ui->lblProduct2Status->setText(text);
    }
}

void MainWindow::onDynamicProductFrameUpdated(int productId,
                                              int seq,
                                              int value,
                                              int groupCnt)
{
    Q_UNUSED(productId)
    Q_UNUSED(seq)
    Q_UNUSED(value)
    Q_UNUSED(groupCnt)
}

void MainWindow::onDynamicProductFinished(DynamicProductResult result)
{
    displayProductResult(result);

    if (result.productId == 1) {
        ui->lblProduct1Status->setText(QString("位置1：完成，%1")
                                       .arg(passText(result.pass)));
    } else if (result.productId == 2) {
        ui->lblProduct2Status->setText(QString("位置2：完成，%1")
                                       .arg(passText(result.pass)));
    }
}

void MainWindow::onDynamicAllFinished(bool allPass,
                                      QVector<DynamicProductResult> results)
{
    m_lastDynamicResults = results;

    clearDynamicResultTable();

    for (const DynamicProductResult &result : results) {
        displayProductResult(result);
    }

    ui->lblOverallStatus->setText(QString("总结果：%1").arg(passText(allPass)));

    setDynamicRunningState(false);

    appendLog(QString("动态检测结束，总结果：%1。").arg(passText(allPass)));
}

void MainWindow::appendLog(const QString &message)
{
    const QString timeText =
            QDateTime::currentDateTime().toString("HH:mm:ss.zzz");

    ui->txtLog->append(QString("[%1] %2").arg(timeText, message));
}

ZlgCanOpenConfig MainWindow::currentCanConfig() const
{
    ZlgCanOpenConfig config;

    config.deviceType = static_cast<ZlgCanDeviceType>(
                ui->cmbCanDeviceType->currentData().toInt());

    config.deviceIndex = ui->spinDeviceIndex->value();
    config.channelIndex = ui->spinChannelIndex->value();

    config.canBaudRate = ui->spinCanBaudRate->value();

    config.canFdAbitBaudRate = ui->spinCanFdAbit->value();
    config.canFdDbitBaudRate = ui->spinCanFdDbit->value();

    config.sendAsCanFd = ui->chkSendAsCanFd->isChecked();
    config.receiveCanFd = ui->chkReceiveCanFd->isChecked();
    config.extendedFrame = ui->chkExtendedFrame->isChecked();
    config.terminalResistance = ui->chkTerminalResistance->isChecked();

    config.pollIntervalMs = 10;

    return config;
}

DynamicProtocol::DynamicChannel MainWindow::currentChannel1() const
{
    return static_cast<DynamicProtocol::DynamicChannel>(
                ui->cmbChannel1->currentData().toInt());
}

DynamicProtocol::DynamicChannel MainWindow::currentChannel2() const
{
    return static_cast<DynamicProtocol::DynamicChannel>(
                ui->cmbChannel2->currentData().toInt());
}

bool MainWindow::validateProductCodes(QString *productCode1,
                                      QString *productCode2) const
{
    const QString code1 = ui->editProductCode1->text().trimmed();
    const QString code2 = ui->editProductCode2->text().trimmed();

    if (code1.isEmpty()) {
        QMessageBox::warning(const_cast<MainWindow *>(this),
                             "提示",
                             "请输入位置1产品编码。");
        return false;
    }

    if (code2.isEmpty()) {
        QMessageBox::warning(const_cast<MainWindow *>(this),
                             "提示",
                             "请输入位置2产品编码。");
        return false;
    }

    if (productCode1) {
        *productCode1 = code1;
    }

    if (productCode2) {
        *productCode2 = code2;
    }

    return true;
}

void MainWindow::setCanUiState(bool connected)
{
    ui->btnConnectCan->setEnabled(!connected);
    ui->btnDisconnectCan->setEnabled(connected);

    ui->cmbCanDeviceType->setEnabled(!connected);
    ui->spinDeviceIndex->setEnabled(!connected);
    ui->spinChannelIndex->setEnabled(!connected);
    ui->spinCanBaudRate->setEnabled(!connected);
    ui->spinCanFdAbit->setEnabled(!connected);
    ui->spinCanFdDbit->setEnabled(!connected);
    ui->chkExtendedFrame->setEnabled(!connected);
    ui->chkSendAsCanFd->setEnabled(!connected);
    ui->chkReceiveCanFd->setEnabled(!connected);
    ui->chkTerminalResistance->setEnabled(!connected);

    ui->btnStartDynamic->setEnabled(connected && !m_dynamicRunning);
    ui->btnOpenManualDynamic->setEnabled(connected);
}

void MainWindow::setDynamicRunningState(bool running)
{
    m_dynamicRunning = running;

    ui->btnStartDynamic->setEnabled(m_canConnected && !running);
    ui->btnStopDynamic->setEnabled(running);
    ui->btnSaveDynamicCsv->setEnabled(!running);
    ui->btnClearDynamic->setEnabled(!running);

    ui->editProductCode1->setEnabled(!running);
    ui->editProductCode2->setEnabled(!running);
    ui->cmbChannel1->setEnabled(!running);
    ui->cmbChannel2->setEnabled(!running);
}

void MainWindow::displayProductResult(const DynamicProductResult &result)
{
    for (const DynamicItemResult &item : result.itemResults) {
        addDynamicResultRow(result, item);
    }
}

void MainWindow::addDynamicResultRow(const DynamicProductResult &product,
                                     const DynamicItemResult &item)
{
    const int row = ui->tblDynamicResult->rowCount();
    ui->tblDynamicResult->insertRow(row);

    auto setItem = [this, row](int column, const QString &text) {
        ui->tblDynamicResult->setItem(row, column, new QTableWidgetItem(text));
    };

    setItem(0, QString("位置%1").arg(product.productId));
    setItem(1, product.productCode);
    setItem(2, product.channelName);
    setItem(3, canIdText(product.txId));
    setItem(4, canIdText(product.rxId));
    setItem(5, QString::number(product.detectProgress));
    setItem(6, QString::number(item.itemNo));
    setItem(7, item.itemName);
    setItem(8, item.standardText);
    setItem(9, QString::number(item.flagValue));
    setItem(10, QString::number(item.displayValue, 'f', 3));
    setItem(11, item.unit);
    setItem(12, passText(item.pass));
    setItem(13, item.message);
}

void MainWindow::clearDynamicResultTable()
{
    ui->tblDynamicResult->setRowCount(0);
}

QString MainWindow::defaultResultDir() const
{
    QDir dir(QDir::currentPath());
    if (!dir.exists("results")) {
        dir.mkdir("results");
    }

    return dir.filePath("results");
}

QString MainWindow::canIdText(quint32 canId) const
{
    return DynamicProtocol::canIdToString(canId);
}

QString MainWindow::passText(bool pass) const
{
    return pass ? "PASS" : "NG";
}
