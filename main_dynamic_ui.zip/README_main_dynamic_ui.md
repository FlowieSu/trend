# 主界面与手动动态窗口接入说明

## 文件

- mainwindow.h / mainwindow.cpp / mainwindow.ui
- manualdynamictestwindow.h / manualdynamictestwindow.cpp / manualdynamictestwindow.ui

## 依赖动态检测文件

这组界面代码依赖以下动态检测文件：

- dynamic_protocol.h/.cpp
- dynamic_result_types.h
- dynamic_test_item_config.h/.cpp
- dynamic_product_context.h/.cpp
- dynamic_test_controller.h/.cpp
- dynamic_csv_exporter.h/.cpp
- zlg_can_device.h/.cpp
- Device.h/.cpp

## 主界面功能

1. 选择 CAN 设备类型：USBCANFD-200U / USBCAN-II+
2. 设置设备索引、通道索引、波特率
3. 连接/断开 CAN
4. 输入位置1/位置2产品编码
5. 选择位置1/位置2动态通道
6. 开始/停止动态检测
7. 显示所有动态检测项明细
8. 保存动态 CSV
9. 打开手动动态测试窗口

## 注意

1. 如果现场使用标准帧，把“扩展帧”取消勾选。
2. 当前默认使用 0x110->0x201 和 0x112->0x301。
3. 如果使用 0x114->0x401 和 0x116->0x501，在界面下拉框切换即可。
4. 手动动态窗口共用主界面的 DynamicTestController，所以必须先在主界面连接 CAN。
