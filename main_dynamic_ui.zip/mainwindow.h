#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>

#include "dynamic_result_types.h"
#include "dynamic_protocol.h"
#include "zlg_can_device.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class DynamicTestController;
class ManualDynamicTestWindow;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void onConnectCanClicked();
    void onDisconnectCanClicked();

    void onStartDynamicClicked();
    void onStopDynamicClicked();

    void onSaveDynamicCsvClicked();
    void onClearDynamicClicked();

    void onOpenManualDynamicClicked();

    void onCanConnectedChanged(bool connected);

    void onDynamicProductProgressChanged(int productId,
                                         int progress,
                                         int groupCnt);

    void onDynamicProductFrameUpdated(int productId,
                                      int seq,
                                      int value,
                                      int groupCnt);

    void onDynamicProductFinished(DynamicProductResult result);

    void onDynamicAllFinished(bool allPass,
                              QVector<DynamicProductResult> results);

    void appendLog(const QString &message);

private:
    void initUi();
    void initCanDeviceTypeCombo();
    void initChannelCombos();
    void initDynamicResultTable();
    void initConnections();

    ZlgCanOpenConfig currentCanConfig() const;
    DynamicProtocol::DynamicChannel currentChannel1() const;
    DynamicProtocol::DynamicChannel currentChannel2() const;

    bool validateProductCodes(QString *productCode1,
                              QString *productCode2) const;

    void setCanUiState(bool connected);
    void setDynamicRunningState(bool running);

    void displayProductResult(const DynamicProductResult &result);
    void addDynamicResultRow(const DynamicProductResult &product,
                             const DynamicItemResult &item);

    void clearDynamicResultTable();

    QString defaultResultDir() const;

    QString canIdText(quint32 canId) const;
    QString passText(bool pass) const;

private:
    Ui::MainWindow *ui = nullptr;

    DynamicTestController *m_dynamicController = nullptr;
    ManualDynamicTestWindow *m_manualDynamicWindow = nullptr;

    QVector<DynamicProductResult> m_lastDynamicResults;

    bool m_canConnected = false;
    bool m_dynamicRunning = false;
};

#endif // MAINWINDOW_H
