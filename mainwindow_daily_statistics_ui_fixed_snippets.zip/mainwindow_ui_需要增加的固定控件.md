# mainwindow.ui 固定控件建议

## 1. 当日计数区域

建议在主界面状态/结果区域加一个 QGroupBox，标题：

```text
当日统计
```

内部用 QGridLayout，放 7 个标题 QLabel + 7 个数值 QLabel。

数值 QLabel 的 objectName 必须如下：

```text
lblDailyTotalCount
lblDailyPassCount
lblDailyNgCount
lblDailyStaticPassCount
lblDailyStaticNgCount
lblDailyDynamicPassCount
lblDailyDynamicNgCount
```

推荐显示：

```text
总测试数：        lblDailyTotalCount
PASS数量：       lblDailyPassCount
NG数量：         lblDailyNgCount
阻容PASS数量：   lblDailyStaticPassCount
阻容NG数量：     lblDailyStaticNgCount
动态PASS数量：   lblDailyDynamicPassCount
动态NG数量：     lblDailyDynamicNgCount
```

这些 QLabel 初始 text 都设为：

```text
0
```

## 2. 接插件插拔次数放进度条下面

把已有的：

```text
lblConnectorPlugCount
```

移动到：

```text
progressTest
```

下面一行。

推荐结构：

```text
当前测试：xxx
progressTest
lblConnectorPlugCount
测试时长：xxx
```

如果你当前 UI 里 `lblConnectorPlugCount` 已经存在，只移动位置，不要新建同名控件。

## 3. 三个按钮高度

把这三个按钮放在同一行，或放到一个 QGridLayout 中，并让它们跨 2 行：

```text
btnStartAutoTest
btnStopTest
btnEmergencyStop
```

推荐属性：

```text
minimumHeight = 78
maximumHeight = 16777215
sizePolicy verticalPolicy = Expanding
```

如果 Qt Creator 里拖不动，就不用在 Designer 里调，直接在代码里调用：

```cpp
setupProductionButtonGeometry();
```

函数代码见 cpp 片段。

## 4. 如果你想直接改 .ui XML，三个按钮可设置这些属性

```xml
<property name="minimumSize">
 <size>
  <width>130</width>
  <height>78</height>
 </size>
</property>
<property name="sizePolicy">
 <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
  <horstretch>0</horstretch>
  <verstretch>0</verstretch>
 </sizepolicy>
</property>
```
