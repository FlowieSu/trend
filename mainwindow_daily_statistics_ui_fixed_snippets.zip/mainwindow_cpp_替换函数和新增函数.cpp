// mainwindow.cpp 需要合并的片段

// 1. 头文件确认
#include "daily_test_statistics.h"

#include <QGridLayout>
#include <QPushButton>
#include <QSizePolicy>
#include <QSet>

// ============================================================================
// 2. initProductionStatusUi() 里替换旧 initDailyCounterUi()
// ============================================================================

void MainWindow::initProductionStatusUi()
{
    /*
     * 你原来的隐藏调试控件逻辑保留。
     * 下面只列出和计数、按钮、接插件相关的关键改动。
     */

    ui->editProductCode1->setMaxLength(18);
    ui->editProductCode2->setMaxLength(18);
    ui->editProductCode1->setFocus();

    ui->progressTest->setRange(0, 100);
    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：待机");

    QSettings settings("ECPS", "StaticDynamicTester");
    m_connectorPlugCount =
            settings.value("runtime/connectorPlugCount", 0).toInt();

    ui->lblConnectorPlugCount->setText(
                QString("接插件插拔次数：%1").arg(m_connectorPlugCount));

    ui->lblTestDuration->setText("测试时长：00:00:00");

    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");

    /*
     * 新逻辑：
     * 不再运行时 new QLabel；
     * 直接刷新 ui 里写死的 lblDailyXXX。
     */
    initDailyStatisticsUi();

    /*
     * 三个量产按钮高度调整：
     * 开始自动化、停止测试、紧急关闭伺服。
     */
    setupProductionButtonGeometry();

    ui->btnEmergencyStop->setStyleSheet(
        "QPushButton {"
        "background-color:#D32F2F;"
        "color:white;"
        "font-weight:bold;"
        "font-size:18px;"
        "border-radius:6px;"
        "padding:8px 16px;"
        "}"
        "QPushButton:pressed { background-color:#B71C1C; }"
    );
}

// ============================================================================
// 3. 新的当日统计 UI 初始化/刷新
// ============================================================================

void MainWindow::initDailyStatisticsUi()
{
    /*
     * DailyTestStatistics 内部按条码保存当天最后一次自动化测试结果。
     * 如果你的 DailyTestStatistics::loadToday() 已经实现了从文件恢复，
     * 启动软件后会恢复当天统计。
     */
    m_dailyStatistics.loadToday();

    refreshDailyStatisticsUi();
}

void MainWindow::refreshDailyStatisticsUi()
{
    const DailyTestSummary s = m_dailyStatistics.summary();

    ui->lblDailyTotalCount->setText(QString::number(s.totalCount));
    ui->lblDailyPassCount->setText(QString::number(s.passCount));
    ui->lblDailyNgCount->setText(QString::number(s.ngCount));

    ui->lblDailyStaticPassCount->setText(QString::number(s.staticPassCount));
    ui->lblDailyStaticNgCount->setText(QString::number(s.staticNgCount));

    ui->lblDailyDynamicPassCount->setText(QString::number(s.dynamicPassCount));
    ui->lblDailyDynamicNgCount->setText(QString::number(s.dynamicNgCount));
}

// ============================================================================
// 4. 三个按钮高度调整
// ============================================================================

void MainWindow::setupProductionButtonGeometry()
{
    /*
     * Qt Designer 里如果被 layout 控制，手动拖大小不会生效。
     * 这里直接通过 layout + sizePolicy 固定生产按钮高度。
     *
     * 高度 78 通常可以做到：
     * 上沿接近位置1产品编码框；
     * 下沿接近位置2产品编码框。
     * 如果你的界面行距更大，可以改成 82 / 86。
     */
    constexpr int productionButtonHeight = 78;

    QList<QPushButton *> buttons;
    buttons << ui->btnStartAutoTest
            << ui->btnStopTest
            << ui->btnEmergencyStop;

    for (QPushButton *button : buttons) {
        if (!button) {
            continue;
        }

        button->setMinimumHeight(productionButtonHeight);
        button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    }

    /*
     * 如果 groupControl 使用 QGridLayout，则把三个按钮重新排成一行，并跨两行。
     * 这样视觉上会和位置1/位置2两个编码框的总高度对齐。
     */
    QGridLayout *grid = qobject_cast<QGridLayout *>(ui->groupControl->layout());

    if (grid) {
        grid->removeWidget(ui->btnStartAutoTest);
        grid->removeWidget(ui->btnStopTest);
        grid->removeWidget(ui->btnEmergencyStop);

        grid->addWidget(ui->btnStartAutoTest, 0, 0, 2, 1);
        grid->addWidget(ui->btnStopTest, 0, 1, 2, 1);
        grid->addWidget(ui->btnEmergencyStop, 0, 2, 2, 1);

        grid->setColumnStretch(0, 1);
        grid->setColumnStretch(1, 1);
        grid->setColumnStretch(2, 1);

        grid->setRowStretch(0, 1);
        grid->setRowStretch(1, 1);
    }
}

// ============================================================================
// 5. 开始自动化测试时清空本轮缓存
// ============================================================================

// 在 MainWindow::onStartAutoTest() 中，成功 validateProductCodes() 之后，
// 启动阻容测试前加入：

/*
m_currentAutoStaticPassMap.clear();
m_currentAutoDynamicPassMap.clear();
*/

// 接插件插拔次数仍然只在自动化测试开始时 +1：
/*
++m_connectorPlugCount;

QSettings settings("ECPS", "StaticDynamicTester");
settings.setValue("runtime/connectorPlugCount", m_connectorPlugCount);

ui->lblConnectorPlugCount->setText(
            QString("接插件插拔次数：%1").arg(m_connectorPlugCount));
*/

// ============================================================================
// 6. 阻容明细回来时，按条码缓存本轮阻容结果
// ============================================================================

// 在 MainWindow::onStaticTestResultReady(const StaticTestResult &result)
// 的末尾追加：

void MainWindow::onStaticTestResultReady_AppendOnlySnippet(const StaticTestResult &result)
{
    if (!m_autoTesting) {
        return;
    }

    QString code = result.productCode.trimmed();

    if (code.isEmpty()) {
        if (result.position == 1) {
            code = m_productCode1.trimmed();
        } else if (result.position == 2) {
            code = m_productCode2.trimmed();
        }
    }

    if (code.isEmpty()) {
        return;
    }

    if (!m_currentAutoStaticPassMap.contains(code)) {
        m_currentAutoStaticPassMap.insert(code, true);
    }

    /*
     * 一个产品有多个阻容测试项。
     * 只要其中任意一项 NG，该产品本轮阻容结果就是 NG。
     */
    m_currentAutoStaticPassMap[code] =
            m_currentAutoStaticPassMap.value(code, true) && result.pass;
}

// 注意：上面函数名带 _AppendOnlySnippet，不能直接作为槽函数。
// 你要把函数体里的内容粘到真实的 onStaticTestResultReady() 末尾。

// ============================================================================
// 7. 按条码获取本轮阻容结果
// ============================================================================

bool MainWindow::staticPassForProductCode(const QString &productCode) const
{
    const QString code = productCode.trimmed();

    if (code.isEmpty()) {
        return false;
    }

    return m_currentAutoStaticPassMap.value(code, false);
}

// ============================================================================
// 8. 动态结束后统一更新 DailyTestStatistics
// ============================================================================

void MainWindow::updateDailyStatisticsAfterAutoTest(const QVector<DynamicProductResult> &results)
{
    /*
     * 只统计自动化测试。
     * 手动阻容测试、手动动态测试不会走 m_autoTesting=true 的自动化收尾链路。
     */
    if (!m_autoTesting || m_stopRequested) {
        return;
    }

    m_currentAutoDynamicPassMap.clear();

    for (const DynamicProductResult &dynamicResult : results) {
        const QString code = dynamicResult.productCode.trimmed();

        if (code.isEmpty()) {
            continue;
        }

        /*
         * finished=false 多半是中断/超时/异常结果。
         * 这里按动态 NG 记录。
         * 如果你希望超时/中断完全不统计，把下一行改成：
         * if (!dynamicResult.finished) continue;
         */
        m_currentAutoDynamicPassMap[code] =
                dynamicResult.finished && dynamicResult.pass;
    }

    const QDateTime now = QDateTime::currentDateTime();

    auto updateOneCode = [&](const QString &productCode) {
        const QString code = productCode.trimmed();

        if (code.isEmpty()) {
            return;
        }

        const bool staticPass = m_currentAutoStaticPassMap.value(code, false);
        const bool dynamicPass = m_currentAutoDynamicPassMap.value(code, false);

        /*
         * DailyTestStatistics 内部必须以 productCode 为 key 覆盖旧记录。
         * 这样同一条码多次 NG 只算 1 次；
         * 最后一次 PASS 会覆盖前面的 NG，实现 NG-1、PASS+1。
         */
        m_dailyStatistics.updateProduct(code,
                                        staticPass,
                                        dynamicPass,
                                        now);
    };

    updateOneCode(m_productCode1);

    /*
     * 单圈模式下 m_productCode2 为空，或者 m_singleProductMode=true。
     * 如果你的变量名不同，把这里改成你的变量名。
     */
    if (!m_singleProductMode) {
        updateOneCode(m_productCode2);
    }

    QString error;
    if (!m_dailyStatistics.save(&error)) {
        appendLog(QString("当日测试统计保存失败：%1").arg(error));
    } else {
        appendLog(QString("当日测试统计已保存：%1")
                  .arg(m_dailyStatistics.todayFilePath()));
    }

    refreshDailyStatisticsUi();
}

// ============================================================================
// 9. onDynamicAllFinished() 中替换旧计数函数调用
// ============================================================================

// 找到旧代码：
/*
if (m_autoTesting && !m_stopRequested) {
    updateDailyCountersAfterAutoTest(m_dynamicResults);
}
*/

// 改成：
/*
if (m_autoTesting && !m_stopRequested) {
    updateDailyStatisticsAfterAutoTest(m_dynamicResults);
}
*/

// ============================================================================
// 10. 删除旧函数
// ============================================================================

// 删除或不再使用以下函数：
//
// initDailyCounterUi()
// loadDailyCounters()
// saveDailyCounters() const
// resetDailyCountersForToday()
// checkDailyCounterDate()
// refreshDailyCounterLabel()
// updateDailyCountersAfterAutoTest(...)
