# 主界面计数写死到 UI + 按条码去重统计 + 按钮高度调整补丁说明

适用前提：
- 你已经把 DailyTestStatistics 类加入工程，包括 .h / .cpp。
- 当前 mainwindow.cpp 基于 daily_counter_overall_label_manual_standard_patch，并已经加入单圈/双圈逻辑。
- 本包不直接覆盖你的 mainwindow.cpp，因为你已经在本地加了单圈逻辑；这里给的是需要合并的函数和片段。

## 目标

1. 不再运行时 new QLabel 动态生成当日计数；
2. 当日计数改成写死在 mainwindow.ui 里的 QLabel；
3. 计数规则改为按产品编码唯一性去重；
4. 手动阻容/手动动态不参与计数；
5. 接插件插拔次数放在进度条下面；
6. “开始自动化测试 / 停止测试 / 紧急关闭伺服”三按钮高度拉高，上沿对齐位置1编码框，下沿对齐位置2编码框。

## 需要你在 mainwindow.ui 中增加/确认的对象名

计数 QLabel：

```text
lblDailyTotalCount
lblDailyPassCount
lblDailyNgCount
lblDailyStaticPassCount
lblDailyStaticNgCount
lblDailyDynamicPassCount
lblDailyDynamicNgCount
```

接插件插拔次数 QLabel：

```text
lblConnectorPlugCount
```

按钮：

```text
btnStartAutoTest
btnStopTest
btnEmergencyStop
```

进度条：

```text
progressTest
```

## 合并顺序

1. 先按 `mainwindow_ui_需要增加的固定控件.md` 在 UI 中添加固定 QLabel；
2. 修改 mainwindow.h，参考 `mainwindow_h_修改片段.txt`；
3. 修改 mainwindow.cpp，参考 `mainwindow_cpp_替换函数和新增函数.cpp`；
4. 删除旧的动态计数 QLabel 相关函数和成员；
5. 重新 qmake、清理、构建。
