# 完整 mainwindow.ui

这个文件已把计数显示固定写入 UI，不需要再在 mainwindow.cpp 里动态 new QLabel。

## 已包含的固定控件

当日统计 QLabel：

- lblDailyTotalCount
- lblDailyPassCount
- lblDailyNgCount
- lblDailyStaticPassCount
- lblDailyStaticNgCount
- lblDailyDynamicPassCount
- lblDailyDynamicNgCount

接插件插拔次数：

- lblConnectorPlugCount

并且 `lblConnectorPlugCount` 已放在进度条 `progressTest` 下方。

## 三个按钮布局

以下按钮已在 UI 的 `gridProduct` 里直接设置为跨两行：

- btnStartAutoTest
- btnStopTest
- btnEmergencyStop

对应 XML 结构为：

```xml
<item row="0" column="4" rowspan="2">
<item row="0" column="5" rowspan="2">
<item row="0" column="6" rowspan="2">
```

并设置了 `minimumSize.height = 78`，不需要再写 `setupProductionButtonGeometry()` 这种运行时调整函数。

## mainwindow.cpp 里应保留/新增的函数

保留或新增：

- initDailyStatisticsUi()
- refreshDailyStatisticsUi()
- updateDailyStatisticsAfterAutoTest(...)
- staticPassForProductCode(...)

删除或不再调用：

- initDailyCounterUi()
- loadDailyCounters()
- saveDailyCounters()
- resetDailyCountersForToday()
- checkDailyCounterDate()
- refreshDailyCounterLabel()
- updateDailyCountersAfterAutoTest(...)
- setupProductionButtonGeometry()

## 使用方式

1. 用本文件覆盖工程中的 `mainwindow.ui`
2. 重新运行 qmake
3. 清理项目
4. 重新构建

如果编译提示某个 `ui->xxx` 找不到，说明你的 mainwindow.cpp 里还有额外控件名没有同步到 UI，把报错的控件名发出来即可继续补。
