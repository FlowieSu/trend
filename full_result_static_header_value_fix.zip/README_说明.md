# 自动化完整结果 CSV：阻容列名改为具体测试项

基于上一版 `daily_xls_ascii_entity_fix` 生成。

## 本次修改

自动化测试完整结果 CSV 的阻容部分改为：

```text
具体测试项列 -> 当前测试值
具体测试项标准列 -> INI 的 standardText
```

不再输出：

```text
阻容测试项1
阻容测试值1
阻容测试标准1
```

## 示例

之前：

```text
阻容测试项1              阻容测试值1    阻容测试标准1
sin+->sin-（红黑）电阻    300 kΩ        INI里的standardText
```

现在：

```text
sin+->sin- 电阻      sin+->sin- 电阻标准
300 kΩ              INI里的standardText
```

电容同理：

```text
sin+->sin- 电容      sin+->sin- 电容标准
6 nF                INI里的standardText
```

并且列名不再显示：

```text
红黑
黑红
```

## 修改文件

真正修改的是：

```text
modified_files/mainwindow.cpp
modified_files/mainwindow.h
```

补丁包里保留其它文件，方便整包覆盖。

## 使用方式

1. 用 `modified_files` 覆盖工程同名文件；
2. 重新 qmake；
3. 清理项目；
4. 重新构建。
