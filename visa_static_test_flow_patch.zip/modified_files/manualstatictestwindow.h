#ifndef MANUALSTATICTESTWINDOW_H
#define MANUALSTATICTESTWINDOW_H

#include <QWidget>
#include <QString>
#include <QVector>

namespace Ui {
class ManualStaticTestWindow;
}

class MitsubishiPLC;
class SCPIController;
class QCloseEvent;

/*
 * ManualStaticTestWindow
 *
 * 手动阻容测试窗口。
 *
 * 功能：
 * 1. 手动选择测试位置：位置1 / 位置2；
 * 2. 手动选择测试项；
 * 3. 手动选择测试方向：红黑 / 黑红；
 * 4. 按既有 PLC M 点映射接通测试通道；
 * 5. 手动测电阻、测电容；
 * 6. 复位阻容通道；
 * 7. 窗口打开、关闭时均保证：
 *    Y27 OFF，Y26 OFF，M19 OFF，M100 脉冲复位。
 *
 * 当前点位约定：
 * M19  ：阻容测试总使能
 * M20  ：测试位置选择，OFF=位置1，ON=位置2
 * M100 ：阻容测试通道复位脉冲
 * Y26  ：测试线路切换，OFF=阻容测试线路，ON=动态测试线路
 * Y27  ：伺服电机控制，OFF=伺服关闭，ON=伺服打开
 */
class ManualStaticTestWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ManualStaticTestWindow(MitsubishiPLC *plc,
                                    SCPIController *dmm,
                                    QWidget *parent = nullptr);
    ~ManualStaticTestWindow() override;

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onApplyChannel();
    void onMeasureResistance();
    void onMeasureCapacitance();
    void onResetChannel();
    void onClearLog();
    void onCloseClicked();
    void onSelectionChanged();

private:
    struct DirectionConfig
    {
        QString name;
        QVector<int> mPoints;
    };

    struct TestItem
    {
        QString name;
        DirectionConfig redBlack;
        DirectionConfig blackRed;
        bool hasBlackRed = true;
    };

private:
    void initUiState();
    void initConnections();
    void initTestItems();
    void initResultTable();

    bool checkReady();
    bool prepareStaticMode();
    bool resetStaticChannels();
    bool applySelectedChannel();

    bool setDynamicMode(bool on);   // Y26
    bool setServoPower(bool on);    // Y27

    int selectedPosition() const;
    int selectedTestIndex() const;
    DirectionConfig selectedDirection() const;

    QString positionText(int position) const;
    QString mPointsText(const QVector<int> &mPoints) const;
    QString formatValue(double value, int precision = 6) const;

    void appendResultRow(const QString &measureType,
                         double displayValue,
                         const QString &unit,
                         const QString &message);

    void appendLog(const QString &message);
    void setChannelReady(bool ready);

private:
    Ui::ManualStaticTestWindow *ui = nullptr;

    MitsubishiPLC *m_plc = nullptr;
    SCPIController *m_dmm = nullptr;

    QVector<TestItem> m_testItems;
    bool m_channelReady = false;
};

#endif // MANUALSTATICTESTWINDOW_H
