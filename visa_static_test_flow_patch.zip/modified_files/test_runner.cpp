#include "test_runner.h"

#include "mitsubishi_plc.h"
#include "scpi_controller.h"
#include "static_test_standard_config.h"

#include <QDateTime>
#include <QThread>
#include <QStringList>
#include <QtGlobal>

#include <cmath>

namespace
{
constexpr int M_RES_CAP_ENABLE = 19;
constexpr int M_POSITION_SELECT = 20;
constexpr int M_RESET_CHANNEL = 100;

constexpr int STATIC_RESET_DELAY_MS = 150;
constexpr int RELAY_ACTION_DELAY_MS = 50;
constexpr int RELAY_STABLE_DELAY_MS = 500;
constexpr int TEST_INTERVAL_MS = 100;

constexpr int RESISTANCE_TIMEOUT_MS = 10000;
constexpr int CAPACITANCE_TIMEOUT_MS = 10000;
}

TestRunner::TestRunner(MitsubishiPLC *plc,
                       SCPIController *dmm,
                       QObject *parent)
    : QObject(parent),
      m_plc(plc),
      m_dmm(dmm)
{
    qRegisterMetaType<StaticTestResult>("StaticTestResult");
    initTestItems();
}

void TestRunner::requestInterrupt()
{
    m_interrupted.store(true);
}

bool TestRunner::checkInterrupted() const
{
    return m_interrupted.load();
}

void TestRunner::runStaticTests(int position,
                                QList<int> selectedIndices)
{
    runStaticTestsForProduct(position,
                             QString(),
                             selectedIndices);
}

void TestRunner::runStaticTestsForProduct(int position,
                                          const QString &productCode,
                                          QList<int> selectedIndices)
{
    m_interrupted.store(false);

    bool hasFailed = false;

    emit logMessage(QString("开始单产品阻容测试：%1，产品编码=%2。")
                    .arg(positionText(position))
                    .arg(productCode.isEmpty() ? "-" : productCode));

    if (!m_plc) {
        emit logMessage("PLC 对象为空，无法执行阻容测试。");
        emit allStaticTestsFinished(false, true);
        return;
    }

    if (!m_dmm) {
        emit logMessage("万用表/电桥对象为空，无法执行阻容测试。");
        emit allStaticTestsFinished(false, true);
        return;
    }

    const bool completed = runOneProduct(position,
                                         productCode,
                                         normalizeIndices(selectedIndices),
                                         hasFailed);

    if (!completed && checkInterrupted()) {
        emit allStaticTestsFinished(true, hasFailed);
        return;
    }

    emit allStaticTestsFinished(false, hasFailed);
}

void TestRunner::runStaticTestsForTwoProducts(const QString &productCode1,
                                              const QString &productCode2,
                                              QList<int> selectedIndices)
{
    m_interrupted.store(false);

    bool hasFailed = false;

    emit logMessage("开始双产品阻容自动测试。");
    emit logMessage(QString("位置1产品编码：%1").arg(productCode1));
    emit logMessage(QString("位置2产品编码：%1").arg(productCode2));

    if (!m_plc) {
        emit logMessage("PLC 对象为空，无法执行双产品阻容测试。");
        emit allStaticTestsFinished(false, true);
        return;
    }

    if (!m_dmm) {
        emit logMessage("万用表/电桥对象为空，无法执行双产品阻容测试。");
        emit allStaticTestsFinished(false, true);
        return;
    }

    const QList<int> indices = normalizeIndices(selectedIndices);

    if (!runOneProduct(1, productCode1, indices, hasFailed)) {
        emit allStaticTestsFinished(checkInterrupted(), true);
        return;
    }

    if (!runOneProduct(2, productCode2, indices, hasFailed)) {
        emit allStaticTestsFinished(checkInterrupted(), true);
        return;
    }

    QString resetError;
    if (!resetStaticChannels(&resetError)) {
        emit logMessage(QString("双产品阻容测试结束后复位失败：%1").arg(resetError));
        hasFailed = true;
    }

    emit logMessage("双产品阻容自动测试完成。");
    emit allStaticTestsFinished(false, hasFailed);
}

bool TestRunner::runOneProduct(int position,
                               const QString &productCode,
                               const QList<int> &selectedIndices,
                               bool &hasFailed)
{
    if (checkInterrupted()) {
        emit logMessage("检测到中断请求，停止阻容测试。");
        return false;
    }

    emit logMessage(QString("开始%1阻容测试，产品编码=%2。")
                    .arg(positionText(position))
                    .arg(productCode.isEmpty() ? "-" : productCode));

    for (int index : selectedIndices) {
        if (checkInterrupted()) {
            emit logMessage("检测到中断请求，停止后续阻容测试。");
            return false;
        }

        if (index < 0 || index >= m_testItems.size()) {
            emit logMessage(QString("测试项下标越界：%1，已跳过。").arg(index));
            hasFailed = true;
            continue;
        }

        const LogicalTestItem &item = m_testItems[index];

        if (!executeOneLogicalItem(position, productCode, item, hasFailed)) {
            if (checkInterrupted()) {
                return false;
            }

            /*
             * 单项测试执行失败不阻塞后续测试，按 NG 继续。
             */
            hasFailed = true;
        }

        if (!sleepWithInterruptCheck(TEST_INTERVAL_MS)) {
            emit logMessage("测试间隔等待时收到中断请求。");
            return false;
        }
    }

    QString resetError;
    if (!resetStaticChannels(&resetError)) {
        emit logMessage(QString("%1阻容测试结束后复位失败：%2")
                        .arg(positionText(position))
                        .arg(resetError));
        hasFailed = true;
    }

    emit logMessage(QString("%1阻容测试完成。").arg(positionText(position)));
    return true;
}

bool TestRunner::executeOneLogicalItem(int position,
                                       const QString &productCode,
                                       const LogicalTestItem &item,
                                       bool &hasFailed)
{
    emit testStarted(QString("%1 - %2").arg(positionText(position), item.name));

    emit logMessage(QString("开始测试项：%1，%2。")
                    .arg(positionText(position))
                    .arg(item.name));

    const DirectionMeasureResult redBlackResult = executeDirection(position,
                                                                   productCode,
                                                                   item,
                                                                   item.redBlack);

    emitDirectionResult(productCode,
                        position,
                        item,
                        item.redBlack,
                        redBlackResult);

    if (checkInterrupted()) {
        return false;
    }

    DirectionMeasureResult blackRedResult;
    bool blackRedExecuted = false;

    if (item.hasBlackRed) {
        blackRedResult = executeDirection(position,
                                          productCode,
                                          item,
                                          item.blackRed);

        blackRedExecuted = true;

        emitDirectionResult(productCode,
                            position,
                            item,
                            item.blackRed,
                            blackRedResult);
    }

    if (checkInterrupted()) {
        return false;
    }

    const bool forwardPass = redBlackResult.pass;
    const bool reversePass = item.hasBlackRed ? blackRedResult.pass : true;
    const bool pass = forwardPass && reversePass;

    if (!pass) {
        hasFailed = true;
    }

    QStringList messages;

    if (!redBlackResult.pass) {
        messages << QString("红黑:%1").arg(redBlackResult.message);
    }

    if (item.hasBlackRed && !blackRedResult.pass) {
        messages << QString("黑红:%1").arg(blackRedResult.message);
    }

    const QString message = messages.isEmpty() ? "OK" : messages.join("; ");

    /*
     * 兼容 MainWindow 现有 9 参数结果槽。
     */
    emit testCompleted(item.name,
                       position,
                       item.standard.text,
                       redBlackResult.resistanceKOhm,
                       blackRedExecuted ? blackRedResult.resistanceKOhm : -1.0,
                       redBlackResult.capacitanceNf,
                       blackRedExecuted ? blackRedResult.capacitanceNf : -1.0,
                       pass,
                       message);

    emit logMessage(QString("测试项完成：%1，%2，结果=%3，%4。")
                    .arg(positionText(position))
                    .arg(item.name)
                    .arg(passText(pass))
                    .arg(message));

    return true;
}

TestRunner::DirectionMeasureResult TestRunner::executeDirection(int position,
                                                                const QString &productCode,
                                                                const LogicalTestItem &item,
                                                                const DirectionConfig &direction)
{
    Q_UNUSED(productCode)

    DirectionMeasureResult result;

    QString error;

    if (!prepareDirection(position, direction, &error)) {
        result.message = error;
        return result;
    }

    emit logMessage(QString("继电器通道已接通，等待%1 ms稳定。")
                    .arg(RELAY_STABLE_DELAY_MS));

    if (!sleepWithInterruptCheck(RELAY_STABLE_DELAY_MS)) {
        result.message = "继电器稳定等待过程中断";
        return result;
    }

    emit logMessage(QString("开始测量：%1，%2，%3。")
                    .arg(positionText(position))
                    .arg(item.name)
                    .arg(direction.name));

    if (item.standard.enableResistance) {
        if (!measureResistance(result.resistanceKOhm, error)) {
            result.message = QString("电阻测量失败：%1").arg(error);
            return result;
        }

        if (checkInterrupted()) {
            result.message = "电阻测量后收到中断请求";
            return result;
        }
    } else {
        /*
         * 例如 5V -> GND：
         * 不进行电阻测量，也不参与电阻判定。
         * 结果中电阻值保留 -1.0，CSV/界面通常显示为 "-"。
         */
        result.resistanceKOhm = -1.0;
    }

    if (item.standard.enableCapacitance) {
        if (!measureCapacitance(result.capacitanceNf, error)) {
            result.message = QString("电容测量失败：%1").arg(error);
            return result;
        }

        if (checkInterrupted()) {
            result.message = "电容测量后收到中断请求";
            return result;
        }
    } else {
        result.capacitanceNf = -1.0;
    }

    result.measureOk = true;

    result.resistancePass = item.standard.enableResistance
            ? isValueInRange(result.resistanceKOhm,
                             item.standard.resistanceMinKOhm,
                             item.standard.resistanceMaxKOhm)
            : true;

    result.capacitancePass = item.standard.enableCapacitance
            ? isValueInRange(result.capacitanceNf,
                             item.standard.capacitanceMinNf,
                             item.standard.capacitanceMaxNf)
            : true;

    result.pass = result.measureOk &&
                  result.resistancePass &&
                  result.capacitancePass;

    QStringList messages;

    if (item.standard.enableResistance && !result.resistancePass) {
        messages << "电阻NG";
    }

    if (item.standard.enableCapacitance && !result.capacitancePass) {
        messages << "电容NG";
    }

    result.message = messages.isEmpty() ? "OK" : messages.join("; ");

    const QString resistanceText = item.standard.enableResistance
            ? QString::number(result.resistanceKOhm, 'f', 6)
            : QString("不测试");

    const QString capacitanceText = item.standard.enableCapacitance
            ? QString::number(result.capacitanceNf, 'f', 6)
            : QString("不测试");

    emit logMessage(QString("测量完成：%1，%2，%3，电阻=%4 kOhm，电容=%5 nF，结果=%6。")
                    .arg(positionText(position))
                    .arg(item.name)
                    .arg(direction.name)
                    .arg(resistanceText)
                    .arg(capacitanceText)
                    .arg(passText(result.pass)));

    return result;
}

bool TestRunner::prepareDirection(int position,
                                  const DirectionConfig &direction,
                                  QString *errorMessage)
{
    if (checkInterrupted()) {
        if (errorMessage) {
            *errorMessage = "用户中断";
        }
        return false;
    }

    if (!m_plc) {
        if (errorMessage) {
            *errorMessage = "PLC对象为空";
        }
        return false;
    }

    if (!resetStaticChannels(errorMessage)) {
        return false;
    }

    /*
     * M20 选择测试位置：
     * OFF = 位置1
     * ON  = 位置2
     */
    if (!m_plc->setMRelay(M_POSITION_SELECT, position == 2)) {
        if (errorMessage) {
            *errorMessage = QString("M20 设置测试位置失败：%1").arg(m_plc->lastError());
        }
        return false;
    }

    if (!sleepWithInterruptCheck(RELAY_ACTION_DELAY_MS)) {
        if (errorMessage) {
            *errorMessage = "位置切换等待过程中断";
        }
        return false;
    }

    /*
     * 先设置 M0~M12 具体通道，最后再打开 M19 总使能。
     */
    for (int mNumber : direction.mPoints) {
        if (!m_plc->setMRelay(mNumber, true)) {
            if (errorMessage) {
                *errorMessage = QString("M%1 ON 失败：%2")
                        .arg(mNumber)
                        .arg(m_plc->lastError());
            }
            return false;
        }

        if (!sleepWithInterruptCheck(RELAY_ACTION_DELAY_MS)) {
            if (errorMessage) {
                *errorMessage = QString("M%1 动作等待过程中断").arg(mNumber);
            }
            return false;
        }
    }

    if (!m_plc->setMRelay(M_RES_CAP_ENABLE, true)) {
        if (errorMessage) {
            *errorMessage = QString("M19 ON 失败：%1").arg(m_plc->lastError());
        }
        return false;
    }

    return true;
}

bool TestRunner::resetStaticChannels(QString *errorMessage)
{
    if (!m_plc) {
        if (errorMessage) {
            *errorMessage = "PLC对象为空";
        }
        return false;
    }

    if (!m_plc->setMRelay(M_RES_CAP_ENABLE, false)) {
        if (errorMessage) {
            *errorMessage = QString("M19 OFF 失败：%1").arg(m_plc->lastError());
        }
        return false;
    }

    if (!m_plc->pulseMRelay(M_RESET_CHANNEL, 100)) {
        if (errorMessage) {
            *errorMessage = QString("M100 脉冲复位失败：%1").arg(m_plc->lastError());
        }
        return false;
    }

    return sleepWithInterruptCheck(STATIC_RESET_DELAY_MS);
}

bool TestRunner::measureResistance(double &resistanceKOhm,
                                   QString &errorMessage)
{
    resistanceKOhm = -1.0;
    errorMessage.clear();

    if (!m_dmm) {
        errorMessage = "万用表/电桥对象为空";
        return false;
    }

    const double resistanceOhm = m_dmm->measureResistance(RESISTANCE_TIMEOUT_MS);

    if (resistanceOhm < 0.0 || !std::isfinite(resistanceOhm)) {
        errorMessage = "电阻返回值无效";
        return false;
    }

    /*
     * VISA READ? 电阻返回单位按 Ohm 处理，界面/CSV 使用 kOhm。
     */
    resistanceKOhm = resistanceOhm / 1000.0;

    emit logMessage(QString("电阻换算：原始=%1 Ohm，显示=%2 kOhm。")
                    .arg(resistanceOhm, 0, 'E', 8)
                    .arg(resistanceKOhm, 0, 'f', 6));

    return true;
}

bool TestRunner::measureCapacitance(double &capacitanceNf,
                                    QString &errorMessage)
{
    capacitanceNf = -1.0;
    errorMessage.clear();

    if (!m_dmm) {
        errorMessage = "万用表/电桥对象为空";
        return false;
    }

    const double capacitanceF = m_dmm->measureCapacitance(CAPACITANCE_TIMEOUT_MS);

    if (capacitanceF < 0.0 || !std::isfinite(capacitanceF)) {
        errorMessage = "电容返回值无效";
        return false;
    }

    /*
     * VISA READ? 电容返回单位按 F 处理，界面/CSV 使用 nF。
     */
    capacitanceNf = capacitanceF * 1000000000.0;

    emit logMessage(QString("电容换算：原始=%1 F，显示=%2 nF。")
                    .arg(capacitanceF, 0, 'E', 8)
                    .arg(capacitanceNf, 0, 'f', 6));

    return true;
}

void TestRunner::emitDirectionResult(const QString &productCode,
                                     int position,
                                     const LogicalTestItem &item,
                                     const DirectionConfig &direction,
                                     const DirectionMeasureResult &result)
{
    StaticTestResult output;

    output.productCode = productCode;
    output.position = position;
    output.testName = item.name;
    output.directionName = direction.name;
    output.mPointsText = mPointsText(direction.mPoints);
    output.standardText = item.standard.text;
    output.resistanceKOhm = result.resistanceKOhm;
    output.capacitanceNf = result.capacitanceNf;
    output.resistancePass = result.resistancePass;
    output.capacitancePass = result.capacitancePass;
    output.pass = result.pass;
    output.message = result.message;
    output.timestamp = timestampNow();

    emit staticTestResultReady(output);
}


void TestRunner::initTestItems()
{
    m_testItems.clear();

    /*
     * 修改位置：
     * 原来这里直接写死所有阻容测试项。
     * 现在先读取外部 INI：
     *   程序目录/config/test_standard.ini
     *
     * 读取成功：
     *   使用 INI 标准。
     *
     * 读取失败：
     *   使用 initDefaultTestItems() 中的原始写死标准，保证现有流程仍能跑。
     */
    QVector<StaticStandardItem> configItems;
    QString errorMessage;
    QString iniResolveMessage;

    const QString iniPath = StaticTestStandardConfig::resolvedIniFilePath(&iniResolveMessage);
    emit logMessage(iniResolveMessage);

    if (!iniPath.isEmpty() &&
            StaticTestStandardConfig::loadStaticItems(iniPath,
                                                      &configItems,
                                                      &errorMessage)) {
        for (const StaticStandardItem &item : configItems) {
            appendConfigItem(item);
        }

        emit logMessage(QString("阻容测试标准已从 INI 加载，共 %1 项，路径：%2。")
                        .arg(m_testItems.size())
                        .arg(iniPath));
        return;
    }

    emit logMessage(QString("阻容测试标准 INI 加载失败，使用内置默认标准：%1")
                    .arg(errorMessage));

    initDefaultTestItems();
}

void TestRunner::appendConfigItem(const StaticStandardItem &configItem)
{
    TestStandard standard;
    standard.resistanceMinKOhm = configItem.resistanceMinKOhm;
    standard.resistanceMaxKOhm = configItem.resistanceMaxKOhm;
    standard.capacitanceMinNf = configItem.capacitanceMinNf;
    standard.capacitanceMaxNf = configItem.capacitanceMaxNf;
    standard.text = configItem.standardText;
    standard.enableResistance = configItem.enableResistance;
    standard.enableCapacitance = configItem.enableCapacitance;

    LogicalTestItem item;
    item.name = configItem.name;
    item.standard = standard;
    item.redBlack = {"红黑", configItem.redBlackMPoints};
    item.blackRed = {"黑红", configItem.blackRedMPoints};
    item.hasBlackRed = configItem.hasBlackRed;

    m_testItems.append(item);
}

void TestRunner::initDefaultTestItems()
{
    m_testItems.clear();

    /*
     * 下面标准值是原始内置默认值。
     * 如果 config/test_standard.ini 不存在或格式错误，会自动回退到这里。
     *
     * 单位：
     * 电阻：kOhm
     * 电容：nF
     */
    TestStandard windingStandard;
    windingStandard.resistanceMinKOhm = 340.0;
    windingStandard.resistanceMaxKOhm = 390.0;
    windingStandard.capacitanceMinNf = 1.0;
    windingStandard.capacitanceMaxNf = 5.0;
    windingStandard.text = "阻值: 365±25 kOhm; 容值: 1.000~5.000 nF";

    TestStandard insulationStandard;
    insulationStandard.resistanceMinKOhm = 1000.0;
    insulationStandard.resistanceMaxKOhm = 999999.0;
    insulationStandard.capacitanceMinNf = 0.0;
    insulationStandard.capacitanceMaxNf = 10.0;
    insulationStandard.text = "阻值: >=1000.000 kOhm; 容值: 0.000~10.000 nF";

    m_testItems.append({
        "sin+ -> sin-",
        windingStandard,
        {"红黑", {3, 6}},
        {"黑红", {4, 5}},
        true
    });

    m_testItems.append({
        "cos+ -> cos-",
        windingStandard,
        {"红黑", {7, 12}},
        {"黑红", {10, 11}},
        true
    });

    m_testItems.append({
        "GND -> sin+",
        insulationStandard,
        {"红黑", {1, 4}},
        {"黑红", {2, 3}},
        true
    });

    m_testItems.append({
        "GND -> sin-",
        insulationStandard,
        {"红黑", {1, 6}},
        {"黑红", {2, 5}},
        true
    });

    m_testItems.append({
        "GND -> cos+",
        insulationStandard,
        {"红黑", {1, 10}},
        {"黑红", {2, 7}},
        true
    });

    m_testItems.append({
        "GND -> cos-",
        insulationStandard,
        {"红黑", {1, 12}},
        {"黑红", {2, 11}},
        true
    });

    /*
     * 5V -> GND 不需要进行电阻测试，只进行电容测试。
     * 红黑/黑红方向仍然共用同一个电容合格范围。
     */
    TestStandard fiveVoltGndStandard = windingStandard;
    fiveVoltGndStandard.enableResistance = false;
    fiveVoltGndStandard.enableCapacitance = true;
    fiveVoltGndStandard.resistanceMinKOhm = 0.0;
    fiveVoltGndStandard.resistanceMaxKOhm = 0.0;
    fiveVoltGndStandard.text = "阻值: 不测试; 容值: 1.000~5.000 nF";

    m_testItems.append({
        "5V -> GND",
        fiveVoltGndStandard,
        {"红黑", {0, 1}},
        {"黑红", {0, 2}},
        true
    });
}


bool TestRunner::isValueInRange(double value,
                                double minValue,
                                double maxValue) const
{
    if (value < 0.0 || !std::isfinite(value)) {
        return false;
    }

    return value >= minValue && value <= maxValue;
}

bool TestRunner::sleepWithInterruptCheck(int totalMs)
{
    int remaining = totalMs;

    while (remaining > 0) {
        if (checkInterrupted()) {
            return false;
        }

        const int step = qMin(remaining, 20);
        QThread::msleep(static_cast<unsigned long>(step));
        remaining -= step;
    }

    return !checkInterrupted();
}

QList<int> TestRunner::normalizeIndices(const QList<int> &selectedIndices) const
{
    if (!selectedIndices.isEmpty()) {
        return selectedIndices;
    }

    QList<int> all;

    for (int i = 0; i < m_testItems.size(); ++i) {
        all.append(i);
    }

    return all;
}

QString TestRunner::positionText(int position) const
{
    return position == 2 ? "位置2" : "位置1";
}

QString TestRunner::mPointsText(const QVector<int> &mPoints) const
{
    QStringList list;

    for (int mNumber : mPoints) {
        list << QString("M%1").arg(mNumber);
    }

    return list.join(" + ");
}

QString TestRunner::passText(bool pass) const
{
    return pass ? "PASS" : "NG";
}

QString TestRunner::timestampNow() const
{
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
}
