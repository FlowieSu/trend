#ifndef SCPI_CONTROLLER_H
#define SCPI_CONTROLLER_H

#include <QObject>
#include <QString>

#include <visa.h>

/*
 * SCPIController
 *
 * USB/VISA 版万用表/电桥 SCPI 控制类。
 *
 * 连接方式：
 *   用户界面输入 VISA 地址，例如：
 *     USB0::0x2A8D::0x1301::MYXXXXXXXX::INSTR
 *     USB0::0x0957::0xXXXX::XXXXXXXX::INSTR
 *
 * 本类不使用 TCP，不使用 QTcpSocket。
 */
class SCPIController : public QObject
{
    Q_OBJECT

public:
    explicit SCPIController(QObject *parent = nullptr);
    ~SCPIController() override;

    bool connectInstrument(const QString &visaAddress);
    void disconnectInstrument();

    bool isConnected() const;
    bool ping();

    /*
     * 返回单位：
     *   measureResistance()  : Ohm
     *   measureCapacitance() : F
     *
     * 上层 TestRunner / ManualStaticTestWindow 再换算成：
     *   Ohm -> kOhm
     *   F   -> nF
     */
    double measureResistance(int timeoutMs);
    double measureCapacitance(int timeoutMs);

    QString lastError() const;

signals:
    void logMessage(const QString &message);
    void connectedChanged(bool connected);

private:
    bool openVisaInstrument(const QString &address);

    bool sendCommand(const QString &command, int timeoutMs);
    bool query(const QString &command, QString *response, int timeoutMs);
    bool readResponse(QString *response, int timeoutMs);

    /*
     * 清空上一条查询残留响应，避免点击按钮后读到旧值。
     * 这里采用短超时 viRead 抽干输入缓存，不改变连接方式。
     */
    bool clearReadBuffer(int maxWaitMs = 50);

    /*
     * 流程：
     *   clearReadBuffer()
     *   CONF:RES / CONF:CAP
     *   QThread::msleep(settleDelayMs)
     *   READ?
     */
    bool configureMeasurementMode(const QString &command,
                                  int settleDelayMs,
                                  int timeoutMs);

    double parseDoubleResponse(const QString &response, bool *ok) const;

    bool setVisaTimeout(int timeoutMs);
    QString visaStatusText(ViStatus status) const;

    void setLastError(const QString &error);
    void clearLastError();

private:
    ViSession m_defaultRm = VI_NULL;
    ViSession m_instrument = VI_NULL;

    QString m_address;
    QString m_lastError;

    bool m_simulationMode = false;
};

#endif // SCPI_CONTROLLER_H
