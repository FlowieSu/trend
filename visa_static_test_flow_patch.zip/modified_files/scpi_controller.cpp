#include "scpi_controller.h"

#include <QByteArray>
#include <QRegularExpression>
#include <QThread>
#include <QtGlobal>

#include <cmath>

namespace
{
constexpr int VISA_OPEN_TIMEOUT_MS = 5000;
constexpr int VISA_DEFAULT_TIMEOUT_MS = 10000;
constexpr int SCPI_COMMAND_TIMEOUT_MS = 1000;
constexpr int SCPI_BUFFER_CLEAR_WAIT_MS = 50;

/*
 * 这里就是“电阻测 10s、电容测 10s”的位置。
 * 如果后续想改为 3s / 5s，只改这两个常量即可。
 */
constexpr int RESISTANCE_MODE_SETTLE_DELAY_MS = 10000;
constexpr int CAPACITANCE_MODE_SETTLE_DELAY_MS = 10000;

const char *SCPI_CONF_RESISTANCE = "CONF:RES";
const char *SCPI_CONF_CAPACITANCE = "CONF:CAP";
const char *SCPI_READ = "READ?";

inline bool isVisaError(ViStatus status)
{
    return status < VI_SUCCESS;
}
}

SCPIController::SCPIController(QObject *parent)
    : QObject(parent)
{
}

SCPIController::~SCPIController()
{
    disconnectInstrument();
}

bool SCPIController::connectInstrument(const QString &visaAddress)
{
    clearLastError();
    disconnectInstrument();

    m_address = visaAddress.trimmed();

    if (m_address.isEmpty()) {
        setLastError("万用表/电桥 VISA 地址为空。");
        return false;
    }

    if (m_address.compare("SIM", Qt::CaseInsensitive) == 0 ||
            m_address.compare("DEMO", Qt::CaseInsensitive) == 0) {
        m_simulationMode = true;
        emit logMessage("SCPI 仿真模式已连接。");
        emit connectedChanged(true);
        return true;
    }

    m_simulationMode = false;

    if (!openVisaInstrument(m_address)) {
        emit connectedChanged(false);
        return false;
    }

    emit connectedChanged(true);
    return true;
}

void SCPIController::disconnectInstrument()
{
    m_simulationMode = false;

    if (m_instrument != VI_NULL) {
        viClose(m_instrument);
        m_instrument = VI_NULL;
    }

    if (m_defaultRm != VI_NULL) {
        viClose(m_defaultRm);
        m_defaultRm = VI_NULL;
    }

    emit connectedChanged(false);
}

bool SCPIController::isConnected() const
{
    if (m_simulationMode) {
        return true;
    }

    return m_instrument != VI_NULL;
}

bool SCPIController::ping()
{
    clearLastError();

    if (m_simulationMode) {
        emit logMessage("SCPI 仿真模式 ping 成功。");
        return true;
    }

    QString response;

    if (!query("*IDN?", &response, VISA_DEFAULT_TIMEOUT_MS)) {
        return false;
    }

    emit logMessage(QString("SCPI 设备响应：%1").arg(response.trimmed()));
    return true;
}

double SCPIController::measureResistance(int timeoutMs)
{
    clearLastError();

    if (m_simulationMode) {
        /*
         * 仿真返回 365 kOhm 对应的 Ohm 原始值。
         */
        return 365000.0;
    }

    /*
     * 不再直接 MEAS:RES?。
     * 采用：
     *   CONF:RES
     *   等待 10s
     *   READ?
     */
    if (!configureMeasurementMode(SCPI_CONF_RESISTANCE,
                                  RESISTANCE_MODE_SETTLE_DELAY_MS,
                                  SCPI_COMMAND_TIMEOUT_MS)) {
        return qQNaN();
    }

    QString response;

    if (!query(SCPI_READ, &response, timeoutMs)) {
        return qQNaN();
    }

    emit logMessage(QString("电阻 READ? 原始返回：%1").arg(response));

    bool ok = false;
    const double value = parseDoubleResponse(response, &ok);

    if (!ok) {
        setLastError(QString("电阻测量响应无法解析：%1").arg(response));
        return qQNaN();
    }

    return value;
}

double SCPIController::measureCapacitance(int timeoutMs)
{
    clearLastError();

    if (m_simulationMode) {
        return 2.2e-9;
    }

    /*
     * 不再直接 MEAS:CAP?。
     * 采用：
     *   CONF:CAP
     *   等待 10s
     *   READ?
     */
    if (!configureMeasurementMode(SCPI_CONF_CAPACITANCE,
                                  CAPACITANCE_MODE_SETTLE_DELAY_MS,
                                  SCPI_COMMAND_TIMEOUT_MS)) {
        return qQNaN();
    }

    QString response;

    if (!query(SCPI_READ, &response, timeoutMs)) {
        return qQNaN();
    }

    emit logMessage(QString("电容 READ? 原始返回：%1").arg(response));

    bool ok = false;
    const double value = parseDoubleResponse(response, &ok);

    if (!ok) {
        setLastError(QString("电容测量响应无法解析：%1").arg(response));
        return qQNaN();
    }

    return value;
}

QString SCPIController::lastError() const
{
    return m_lastError;
}

bool SCPIController::openVisaInstrument(const QString &address)
{
    ViStatus status = viOpenDefaultRM(&m_defaultRm);

    if (isVisaError(status)) {
        setLastError(QString("viOpenDefaultRM 失败：%1").arg(visaStatusText(status)));
        return false;
    }

    const QByteArray visaAddress = address.toLatin1();

    status = viOpen(m_defaultRm,
                    const_cast<ViRsrc>(visaAddress.constData()),
                    VI_NULL,
                    VISA_OPEN_TIMEOUT_MS,
                    &m_instrument);

    if (isVisaError(status)) {
        setLastError(QString("viOpen 失败，地址=%1，错误=%2")
                     .arg(address)
                     .arg(visaStatusText(status)));
        viClose(m_defaultRm);
        m_defaultRm = VI_NULL;
        return false;
    }

    /*
     * 常用 USBTMC/SCPI 设置：
     *   - 超时默认 10s；
     *   - 读到 \\n 作为终止；
     *   - 写命令时发送 END。
     */
    setVisaTimeout(VISA_DEFAULT_TIMEOUT_MS);
    viSetAttribute(m_instrument, VI_ATTR_TERMCHAR, '\n');
    viSetAttribute(m_instrument, VI_ATTR_TERMCHAR_EN, VI_TRUE);
    viSetAttribute(m_instrument, VI_ATTR_SEND_END_EN, VI_TRUE);

    emit logMessage(QString("SCPI VISA 已连接：%1").arg(address));
    return true;
}

bool SCPIController::sendCommand(const QString &command, int timeoutMs)
{
    if (!isConnected()) {
        setLastError("SCPI 设备未连接。");
        return false;
    }

    if (m_simulationMode) {
        return true;
    }

    setVisaTimeout(timeoutMs);

    QByteArray data = command.trimmed().toLatin1();
    data.append('\n');

    ViUInt32 written = 0;
    ViStatus status = viWrite(m_instrument,
                              reinterpret_cast<ViBuf>(data.data()),
                              static_cast<ViUInt32>(data.size()),
                              &written);

    if (isVisaError(status)) {
        setLastError(QString("SCPI 命令发送失败：%1，错误=%2")
                     .arg(command)
                     .arg(visaStatusText(status)));
        return false;
    }

    if (written != static_cast<ViUInt32>(data.size())) {
        setLastError(QString("SCPI 命令未完整发送：%1，written=%2，expected=%3")
                     .arg(command)
                     .arg(written)
                     .arg(data.size()));
        return false;
    }

    return true;
}

bool SCPIController::query(const QString &command,
                           QString *response,
                           int timeoutMs)
{
    if (response) {
        response->clear();
    }

    /*
     * 查询前先抽干残留响应，避免按钮刚点下去就读到上一条结果。
     */
    clearReadBuffer(SCPI_BUFFER_CLEAR_WAIT_MS);

    if (!sendCommand(command, timeoutMs)) {
        return false;
    }

    return readResponse(response, timeoutMs);
}

bool SCPIController::readResponse(QString *response, int timeoutMs)
{
    if (!isConnected()) {
        setLastError("SCPI 设备未连接。");
        return false;
    }

    if (m_simulationMode) {
        if (response) {
            *response = "0";
        }
        return true;
    }

    setVisaTimeout(timeoutMs);

    QByteArray buffer;
    ViStatus status = VI_SUCCESS;

    while (true) {
        ViByte raw[512] = {0};
        ViUInt32 readCount = 0;

        status = viRead(m_instrument,
                        raw,
                        static_cast<ViUInt32>(sizeof(raw)),
                        &readCount);

        if (readCount > 0) {
            buffer.append(reinterpret_cast<const char *>(raw),
                          static_cast<int>(readCount));
        }

        if (status == VI_SUCCESS_TERM_CHAR ||
                buffer.contains('\n') ||
                buffer.contains('\r')) {
            break;
        }

        if (status == VI_SUCCESS_MAX_CNT) {
            continue;
        }

        if (status == VI_ERROR_TMO) {
            if (!buffer.isEmpty()) {
                break;
            }

            setLastError(QString("SCPI 查询超时，timeout=%1 ms。").arg(timeoutMs));
            return false;
        }

        if (isVisaError(status)) {
            setLastError(QString("SCPI 读取失败：%1").arg(visaStatusText(status)));
            return false;
        }

        if (status == VI_SUCCESS) {
            break;
        }
    }

    if (buffer.isEmpty()) {
        setLastError("SCPI 查询无响应。");
        return false;
    }

    if (response) {
        *response = QString::fromLatin1(buffer).trimmed();
    }

    return true;
}

bool SCPIController::clearReadBuffer(int maxWaitMs)
{
    if (m_simulationMode) {
        return true;
    }

    if (!isConnected()) {
        return false;
    }

    /*
     * 不用 TCP，不用 socket。
     * 这里通过短超时 viRead 尝试抽干 VISA 输入缓存。
     */
    ViUInt32 oldTimeout = VISA_DEFAULT_TIMEOUT_MS;
    viGetAttribute(m_instrument, VI_ATTR_TMO_VALUE, &oldTimeout);

    setVisaTimeout(maxWaitMs);

    QByteArray dropped;

    while (true) {
        ViByte raw[256] = {0};
        ViUInt32 readCount = 0;

        const ViStatus status = viRead(m_instrument,
                                       raw,
                                       static_cast<ViUInt32>(sizeof(raw)),
                                       &readCount);

        if (readCount > 0) {
            dropped.append(reinterpret_cast<const char *>(raw),
                           static_cast<int>(readCount));
        }

        if (status == VI_SUCCESS_MAX_CNT) {
            continue;
        }

        /*
         * 读到超时，说明当前已经没有残留响应。
         */
        if (status == VI_ERROR_TMO) {
            break;
        }

        if (isVisaError(status)) {
            break;
        }

        if (readCount == 0) {
            break;
        }

        if (status == VI_SUCCESS_TERM_CHAR ||
                dropped.contains('\n') ||
                dropped.contains('\r')) {
            break;
        }
    }

    viSetAttribute(m_instrument, VI_ATTR_TMO_VALUE, oldTimeout);

    if (!dropped.trimmed().isEmpty()) {
        emit logMessage(QString("已清空SCPI残留响应：%1")
                        .arg(QString::fromLatin1(dropped).trimmed()));
    }

    return true;
}

bool SCPIController::configureMeasurementMode(const QString &command,
                                              int settleDelayMs,
                                              int timeoutMs)
{
    clearReadBuffer(SCPI_BUFFER_CLEAR_WAIT_MS);

    if (!sendCommand(command, timeoutMs)) {
        return false;
    }

    emit logMessage(QString("已发送SCPI配置命令：%1，等待%2 ms后读取。")
                    .arg(command)
                    .arg(settleDelayMs));

    if (settleDelayMs > 0) {
        QThread::msleep(static_cast<unsigned long>(settleDelayMs));
    }

    return true;
}

double SCPIController::parseDoubleResponse(const QString &response,
                                           bool *ok) const
{
    QString text = response.trimmed();

    /*
     * 兼容：
     *   +1.82403955E-10
     *   +1.82403955E-10,+0
     *   1.824 nF
     */
    const int commaIndex = text.indexOf(',');

    if (commaIndex >= 0) {
        text = text.left(commaIndex).trimmed();
    }

    QRegularExpression numberRegex("[-+]?\\d*\\.?\\d+(?:[Ee][-+]?\\d+)?");
    QRegularExpressionMatch match = numberRegex.match(text);

    if (!match.hasMatch()) {
        if (ok) {
            *ok = false;
        }

        return qQNaN();
    }

    bool localOk = false;
    const double value = match.captured(0).toDouble(&localOk);

    if (ok) {
        *ok = localOk;
    }

    return value;
}

bool SCPIController::setVisaTimeout(int timeoutMs)
{
    if (m_instrument == VI_NULL) {
        return false;
    }

    const ViStatus status = viSetAttribute(m_instrument,
                                           VI_ATTR_TMO_VALUE,
                                           static_cast<ViAttrState>(timeoutMs));

    if (isVisaError(status)) {
        setLastError(QString("设置 VISA 超时失败：%1").arg(visaStatusText(status)));
        return false;
    }

    return true;
}

QString SCPIController::visaStatusText(ViStatus status) const
{
    ViChar description[256] = {0};
    const ViSession session = m_instrument != VI_NULL ? m_instrument : m_defaultRm;

    if (session != VI_NULL &&
            viStatusDesc(session, status, description) >= VI_SUCCESS) {
        return QString("%1 (%2)")
                .arg(QString::fromLocal8Bit(description))
                .arg(status);
    }

    return QString("VISA状态码=%1").arg(status);
}

void SCPIController::setLastError(const QString &error)
{
    m_lastError = error;

    if (!error.isEmpty()) {
        emit logMessage(error);
    }
}

void SCPIController::clearLastError()
{
    m_lastError.clear();
}
