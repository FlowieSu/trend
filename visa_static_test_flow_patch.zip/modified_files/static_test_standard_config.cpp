#include "static_test_standard_config.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QSettings>
#include <QStringList>

bool StaticTestStandardConfig::loadStaticItems(const QString &iniFilePath,
                                               QVector<StaticStandardItem> *items,
                                               QString *errorMessage)
{
    if (!items) {
        setError(errorMessage, "items 指针为空。");
        return false;
    }

    items->clear();

    QString filePath = iniFilePath.trimmed();

    if (filePath.isEmpty()) {
        filePath = resolvedIniFilePath(errorMessage);

        if (filePath.isEmpty()) {
            return false;
        }
    }

    if (!QFileInfo::exists(filePath)) {
        setError(errorMessage, QString("阻容标准 INI 文件不存在：%1").arg(filePath));
        return false;
    }

    QSettings settings(filePath, QSettings::IniFormat);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    settings.setIniCodec("UTF-8");
#endif

    settings.beginGroup("Static");
    const int itemCount = settings.value("itemCount", 0).toInt();
    settings.endGroup();

    if (itemCount <= 0) {
        setError(errorMessage, "Static/itemCount 无效或未配置。");
        return false;
    }

    QVector<StaticStandardItem> loadedItems;

    for (int i = 1; i <= itemCount; ++i) {
        StaticStandardItem item;
        QString error;

        if (!readOneItem(settings, i, &item, &error)) {
            setError(errorMessage, QString("读取 StaticItem%1 失败：%2")
                     .arg(i)
                     .arg(error));
            return false;
        }

        loadedItems.append(item);
    }

    if (loadedItems.isEmpty()) {
        setError(errorMessage, "未读取到任何阻容测试项。");
        return false;
    }

    *items = loadedItems;
    return true;
}

QString StaticTestStandardConfig::defaultIniFilePath()
{
    return QDir(QCoreApplication::applicationDirPath())
            .filePath("config/test_standard.ini");
}

QStringList StaticTestStandardConfig::candidateIniFilePaths()
{
    QStringList candidates;

    const QString appDir = QCoreApplication::applicationDirPath();
    const QString currentDir = QDir::currentPath();

    candidates << QDir(appDir).filePath("config/test_standard.ini");
    candidates << QDir(appDir).filePath("../config/test_standard.ini");
    candidates << QDir(appDir).filePath("../../config/test_standard.ini");
    candidates << QDir(appDir).filePath("../../../config/test_standard.ini");
    candidates << QDir(currentDir).filePath("config/test_standard.ini");

    QStringList normalized;

    for (const QString &path : candidates) {
        const QString cleanPath = QDir::cleanPath(path);

        if (!normalized.contains(cleanPath)) {
            normalized << cleanPath;
        }
    }

    return normalized;
}

QString StaticTestStandardConfig::resolvedIniFilePath(QString *message)
{
    const QStringList candidates = candidateIniFilePaths();

    for (const QString &path : candidates) {
        if (QFileInfo::exists(path)) {
            if (message) {
                *message = QString("已找到阻容标准 INI：%1").arg(path);
            }

            return path;
        }
    }

    if (message) {
        *message = QString("未找到阻容标准 INI，已尝试路径：%1")
                .arg(candidates.join(" | "));
    }

    return QString();
}

QVector<int> StaticTestStandardConfig::parseMPoints(const QString &text,
                                                    bool *ok)
{
    QVector<int> points;

    if (ok) {
        *ok = true;
    }

    const QString trimmed = text.trimmed();

    if (trimmed.isEmpty()) {
        return points;
    }

    const QStringList parts = trimmed.split(",", QString::SkipEmptyParts);

    for (const QString &part : parts) {
        bool oneOk = false;
        const int value = part.trimmed().toInt(&oneOk);

        if (!oneOk) {
            if (ok) {
                *ok = false;
            }

            points.clear();
            return points;
        }

        points.append(value);
    }

    return points;
}

bool StaticTestStandardConfig::readOneItem(QSettings &settings,
                                           int index,
                                           StaticStandardItem *item,
                                           QString *errorMessage)
{
    if (!item) {
        setError(errorMessage, "item 指针为空。");
        return false;
    }

    const QString groupName = QString("StaticItem%1").arg(index);

    settings.beginGroup(groupName);

    item->name = settings.value("name").toString().trimmed();

    item->resistanceMinKOhm = settings.value("resistanceMinKOhm").toDouble();
    item->resistanceMaxKOhm = settings.value("resistanceMaxKOhm").toDouble();

    item->capacitanceMinNf = settings.value("capacitanceMinNf").toDouble();
    item->capacitanceMaxNf = settings.value("capacitanceMaxNf").toDouble();

    item->standardText = settings.value("standardText").toString().trimmed();

    item->enableResistance = settings.value("enableResistance", true).toBool();
    item->enableCapacitance = settings.value("enableCapacitance", true).toBool();

    bool redOk = false;
    bool blackOk = false;

    item->redBlackMPoints =
            parseMPoints(settings.value("redBlackMPoints").toString(),
                         &redOk);

    item->blackRedMPoints =
            parseMPoints(settings.value("blackRedMPoints").toString(),
                         &blackOk);

    item->hasBlackRed = settings.value("hasBlackRed", true).toBool();

    settings.endGroup();

    if (item->name.isEmpty()) {
        setError(errorMessage, "name 为空。");
        return false;
    }

    if (item->enableResistance &&
            item->resistanceMinKOhm > item->resistanceMaxKOhm) {
        setError(errorMessage, "电阻下限大于上限。");
        return false;
    }

    if (item->enableCapacitance &&
            item->capacitanceMinNf > item->capacitanceMaxNf) {
        setError(errorMessage, "电容下限大于上限。");
        return false;
    }

    if (!item->enableResistance && !item->enableCapacitance) {
        setError(errorMessage, "enableResistance 和 enableCapacitance 不能同时为 false。");
        return false;
    }

    if (item->standardText.isEmpty()) {
        QStringList parts;

        if (item->enableResistance) {
            parts << QString("阻值: %1~%2 kOhm")
                     .arg(item->resistanceMinKOhm, 0, 'f', 3)
                     .arg(item->resistanceMaxKOhm, 0, 'f', 3);
        } else {
            parts << "阻值: 不测试";
        }

        if (item->enableCapacitance) {
            parts << QString("容值: %1~%2 nF")
                     .arg(item->capacitanceMinNf, 0, 'f', 3)
                     .arg(item->capacitanceMaxNf, 0, 'f', 3);
        } else {
            parts << "容值: 不测试";
        }

        item->standardText = parts.join("; ");
    }

    if (!redOk || item->redBlackMPoints.isEmpty()) {
        setError(errorMessage, "redBlackMPoints 无效或为空。");
        return false;
    }

    if (item->hasBlackRed) {
        if (!blackOk || item->blackRedMPoints.isEmpty()) {
            setError(errorMessage, "hasBlackRed=true 时 blackRedMPoints 不能为空。");
            return false;
        }
    }

    return true;
}

void StaticTestStandardConfig::setError(QString *errorMessage,
                                        const QString &message)
{
    if (errorMessage) {
        *errorMessage = message;
    }
}
