#ifndef STATIC_TEST_STANDARD_CONFIG_H
#define STATIC_TEST_STANDARD_CONFIG_H

#include <QString>
#include <QStringList>
#include <QVector>

/*
 * StaticTestStandardConfig
 *
 * 负责读取阻容测试标准 INI。
 *
 * 标准单位：
 *   resistanceMinKOhm / resistanceMaxKOhm : kOhm
 *   capacitanceMinNf / capacitanceMaxNf   : nF
 */
struct StaticStandardItem
{
    QString name;

    double resistanceMinKOhm = 0.0;
    double resistanceMaxKOhm = 0.0;

    double capacitanceMinNf = 0.0;
    double capacitanceMaxNf = 0.0;

    QString standardText;

    bool enableResistance = true;
    bool enableCapacitance = true;

    QVector<int> redBlackMPoints;
    QVector<int> blackRedMPoints;

    bool hasBlackRed = true;
};

class StaticTestStandardConfig
{
public:
    static bool loadStaticItems(const QString &iniFilePath,
                                QVector<StaticStandardItem> *items,
                                QString *errorMessage = nullptr);

    /*
     * 默认优先路径：
     *   exe同级目录/config/test_standard.ini
     */
    static QString defaultIniFilePath();

    /*
     * 为了避免 Qt Creator 调试时 build/bin 下没有 config，
     * 这里增加候选路径查找。
     */
    static QStringList candidateIniFilePaths();
    static QString resolvedIniFilePath(QString *message = nullptr);

private:
    static QVector<int> parseMPoints(const QString &text,
                                     bool *ok = nullptr);

    static bool readOneItem(class QSettings &settings,
                            int index,
                            StaticStandardItem *item,
                            QString *errorMessage);

    static void setError(QString *errorMessage,
                         const QString &message);
};

#endif // STATIC_TEST_STANDARD_CONFIG_H
