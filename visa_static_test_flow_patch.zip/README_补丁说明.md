# USB/VISA 阻容测试流程补丁

## 修改文件

```text
modified_files/scpi_controller.h
modified_files/scpi_controller.cpp
modified_files/test_runner.cpp
modified_files/static_test_standard_config.h
modified_files/static_test_standard_config.cpp
modified_files/manualstatictestwindow.h
modified_files/manualstatictestwindow.cpp
visa_qmake_snippet.pri
```

直接用 `modified_files` 里的文件覆盖工程同名文件。

## 这版修正的关键点

### 1. 不再使用 TCP

`scpi_controller` 已改为 USB/VISA 版本：

```text
viOpenDefaultRM
viOpen
viWrite
viRead
```

界面里仍然输入 VISA 地址，例如：

```text
USB0::0x2A8D::0x1301::MYXXXXXXXX::INSTR
```

### 2. 阻容测量流程

```text
1. PLC / 继电器 M 点切换；
2. 等待继电器稳定 500 ms；
3. 清空 VISA 输入缓存；
4. 发送 CONF:RES 或 CONF:CAP；
5. 等待测量稳定：
   电阻 10000 ms
   电容 10000 ms
6. 发送 READ? 读取新测量值；
8. 换算显示：
   电阻：Ohm -> kOhm
   电容：F -> nF
```

按你的要求，本补丁仍然没有加入 `9.9E37` 超量程值拦截。

### 3. 10 秒在哪里改

在 `scpi_controller.cpp` 顶部：

```cpp
constexpr int RESISTANCE_MODE_SETTLE_DELAY_MS = 10000;
constexpr int CAPACITANCE_MODE_SETTLE_DELAY_MS = 10000;
```

### 4. INI 加载增强

原来只读：

```text
exe同级目录/config/test_standard.ini
```

现在会依次尝试：

```text
exe同级目录/config/test_standard.ini
exe上一级/config/test_standard.ini
exe上两级/config/test_standard.ini
exe上三级/config/test_standard.ini
当前工作目录/config/test_standard.ini
```

自动测试和手动阻容测试都会打印实际找到的 INI 路径。

### 5. 手动阻容测试

手动阻容测试的测试项和 M 点也改为优先从 INI 读取。INI 失败时才使用内置兜底 M 点。

### 6. .pro 注意

由于这版 `scpi_controller` 使用 `visa.h`，工程需要能找到 VISA 头文件和 lib。

参考 `visa_qmake_snippet.pri`，把适合你 Qt Kit 的路径复制到 `.pro` 中。

如果你用的是 MinGW Kit，VISA 的 MSVC `.lib` 可能不能直接链接，建议切到 MSVC Qt Kit。
