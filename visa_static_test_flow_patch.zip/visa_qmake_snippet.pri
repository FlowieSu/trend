# VISA 配置片段：复制到 ECPS_StaticAndDynamic_Test.pro 中，并按你的 Qt Kit 修改路径

# 如果你使用 64位 MSVC Kit，通常使用下面路径：
VISA_ROOT = C:/Program Files/IVI Foundation/VISA/Win64
INCLUDEPATH += "$$VISA_ROOT/Include"
win32:LIBS += "$$VISA_ROOT/Lib_x64/msc/visa64.lib"

# 如果你使用 32位 MSVC Kit，改用：
# VISA_ROOT = C:/Program Files (x86)/IVI Foundation/VISA/WinNT
# INCLUDEPATH += "$$VISA_ROOT/include"
# win32:LIBS += "$$VISA_ROOT/lib/msc/visa32.lib"

# 注意：
# 1. 如果你用 MinGW Kit，NI/Keysight 提供的 MSVC .lib 可能不能直接链接；
# 2. 最稳妥方式是使用 MSVC Qt Kit 编译；
# 3. 产线电脑需要安装 NI-VISA Runtime 或 Keysight VISA Runtime。
