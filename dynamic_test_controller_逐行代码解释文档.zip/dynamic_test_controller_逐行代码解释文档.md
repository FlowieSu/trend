# DynamicTestController 逐行代码解释文档

本文档基于你刚上传的 `dynamic_test_controller(1).h` 和 `dynamic_test_controller(1).cpp` 生成，只解释 controller 层代码；`DynamicProductContext` 的缓存、判定和完成锁定逻辑在本文中只作为调用对象说明。

## 1. Controller 在动态检测流程中的定位

`DynamicTestController` 是动态测试的流程调度层。它不直接解析每个检测项的 PASS/NG，而是负责打开 CAN、发送复位帧和开始检测帧、接收 CAN 帧、把帧分发给两个 `DynamicProductContext`、在单产品完成时上报 `productFinished`、在双产品完成时上报 `allFinished`。

当前版本相比之前流程，controller 层有三个关键变化：

1. `m_acceptFrames`：复位和发送开始帧前会屏蔽接收，避免残留帧进入本轮结果。
2. `clearBuffer()`：启动前和发送开始帧前分别清空 CAN 接收缓存。
3. `nextSeed()`：seed 从 2 到 255 循环，避免 0/1。

## 2. 总体执行链路

```text
openCanDevice()
  -> ensureCanDevice()
  -> ZlgCanDevice::openDevice()

startDynamicTestWithChannels()
  -> 参数检查
  -> resetTestState()
  -> prepareProduct(product1/product2)
  -> clearBuffer()
  -> sendResetFrames()
  -> 100ms later: clearBuffer() + m_acceptFrames=true + sendStartFrames() + start timeout

ZlgCanDevice::frameReceived
  -> onFrameReceived()
  -> m_product1.handleFrame() / m_product2.handleFrame()
  -> productProgressChanged() / productFrameUpdated()
  -> checkProductFinished()
  -> finishIfAllDone()

finishIfAllDone()
  -> stop timeout
  -> allFinished(allPass, m_finishedResults)
```

## 3. `dynamic_test_controller.h` 逐行解释

### 3.1. 文件开头与依赖声明（第 1-29 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 1 | `#ifndef DYNAMIC_TEST_CONTROLLER_H` | 头文件包含保护开始，避免该头文件被重复包含。 |
| 2 | `#define DYNAMIC_TEST_CONTROLLER_H` | 定义头文件保护宏，与 `#ifndef` 配合防止重复包含。 |
| 3 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 4 | `#include <QObject>` | 包含 `QObject`，因为 controller 继承自 QObject 并使用信号槽机制。 |
| 5 | `#include <QTimer>` | 包含 `QTimer`，用于动态检测超时控制和延迟发送开始检测帧。 |
| 6 | `#include <QVector>` | 包含 `QVector`，用于保存检测项配置和动态检测结果集合。 |
| 7 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 8 | `#include "zlg_can_device.h"` | 包含 ZLG CAN 设备封装类，controller 通过它打开设备、发送帧和接收帧。 |
| 9 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 10 | `#include "dynamic_protocol.h"` | 包含动态检测 CAN 协议定义，例如通道、帧构造、ID 字符串转换等。 |
| 11 | `#include "dynamic_product_context.h"` | 包含单产品上下文，controller 将 CAN 帧分发给位置1/位置2上下文处理。 |
| 12 | `#include "dynamic_result_types.h"` | 包含动态检测结果结构体，例如 `DynamicProductResult`。 |
| 13 | `#include "dynamic_test_item_config.h"` | 包含动态检测项配置结构和默认配置创建函数。 |
| 14 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 15 | `/*` | 块注释开始，说明下面代码的设计目的或流程约定。 |
| 16 | ` * 动态检测控制器。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 17 | ` *` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 18 | ` * 职责：` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 19 | ` * 1. 管理 ZlgCanDevice；` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 20 | ` * 2. 发送复位帧和开始检测帧；` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 21 | ` * 3. 接收 CAN 帧并分发给两个 DynamicProductContext；` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 22 | ` * 4. 在 DetectInProgressFlag == 100 时输出产品结果；` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 23 | ` * 5. 两个产品完成后输出总结果。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 24 | ` */` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 25 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 26 | `class DynamicTestController : public QObject` | 声明动态检测控制器类，继承 `QObject` 以支持 Qt 信号槽。 |
| 27 | `{` | 代码块开始。 |
| 28 | `    Q_OBJECT` | 启用 Qt 元对象系统，使该类可以定义 signals、slots 和跨线程信号。 |
| 29 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 3.2. 头文件区域：public:（第 30-41 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 30 | `public:` | 访问控制区：`public:`，用于划分类的公开接口、槽函数、信号和私有成员。 |
| 31 | `    explicit DynamicTestController(QObject *parent = nullptr);` | 声明构造函数，`explicit` 防止隐式类型转换；`parent` 用于 Qt 对象树管理。 |
| 32 | `    ~DynamicTestController() override;` | 声明析构函数；`override` 表示重写基类虚析构行为。 |
| 33 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 34 | `    bool isCanOpen() const;` | 声明查询 CAN 设备打开状态的只读接口。 |
| 35 | `    bool isRunning() const;` | 声明查询动态检测运行状态的只读接口。 |
| 36 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 37 | `    void setTimeoutMs(int timeoutMs);` | 声明设置超时时间的接口。 |
| 38 | `    int timeoutMs() const;` | 声明读取超时时间的接口。 |
| 39 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 40 | `    void setItemMetas(const QVector<DynamicTestItemMeta> &metas);` | 声明外部设置动态检测项元数据的接口。 |
| 41 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 3.3. 头文件区域：public slots:（第 42-69 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 42 | `public slots:` | 访问控制区：`public slots:`，用于划分类的公开接口、槽函数、信号和私有成员。 |
| 43 | `    bool openCanDevice(const ZlgCanOpenConfig &config);` | 声明打开 CAN 设备的槽函数，参数为 ZLG CAN 打开配置。 |
| 44 | `    void closeCanDevice();` | 声明关闭 CAN 设备的槽函数。 |
| 45 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 46 | `    /*` | 块注释开始，说明下面代码的设计目的或流程约定。 |
| 47 | `     * 默认使用 0x110/0x112 两个通道。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 48 | `     */` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 49 | `    void startDynamicTest(const QString &productCode1,` | 声明默认通道启动动态检测的槽函数。 |
| 50 | `                          const QString &productCode2);` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 51 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 52 | `    void startDynamicTestWithChannels(const QString &productCode1,` | 声明按通道启动动态检测的重载槽函数。 |
| 53 | `                                      DynamicProtocol::DynamicChannel channel1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 54 | `                                      const QString &productCode2,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 55 | `                                      DynamicProtocol::DynamicChannel channel2);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 56 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 57 | `    /*` | 块注释开始，说明下面代码的设计目的或流程约定。 |
| 58 | `     * 新增重载：用于“动态检测参数配置”窗口传入 thresholdFlag。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 59 | `     * 不改变原动态检测流程，只覆盖开始检测帧 Byte3~Byte4。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 60 | `     */` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 61 | `    void startDynamicTestWithChannels(const QString &productCode1,` | 声明按通道启动动态检测的重载槽函数。 |
| 62 | `                                      DynamicProtocol::DynamicChannel channel1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 63 | `                                      int thresholdFlag1,` | 定义整型变量。 |
| 64 | `                                      const QString &productCode2,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 65 | `                                      DynamicProtocol::DynamicChannel channel2,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 66 | `                                      int thresholdFlag2);` | 定义整型变量。 |
| 67 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 68 | `    void requestStop();` | 声明手动停止动态检测的槽函数。 |
| 69 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 3.4. 头文件区域：signals:（第 70-88 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 70 | `signals:` | 访问控制区：`signals:`，用于划分类的公开接口、槽函数、信号和私有成员。 |
| 71 | `    void logMessage(const QString &message);` | 声明日志信号，供 MainWindow 或日志窗口显示文本。 |
| 72 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 73 | `    void canConnectedChanged(bool connected);` | 声明 CAN 连接状态变化信号。 |
| 74 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 75 | `    void productProgressChanged(int productId,` | 声明产品进度更新信号，传出产品位置、进度值和轮询组号。 |
| 76 | `                                int progress,` | 定义整型变量。 |
| 77 | `                                int groupCnt);` | 定义整型变量。 |
| 78 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 79 | `    void productFrameUpdated(int productId,` | 声明单帧更新信号，传出产品位置、seq、value 和 groupCnt，用于实时显示。 |
| 80 | `                             int seq,` | 定义整型变量。 |
| 81 | `                             int value,` | 定义整型变量。 |
| 82 | `                             int groupCnt);` | 定义整型变量。 |
| 83 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 84 | `    void productFinished(DynamicProductResult result);` | 声明单产品动态检测完成信号，携带完整产品结果。 |
| 85 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 86 | `    void allFinished(bool allPass,` | 声明双产品动态检测全部完成信号，携带总结果和两个产品结果集合。 |
| 87 | `                     QVector<DynamicProductResult> results);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 88 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 3.5. 头文件区域：private slots:（第 89-100 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 89 | `private slots:` | 访问控制区：`private slots:`，用于划分类的公开接口、槽函数、信号和私有成员。 |
| 90 | `    void onCanConnectedChanged(bool connected);` | 声明 CAN 连接变化内部槽函数。 |
| 91 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 92 | `    void onFrameReceived(quint32 canId,` | 声明 CAN 收帧内部槽函数。 |
| 93 | `                         QByteArray data);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 94 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 95 | `    void onSendFinished(quint32 canId,` | 声明 CAN 发送完成内部槽函数。 |
| 96 | `                        bool ok,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 97 | `                        QString message);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 98 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 99 | `    void onTimeout();` | 声明动态检测超时内部槽函数。 |
| 100 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 3.6. 头文件区域：private:（第 101-128 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 101 | `private:` | 访问控制区：`private:`，用于划分类的公开接口、槽函数、信号和私有成员。 |
| 102 | `    void ensureCanDevice();` | 声明确保 `ZlgCanDevice` 对象存在的私有函数。 |
| 103 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 104 | `    void resetTestState();` | 声明重置单次动态检测状态的私有函数。 |
| 105 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 106 | `    int nextSeed();` | 声明生成下一次检测 seed 的私有函数。 |
| 107 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 108 | `    bool prepareProduct(DynamicProductContext &context,` | 声明初始化单个产品上下文的私有函数。 |
| 109 | `                        const QString &productCode,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 110 | `                        DynamicProtocol::DynamicChannel channel);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 111 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 112 | `    bool prepareProduct(DynamicProductContext &context,` | 声明初始化单个产品上下文的私有函数。 |
| 113 | `                        const QString &productCode,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 114 | `                        DynamicProtocol::DynamicChannel channel,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 115 | `                        int thresholdFlag);` | 定义整型变量。 |
| 116 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 117 | `    void sendResetFrames();` | 声明发送复位帧的私有函数。 |
| 118 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 119 | `    void sendStartFrames();` | 声明发送开始检测帧的私有函数。 |
| 120 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 121 | `    void checkProductFinished(DynamicProductContext &context);` | 声明检查单个产品是否完成并上报的私有函数。 |
| 122 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 123 | `    void finishIfAllDone();` | 声明检查双产品是否全部完成的私有函数。 |
| 124 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 125 | `    void emitAbortResults(const QString &message);` | 声明手动停止或超时时生成中止结果的私有函数。 |
| 126 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 127 | `    QString canIdText(quint32 canId) const;` | 声明 CAN ID 格式化工具函数。 |
| 128 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 3.7. 头文件区域：private:（第 129-149 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 129 | `private:` | 访问控制区：`private:`，用于划分类的公开接口、槽函数、信号和私有成员。 |
| 130 | `    ZlgCanDevice *m_canDevice = nullptr;` | 保存 ZLG CAN 设备对象指针；为空时表示尚未创建或已关闭。 |
| 131 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 132 | `    bool m_canOpen = false;` | 保存 CAN 设备打开状态。 |
| 133 | `    bool m_running = false;` | 保存动态检测流程是否处于运行中。 |
| 134 | `    bool m_acceptFrames = false;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 135 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 136 | `    int m_timeoutMs = 180000;` | 保存动态检测超时时间，默认 180000 ms，即 3 分钟。 |
| 137 | `    int m_nextSeed = 2;` | 保存下一次要分配的 seed，当前从 2 开始，避开 0/1。 |
| 138 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 139 | `    QTimer *m_timeoutTimer = nullptr;` | 保存单次超时定时器指针。 |
| 140 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 141 | `    QVector<DynamicTestItemMeta> m_itemMetas;` | 保存动态检测项配置，用于初始化两个产品上下文。 |
| 142 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 143 | `    DynamicProductContext m_product1;` | 保存位置1的动态产品上下文。 |
| 144 | `    DynamicProductContext m_product2;` | 保存位置2的动态产品上下文。 |
| 145 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 146 | `    QVector<DynamicProductResult> m_finishedResults;` | 保存已经完成并上报的产品结果。 |
| 147 | `};` | 类声明结束。 |
| 148 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 149 | `#endif // DYNAMIC_TEST_CONTROLLER_H` | 结束头文件保护或条件编译块。 |

## 4. `dynamic_test_controller.cpp` 逐行解释

### 4.1. 文件头与 include（第 1-5 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 1 | `#include "dynamic_test_controller.h"` | 包含本类头文件，使 cpp 能访问类声明、成员函数声明和成员变量。 |
| 2 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 3 | `#include <QMetaType>` | 包含 Qt 元类型系统头文件，用于 `qRegisterMetaType` 注册跨线程信号参数类型。 |
| 4 | `#include <QTimer>` | 包含 `QTimer`，用于动态检测超时控制和延迟发送开始检测帧。 |
| 5 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.2. 构造函数：注册跨线程信号类型，加载动态检测项配置，创建并连接超时定时器。（第 6-22 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 6 | `DynamicTestController::DynamicTestController(QObject *parent)` | 构造函数：注册跨线程信号类型，加载动态检测项配置，创建并连接超时定时器。 |
| 7 | `    : QObject(parent)` | 调用 QObject 基类构造函数，把 parent 交给 Qt 对象树。 |
| 8 | `{` | 代码块开始。 |
| 9 | `    qRegisterMetaType<DynamicItemResult>("DynamicItemResult");` | 注册单项动态结果类型，使其可以作为 queued signal 参数跨线程传递。 |
| 10 | `    qRegisterMetaType<DynamicProductResult>("DynamicProductResult");` | 注册单产品动态结果类型，保证跨线程信号能传递完整结果。 |
| 11 | `    qRegisterMetaType<QVector<DynamicProductResult>>("QVector<DynamicProductResult>");` | 注册产品结果集合类型，用于 `allFinished` 信号传递两个产品结果。 |
| 12 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 13 | `    qRegisterMetaType<DynamicProtocol::DynamicChannel>("DynamicProtocol::DynamicChannel");` | 注册动态通道枚举类型，供信号槽或 QVariant 使用。 |
| 14 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 15 | `    m_itemMetas = createDefaultDynamicTestItemMetas();` | 保存动态检测项配置，用于初始化两个产品上下文。 |
| 16 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 17 | `    m_timeoutTimer = new QTimer(this);` | 保存单次超时定时器指针。 |
| 18 | `    m_timeoutTimer->setSingleShot(true);` | 保存单次超时定时器指针。 |
| 19 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 20 | `    connect(m_timeoutTimer,` | 保存单次超时定时器指针。 |
| 21 | `            &QTimer::timeout,` | 指定定时器超时信号作为信号源。 |
| 22 | `            this,` | 信号接收者为当前 controller 对象。 |

### 4.3. 动态检测超时回调，生成超时中止结果。（第 23-25 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 23 | `            &DynamicTestController::onTimeout);` | 动态检测超时回调，生成超时中止结果。 |
| 24 | `}` | 代码块结束。 |
| 25 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.4. 析构函数：关闭 CAN 设备并释放相关资源。（第 26-30 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 26 | `DynamicTestController::~DynamicTestController()` | 析构函数：关闭 CAN 设备并释放相关资源。 |
| 27 | `{` | 代码块开始。 |
| 28 | `    closeCanDevice();` | 关闭 CAN 设备并清理状态。 |
| 29 | `}` | 代码块结束。 |
| 30 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.5. 查询 CAN 设备是否已打开。（第 31-35 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 31 | `bool DynamicTestController::isCanOpen() const` | 查询 CAN 设备是否已打开。 |
| 32 | `{` | 代码块开始。 |
| 33 | `    return m_canOpen;` | 保存 CAN 设备打开状态。 |
| 34 | `}` | 代码块结束。 |
| 35 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.6. 查询动态检测流程是否正在运行。（第 36-40 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 36 | `bool DynamicTestController::isRunning() const` | 查询动态检测流程是否正在运行。 |
| 37 | `{` | 代码块开始。 |
| 38 | `    return m_running;` | 保存动态检测流程是否处于运行中。 |
| 39 | `}` | 代码块结束。 |
| 40 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.7. 设置动态检测超时时间，避免外部传入非正数。（第 41-47 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 41 | `void DynamicTestController::setTimeoutMs(int timeoutMs)` | 设置动态检测超时时间，避免外部传入非正数。 |
| 42 | `{` | 代码块开始。 |
| 43 | `    if (timeoutMs > 0) {` | 只接受正数超时时间，避免把超时设置成无效值。 |
| 44 | `        m_timeoutMs = timeoutMs;` | 保存动态检测超时时间，默认 180000 ms，即 3 分钟。 |
| 45 | `    }` | 代码块结束。 |
| 46 | `}` | 代码块结束。 |
| 47 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.8. 返回当前动态检测超时时间。（第 48-52 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 48 | `int DynamicTestController::timeoutMs() const` | 返回当前动态检测超时时间。 |
| 49 | `{` | 代码块开始。 |
| 50 | `    return m_timeoutMs;` | 保存动态检测超时时间，默认 180000 ms，即 3 分钟。 |
| 51 | `}` | 代码块结束。 |
| 52 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.9. 设置动态检测项元数据，通常来自 INI 配置或默认配置。（第 53-59 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 53 | `void DynamicTestController::setItemMetas(const QVector<DynamicTestItemMeta> &metas)` | 设置动态检测项元数据，通常来自 INI 配置或默认配置。 |
| 54 | `{` | 代码块开始。 |
| 55 | `    if (!metas.isEmpty()) {` | 只有传入的检测项配置非空时才覆盖当前配置。 |
| 56 | `        m_itemMetas = metas;` | 保存动态检测项配置，用于初始化两个产品上下文。 |
| 57 | `    }` | 代码块结束。 |
| 58 | `}` | 代码块结束。 |
| 59 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.10. 打开 ZLG CAN 设备；运行中禁止重新打开。（第 60-74 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 60 | `bool DynamicTestController::openCanDevice(const ZlgCanOpenConfig &config)` | 打开 ZLG CAN 设备；运行中禁止重新打开。 |
| 61 | `{` | 代码块开始。 |
| 62 | `    if (m_running) {` | 保存动态检测流程是否处于运行中。 |
| 63 | `        emit logMessage("动态检测运行中，不能重新打开 CAN 设备。");` | 发出日志：运行中禁止重新打开 CAN。 |
| 64 | `        return false;` | 返回失败，表示当前操作未执行成功或当前条件不满足。 |
| 65 | `    }` | 代码块结束。 |
| 66 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 67 | `    ensureCanDevice();` | 确保 `m_canDevice` 已创建；未创建则在该函数内创建并连接信号槽。 |
| 68 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 69 | `    const bool ok = m_canDevice->openDevice(config);` | 调用 ZLG CAN 封装类打开硬件设备。 |
| 70 | `    m_canOpen = ok;` | 保存 CAN 设备打开状态。 |
| 71 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 72 | `    return ok;` | 把 CAN 打开结果返回给调用方。 |
| 73 | `}` | 代码块结束。 |
| 74 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.11. 关闭 CAN 设备，停止超时定时器，并重置运行状态。（第 75-91 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 75 | `void DynamicTestController::closeCanDevice()` | 关闭 CAN 设备，停止超时定时器，并重置运行状态。 |
| 76 | `{` | 代码块开始。 |
| 77 | `    if (m_timeoutTimer) {` | 保存单次超时定时器指针。 |
| 78 | `        m_timeoutTimer->stop();` | 保存单次超时定时器指针。 |
| 79 | `    }` | 代码块结束。 |
| 80 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 81 | `    if (m_canDevice) {` | 判断 CAN 设备对象是否存在。 |
| 82 | `        m_canDevice->closeDevice();` | 调用设备封装类关闭 CAN 硬件。 |
| 83 | `        m_canDevice->deleteLater();` | 使用 Qt 延迟删除对象，避免在信号槽调用链中立即析构造成风险。 |
| 84 | `        m_canDevice = nullptr;` | 清空设备指针，表示当前没有可用 CAN 设备对象。 |
| 85 | `    }` | 代码块结束。 |
| 86 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 87 | `    m_canOpen = false;` | 保存 CAN 设备打开状态。 |
| 88 | `    m_running = false;` | 保存动态检测流程是否处于运行中。 |
| 89 | `    m_acceptFrames = false;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 90 | `}` | 代码块结束。 |
| 91 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.12. 默认通道启动入口：位置1用 0x110，位置2用 0x112。（第 92-100 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 92 | `void DynamicTestController::startDynamicTest(const QString &productCode1,` | 默认通道启动入口：位置1用 0x110，位置2用 0x112。 |
| 93 | `                                             const QString &productCode2)` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 94 | `{` | 代码块开始。 |
| 95 | `    startDynamicTestWithChannels(productCode1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 96 | `                                 DynamicProtocol::DynamicChannel::Channel110,` | 指定默认位置1动态发送通道为 0x110。 |
| 97 | `                                 productCode2,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 98 | `                                 DynamicProtocol::DynamicChannel::Channel112);` | 指定默认位置2动态发送通道为 0x112。 |
| 99 | `}` | 代码块结束。 |
| 100 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.13. 按指定通道和阈值启动双产品动态检测的核心入口。（第 101-119 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 101 | `void DynamicTestController::startDynamicTestWithChannels(const QString &productCode1,` | 按指定通道和阈值启动双产品动态检测的核心入口。 |
| 102 | `                                                         DynamicProtocol::DynamicChannel channel1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 103 | `                                                         const QString &productCode2,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 104 | `                                                         DynamicProtocol::DynamicChannel channel2)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 105 | `{` | 代码块开始。 |
| 106 | `    const DynamicProtocol::ChannelConfig cfg1 =` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 107 | `            DynamicProtocol::channelConfig(channel1);` | 根据位置1选择的通道取得协议配置，包括 txId/rxId/默认 thresholdFlag。 |
| 108 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 109 | `    const DynamicProtocol::ChannelConfig cfg2 =` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 110 | `            DynamicProtocol::channelConfig(channel2);` | 根据位置2选择的通道取得协议配置。 |
| 111 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 112 | `    startDynamicTestWithChannels(productCode1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 113 | `                                 channel1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 114 | `                                 cfg1.thresholdFlag,` | 使用通道默认 thresholdFlag 作为位置1开始检测帧参数。 |
| 115 | `                                 productCode2,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 116 | `                                 channel2,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 117 | `                                 cfg2.thresholdFlag);` | 使用通道默认 thresholdFlag 作为位置2开始检测帧参数。 |
| 118 | `}` | 代码块结束。 |
| 119 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.14. 按指定通道和阈值启动双产品动态检测的核心入口。（第 120-197 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 120 | `void DynamicTestController::startDynamicTestWithChannels(const QString &productCode1,` | 按指定通道和阈值启动双产品动态检测的核心入口。 |
| 121 | `                                                         DynamicProtocol::DynamicChannel channel1,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 122 | `                                                         int thresholdFlag1,` | 定义整型变量。 |
| 123 | `                                                         const QString &productCode2,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 124 | `                                                         DynamicProtocol::DynamicChannel channel2,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 125 | `                                                         int thresholdFlag2)` | 定义整型变量。 |
| 126 | `{` | 代码块开始。 |
| 127 | `    if (!m_canDevice \|\| !m_canDevice->isOpen()) {` | 启动前检查 CAN 设备对象存在且硬件已经打开。 |
| 128 | `        emit logMessage("CAN 设备未连接，禁止启动动态检测。");` | 发出日志：CAN 未连接，拒绝启动动态检测。 |
| 129 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 130 | `    }` | 代码块结束。 |
| 131 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 132 | `    if (m_running) {` | 保存动态检测流程是否处于运行中。 |
| 133 | `        emit logMessage("动态检测正在运行，禁止重复启动。");` | 发出日志：动态检测已经在运行，拒绝重复启动。 |
| 134 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 135 | `    }` | 代码块结束。 |
| 136 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 137 | `    if (productCode1.trimmed().isEmpty() \|\| productCode2.trimmed().isEmpty()) {` | 检查两个产品条码去除空白后是否为空。 |
| 138 | `        emit logMessage("产品编码为空，禁止启动动态检测。");` | 发出日志：条码为空，拒绝启动动态检测。 |
| 139 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 140 | `    }` | 代码块结束。 |
| 141 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 142 | `    if (channel1 == channel2) {` | 检查两个位置是否选择了相同通道；相同通道会导致收发冲突。 |
| 143 | `        emit logMessage("位置1和位置2动态发送通道重复，禁止启动动态检测。");` | 发出日志：两个产品不能使用同一个动态通道。 |
| 144 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 145 | `    }` | 代码块结束。 |
| 146 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 147 | `    resetTestState();` | 清空上一轮检测状态，准备启动新一轮动态测试。 |
| 148 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 149 | `    if (!prepareProduct(m_product1, productCode1.trimmed(), channel1, thresholdFlag1)) {` | 保存位置1的动态产品上下文。 |
| 150 | `        emit logMessage("位置1动态检测上下文初始化失败。");` | 发出日志：位置1上下文初始化失败，启动流程中止。 |
| 151 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 152 | `    }` | 代码块结束。 |
| 153 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 154 | `    if (!prepareProduct(m_product2, productCode2.trimmed(), channel2, thresholdFlag2)) {` | 保存位置2的动态产品上下文。 |
| 155 | `        emit logMessage("位置2动态检测上下文初始化失败。");` | 发出日志：位置2上下文初始化失败，启动流程中止。 |
| 156 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 157 | `    }` | 代码块结束。 |
| 158 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 159 | `    m_running = true;` | 保存动态检测流程是否处于运行中。 |
| 160 | `    m_acceptFrames = false;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 161 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 162 | `    emit logMessage(QString("动态检测开始：位置1=%1，通道=%2，threshold=%3；位置2=%4，通道=%5，threshold=%6。")` | 输出本轮动态检测的启动信息，包括条码、通道和 threshold。 |
| 163 | `                    .arg(productCode1.trimmed())` | 把位置1条码填入日志字符串。 |
| 164 | `                    .arg(DynamicProtocol::channelName(channel1))` | 把位置1通道名填入日志字符串。 |
| 165 | `                    .arg(thresholdFlag1)` | 把位置1 thresholdFlag 填入日志字符串。 |
| 166 | `                    .arg(productCode2.trimmed())` | 把位置2条码填入日志字符串。 |
| 167 | `                    .arg(DynamicProtocol::channelName(channel2))` | 把位置2通道名填入日志字符串。 |
| 168 | `                    .arg(thresholdFlag2));` | 把位置2 thresholdFlag 填入日志字符串。 |
| 169 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 170 | `    if (m_canDevice && !m_canDevice->clearBuffer()) {` | 条件判断，根据当前状态选择是否进入该分支。 |
| 171 | `        emit logMessage("动态检测开始前清空 CAN 接收缓存失败，继续执行。");` | 输出本轮动态检测的启动信息，包括条码、通道和 threshold。 |
| 172 | `    }` | 代码块结束。 |
| 173 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 174 | `    sendResetFrames();` | 向两个产品发送复位帧，使检测板进入干净状态。 |
| 175 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 176 | `    /*` | 块注释开始，说明下面代码的设计目的或流程约定。 |
| 177 | `     * 复位帧之后稍等再发开始检测帧。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 178 | `     * 不改变原流程，只把开始检测帧中的 thresholdFlag 改为外部配置。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 179 | `     */` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 180 | `    QTimer::singleShot(100, this, [this]() {` | 使用 100 ms 单次延迟，让复位帧先执行，再发送开始检测帧。 |
| 181 | `        if (!m_running) {` | 保存动态检测流程是否处于运行中。 |
| 182 | `            return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 183 | `        }` | 代码块结束。 |
| 184 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 185 | `        if (m_canDevice && !m_canDevice->clearBuffer()) {` | 条件判断，根据当前状态选择是否进入该分支。 |
| 186 | `            emit logMessage("发送开始检测帧前清空 CAN 接收缓存失败，继续执行。");` | 发出 Qt 信号，通知 UI 或上层流程。 |
| 187 | `        }` | 代码块结束。 |
| 188 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 189 | `        m_acceptFrames = true;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 190 | `        sendStartFrames();` | 发送两个产品的开始检测帧。 |
| 191 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 192 | `        if (m_timeoutTimer) {` | 保存单次超时定时器指针。 |
| 193 | `            m_timeoutTimer->start(m_timeoutMs);` | 保存动态检测超时时间，默认 180000 ms，即 3 分钟。 |
| 194 | `        }` | 代码块结束。 |
| 195 | `    });` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 196 | `}` | 代码块结束。 |
| 197 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.15. 手动停止动态检测，输出中止结果。（第 198-212 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 198 | `void DynamicTestController::requestStop()` | 手动停止动态检测，输出中止结果。 |
| 199 | `{` | 代码块开始。 |
| 200 | `    if (!m_running) {` | 保存动态检测流程是否处于运行中。 |
| 201 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 202 | `    }` | 代码块结束。 |
| 203 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 204 | `    emit logMessage("动态检测被请求停止。");` | 发出日志：用户或上层流程请求手动停止。 |
| 205 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 206 | `    if (m_timeoutTimer) {` | 保存单次超时定时器指针。 |
| 207 | `        m_timeoutTimer->stop();` | 保存单次超时定时器指针。 |
| 208 | `    }` | 代码块结束。 |
| 209 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 210 | `    emitAbortResults("动态检测被手动停止");` | 构造手动停止的中止结果，并发送 allFinished(false)。 |
| 211 | `}` | 代码块结束。 |
| 212 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.16. CAN 连接状态变化回调，同步内部状态并通知 UI。（第 213-218 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 213 | `void DynamicTestController::onCanConnectedChanged(bool connected)` | CAN 连接状态变化回调，同步内部状态并通知 UI。 |
| 214 | `{` | 代码块开始。 |
| 215 | `    m_canOpen = connected;` | 保存 CAN 设备打开状态。 |
| 216 | `    emit canConnectedChanged(connected);` | 把 CAN 连接状态变化继续通知 UI 或其他模块。 |
| 217 | `}` | 代码块结束。 |
| 218 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.17. CAN 收帧入口：运行且允许接收后，将帧分发给两个产品上下文。（第 219-281 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 219 | `void DynamicTestController::onFrameReceived(quint32 canId,` | CAN 收帧入口：运行且允许接收后，将帧分发给两个产品上下文。 |
| 220 | `                                            QByteArray data)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 221 | `{` | 代码块开始。 |
| 222 | `    if (!m_running) {` | 保存动态检测流程是否处于运行中。 |
| 223 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 224 | `    }` | 代码块结束。 |
| 225 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 226 | `    if (!m_acceptFrames) {` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 227 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 228 | `    }` | 代码块结束。 |
| 229 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 230 | `    bool handled = false;` | 记录当前 CAN 帧是否被任一产品上下文处理。 |
| 231 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 232 | `    if (m_product1.handleFrame(canId, data)) {` | 保存位置1的动态产品上下文。 |
| 233 | `        handled = true;` | 标记该帧已被至少一个产品上下文接收处理。 |
| 234 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 235 | `        emit productProgressChanged(m_product1.productId(),` | 保存位置1的动态产品上下文。 |
| 236 | `                                    m_product1.detectProgress(),` | 保存位置1的动态产品上下文。 |
| 237 | `                                    m_product1.groupCnt());` | 保存位置1的动态产品上下文。 |
| 238 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 239 | `        if (data.size() >= 6) {` | 只有原始数据至少 6 字节时才解析 seq/value/groupCnt 并发送单帧更新信号。 |
| 240 | `            emit productFrameUpdated(m_product1.productId(),` | 保存位置1的动态产品上下文。 |
| 241 | `                                     static_cast<unsigned char>(data[0]),` | 从第 0 字节取 seq。 |
| 242 | `                                     static_cast<qint16>(` | 把 Byte2~Byte3 组合成 16 位有符号 value。 |
| 243 | `                                         (static_cast<unsigned char>(data[3]) << 8)` | 取 value 高字节并左移 8 位。 |
| 244 | `                                         \| static_cast<unsigned char>(data[2])),` | 取 value 低字节，与高字节合成 value。 |
| 245 | `                                     (static_cast<unsigned char>(data[5]) << 8)` | 取 groupCnt 高字节并左移 8 位。 |
| 246 | `                                     \| static_cast<unsigned char>(data[4]));` | 取 groupCnt 低字节，与高字节合成轮询组号。 |
| 247 | `        }` | 代码块结束。 |
| 248 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 249 | `        checkProductFinished(m_product1);` | 保存位置1的动态产品上下文。 |
| 250 | `    }` | 代码块结束。 |
| 251 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 252 | `    if (m_product2.handleFrame(canId, data)) {` | 保存位置2的动态产品上下文。 |
| 253 | `        handled = true;` | 标记该帧已被至少一个产品上下文接收处理。 |
| 254 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 255 | `        emit productProgressChanged(m_product2.productId(),` | 保存位置2的动态产品上下文。 |
| 256 | `                                    m_product2.detectProgress(),` | 保存位置2的动态产品上下文。 |
| 257 | `                                    m_product2.groupCnt());` | 保存位置2的动态产品上下文。 |
| 258 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 259 | `        if (data.size() >= 6) {` | 只有原始数据至少 6 字节时才解析 seq/value/groupCnt 并发送单帧更新信号。 |
| 260 | `            emit productFrameUpdated(m_product2.productId(),` | 保存位置2的动态产品上下文。 |
| 261 | `                                     static_cast<unsigned char>(data[0]),` | 从第 0 字节取 seq。 |
| 262 | `                                     static_cast<qint16>(` | 把 Byte2~Byte3 组合成 16 位有符号 value。 |
| 263 | `                                         (static_cast<unsigned char>(data[3]) << 8)` | 取 value 高字节并左移 8 位。 |
| 264 | `                                         \| static_cast<unsigned char>(data[2])),` | 取 value 低字节，与高字节合成 value。 |
| 265 | `                                     (static_cast<unsigned char>(data[5]) << 8)` | 取 groupCnt 高字节并左移 8 位。 |
| 266 | `                                     \| static_cast<unsigned char>(data[4]));` | 取 groupCnt 低字节，与高字节合成轮询组号。 |
| 267 | `        }` | 代码块结束。 |
| 268 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 269 | `        checkProductFinished(m_product2);` | 保存位置2的动态产品上下文。 |
| 270 | `    }` | 代码块结束。 |
| 271 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 272 | `    if (!handled) {` | 如果当前帧不属于位置1或位置2，则不输出日志，避免总线其他帧刷屏。 |
| 273 | `        /*` | 块注释开始，说明下面代码的设计目的或流程约定。 |
| 274 | `         * 非动态检测 ID，不打印日志，避免 CAN 总线上其它帧刷屏。` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 275 | `         */` | 块注释内容或结束符，用于解释代码设计，不参与编译逻辑。 |
| 276 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 277 | `    }` | 代码块结束。 |
| 278 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 279 | `    finishIfAllDone();` | 每处理完一帧后检查两个产品是否都已完成并上报。 |
| 280 | `}` | 代码块结束。 |
| 281 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.18. CAN 发送完成回调，输出发送日志。（第 282-291 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 282 | `void DynamicTestController::onSendFinished(quint32 canId,` | CAN 发送完成回调，输出发送日志。 |
| 283 | `                                           bool ok,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 284 | `                                           QString message)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 285 | `{` | 代码块开始。 |
| 286 | `    emit logMessage(QString("发送帧 %1：%2，%3")` | 把 CAN 发送结果整理为日志输出。 |
| 287 | `                    .arg(canIdText(canId))` | 把发送帧 CAN ID 格式化为日志文本。 |
| 288 | `                    .arg(ok ? "成功" : "失败")` | 根据发送结果布尔值显示“成功”或“失败”。 |
| 289 | `                    .arg(message));` | 把底层发送结果消息填入日志。 |
| 290 | `}` | 代码块结束。 |
| 291 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.19. 动态检测超时回调，生成超时中止结果。（第 292-301 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 292 | `void DynamicTestController::onTimeout()` | 动态检测超时回调，生成超时中止结果。 |
| 293 | `{` | 代码块开始。 |
| 294 | `    if (!m_running) {` | 保存动态检测流程是否处于运行中。 |
| 295 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 296 | `    }` | 代码块结束。 |
| 297 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 298 | `    emit logMessage("动态检测超时。");` | 发出超时日志，并用超时原因构造中止结果。 |
| 299 | `    emitAbortResults("动态检测超时");` | 发出超时日志，并用超时原因构造中止结果。 |
| 300 | `}` | 代码块结束。 |
| 301 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.20. 懒加载 ZlgCanDevice，并绑定设备信号到 controller 槽函数。（第 302-312 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 302 | `void DynamicTestController::ensureCanDevice()` | 懒加载 ZlgCanDevice，并绑定设备信号到 controller 槽函数。 |
| 303 | `{` | 代码块开始。 |
| 304 | `    if (m_canDevice) {` | 判断 CAN 设备对象是否存在。 |
| 305 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 306 | `    }` | 代码块结束。 |
| 307 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 308 | `    m_canDevice = new ZlgCanDevice(this);` | 保存 ZLG CAN 设备对象指针；为空时表示尚未创建或已关闭。 |
| 309 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 310 | `    connect(m_canDevice,` | 开始建立 Qt 信号槽连接。 |
| 311 | `            &ZlgCanDevice::connectedChanged,` | 绑定设备连接状态变化信号。 |
| 312 | `            this,` | 信号接收者为当前 controller 对象。 |

### 4.21. CAN 连接状态变化回调，同步内部状态并通知 UI。（第 313-317 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 313 | `            &DynamicTestController::onCanConnectedChanged);` | CAN 连接状态变化回调，同步内部状态并通知 UI。 |
| 314 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 315 | `    connect(m_canDevice,` | 开始建立 Qt 信号槽连接。 |
| 316 | `            &ZlgCanDevice::frameReceived,` | 绑定 CAN 收帧信号。 |
| 317 | `            this,` | 信号接收者为当前 controller 对象。 |

### 4.22. CAN 收帧入口：运行且允许接收后，将帧分发给两个产品上下文。（第 318-322 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 318 | `            &DynamicTestController::onFrameReceived);` | CAN 收帧入口：运行且允许接收后，将帧分发给两个产品上下文。 |
| 319 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 320 | `    connect(m_canDevice,` | 开始建立 Qt 信号槽连接。 |
| 321 | `            &ZlgCanDevice::sendFinished,` | 绑定 CAN 发送完成信号。 |
| 322 | `            this,` | 信号接收者为当前 controller 对象。 |

### 4.23. CAN 发送完成回调，输出发送日志。（第 323-327 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 323 | `            &DynamicTestController::onSendFinished);` | CAN 发送完成回调，输出发送日志。 |
| 324 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 325 | `    connect(m_canDevice,` | 开始建立 Qt 信号槽连接。 |
| 326 | `            &ZlgCanDevice::logMessage,` | 绑定设备层日志信号。 |
| 327 | `            this,` | 信号接收者为当前 controller 对象。 |

### 4.24. DynamicTestController::logMessage（第 328-330 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 328 | `            &DynamicTestController::logMessage);` | 成员函数 `DynamicTestController::logMessage` 的定义或声明。 |
| 329 | `}` | 代码块结束。 |
| 330 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.25. 重置一次动态检测的运行状态、两个产品上下文和超时定时器。（第 331-343 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 331 | `void DynamicTestController::resetTestState()` | 重置一次动态检测的运行状态、两个产品上下文和超时定时器。 |
| 332 | `{` | 代码块开始。 |
| 333 | `    m_finishedResults.clear();` | 保存已经完成并上报的产品结果。 |
| 334 | `    m_acceptFrames = false;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 335 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 336 | `    m_product1.reset();` | 保存位置1的动态产品上下文。 |
| 337 | `    m_product2.reset();` | 保存位置2的动态产品上下文。 |
| 338 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 339 | `    if (m_timeoutTimer) {` | 保存单次超时定时器指针。 |
| 340 | `        m_timeoutTimer->stop();` | 保存单次超时定时器指针。 |
| 341 | `    }` | 代码块结束。 |
| 342 | `}` | 代码块结束。 |
| 343 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.26. 生成检测板交互 seed，范围控制在 2~255。（第 344-360 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 344 | `int DynamicTestController::nextSeed()` | 生成检测板交互 seed，范围控制在 2~255。 |
| 345 | `{` | 代码块开始。 |
| 346 | `    int seed = m_nextSeed & 0xFF;` | 保存下一次要分配的 seed，当前从 2 开始，避开 0/1。 |
| 347 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 348 | `    if (seed < 2) {` | 避免 seed 使用 0 或 1；当前协议从 2 开始分配。 |
| 349 | `        seed = 2;` | 把 seed 修正为最小可用值 2。 |
| 350 | `    }` | 代码块结束。 |
| 351 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 352 | `    ++m_nextSeed;` | 保存下一次要分配的 seed，当前从 2 开始，避开 0/1。 |
| 353 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 354 | `    if (m_nextSeed > 255) {` | 保存下一次要分配的 seed，当前从 2 开始，避开 0/1。 |
| 355 | `        m_nextSeed = 2;` | 保存下一次要分配的 seed，当前从 2 开始，避开 0/1。 |
| 356 | `    }` | 代码块结束。 |
| 357 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 358 | `    return seed;` | 返回本次分配给产品上下文的 seed。 |
| 359 | `}` | 代码块结束。 |
| 360 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.27. 根据产品条码、通道和 thresholdFlag 初始化单个产品上下文。（第 361-373 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 361 | `bool DynamicTestController::prepareProduct(DynamicProductContext &context,` | 根据产品条码、通道和 thresholdFlag 初始化单个产品上下文。 |
| 362 | `                                           const QString &productCode,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 363 | `                                           DynamicProtocol::DynamicChannel channel)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 364 | `{` | 代码块开始。 |
| 365 | `    const DynamicProtocol::ChannelConfig cfg =` | 根据指定动态通道取得协议配置。 |
| 366 | `            DynamicProtocol::channelConfig(channel);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 367 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 368 | `    return prepareProduct(context,` | 调用带 thresholdFlag 的重载版本，使用通道默认 thresholdFlag。 |
| 369 | `                          productCode,` | 传入当前产品条码。 |
| 370 | `                          channel,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 371 | `                          cfg.thresholdFlag);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 372 | `}` | 代码块结束。 |
| 373 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.28. 根据产品条码、通道和 thresholdFlag 初始化单个产品上下文。（第 374-395 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 374 | `bool DynamicTestController::prepareProduct(DynamicProductContext &context,` | 根据产品条码、通道和 thresholdFlag 初始化单个产品上下文。 |
| 375 | `                                           const QString &productCode,` | 定义只读局部变量，保存本行计算或构造的中间结果。 |
| 376 | `                                           DynamicProtocol::DynamicChannel channel,` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 377 | `                                           int thresholdFlag)` | 定义整型变量。 |
| 378 | `{` | 代码块开始。 |
| 379 | `    DynamicProtocol::ChannelConfig cfg =` | 根据指定动态通道取得协议配置。 |
| 380 | `            DynamicProtocol::channelConfig(channel);` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 381 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 382 | `    if (cfg.txId == 0 \|\| cfg.rxId == 0) {` | 检查通道配置是否合法；txId/rxId 为 0 表示配置无效。 |
| 383 | `        return false;` | 返回失败，表示当前操作未执行成功或当前条件不满足。 |
| 384 | `    }` | 代码块结束。 |
| 385 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 386 | `    cfg.thresholdFlag = thresholdFlag;` | 把外部配置的 thresholdFlag 覆盖到通道配置中。 |
| 387 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 388 | `    context.setup(cfg,` | 初始化单产品上下文，包括通道配置、条码、seed 和检测项配置。 |
| 389 | `                  productCode,` | 传入当前产品条码。 |
| 390 | `                  nextSeed(),` | 为该产品分配新的 seed。 |
| 391 | `                  m_itemMetas);` | 保存动态检测项配置，用于初始化两个产品上下文。 |
| 392 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 393 | `    return true;` | 返回成功，或表示当前分支处理完成。 |
| 394 | `}` | 代码块结束。 |
| 395 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.29. 向两个产品通道发送复位帧。（第 396-411 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 396 | `void DynamicTestController::sendResetFrames()` | 向两个产品通道发送复位帧。 |
| 397 | `{` | 代码块开始。 |
| 398 | `    if (!m_canDevice) {` | 条件判断，根据当前状态选择是否进入该分支。 |
| 399 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 400 | `    }` | 代码块结束。 |
| 401 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 402 | `    const QByteArray resetFrame = DynamicProtocol::buildResetFrame();` | 构造协议定义的复位帧数据。 |
| 403 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 404 | `    m_canDevice->sendFrame(m_product1.txId(), resetFrame);` | 保存位置1的动态产品上下文。 |
| 405 | `    m_canDevice->sendFrame(m_product2.txId(), resetFrame);` | 保存位置2的动态产品上下文。 |
| 406 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 407 | `    emit logMessage(QString("已发送复位帧：%1、%2。")` | 输出复位帧发送日志。 |
| 408 | `                    .arg(canIdText(m_product1.txId()))` | 保存位置1的动态产品上下文。 |
| 409 | `                    .arg(canIdText(m_product2.txId())));` | 保存位置2的动态产品上下文。 |
| 410 | `}` | 代码块结束。 |
| 411 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.30. 向两个产品通道发送开始检测帧，帧内包含 thresholdFlag 和 seed。（第 412-435 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 412 | `void DynamicTestController::sendStartFrames()` | 向两个产品通道发送开始检测帧，帧内包含 thresholdFlag 和 seed。 |
| 413 | `{` | 代码块开始。 |
| 414 | `    if (!m_canDevice) {` | 条件判断，根据当前状态选择是否进入该分支。 |
| 415 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 416 | `    }` | 代码块结束。 |
| 417 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 418 | `    const QByteArray start1 =` | 构造位置1开始检测帧。 |
| 419 | `            DynamicProtocol::buildStartFrame(m_product1.thresholdFlag(),` | 保存位置1的动态产品上下文。 |
| 420 | `                                             m_product1.seed());` | 保存位置1的动态产品上下文。 |
| 421 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 422 | `    const QByteArray start2 =` | 构造位置2开始检测帧。 |
| 423 | `            DynamicProtocol::buildStartFrame(m_product2.thresholdFlag(),` | 保存位置2的动态产品上下文。 |
| 424 | `                                             m_product2.seed());` | 保存位置2的动态产品上下文。 |
| 425 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 426 | `    m_canDevice->sendFrame(m_product1.txId(), start1);` | 保存位置1的动态产品上下文。 |
| 427 | `    m_canDevice->sendFrame(m_product2.txId(), start2);` | 保存位置2的动态产品上下文。 |
| 428 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 429 | `    emit logMessage(QString("已发送开始检测帧：%1 DATA=%2；%3 DATA=%4。")` | 输出开始检测帧发送日志，并打印 DATA 字节。 |
| 430 | `                    .arg(canIdText(m_product1.txId()))` | 保存位置1的动态产品上下文。 |
| 431 | `                    .arg(DynamicProtocol::frameDataToString(start1))` | 把位置1开始帧字节转成可读字符串。 |
| 432 | `                    .arg(canIdText(m_product2.txId()))` | 保存位置2的动态产品上下文。 |
| 433 | `                    .arg(DynamicProtocol::frameDataToString(start2)));` | 把位置2开始帧字节转成可读字符串。 |
| 434 | `}` | 代码块结束。 |
| 435 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.31. 检查单个产品是否完成；完成后 buildResult、标记已上报、通知 UI。（第 436-456 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 436 | `void DynamicTestController::checkProductFinished(DynamicProductContext &context)` | 检查单个产品是否完成；完成后 buildResult、标记已上报、通知 UI。 |
| 437 | `{` | 代码块开始。 |
| 438 | `    if (!context.isFinished() \|\| context.isReported()) {` | 如果该产品未完成，或已经上报过，则不重复生成结果。 |
| 439 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 440 | `    }` | 代码块结束。 |
| 441 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 442 | `    DynamicProductResult result = context.buildResult();` | 从产品上下文生成完整动态检测结果。 |
| 443 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 444 | `    context.markReported();` | 标记该产品结果已上报，避免后续帧触发重复上报。 |
| 445 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 446 | `    m_finishedResults.append(result);` | 保存已经完成并上报的产品结果。 |
| 447 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 448 | `    emit logMessage(QString("位置%1动态检测完成：%2，进度=%3，总结果=%4。")` | 输出单产品完成日志，包括位置、条码、进度和 PASS/NG。 |
| 449 | `                    .arg(result.productId)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 450 | `                    .arg(result.productCode)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 451 | `                    .arg(result.detectProgress)` | 代码续行或结构性语句，配合上下文共同完成函数逻辑。 |
| 452 | `                    .arg(result.pass ? "PASS" : "NG"));` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 453 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 454 | `    emit productFinished(result);` | 向 UI 发出单产品完成信号。 |
| 455 | `}` | 代码块结束。 |
| 456 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.32. 检查两个产品是否均完成且均已上报；若满足则输出双产品最终结果。（第 457-492 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 457 | `void DynamicTestController::finishIfAllDone()` | 检查两个产品是否均完成且均已上报；若满足则输出双产品最终结果。 |
| 458 | `{` | 代码块开始。 |
| 459 | `    if (!m_running) {` | 保存动态检测流程是否处于运行中。 |
| 460 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 461 | `    }` | 代码块结束。 |
| 462 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 463 | `    if (!m_product1.isFinished() \|\| !m_product2.isFinished()) {` | 保存位置1的动态产品上下文。 |
| 464 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 465 | `    }` | 代码块结束。 |
| 466 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 467 | `    if (!m_product1.isReported() \|\| !m_product2.isReported()) {` | 保存位置1的动态产品上下文。 |
| 468 | `        return;` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 469 | `    }` | 代码块结束。 |
| 470 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 471 | `    if (m_timeoutTimer) {` | 保存单次超时定时器指针。 |
| 472 | `        m_timeoutTimer->stop();` | 保存单次超时定时器指针。 |
| 473 | `    }` | 代码块结束。 |
| 474 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 475 | `    bool allPass = true;` | 先假设双产品总结果合格，后续遍历发现 NG 再改为 false。 |
| 476 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 477 | `    for (const DynamicProductResult &result : m_finishedResults) {` | 保存已经完成并上报的产品结果。 |
| 478 | `        if (!result.pass) {` | 如果任一产品结果为 NG，则双产品总结果为 NG。 |
| 479 | `            allPass = false;` | 把双产品总结果置为不合格。 |
| 480 | `            break;` | 已确认总结果为 NG，无需继续遍历。 |
| 481 | `        }` | 代码块结束。 |
| 482 | `    }` | 代码块结束。 |
| 483 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 484 | `    m_running = false;` | 保存动态检测流程是否处于运行中。 |
| 485 | `    m_acceptFrames = false;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 486 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 487 | `    emit logMessage(QString("双产品动态检测完成，总结果=%1。")` | 输出双产品动态检测最终日志。 |
| 488 | `                    .arg(allPass ? "PASS" : "NG"));` | 执行一条语句，完成状态更新、函数调用或参数传递。 |
| 489 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 490 | `    emit allFinished(allPass, m_finishedResults);` | 保存已经完成并上报的产品结果。 |
| 491 | `}` | 代码块结束。 |
| 492 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.33. 动态检测被停止或超时时，构造中止结果并发送 allFinished(false)。（第 493-510 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 493 | `void DynamicTestController::emitAbortResults(const QString &message)` | 动态检测被停止或超时时，构造中止结果并发送 allFinished(false)。 |
| 494 | `{` | 代码块开始。 |
| 495 | `    QVector<DynamicProductResult> results;` | 创建中止结果集合，用于手动停止或超时场景。 |
| 496 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 497 | `    if (m_product1.isConfigured()) {` | 保存位置1的动态产品上下文。 |
| 498 | `        results.append(m_product1.buildResult(message));` | 保存位置1的动态产品上下文。 |
| 499 | `    }` | 代码块结束。 |
| 500 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 501 | `    if (m_product2.isConfigured()) {` | 保存位置2的动态产品上下文。 |
| 502 | `        results.append(m_product2.buildResult(message));` | 保存位置2的动态产品上下文。 |
| 503 | `    }` | 代码块结束。 |
| 504 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 505 | `    m_running = false;` | 保存动态检测流程是否处于运行中。 |
| 506 | `    m_acceptFrames = false;` | 保存是否开始接收并处理检测帧；用于屏蔽复位/启动前的残留帧。 |
| 507 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |
| 508 | `    emit allFinished(false, results);` | 发出动态检测中止完成信号，总结果固定为 false。 |
| 509 | `}` | 代码块结束。 |
| 510 | &nbsp; | 空行，用于分隔代码块，提高可读性。 |

### 4.34. 把 CAN ID 转为统一格式字符串，主要用于日志。（第 511-514 行）

| 行号 | 代码 | 解释 |
|---:|---|---|
| 511 | `QString DynamicTestController::canIdText(quint32 canId) const` | 把 CAN ID 转为统一格式字符串，主要用于日志。 |
| 512 | `{` | 代码块开始。 |
| 513 | `    return DynamicProtocol::canIdToString(canId);` | 调用协议工具函数把 CAN ID 转成字符串。 |
| 514 | `}` | 代码块结束。 |

## 5. 当前 controller 代码中的关键状态变量

| 变量 | 含义 | 对流程的影响 |
|---|---|---|
| `m_canDevice` | ZLG CAN 设备封装指针 | 负责打开设备、发送帧、接收帧。 |
| `m_canOpen` | CAN 打开状态 | UI 可据此显示连接状态。 |
| `m_running` | 动态检测是否正在运行 | 防止重复启动、控制收帧和超时处理。 |
| `m_acceptFrames` | 是否接受本轮检测帧 | 启动前为 false，发送开始帧前置 true，用于过滤残留帧。 |
| `m_timeoutMs` | 超时时间 | `m_timeoutTimer` 到时后触发 `onTimeout()`。 |
| `m_nextSeed` | 下一次分配 seed | 每个产品 setup 时调用 `nextSeed()` 分配。 |
| `m_itemMetas` | 动态检测项配置 | 传入 `DynamicProductContext`，决定 flagSeq/valueSeq 和判定项。 |
| `m_product1` / `m_product2` | 两个产品上下文 | 真正缓存 CAN 帧、判断单产品完成、生成结果。 |
| `m_finishedResults` | 已完成产品结果集合 | 两个产品都完成后通过 `allFinished` 输出。 |

## 6. 当前 controller 与 product context 的边界

- controller 只负责“流程调度”和“双产品完成汇总”。
- 单帧是否属于当前产品、seed 是否正确、groupCnt 是否混组、DetectInProgressFlag 是否到 100、是否满足 `hasRequiredFrames()`，这些都在 `DynamicProductContext::handleFrame()` 及其内部函数处理。
- 因此，如果后续排查 `valueSeq=45/49` 收不到，controller 侧重点看 `m_acceptFrames` 是否过早关闭、`clearBuffer()` 是否清掉了不该清的帧、`onFrameReceived()` 是否进入；context 侧重点看 seed、checkOk、groupCnt、m_finalDataMode 和 hasRequiredFrames。
