# 当日计数 + 总结果标签 + 手动动态标准列补丁

## 修改文件

```text
modified_files/mainwindow.h
modified_files/mainwindow.cpp
modified_files/manualdynamictestwindow.cpp
```

直接用 `modified_files` 里的文件覆盖工程同名文件即可。

## 修改点 1：当日测试计数

主界面右上状态区域新增：

```text
今日计数：总数 N  良品 N  不良 N  阻容不良 N  动态不良 N
```

计数逻辑：

```text
1. 按产品位置计数，位置1和位置2分别计 1 个产品；
2. 静态阻容结果和动态结果都 PASS，记为良品；
3. 任一环节 NG，记为不良；
4. 阻容有 NG，阻容不良 +1；
5. 动态有 NG，动态不良 +1；
6. 同一产品如果阻容和动态都 NG，不良只 +1，但阻容不良和动态不良各 +1；
7. 中断、超时、未完成的动态结果不计入当日统计。
```

持久化逻辑：

```text
1. 使用 QSettings 保存；
2. 上位机重启后计数不清零；
3. 日期变化后自动清零；
4. 程序运行跨 24:00 时，最多 1 分钟内自动清零。
```

QSettings key：

```text
dailyCounter/date
dailyCounter/total
dailyCounter/good
dailyCounter/bad
dailyCounter/staticNg
dailyCounter/dynamicNg
```

## 修改点 2：阻容/动态总结果标签不再遮挡文字

原来 `setOverallResultLabel()` 会把标签直接改成：

```text
PASS
NG
```

现在改成：

```text
阻容：PASS
阻容：NG
动态：PASS
动态：NG
```

并把字体从 30px 降到 20px，避免挡住原有文字。

## 修改点 3：手动动态测试增加“检测标准”列

`manualdynamictestwindow.cpp` 中：

```text
tblResult 列数 9 -> 10
新增表头：检测标准
新增显示：item.standardText
```

## .pro 不需要修改

本补丁没有新增源文件或头文件，因此 `.pro` 不需要修改。
