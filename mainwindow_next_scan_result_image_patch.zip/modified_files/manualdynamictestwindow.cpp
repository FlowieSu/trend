#include "manualdynamictestwindow.h"
#include "ui_manualdynamictestwindow.h"

#include "dynamic_test_controller.h"

#include <QDateTime>
#include <QMessageBox>
#include <QTableWidgetItem>

ManualDynamicTestWindow::ManualDynamicTestWindow(DynamicTestController *controller,
                                                 const DynamicParamConfig &config,
                                                 const QString &productCode1,
                                                 const QString &productCode2,
                                                 QWidget *parent)
    : QWidget(parent),
      ui(new Ui::ManualDynamicTestWindow),
      m_controller(controller),
      m_config(config)
{
    ui->setupUi(this);

    initUi(productCode1, productCode2);
    initConnections();

    appendLog("手动动态测试窗口已打开。");
}

ManualDynamicTestWindow::~ManualDynamicTestWindow()
{
    delete ui;
}

void ManualDynamicTestWindow::initUi(const QString &productCode1,
                                     const QString &productCode2)
{
    initResultTable();

    ui->editProductCode1->setText(productCode1);
    ui->editProductCode2->setText(productCode2);

    ui->editProductCode1->setMaxLength(18);
    ui->editProductCode2->setMaxLength(18);

    ui->lblProduct1Status->setText("位置1：未开始");
    ui->lblProduct2Status->setText("位置2：未开始");
    ui->lblOverallStatus->setText("总结果：-");

    ui->lblParamInfo->setText(QString("位置1：%1 threshold=%2；位置2：%3 threshold=%4")
                              .arg(DynamicProtocol::channelName(m_config.position1Channel))
                              .arg(m_config.position1ThresholdFlag)
                              .arg(DynamicProtocol::channelName(m_config.position2Channel))
                              .arg(m_config.position2ThresholdFlag));

    setRunningState(false);
}

void ManualDynamicTestWindow::initResultTable()
{
    ui->tblResult->setColumnCount(10);

    QStringList headers;
    headers << "位置"
            << "产品编码"
            << "通道"
            << "检测进度"
            << "检测项编号"
            << "检测项名称"
            << "检测值"
            << "单位"
            << "检测标准"
            << "结果";

    ui->tblResult->setHorizontalHeaderLabels(headers);
    ui->tblResult->horizontalHeader()->setStretchLastSection(true);
    ui->tblResult->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tblResult->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tblResult->setAlternatingRowColors(true);
}

void ManualDynamicTestWindow::initConnections()
{
    connect(ui->btnStart,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onStartClicked);

    connect(ui->btnStop,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onStopClicked);

    connect(ui->btnClear,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onClearClicked);

    if (!m_controller) {
        return;
    }

    connect(m_controller,
            &DynamicTestController::logMessage,
            this,
            &ManualDynamicTestWindow::appendLog);

    connect(m_controller,
            &DynamicTestController::productProgressChanged,
            this,
            &ManualDynamicTestWindow::onProductProgressChanged);

    connect(m_controller,
            &DynamicTestController::productFinished,
            this,
            &ManualDynamicTestWindow::onProductFinished);

    connect(m_controller,
            &DynamicTestController::allFinished,
            this,
            &ManualDynamicTestWindow::onAllFinished);
}

void ManualDynamicTestWindow::onStartClicked()
{
    if (!m_controller) {
        QMessageBox::warning(this, "提示", "动态检测控制器为空。");
        return;
    }

    if (!m_controller->isCanOpen()) {
        QMessageBox::warning(this, "提示", "请先在“调试 -> 设备连接”中连接 CAN。");
        return;
    }

    QString productCode1;
    QString productCode2;

    if (!validateProductCodes(&productCode1, &productCode2)) {
        return;
    }

    if (m_config.position1Channel == m_config.position2Channel) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能使用同一个动态发送通道，请先修改动态检测参数配置。");
        return;
    }

    clearResultTable();

    ui->lblProduct1Status->setText("位置1：检测中");
    ui->lblProduct2Status->setText("位置2：检测中");
    ui->lblOverallStatus->setText("总结果：检测中");

    setRunningState(true);

    m_controller->startDynamicTestWithChannels(productCode1,
                                               m_config.position1Channel,
                                               m_config.position1ThresholdFlag,
                                               productCode2,
                                               m_config.position2Channel,
                                               m_config.position2ThresholdFlag);
}

void ManualDynamicTestWindow::onStopClicked()
{
    if (m_controller) {
        m_controller->requestStop();
    }
}

void ManualDynamicTestWindow::onClearClicked()
{
    clearResultTable();

    ui->lblProduct1Status->setText("位置1：未开始");
    ui->lblProduct2Status->setText("位置2：未开始");
    ui->lblOverallStatus->setText("总结果：-");

    appendLog("手动动态检测显示结果已清空。");
}

void ManualDynamicTestWindow::onProductProgressChanged(int productId,
                                                       int progress,
                                                       int groupCnt)
{
    const QString text =
            QString("位置%1：检测中，进度=%2%，轮询组=%3")
            .arg(productId)
            .arg(progress)
            .arg(groupCnt);

    if (productId == 1) {
        ui->lblProduct1Status->setText(text);
    } else if (productId == 2) {
        ui->lblProduct2Status->setText(text);
    }
}

void ManualDynamicTestWindow::onProductFinished(DynamicProductResult result)
{
    displayProductResult(result);

    if (result.productId == 1) {
        ui->lblProduct1Status->setText(QString("位置1：完成，%1")
                                       .arg(passText(result.pass)));
    } else if (result.productId == 2) {
        ui->lblProduct2Status->setText(QString("位置2：完成，%1")
                                       .arg(passText(result.pass)));
    }
}

void ManualDynamicTestWindow::onAllFinished(bool allPass,
                                            QVector<DynamicProductResult> results)
{
    clearResultTable();

    for (const DynamicProductResult &result : results) {
        displayProductResult(result);
    }

    ui->lblOverallStatus->setText(QString("总结果：%1").arg(passText(allPass)));

    setRunningState(false);

    appendLog(QString("手动动态检测结束，总结果：%1。")
              .arg(passText(allPass)));
}

void ManualDynamicTestWindow::appendLog(const QString &message)
{
    const QString timeText =
            QDateTime::currentDateTime().toString("HH:mm:ss.zzz");

    ui->txtLog->append(QString("[%1] %2").arg(timeText, message));
}

bool ManualDynamicTestWindow::validateProductCodes(QString *productCode1,
                                                   QString *productCode2) const
{
    const QString code1 = ui->editProductCode1->text().trimmed();
    const QString code2 = ui->editProductCode2->text().trimmed();

    if (code1.length() != 18) {
        QMessageBox::warning(const_cast<ManualDynamicTestWindow *>(this),
                             "提示",
                             "位置1条码必须为18位。");
        return false;
    }

    if (code2.length() != 18) {
        QMessageBox::warning(const_cast<ManualDynamicTestWindow *>(this),
                             "提示",
                             "位置2条码必须为18位。");
        return false;
    }

    if (productCode1) {
        *productCode1 = code1;
    }

    if (productCode2) {
        *productCode2 = code2;
    }

    return true;
}

void ManualDynamicTestWindow::displayProductResult(const DynamicProductResult &result)
{
    for (const DynamicItemResult &item : result.itemResults) {
        addResultRow(result, item);
    }
}

void ManualDynamicTestWindow::addResultRow(const DynamicProductResult &product,
                                           const DynamicItemResult &item)
{
    const int row = ui->tblResult->rowCount();
    ui->tblResult->insertRow(row);

    auto setItem = [this, row](int column, const QString &text) {
        ui->tblResult->setItem(row, column, new QTableWidgetItem(text));
    };

    setItem(0, QString("位置%1").arg(product.productId));
    setItem(1, product.productCode);
    setItem(2, product.channelName);
    setItem(3, QString::number(product.detectProgress));
    setItem(4, QString::number(item.itemNo));
    setItem(5, item.itemName);
    setItem(6, QString::number(item.rawValue));
    setItem(7, item.unit);
    setItem(8, item.standardText);
    setItem(9, passText(item.pass));

    setRowColor(row, item.pass);
}

void ManualDynamicTestWindow::clearResultTable()
{
    ui->tblResult->setRowCount(0);
}

void ManualDynamicTestWindow::setRunningState(bool running)
{
    m_running = running;

    ui->btnStart->setEnabled(!running);
    ui->btnStop->setEnabled(running);
    ui->btnClear->setEnabled(!running);

    ui->editProductCode1->setEnabled(!running);
    ui->editProductCode2->setEnabled(!running);
}

void ManualDynamicTestWindow::setRowColor(int row, bool pass)
{
    const QColor color = pass ? QColor(0, 128, 0) : QColor(200, 0, 0);

    for (int col = 0; col < ui->tblResult->columnCount(); ++col) {
        QTableWidgetItem *it = ui->tblResult->item(row, col);
        if (it) {
            it->setForeground(color);
        }
    }
}

QString ManualDynamicTestWindow::passText(bool pass) const
{
    return pass ? "PASS" : "NG";
}
