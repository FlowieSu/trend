# MainWindow 下一次扫码清空旧条码 + 自动测试完成显示 PASS/NG 图片补丁

基于上一版 `mainwindow_single_daily_statistics_integrated_patch` 生成。

## 修改文件

```text
modified_files/mainwindow.h
modified_files/mainwindow.cpp
modified_files/mainwindow.ui
```

## 新增功能 1：自动测试完成后下一次扫码自动清空旧条码

自动化测试完成后执行：

```cpp
prepareNextBarcodeInput();
```

效果：

1. 光标聚焦到 `editProductCode1`；
2. 选中位置1旧条码；
3. 当位置1检测到下一次用户输入时：
   - 清空位置1旧文本；
   - 清空位置2旧文本；
   - 保留这一次已经输入的新内容；
4. 位置1输入满 18 位后，自动聚焦到位置2。

涉及函数：

```cpp
onBarcode1Changed(...)
prepareNextBarcodeInput()
```

注意：连接信号已从 `textChanged` 改成 `textEdited`，避免程序内部 setText/clear 时误触发扫码逻辑。

## 新增功能 2：自动测试完成显示 pass.png / ng.png

`mainwindow.ui` 新增：

```text
lblFinalResultImage
```

自动化测试完成后：

```cpp
showFinalResultImage(finalPass);
```

其中：

```cpp
finalPass = !m_staticHasFailed && !m_dynamicHasFailed;
```

即：

```text
阻容 PASS 且 动态 PASS -> 显示 pass.png
任意一个 NG -> 显示 ng.png
```

点击“开始自动化测试”时执行：

```cpp
hideFinalResultImage();
```

所以开始下一轮会隐藏上一轮图片。

## 图片放置位置

默认查找：

```text
程序运行目录/pass.png
程序运行目录/ng.png
```

也兼容当前工作目录：

```text
./pass.png
./ng.png
```

如果图片没找到，界面会退化显示大号文字 PASS/NG，不影响测试流程。

## 使用方式

1. 用 `modified_files` 中三个文件覆盖工程同名文件；
2. 把 `pass.png` 和 `ng.png` 放到 exe 同目录；
3. 重新运行 qmake；
4. 清理项目；
5. 重新构建。

