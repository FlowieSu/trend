
## 本次修正说明：主界面最终版

请使用：

```text
modified_based_on_full_mainwindow/mainwindow.h
modified_based_on_full_mainwindow/mainwindow.cpp
modified_based_on_full_mainwindow/mainwindow.ui
```

该版本已修正：

```text
主界面不再显示 PLC/仪表连接区域
主界面不再显示 CAN设备连接区域
主界面不再显示日志输出区域
主界面不再显示手动动态/手动阻容/PLC点位测试按钮
主界面不再显示导出阻容CSV/导出动态CSV按钮
主界面不再显示动态通道选择控件
```

这些功能统一入口为：

```text
调试 -> 设备连接
调试 -> 动态检测参数配置
调试 -> 手动动态测试
调试 -> 手动阻容测试
调试 -> PLC点位测试
调试 -> 日志输出窗口
```

注意：为了不改当前已经能正常运行的设备连接函数，`mainwindow.cpp` 中仍保留少量隐藏控件作为参数缓存，但运行界面上不会显示这些区域。

# 基于 mainwindow_full_regenerated 的修正版代码包

你当前使用的主界面来自 `mainwindow_full_regenerated`，所以这版代码包以它为基线重新整理。

## 这版和上一版的区别

上一版 `mainwindow.ui / mainwindow.cpp` 是独立生成的主界面结构，不适合作为你当前工程的直接基础。

这一版：

- `baseline_mainwindow_full_regenerated/` 保存原始基线；
- `modified_based_on_full_mainwindow/` 是基于该基线改出来的 `mainwindow.h/.cpp/.ui`；
- `patches/` 是相对 `mainwindow_full_regenerated` 的差异补丁；
- `new_files/` 是新增弹窗；
- `modified_files_reference_new_dynamic/` 是仍需配套使用的新动态相关文件。

## 新增文件

```text
new_files/
├── deviceconnectiondialog.h/.cpp/.ui
├── dynamicparamconfigdialog.h/.cpp/.ui
└── logwindow.h/.cpp/.ui
```

### deviceconnectiondialog

对应菜单：

```text
调试 -> 设备连接
```

只负责收集连接参数：

```text
PLC：COM口
万用表/电桥：VISA地址
CAN：ZlgCanOpenConfig
```

主界面里的原连接函数不删除。  
`MainWindow` 中的新槽函数会继续使用当前能跑的连接逻辑。

### dynamicparamconfigdialog

对应菜单：

```text
调试 -> 动态检测参数配置
```

包含：

```text
位置1发送报文：110 / 112 / 114 / 116
位置1 thresholdFlag，默认 2

位置2发送报文：110 / 112 / 114 / 116
位置2 thresholdFlag，默认 2
```

### logwindow

对应菜单：

```text
调试 -> 日志输出窗口
```

主界面日志会同步转发到这个窗口。

## 修改文件

### 1. mainwindow.h/.cpp/.ui

路径：

```text
modified_based_on_full_mainwindow/
├── mainwindow.h
├── mainwindow.cpp
└── mainwindow.ui
```

修改点：

```text
1. 在原 mainwindow_full_regenerated 基础上新增“调试”菜单
2. 隐藏原主界面的设备连接按钮、手动按钮、CSV导出按钮、动态通道选择控件
3. 新增顶部状态栏：
   - 当前测试
   - QProgressBar测试进度
   - 接插件插拔次数
   - 测试时长
   - 阻容PASS/NG
   - 动态PASS/NG
4. 位置1条码限制18位，输入满18位自动跳到位置2
5. 紧急关闭伺服按钮变红
6. 阻容完成后进度条到50%，自动保存阻容结果
7. 动态完成后进度条到100%，自动保存动态结果
8. 动态表格显示字段简化
9. PASS行绿色，NG行红色
10. 自动测试启动动态时，使用“动态检测参数配置”里的通道和 thresholdFlag
```

注意：  
这版没有删除 `onConnectDevices()`、`onConnectCan()`、`prepareStaticMode()`、`prepareDynamicMode()`、`finishDynamicMode()` 等原流程函数。

### 2. 新动态相关文件

路径：

```text
modified_files_reference_new_dynamic/
```

其中这些文件要配套使用：

```text
dynamic_test_controller.h/.cpp
dynamic_protocol.cpp
dynamic_csv_exporter.h/.cpp
csv_exporter.h/.cpp
manualdynamictestwindow.h/.cpp/.ui
```

它们不再引用：

```text
usbcanfd_200u
sensor
AllInfo
```

## 关键原则

这版只做：

```text
界面入口迁移
参数配置外置
结果显示简化
自动保存
统计和状态显示
```

不改：

```text
PLC动作顺序
M19/M20/M26/M27/M100逻辑
阻容测试流程
动态测试接收解析流程
CAN底层收发逻辑
```

## 合并建议

1. 先备份你当前工程。
2. 使用 `modified_based_on_full_mainwindow/` 替换当前 `mainwindow.h/.cpp/.ui`。
3. 加入 `new_files/` 三个窗口文件。
4. 使用 `modified_files_reference_new_dynamic/` 中的新动态相关文件替换对应文件。
5. 修改 `.pro`，加入新增窗口文件。
6. 编译。
7. 先只验证：
   - 主界面能打开；
   - 调试菜单存在；
   - 设备连接窗口能打开；
   - 动态参数配置窗口能打开。
8. 再验证：
   - CAN连接；
   - 手动动态；
   - 阻容；
   - 完整自动化流程。
