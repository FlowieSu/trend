#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include <QVector>
#include <QString>
#include <QElapsedTimer>
#include <QTimer>

#include "test_runner.h"
#include "dynamic_result_types.h"
#include "dynamic_protocol.h"
#include "zlg_can_device.h"
#include "dynamicparamconfigdialog.h"

class QThread;
class QCloseEvent;
class QTableWidget;
class QLabel;

class MitsubishiPLC;
class SCPIController;
class TestRunner;
class DynamicTestController;
class ManualDynamicTestWindow;
class DeviceConnectionDialog;
class DynamicParamConfigDialog;
class LogWindow;

namespace Ui {
class MainWindow;
}

/*
 * MainWindow
 *
 * ECPS 静态阻容 + 动态 CAN 检测一体化主界面。
 *
 * 保留内容：
 * 1. PLC 连接；
 * 2. 万用表/电桥连接；
 * 3. 自动阻容测试；
 * 4. 手动阻容窗口入口；
 * 5. PLC 点位测试窗口入口；
 * 6. 阻容结果显示和 CSV 导出。
 *
 * 新增/更新内容：
 * 1. CAN 设备类型选择：USBCANFD-200U / USBCAN-II+；
 * 2. 动态通道选择：0x110/0x112/0x114/0x116；
 * 3. 动态结果按检测项明细显示；
 * 4. 动态结果按检测项明细保存 CSV；
 * 5. 使用 DynamicTestController + ZlgCanDevice + DynamicProductContext 新链路。
 *
 * 点位约定：
 * M19  ：阻容测试总使能
 * M20  ：测试位置选择，OFF=位置1，ON=位置2
 * M100 ：阻容测试通道复位脉冲
 * M26  ：映射 Y26，OFF=阻容测试线路，ON=动态测试线路
 * M27  ：映射 Y27，OFF=伺服关闭，ON=伺服打开
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onRefreshPorts();
    void onConnectDevices();

    void onConnectCan();
    void onDisconnectCan();
    void onCanConnectedChanged(bool connected);

    void onStartAutoTest();
    void onStopTest();

    void onOpenManualStaticTestWindow();
    void onOpenManualDynamicTestWindow();
    void onOpenPlcTestWindow();

    void onEmergencyStop();
    void onExportStaticCsv();
    void onExportDynamicCsv();
    void onClearResults();

    void onActionDeviceConnectionTriggered();
    void onActionDynamicParamConfigTriggered();
    void onActionManualDynamicTestTriggered();
    void onActionManualStaticTestTriggered();
    void onActionPlcPointTestTriggered();
    void onActionLogWindowTriggered();

    void onDeviceDialogConnectPlcRequested(QString portName);
    void onDeviceDialogConnectMeterRequested(QString visaAddress);
    void onDeviceDialogConnectCanRequested(ZlgCanOpenConfig config);
    void onDeviceDialogCloseCanRequested();

    void onBarcode1Changed(const QString &text);
    void updateTestDuration();

    void onStaticTestStarted(const QString &testName);
    void onStaticTestCompleted(const QString &testName,
                               int position,
                               const QString &standardText,
                               double forwardResistanceKOhm,
                               double reverseResistanceKOhm,
                               double forwardCapacitanceNf,
                               double reverseCapacitanceNf,
                               bool pass,
                               const QString &message);
    void onStaticTestResultReady(const StaticTestResult &result);
    void onStaticTestsFinished(bool interrupted, bool hasFailed);

    void onDynamicLogMessage(const QString &message);
    void onDynamicProductProgressChanged(int productId,
                                         int progress,
                                         int groupCnt);
    void onDynamicProductFrameUpdated(int productId,
                                      int seq,
                                      int value,
                                      int groupCnt);
    void onDynamicProductFinished(DynamicProductResult result);
    void onDynamicAllFinished(bool allPass,
                              QVector<DynamicProductResult> results);

private:
    void initUi();
    void initConnections();
    void initResultTables();
    void initCanUi();
    void initDebugMenu();
    void initProductionStatusUi();
    void refreshSerialPorts();

    bool validateProductCodes();

    bool prepareStaticMode();
    bool prepareDynamicMode();
    void finishDynamicMode();

    bool setDynamicMode(bool on);   // M26 -> Y26
    bool setServoPower(bool on);    // M27 -> Y27

    bool emergencyStopServo(const QString &reason);
    void safeStopAll(const QString &reason);

    QList<int> allStaticTestIndices() const;

    void startStaticAutoTest();
    void startDynamicAutoTest();
    void cleanupStaticThread();

    void addStaticSummaryRow(const QString &testName,
                             int position,
                             const QString &standardText,
                             double forwardResistanceKOhm,
                             double reverseResistanceKOhm,
                             double forwardCapacitanceNf,
                             double reverseCapacitanceNf,
                             bool pass,
                             const QString &message);

    void addDynamicProductResult(const DynamicProductResult &productResult);
    void addDynamicItemResultRow(const DynamicProductResult &productResult,
                                 const DynamicItemResult &itemResult);

    ZlgCanOpenConfig currentCanConfig() const;
    DynamicProtocol::DynamicChannel currentDynamicChannel1() const;
    DynamicProtocol::DynamicChannel currentDynamicChannel2() const;

    QString defaultCsvDir() const;
    bool saveStaticCsv(const QString &filePath);
    bool saveDynamicCsv(const QString &filePath);
    void autoSaveStaticResults();
    void autoSaveDynamicResults(const QVector<DynamicProductResult> &results);

    QString quoteCsvField(const QString &text) const;
    QString formatValue(double value, int precision = 6) const;
    QString positionText(int position) const;
    QString passText(bool pass) const;
    QString boolText(bool value) const;
    QString timestampNow() const;
    QString canIdText(quint32 canId) const;

    void setRowResultColor(QTableWidget *table, int row, bool pass);
    void setOverallResultLabel(QLabel *label, bool pass);
    void resetOverallResultLabel(QLabel *label, const QString &text);

    void startTestDurationTimer();
    void stopTestDurationTimer();
    QString formatDuration(qint64 seconds) const;

    void appendLog(const QString &message);
    void setAutoTestingState(bool running);
    void setCanConnectedState(bool connected);
    void updateOverallStatus(const QString &status);

private:
    Ui::MainWindow *ui = nullptr;

    MitsubishiPLC *m_plc = nullptr;
    SCPIController *m_dmm = nullptr;
    DynamicTestController *m_dynamicController = nullptr;
    ManualDynamicTestWindow *m_manualDynamicWindow = nullptr;
    DeviceConnectionDialog *m_deviceConnectionDialog = nullptr;
    DynamicParamConfigDialog *m_dynamicParamConfigDialog = nullptr;
    LogWindow *m_logWindow = nullptr;

    DynamicParamConfig m_dynamicParamConfig;

    int m_connectorPlugCount = 0;
    QElapsedTimer m_testElapsedTimer;
    QTimer *m_testDurationTimer = nullptr;

    QThread *m_staticThread = nullptr;
    TestRunner *m_staticRunner = nullptr;

    bool m_autoTesting = false;
    bool m_staticHasFailed = false;
    bool m_dynamicHasFailed = false;
    bool m_stopRequested = false;
    bool m_canConnected = false;

    QString m_productCode1;
    QString m_productCode2;

    QVector<StaticTestResult> m_staticResults;
    QVector<DynamicProductResult> m_dynamicResults;
};

#endif // MAINWINDOW_H
