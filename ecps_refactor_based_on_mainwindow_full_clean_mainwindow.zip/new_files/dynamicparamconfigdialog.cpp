#include "dynamicparamconfigdialog.h"
#include "ui_dynamicparamconfigdialog.h"

#include <QComboBox>
#include <QMessageBox>
#include <QSettings>
#include <QVariant>

DynamicParamConfigDialog::DynamicParamConfigDialog(QWidget *parent)
    : QDialog(parent),
      ui(new Ui::DynamicParamConfigDialog)
{
    ui->setupUi(this);

    qRegisterMetaType<DynamicParamConfig>("DynamicParamConfig");

    initUi();
    loadFromSettings();

    connect(ui->btnApply,
            &QPushButton::clicked,
            this,
            &DynamicParamConfigDialog::onApplyClicked);

    connect(ui->btnOk,
            &QPushButton::clicked,
            this,
            &DynamicParamConfigDialog::onOkClicked);

    connect(ui->btnCancel,
            &QPushButton::clicked,
            this,
            &DynamicParamConfigDialog::reject);
}

DynamicParamConfigDialog::~DynamicParamConfigDialog()
{
    delete ui;
}

void DynamicParamConfigDialog::initUi()
{
    auto initCombo = [](QComboBox *combo) {
        combo->clear();
        combo->addItem("发送 110，接收 201",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel110));
        combo->addItem("发送 112，接收 301",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel112));
        combo->addItem("发送 114，接收 401",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel114));
        combo->addItem("发送 116，接收 501",
                       static_cast<int>(DynamicProtocol::DynamicChannel::Channel116));
    };

    initCombo(ui->cmbPosition1Channel);
    initCombo(ui->cmbPosition2Channel);

    ui->cmbPosition1Channel->setCurrentIndex(0);
    ui->cmbPosition2Channel->setCurrentIndex(1);

    ui->spinPosition1ThresholdFlag->setRange(0, 65535);
    ui->spinPosition2ThresholdFlag->setRange(0, 65535);

    /*
     * 最新要求：110 / 112 / 114 / 116 默认 thresholdFlag 均为 2。
     */
    ui->spinPosition1ThresholdFlag->setValue(2);
    ui->spinPosition2ThresholdFlag->setValue(2);
}

DynamicParamConfig DynamicParamConfigDialog::config() const
{
    DynamicParamConfig c;

    c.position1Channel = intToChannel(ui->cmbPosition1Channel->currentData().toInt());
    c.position2Channel = intToChannel(ui->cmbPosition2Channel->currentData().toInt());

    c.position1ThresholdFlag = ui->spinPosition1ThresholdFlag->value();
    c.position2ThresholdFlag = ui->spinPosition2ThresholdFlag->value();

    return c;
}

void DynamicParamConfigDialog::setConfig(const DynamicParamConfig &config)
{
    setComboChannel(ui->cmbPosition1Channel, config.position1Channel);
    setComboChannel(ui->cmbPosition2Channel, config.position2Channel);

    ui->spinPosition1ThresholdFlag->setValue(config.position1ThresholdFlag);
    ui->spinPosition2ThresholdFlag->setValue(config.position2ThresholdFlag);
}

void DynamicParamConfigDialog::onApplyClicked()
{
    const DynamicParamConfig c = config();

    if (c.position1Channel == c.position2Channel) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能选择同一个动态发送报文。");
        return;
    }

    saveToSettings();
    emit configApplied(c);
}

void DynamicParamConfigDialog::onOkClicked()
{
    const DynamicParamConfig c = config();

    if (c.position1Channel == c.position2Channel) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能选择同一个动态发送报文。");
        return;
    }

    saveToSettings();
    emit configApplied(c);
    accept();
}

void DynamicParamConfigDialog::loadFromSettings()
{
    QSettings settings("ECPS", "StaticDynamicTester");

    DynamicParamConfig c;
    c.position1Channel = intToChannel(settings.value("dynamic/position1Channel", 0).toInt());
    c.position2Channel = intToChannel(settings.value("dynamic/position2Channel", 1).toInt());
    c.position1ThresholdFlag = settings.value("dynamic/position1ThresholdFlag", 2).toInt();
    c.position2ThresholdFlag = settings.value("dynamic/position2ThresholdFlag", 2).toInt();

    setConfig(c);
}

void DynamicParamConfigDialog::saveToSettings() const
{
    const DynamicParamConfig c = config();

    QSettings settings("ECPS", "StaticDynamicTester");
    settings.setValue("dynamic/position1Channel", channelToInt(c.position1Channel));
    settings.setValue("dynamic/position2Channel", channelToInt(c.position2Channel));
    settings.setValue("dynamic/position1ThresholdFlag", c.position1ThresholdFlag);
    settings.setValue("dynamic/position2ThresholdFlag", c.position2ThresholdFlag);
}

int DynamicParamConfigDialog::channelToInt(DynamicProtocol::DynamicChannel channel)
{
    return static_cast<int>(channel);
}

DynamicProtocol::DynamicChannel DynamicParamConfigDialog::intToChannel(int value)
{
    switch (value) {
    case 0:
        return DynamicProtocol::DynamicChannel::Channel110;
    case 1:
        return DynamicProtocol::DynamicChannel::Channel112;
    case 2:
        return DynamicProtocol::DynamicChannel::Channel114;
    case 3:
        return DynamicProtocol::DynamicChannel::Channel116;
    default:
        return DynamicProtocol::DynamicChannel::Channel110;
    }
}

void DynamicParamConfigDialog::setComboChannel(QComboBox *combo,
                                               DynamicProtocol::DynamicChannel channel)
{
    const int index = combo->findData(static_cast<int>(channel));
    if (index >= 0) {
        combo->setCurrentIndex(index);
    }
}
