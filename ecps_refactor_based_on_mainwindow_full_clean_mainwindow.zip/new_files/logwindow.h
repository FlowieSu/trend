#ifndef LOGWINDOW_H
#define LOGWINDOW_H

#include <QWidget>

namespace Ui {
class LogWindow;
}

class LogWindow : public QWidget
{
    Q_OBJECT

public:
    explicit LogWindow(QWidget *parent = nullptr);
    ~LogWindow() override;

public slots:
    void appendLog(const QString &message);
    void clearLog();

private:
    Ui::LogWindow *ui = nullptr;
};

#endif // LOGWINDOW_H
