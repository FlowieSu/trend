#include "logwindow.h"
#include "ui_logwindow.h"

#include <QDateTime>

LogWindow::LogWindow(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::LogWindow)
{
    ui->setupUi(this);

    connect(ui->btnClear,
            &QPushButton::clicked,
            this,
            &LogWindow::clearLog);
}

LogWindow::~LogWindow()
{
    delete ui;
}

void LogWindow::appendLog(const QString &message)
{
    const QString timeText =
            QDateTime::currentDateTime().toString("HH:mm:ss.zzz");

    ui->textLog->append(QString("[%1] %2").arg(timeText, message));
}

void LogWindow::clearLog()
{
    ui->textLog->clear();
}
