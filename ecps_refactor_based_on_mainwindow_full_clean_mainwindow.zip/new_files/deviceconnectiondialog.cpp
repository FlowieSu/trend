#include "deviceconnectiondialog.h"
#include "ui_deviceconnectiondialog.h"

#include <QMessageBox>
#include <QSettings>

DeviceConnectionDialog::DeviceConnectionDialog(QWidget *parent)
    : QDialog(parent),
      ui(new Ui::DeviceConnectionDialog)
{
    ui->setupUi(this);

    qRegisterMetaType<ZlgCanOpenConfig>("ZlgCanOpenConfig");

    initUi();
    loadFromSettings();

    connect(ui->btnRefreshPorts,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onRefreshPortsClicked);

    connect(ui->btnConnectPlc,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onConnectPlcClicked);

    connect(ui->btnConnectMeter,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onConnectMeterClicked);

    connect(ui->btnConnectCan,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onConnectCanClicked);

    connect(ui->btnCloseCan,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onCloseCanClicked);

    connect(ui->btnClose,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::close);
}

DeviceConnectionDialog::~DeviceConnectionDialog()
{
    delete ui;
}

void DeviceConnectionDialog::initUi()
{
    setWindowTitle("设备连接");

    ui->lblPlcStatus->setText("PLC：未连接");
    ui->lblMeterStatus->setText("万用表/电桥：未连接");
    ui->lblCanStatus->setText("CAN：未连接");

    ui->editVisaAddress->setPlaceholderText("例如：USB0::0x2A8D::0x0101::MYxxxx::INSTR");

    ui->cmbCanDeviceType->clear();
    ui->cmbCanDeviceType->addItem("USBCANFD-200U",
                                  static_cast<int>(ZlgCanDeviceType::UsbCanFd200U));
    ui->cmbCanDeviceType->addItem("USBCAN-II+",
                                  static_cast<int>(ZlgCanDeviceType::UsbCanIIPlus));

    ui->spinCanDeviceIndex->setRange(0, 16);
    ui->spinCanChannelIndex->setRange(0, 8);

    ui->spinCanBaudRate->setRange(10000, 1000000);
    ui->spinCanBaudRate->setValue(500000);

    ui->spinCanFdAbit->setRange(10000, 1000000);
    ui->spinCanFdAbit->setValue(500000);

    ui->spinCanFdDbit->setRange(10000, 8000000);
    ui->spinCanFdDbit->setValue(2000000);

    ui->chkExtendedFrame->setChecked(true);
    ui->chkSendAsCanFd->setChecked(false);
    ui->chkReceiveCanFd->setChecked(false);
    ui->chkTerminalResistance->setChecked(false);
}

QString DeviceConnectionDialog::plcPortName() const
{
    return ui->cmbPlcPort->currentText().trimmed();
}

QString DeviceConnectionDialog::visaAddress() const
{
    return ui->editVisaAddress->text().trimmed();
}

ZlgCanOpenConfig DeviceConnectionDialog::canConfig() const
{
    ZlgCanOpenConfig config;

    config.deviceType =
            static_cast<ZlgCanDeviceType>(ui->cmbCanDeviceType->currentData().toInt());

    config.deviceIndex = ui->spinCanDeviceIndex->value();
    config.channelIndex = ui->spinCanChannelIndex->value();

    config.canBaudRate = ui->spinCanBaudRate->value();
    config.canFdAbitBaudRate = ui->spinCanFdAbit->value();
    config.canFdDbitBaudRate = ui->spinCanFdDbit->value();

    config.extendedFrame = ui->chkExtendedFrame->isChecked();
    config.sendAsCanFd = ui->chkSendAsCanFd->isChecked();
    config.receiveCanFd = ui->chkReceiveCanFd->isChecked();
    config.terminalResistance = ui->chkTerminalResistance->isChecked();

    return config;
}

void DeviceConnectionDialog::setAvailablePlcPorts(const QStringList &ports)
{
    const QString current = ui->cmbPlcPort->currentText();

    ui->cmbPlcPort->clear();

    if (ports.isEmpty()) {
        ui->cmbPlcPort->addItem("未发现串口");
        return;
    }

    ui->cmbPlcPort->addItems(ports);

    const int index = ui->cmbPlcPort->findText(current);
    if (index >= 0) {
        ui->cmbPlcPort->setCurrentIndex(index);
    }
}

void DeviceConnectionDialog::setPlcStatusText(const QString &text)
{
    ui->lblPlcStatus->setText(text);
}

void DeviceConnectionDialog::setMeterStatusText(const QString &text)
{
    ui->lblMeterStatus->setText(text);
}

void DeviceConnectionDialog::setCanStatusText(const QString &text)
{
    ui->lblCanStatus->setText(text);
}

void DeviceConnectionDialog::onRefreshPortsClicked()
{
    emit refreshPlcPortsRequested();
}

void DeviceConnectionDialog::onConnectPlcClicked()
{
    const QString port = plcPortName();

    if (port.isEmpty() || port == "未发现串口") {
        QMessageBox::warning(this, "提示", "请选择正确的 PLC 串口。");
        return;
    }

    saveToSettings();
    emit connectPlcRequested(port);
}

void DeviceConnectionDialog::onConnectMeterClicked()
{
    const QString visa = visaAddress();

    if (visa.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入万用表/电桥 VISA 地址。");
        return;
    }

    saveToSettings();
    emit connectMeterRequested(visa);
}

void DeviceConnectionDialog::onConnectCanClicked()
{
    saveToSettings();
    emit connectCanRequested(canConfig());
}

void DeviceConnectionDialog::onCloseCanClicked()
{
    emit closeCanRequested();
}

void DeviceConnectionDialog::loadFromSettings()
{
    QSettings settings("ECPS", "StaticDynamicTester");

    ui->editVisaAddress->setText(settings.value("device/visaAddress", "").toString());

    const QString lastPort = settings.value("device/plcPort", "").toString();
    if (!lastPort.isEmpty() && ui->cmbPlcPort->findText(lastPort) < 0) {
        ui->cmbPlcPort->addItem(lastPort);
    }

    const int index = ui->cmbPlcPort->findText(lastPort);
    if (index >= 0) {
        ui->cmbPlcPort->setCurrentIndex(index);
    }

    ui->spinCanDeviceIndex->setValue(settings.value("can/deviceIndex", 0).toInt());
    ui->spinCanChannelIndex->setValue(settings.value("can/channelIndex", 0).toInt());
    ui->spinCanBaudRate->setValue(settings.value("can/baudRate", 500000).toInt());
    ui->spinCanFdAbit->setValue(settings.value("can/abit", 500000).toInt());
    ui->spinCanFdDbit->setValue(settings.value("can/dbit", 2000000).toInt());
    ui->chkExtendedFrame->setChecked(settings.value("can/extendedFrame", true).toBool());
    ui->chkSendAsCanFd->setChecked(settings.value("can/sendAsCanFd", false).toBool());
    ui->chkReceiveCanFd->setChecked(settings.value("can/receiveCanFd", false).toBool());
    ui->chkTerminalResistance->setChecked(settings.value("can/terminalResistance", false).toBool());
}

void DeviceConnectionDialog::saveToSettings() const
{
    QSettings settings("ECPS", "StaticDynamicTester");

    settings.setValue("device/plcPort", plcPortName());
    settings.setValue("device/visaAddress", visaAddress());

    const ZlgCanOpenConfig cfg = canConfig();
    settings.setValue("can/deviceType", static_cast<int>(cfg.deviceType));
    settings.setValue("can/deviceIndex", cfg.deviceIndex);
    settings.setValue("can/channelIndex", cfg.channelIndex);
    settings.setValue("can/baudRate", cfg.canBaudRate);
    settings.setValue("can/abit", cfg.canFdAbitBaudRate);
    settings.setValue("can/dbit", cfg.canFdDbitBaudRate);
    settings.setValue("can/extendedFrame", cfg.extendedFrame);
    settings.setValue("can/sendAsCanFd", cfg.sendAsCanFd);
    settings.setValue("can/receiveCanFd", cfg.receiveCanFd);
    settings.setValue("can/terminalResistance", cfg.terminalResistance);
}
