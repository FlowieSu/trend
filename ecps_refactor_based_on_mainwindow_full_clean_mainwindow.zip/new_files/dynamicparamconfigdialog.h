#ifndef DYNAMICPARAMCONFIGDIALOG_H
#define DYNAMICPARAMCONFIGDIALOG_H

#include <QDialog>

#include "dynamic_protocol.h"

/*
 * 动态检测参数配置窗口
 *
 * 菜单入口：
 *   调试 -> 动态检测参数配置
 *
 * 当前配置：
 *   位置1发送报文：110 / 112 / 114 / 116
 *   位置1 thresholdFlag，默认 2
 *   位置2发送报文：110 / 112 / 114 / 116
 *   位置2 thresholdFlag，默认 2
 *
 * 注意：
 *   这里不包含 usbcanfd_200u / sensor 旧逻辑。
 *   参数会传给新的 DynamicTestController：
 *
 *   startDynamicTestWithChannels(productCode1,
 *                                channel1,
 *                                thresholdFlag1,
 *                                productCode2,
 *                                channel2,
 *                                thresholdFlag2);
 */

namespace Ui {
class DynamicParamConfigDialog;
}

struct DynamicParamConfig
{
    DynamicProtocol::DynamicChannel position1Channel =
            DynamicProtocol::DynamicChannel::Channel110;

    DynamicProtocol::DynamicChannel position2Channel =
            DynamicProtocol::DynamicChannel::Channel112;

    int position1ThresholdFlag = 2;
    int position2ThresholdFlag = 2;
};

class DynamicParamConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DynamicParamConfigDialog(QWidget *parent = nullptr);
    ~DynamicParamConfigDialog() override;

    DynamicParamConfig config() const;
    void setConfig(const DynamicParamConfig &config);

signals:
    void configApplied(DynamicParamConfig config);

private slots:
    void onApplyClicked();
    void onOkClicked();

private:
    void initUi();
    void loadFromSettings();
    void saveToSettings() const;

    static int channelToInt(DynamicProtocol::DynamicChannel channel);
    static DynamicProtocol::DynamicChannel intToChannel(int value);

    void setComboChannel(class QComboBox *combo,
                         DynamicProtocol::DynamicChannel channel);

private:
    Ui::DynamicParamConfigDialog *ui = nullptr;
};

Q_DECLARE_METATYPE(DynamicParamConfig)

#endif // DYNAMICPARAMCONFIGDIALOG_H
