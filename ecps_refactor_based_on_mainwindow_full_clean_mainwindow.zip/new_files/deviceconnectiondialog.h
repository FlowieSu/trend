#ifndef DEVICECONNECTIONDIALOG_H
#define DEVICECONNECTIONDIALOG_H

#include <QDialog>
#include <QString>
#include <QStringList>

#include "zlg_can_device.h"

/*
 * 设备连接窗口
 *
 * 菜单入口：
 *   调试 -> 设备连接
 *
 * 原则：
 *   不修改现有 PLC / 万用表 / CAN 连接函数。
 *   本窗口只收集参数并发出信号，MainWindow 收到后调用当前已能正常运行的连接函数。
 *
 * 当前实际：
 *   PLC：只传 COM 口；
 *   万用表：只传 VISA 地址；
 *   CAN：使用新动态流程的 ZlgCanOpenConfig。
 */

namespace Ui {
class DeviceConnectionDialog;
}

class DeviceConnectionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DeviceConnectionDialog(QWidget *parent = nullptr);
    ~DeviceConnectionDialog() override;

    QString plcPortName() const;
    QString visaAddress() const;
    ZlgCanOpenConfig canConfig() const;

    void setAvailablePlcPorts(const QStringList &ports);
    void setPlcStatusText(const QString &text);
    void setMeterStatusText(const QString &text);
    void setCanStatusText(const QString &text);

signals:
    void refreshPlcPortsRequested();

    void connectPlcRequested(QString portName);
    void connectMeterRequested(QString visaAddress);
    void connectCanRequested(ZlgCanOpenConfig config);

    void closeCanRequested();

private slots:
    void onRefreshPortsClicked();
    void onConnectPlcClicked();
    void onConnectMeterClicked();
    void onConnectCanClicked();
    void onCloseCanClicked();

private:
    void initUi();
    void loadFromSettings();
    void saveToSettings() const;

private:
    Ui::DeviceConnectionDialog *ui = nullptr;
};

#endif // DEVICECONNECTIONDIALOG_H
