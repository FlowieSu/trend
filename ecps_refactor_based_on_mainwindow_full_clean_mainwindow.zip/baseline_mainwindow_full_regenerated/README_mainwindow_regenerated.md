# 重新生成的主界面文件说明

这组文件是完整主界面，不是动态测试单独示例。

保留内容：
- PLC 连接
- 万用表/电桥连接
- 自动阻容测试
- 阻容结果表
- 阻容 CSV 导出
- 手动阻容测试窗口入口
- PLC 点位测试窗口入口
- 自动化测试流程中的 PLC 安全动作

新增/更新内容：
- CAN 设备选择：USBCANFD-200U / USBCAN-II+
- CAN 连接/断开
- 位置1/位置2动态通道选择
- 动态检测明细结果表
- 动态 CSV 明细导出
- 使用新的 DynamicTestController / ZlgCanDevice / DynamicProductResult

依赖：
- dynamic_test_controller.h/.cpp 需要使用新版，即包含 openCanDevice、closeCanDevice、startDynamicTestWithChannels、productFinished、allFinished 等接口。
- manualdynamictestwindow.h/.cpp 需要使用新版构造函数：ManualDynamicTestWindow(DynamicTestController*, QString, QString, QWidget*)。
- zlg_can_device.h/.cpp、dynamic_protocol、dynamic_product_context、dynamic_csv_exporter 等动态文件需要加入工程。

注意：
- M26/M27 按 setMRelay(26/27) 控制，不再调用 setYRelay。
- 如果现场使用标准帧，请在界面取消“扩展帧”。
