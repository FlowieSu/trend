#include "csv_exporter.h"

#include <QCoreApplication>
#include <QDate>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStringList>
#include <QTextStream>

#include <cmath>

bool CsvExporter::exportStaticResults(const QVector<StaticTestResult> &results,
                                      const QString &filePath,
                                      QString *errorMessage)
{
    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        setError(errorMessage, QString("阻容CSV打开失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("GBK");
#endif

    out << headerLine() << "\n";

    const QStringList lines = recordLines(results);
    for (const QString &line : lines) {
        out << line << "\n";
    }

    return true;
}

bool CsvExporter::appendStaticResults(const QVector<StaticTestResult> &results,
                                      const QString &filePath,
                                      QString *errorMessage)
{
    return appendLinesGbk(filePath,
                          headerLine(),
                          recordLines(results),
                          errorMessage);
}

bool CsvExporter::autoSaveStaticResultsForPosition(const QVector<StaticTestResult> &allResults,
                                                   int position,
                                                   const QString &productCode,
                                                   QString *savedFilePath,
                                                   QString *errorMessage)
{
    QVector<StaticTestResult> rows;

    for (const StaticTestResult &r : allResults) {
        if (r.position == position) {
            rows.append(r);
        }
    }

    if (rows.isEmpty()) {
        setError(errorMessage, QString("位置%1没有阻容测试结果。").arg(position));
        return false;
    }

    const QString filePath = autoFilePath(productCode);

    const bool ok = appendStaticResults(rows,
                                        filePath,
                                        errorMessage);

    if (ok && savedFilePath) {
        *savedFilePath = filePath;
    }

    return ok;
}

QString CsvExporter::defaultResultDir()
{
    const QString resultDir =
            QDir(QCoreApplication::applicationDirPath()).filePath("results");

    QDir().mkpath(resultDir);

    return resultDir;
}

QString CsvExporter::buildStaticFileName(const QString &productCode1,
                                         const QString &productCode2)
{
    return QString("阻容测试结果_%1_%2_%3.csv")
            .arg(productCode1.trimmed().isEmpty() ? "位置1" : productCode1.trimmed())
            .arg(productCode2.trimmed().isEmpty() ? "位置2" : productCode2.trimmed())
            .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"));
}

QString CsvExporter::headerLine()
{
    return "测试类型,产品编码,测试位置,测试项,测试方向,M点,测试标准,电阻/kOhm,电容/nF,电阻结果,电容结果,总结果,备注,测试时间";
}

QStringList CsvExporter::recordLines(const QVector<StaticTestResult> &results)
{
    QStringList lines;

    for (const StaticTestResult &r : results) {
        QStringList cols;

        cols << quoteCsvField("阻容测试")
             << quoteCsvField(r.productCode)
             << quoteCsvField(positionText(r.position))
             << quoteCsvField(r.testName)
             << quoteCsvField(r.directionName)
             << quoteCsvField(r.mPointsText)
             << quoteCsvField(r.standardText)
             << quoteCsvField(formatValue(r.resistanceKOhm))
             << quoteCsvField(formatValue(r.capacitanceNf))
             << quoteCsvField(passText(r.resistancePass))
             << quoteCsvField(passText(r.capacitancePass))
             << quoteCsvField(passText(r.pass))
             << quoteCsvField(r.message)
             << quoteCsvField(r.timestamp);

        lines << cols.join(",");
    }

    return lines;
}

QString CsvExporter::quoteCsvField(const QString &text)
{
    QString escaped = text;
    escaped.replace("\"", "\"\"");

    if (escaped.contains(",")
            || escaped.contains("\"")
            || escaped.contains("\n")
            || escaped.contains("\r")) {
        escaped = "\"" + escaped + "\"";
    }

    return escaped;
}

QString CsvExporter::formatValue(double value, int precision)
{
    if (value < 0.0 || !std::isfinite(value)) {
        return "-";
    }

    return QString::number(value, 'f', precision);
}

QString CsvExporter::passText(bool pass)
{
    return pass ? "PASS" : "NG";
}

QString CsvExporter::positionText(int position)
{
    return position == 2 ? "位置2" : "位置1";
}

QString CsvExporter::timestampNow()
{
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
}

QString CsvExporter::autoFilePath(const QString &productCode)
{
    const QString rootDir = "D:/阻容测试结果";
    const QString dir = monthlyDir(rootDir);
    const QString dateText = QDate::currentDate().toString("yyyyMMdd");

    const QString fileName = QString("%1_阻容测试_%2.csv")
                             .arg(safeFileNamePart(productCode))
                             .arg(dateText);

    return QDir(dir).filePath(fileName);
}

QString CsvExporter::monthlyDir(const QString &rootDir)
{
    const QDate now = QDate::currentDate();

    const QString monthDir =
            QString("%1年%2月")
            .arg(now.year())
            .arg(now.month(), 2, 10, QLatin1Char('0'));

    return QDir(rootDir).filePath(monthDir);
}

QString CsvExporter::safeFileNamePart(const QString &text)
{
    QString s = text.trimmed();

    if (s.isEmpty()) {
        s = "未扫码";
    }

    const QString invalid = "\\/:*?\"<>|";
    for (const QChar &ch : invalid) {
        s.replace(ch, "_");
    }

    return s;
}

bool CsvExporter::ensureParentDir(const QString &filePath,
                                  QString *errorMessage)
{
    const QFileInfo info(filePath);
    const QString dirPath = info.absolutePath();

    if (dirPath.isEmpty()) {
        return true;
    }

    QDir dir;

    if (!dir.mkpath(dirPath)) {
        setError(errorMessage, QString("创建CSV目录失败：%1").arg(dirPath));
        return false;
    }

    return true;
}

bool CsvExporter::appendLinesGbk(const QString &filePath,
                                 const QString &header,
                                 const QStringList &lines,
                                 QString *errorMessage)
{
    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    const bool fileExists = QFile::exists(filePath);

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        setError(errorMessage, QString("CSV打开失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("GBK");
#endif

    if (!fileExists || file.size() == 0) {
        out << header << "\n";
    }

    for (const QString &line : lines) {
        out << line << "\n";
    }

    return true;
}

void CsvExporter::setError(QString *errorMessage,
                           const QString &message)
{
    if (errorMessage) {
        *errorMessage = message;
    }
}
