#ifndef CSV_EXPORTER_H
#define CSV_EXPORTER_H

#include <QString>
#include <QVector>

#include "test_runner.h"

/*
 * CsvExporter
 *
 * 只处理阻容测试 CSV。
 * 动态测试结果由 DynamicCsvExporter 处理。
 *
 * 新增：
 *   autoSaveStaticResultsForPosition()
 *
 * 保存要求：
 *   1. GBK编码；
 *   2. 位置1/2单独保存；
 *   3. 文件名：条码_阻容测试_yyyyMMdd.csv；
 *   4. 路径：D:/阻容测试结果/yyyy年MM月；
 *   5. 同名文件存在时追加记录，不覆盖，不重复写表头；
 *   6. 阻容表头保持原字段不变。
 */
class CsvExporter
{
public:
    static bool exportStaticResults(const QVector<StaticTestResult> &results,
                                    const QString &filePath,
                                    QString *errorMessage = nullptr);

    static bool appendStaticResults(const QVector<StaticTestResult> &results,
                                    const QString &filePath,
                                    QString *errorMessage = nullptr);

    static bool autoSaveStaticResultsForPosition(const QVector<StaticTestResult> &allResults,
                                                 int position,
                                                 const QString &productCode,
                                                 QString *savedFilePath = nullptr,
                                                 QString *errorMessage = nullptr);

    static QString defaultResultDir();

    static QString buildStaticFileName(const QString &productCode1,
                                       const QString &productCode2);

    static QString quoteCsvField(const QString &text);
    static QString formatValue(double value, int precision = 6);
    static QString passText(bool pass);
    static QString positionText(int position);
    static QString timestampNow();

private:
    static QString headerLine();
    static QStringList recordLines(const QVector<StaticTestResult> &results);

    static QString autoFilePath(const QString &productCode);
    static QString monthlyDir(const QString &rootDir);
    static QString safeFileNamePart(const QString &text);

    static bool ensureParentDir(const QString &filePath,
                                QString *errorMessage);

    static bool appendLinesGbk(const QString &filePath,
                               const QString &header,
                               const QStringList &lines,
                               QString *errorMessage);

    static void setError(QString *errorMessage,
                         const QString &message);
};

#endif // CSV_EXPORTER_H
