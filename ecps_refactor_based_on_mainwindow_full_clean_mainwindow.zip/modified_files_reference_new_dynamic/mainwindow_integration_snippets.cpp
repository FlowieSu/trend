/*
 * mainwindow.cpp 增量片段
 *
 * 用法：
 *   复制到你的 MainWindow 中合并，不要盲目整文件覆盖。
 *
 * 本片段只对接新动态流程：
 *   DynamicTestController
 *   DynamicProductResult
 *   DynamicCsvExporter
 *
 * 不引用 usbcanfd_200u / sensor / AllInfo。
 */

#include "deviceconnectiondialog.h"
#include "dynamicparamconfigdialog.h"
#include "logwindow.h"

#include "csv_exporter.h"
#include "dynamic_csv_exporter.h"

#include <QMenuBar>
#include <QSettings>
#include <QSerialPortInfo>
#include <QTableWidgetItem>

/* 构造函数中，ui->setupUi(this) 后增加 */
initDebugMenu();
initProductionUiState();

m_testDurationTimer = new QTimer(this);
connect(m_testDurationTimer,
        &QTimer::timeout,
        this,
        &MainWindow::updateTestDuration);

/* initConnections() 中增加 */
connect(ui->editProductCode1,
        &QLineEdit::textChanged,
        this,
        &MainWindow::onBarcode1Changed);

/* 如果你已有 DynamicTestController 连接，确认使用新信号： */
connect(m_dynamicController,
        &DynamicTestController::productFinished,
        this,
        &MainWindow::onDynamicProductFinished);

connect(m_dynamicController,
        &DynamicTestController::allFinished,
        this,
        &MainWindow::onDynamicAllFinished);

void MainWindow::initDebugMenu()
{
    QMenu *debugMenu = menuBar()->addMenu("调试");

    QAction *actDeviceConnection = debugMenu->addAction("设备连接");
    QAction *actDynamicParamConfig = debugMenu->addAction("动态检测参数配置");
    debugMenu->addSeparator();

    QAction *actManualDynamicTest = debugMenu->addAction("手动动态测试");
    QAction *actManualStaticTest = debugMenu->addAction("手动阻容测试");
    QAction *actPlcPointTest = debugMenu->addAction("PLC点位测试");
    debugMenu->addSeparator();

    QAction *actLogWindow = debugMenu->addAction("日志输出窗口");

    connect(actDeviceConnection,
            &QAction::triggered,
            this,
            &MainWindow::onActionDeviceConnectionTriggered);

    connect(actDynamicParamConfig,
            &QAction::triggered,
            this,
            &MainWindow::onActionDynamicParamConfigTriggered);

    connect(actManualDynamicTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionManualDynamicTestTriggered);

    connect(actManualStaticTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionManualStaticTestTriggered);

    connect(actPlcPointTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionPlcPointTestTriggered);

    connect(actLogWindow,
            &QAction::triggered,
            this,
            &MainWindow::onActionLogWindowTriggered);
}

void MainWindow::initProductionUiState()
{
    ui->editProductCode1->setMaxLength(18);
    ui->editProductCode2->setMaxLength(18);
    ui->editProductCode1->setFocus();

    ui->progressTest->setRange(0, 100);
    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：待机");

    QSettings settings("ECPS", "StaticDynamicTester");
    m_connectorPlugCount =
            settings.value("runtime/connectorPlugCount", 0).toInt();

    ui->lblConnectorPlugCount->setText(
                QString("接插件插拔次数：%1").arg(m_connectorPlugCount));

    ui->lblTestDuration->setText("测试时长：00:00:00");

    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");

    ui->btnEmergencyStop->setStyleSheet(
        "QPushButton {"
        "background-color:#D32F2F;"
        "color:white;"
        "font-weight:bold;"
        "font-size:18px;"
        "border-radius:6px;"
        "padding:8px 16px;"
        "}"
        "QPushButton:pressed { background-color:#B71C1C; }"
    );

    /*
     * 动态显示表头简化。
     */
    ui->tableDynamicResults->clear();
    ui->tableDynamicResults->setColumnCount(9);
    ui->tableDynamicResults->setHorizontalHeaderLabels({
        "位置",
        "产品编码",
        "通道",
        "检测进度",
        "检测项编号",
        "检测项名称",
        "检测值",
        "单位",
        "结果"
    });
}

void MainWindow::onBarcode1Changed(const QString &text)
{
    if (text.length() == 18) {
        ui->editProductCode2->setFocus();
        ui->editProductCode2->selectAll();
    }
}

void MainWindow::onActionDeviceConnectionTriggered()
{
    if (!m_deviceConnectionDialog) {
        m_deviceConnectionDialog = new DeviceConnectionDialog(this);
        m_deviceConnectionDialog->setAttribute(Qt::WA_DeleteOnClose);

        connect(m_deviceConnectionDialog,
                &QObject::destroyed,
                this,
                [this]() {
                    m_deviceConnectionDialog = nullptr;
                });

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::refreshPlcPortsRequested,
                this,
                [this]() {
                    QStringList ports;
                    for (const QSerialPortInfo &port : QSerialPortInfo::availablePorts()) {
                        ports << port.portName();
                    }

                    if (m_deviceConnectionDialog) {
                        m_deviceConnectionDialog->setAvailablePlcPorts(ports);
                    }
                });

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectPlcRequested,
                this,
                &MainWindow::onDeviceDialogConnectPlcRequested);

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectMeterRequested,
                this,
                &MainWindow::onDeviceDialogConnectMeterRequested);

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectCanRequested,
                this,
                &MainWindow::onDeviceDialogConnectCanRequested);

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::closeCanRequested,
                this,
                &MainWindow::onDeviceDialogCloseCanRequested);
    }

    QStringList ports;
    for (const QSerialPortInfo &port : QSerialPortInfo::availablePorts()) {
        ports << port.portName();
    }

    m_deviceConnectionDialog->setAvailablePlcPorts(ports);
    m_deviceConnectionDialog->show();
    m_deviceConnectionDialog->raise();
    m_deviceConnectionDialog->activateWindow();
}

/*
 * 这里调用你当前已经能跑的 PLC 连接函数，不要改底层实现。
 * 下面函数名只是示例，把 m_plc->connectDevice(portName) 替换成你现有函数名。
 */
void MainWindow::onDeviceDialogConnectPlcRequested(QString portName)
{
    appendLog(QString("连接PLC：%1").arg(portName));

    // TODO: 保持你现有能跑的 PLC 连接函数，只把串口参数换成 portName。
    // bool ok = m_plc->connectDevice(portName);

    bool ok = true; // 替换为现有连接结果

    ui->lblPLCStatus->setText(ok ? QString("PLC：已连接 %1").arg(portName)
                                  : QString("PLC：连接失败"));

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setPlcStatusText(ui->lblPLCStatus->text());
    }
}

/*
 * 这里调用你当前已经能跑的万用表连接函数，不要改底层实现。
 */
void MainWindow::onDeviceDialogConnectMeterRequested(QString visaAddress)
{
    appendLog(QString("连接万用表/电桥：%1").arg(visaAddress));

    // TODO: 保持你现有能跑的万用表连接函数，只把参数换成 visaAddress。
    // bool ok = m_dmm->connectInstrument(visaAddress);

    bool ok = true; // 替换为现有连接结果

    ui->lblDMMStatus->setText(ok ? "万用表/电桥：已连接"
                                  : "万用表/电桥：连接失败");

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setMeterStatusText(ui->lblDMMStatus->text());
    }
}

void MainWindow::onDeviceDialogConnectCanRequested(ZlgCanOpenConfig config)
{
    if (!m_dynamicController) {
        appendLog("动态检测控制器为空，CAN连接失败。");
        return;
    }

    const bool ok = m_dynamicController->openCanDevice(config);

    ui->lblCanStatus->setText(ok ? "CAN：已连接" : "CAN：连接失败");

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setCanStatusText(ui->lblCanStatus->text());
    }
}

void MainWindow::onDeviceDialogCloseCanRequested()
{
    if (m_dynamicController) {
        m_dynamicController->closeCanDevice();
    }

    ui->lblCanStatus->setText("CAN：未连接");

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setCanStatusText(ui->lblCanStatus->text());
    }
}

void MainWindow::onActionDynamicParamConfigTriggered()
{
    if (!m_dynamicParamConfigDialog) {
        m_dynamicParamConfigDialog = new DynamicParamConfigDialog(this);
        m_dynamicParamConfigDialog->setAttribute(Qt::WA_DeleteOnClose);
        m_dynamicParamConfigDialog->setConfig(m_dynamicParamConfig);

        connect(m_dynamicParamConfigDialog,
                &QObject::destroyed,
                this,
                [this]() {
                    m_dynamicParamConfigDialog = nullptr;
                });

        connect(m_dynamicParamConfigDialog,
                &DynamicParamConfigDialog::configApplied,
                this,
                [this](DynamicParamConfig config) {
                    m_dynamicParamConfig = config;

                    appendLog(QString("动态参数已应用：位置1=%1 threshold=%2；位置2=%3 threshold=%4。")
                              .arg(DynamicProtocol::channelName(config.position1Channel))
                              .arg(config.position1ThresholdFlag)
                              .arg(DynamicProtocol::channelName(config.position2Channel))
                              .arg(config.position2ThresholdFlag));
                });
    }

    m_dynamicParamConfigDialog->show();
    m_dynamicParamConfigDialog->raise();
    m_dynamicParamConfigDialog->activateWindow();
}

void MainWindow::onActionManualDynamicTestTriggered()
{
    if (!m_dynamicController) {
        QMessageBox::warning(this, "提示", "动态检测控制器未初始化。");
        return;
    }

    auto *window = new ManualDynamicTestWindow(m_dynamicController,
                                               m_dynamicParamConfig,
                                               ui->editProductCode1->text().trimmed(),
                                               ui->editProductCode2->text().trimmed(),
                                               nullptr);

    window->setAttribute(Qt::WA_DeleteOnClose);
    window->show();
    window->raise();
    window->activateWindow();
}

void MainWindow::onActionManualStaticTestTriggered()
{
    onOpenManualStaticTestWindow();
}

void MainWindow::onActionPlcPointTestTriggered()
{
    onOpenPlcTestWindow();
}

void MainWindow::onActionLogWindowTriggered()
{
    if (!m_logWindow) {
        m_logWindow = new LogWindow(nullptr);
        m_logWindow->setAttribute(Qt::WA_DeleteOnClose);

        connect(m_logWindow,
                &QObject::destroyed,
                this,
                [this]() {
                    m_logWindow = nullptr;
                });
    }

    m_logWindow->show();
    m_logWindow->raise();
    m_logWindow->activateWindow();
}

void MainWindow::appendLog(const QString &message)
{
    const QString timeText =
            QDateTime::currentDateTime().toString("HH:mm:ss.zzz");

    /*
     * 如果你已经从主界面删除 textLog，这一段可以删掉。
     */
    if (ui->textLog) {
        ui->textLog->append(QString("[%1] %2").arg(timeText, message));
    }

    if (m_logWindow) {
        m_logWindow->appendLog(message);
    }
}

/*
 * 开始自动化测试函数中，在真正启动流程前增加：
 */
void MainWindow::beforeStartAutoTestUiReset()
{
    ++m_connectorPlugCount;

    QSettings settings("ECPS", "StaticDynamicTester");
    settings.setValue("runtime/connectorPlugCount", m_connectorPlugCount);

    ui->lblConnectorPlugCount->setText(
                QString("接插件插拔次数：%1").arg(m_connectorPlugCount));

    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：阻容测试");

    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");

    startTestDurationTimer();
}

/*
 * 条码检查函数中增加 18 位限制。
 */
bool MainWindow::checkBarcodeLength()
{
    if (ui->editProductCode1->text().trimmed().length() != 18) {
        QMessageBox::warning(this, "提示", "位置1条码必须为18位。");
        return false;
    }

    if (ui->editProductCode2->text().trimmed().length() != 18) {
        QMessageBox::warning(this, "提示", "位置2条码必须为18位。");
        return false;
    }

    return true;
}

/*
 * 阻容单条结果显示时，插入行后加颜色：
 * setRowResultColor(ui->tableStaticResults, row, result.pass);
 */

/*
 * 阻容全部完成时加：
 */
void MainWindow::onStaticAllFinishedUiAppend(bool staticAllPass)
{
    ui->progressTest->setValue(50);
    setOverallResultLabel(ui->lblStaticOverallResult, staticAllPass);
    autoSaveStaticResults();
}

/*
 * 启动动态时，用配置窗口参数，不要再从主界面控件取通道。
 */
void MainWindow::startDynamicByConfiguredParams()
{
    ui->lblCurrentTestStage->setText("当前测试：动态测试");

    m_dynamicController->startDynamicTestWithChannels(ui->editProductCode1->text().trimmed(),
                                                      m_dynamicParamConfig.position1Channel,
                                                      m_dynamicParamConfig.position1ThresholdFlag,
                                                      ui->editProductCode2->text().trimmed(),
                                                      m_dynamicParamConfig.position2Channel,
                                                      m_dynamicParamConfig.position2ThresholdFlag);
}

void MainWindow::onDynamicProductFinished(DynamicProductResult result)
{
    displayDynamicProductResult(result);
}

void MainWindow::onDynamicAllFinished(bool allPass,
                                      QVector<DynamicProductResult> results)
{
    m_lastDynamicResults = results;

    ui->progressTest->setValue(100);
    ui->lblCurrentTestStage->setText("当前测试：测试完成");
    setOverallResultLabel(ui->lblDynamicOverallResult, allPass);

    autoSaveDynamicResults(results);
    stopTestDurationTimer();
}

void MainWindow::displayDynamicProductResult(const DynamicProductResult &result)
{
    for (const DynamicItemResult &item : result.itemResults) {
        const int row = ui->tableDynamicResults->rowCount();
        ui->tableDynamicResults->insertRow(row);

        ui->tableDynamicResults->setItem(row, 0, new QTableWidgetItem(QString("位置%1").arg(result.productId)));
        ui->tableDynamicResults->setItem(row, 1, new QTableWidgetItem(result.productCode));
        ui->tableDynamicResults->setItem(row, 2, new QTableWidgetItem(result.channelName));
        ui->tableDynamicResults->setItem(row, 3, new QTableWidgetItem(QString::number(result.detectProgress)));
        ui->tableDynamicResults->setItem(row, 4, new QTableWidgetItem(QString::number(item.itemNo)));
        ui->tableDynamicResults->setItem(row, 5, new QTableWidgetItem(item.itemName));
        ui->tableDynamicResults->setItem(row, 6, new QTableWidgetItem(QString::number(item.rawValue)));
        ui->tableDynamicResults->setItem(row, 7, new QTableWidgetItem(item.unit));
        ui->tableDynamicResults->setItem(row, 8, new QTableWidgetItem(item.pass ? "PASS" : "NG"));

        setRowResultColor(ui->tableDynamicResults, row, item.pass);
    }
}

void MainWindow::autoSaveStaticResults()
{
    QString path;
    QString error;

    if (CsvExporter::autoSaveStaticResultsForPosition(m_staticResults,
                                                       1,
                                                       ui->editProductCode1->text().trimmed(),
                                                       &path,
                                                       &error)) {
        appendLog(QString("位置1阻容结果已自动保存：%1").arg(path));
    } else {
        appendLog(QString("位置1阻容结果自动保存失败：%1").arg(error));
    }

    if (CsvExporter::autoSaveStaticResultsForPosition(m_staticResults,
                                                       2,
                                                       ui->editProductCode2->text().trimmed(),
                                                       &path,
                                                       &error)) {
        appendLog(QString("位置2阻容结果已自动保存：%1").arg(path));
    } else {
        appendLog(QString("位置2阻容结果自动保存失败：%1").arg(error));
    }
}

void MainWindow::autoSaveDynamicResults(const QVector<DynamicProductResult> &results)
{
    QVector<QString> paths;
    QString error;

    if (DynamicCsvExporter::autoSaveResults(results, &paths, &error)) {
        for (const QString &path : paths) {
            appendLog(QString("动态结果已自动保存：%1").arg(path));
        }
    } else {
        appendLog(QString("动态结果自动保存失败：%1").arg(error));
    }
}

void MainWindow::setRowResultColor(QTableWidget *table, int row, bool pass)
{
    const QColor color = pass ? QColor(0, 128, 0) : QColor(200, 0, 0);

    for (int col = 0; col < table->columnCount(); ++col) {
        QTableWidgetItem *item = table->item(row, col);
        if (item) {
            item->setForeground(color);
        }
    }
}

void MainWindow::setOverallResultLabel(QLabel *label, bool pass)
{
    label->setText(pass ? "PASS" : "NG");
    label->setStyleSheet(pass
                         ? "background-color:#1B5E20;color:white;font-size:30px;font-weight:bold;padding:8px;"
                         : "background-color:#B71C1C;color:white;font-size:30px;font-weight:bold;padding:8px;");
}

void MainWindow::resetOverallResultLabel(QLabel *label, const QString &text)
{
    label->setText(text);
    label->setStyleSheet("background-color:#EEEEEE;color:#333333;font-size:24px;font-weight:bold;padding:8px;");
}

void MainWindow::startTestDurationTimer()
{
    ui->lblTestDuration->setText("测试时长：00:00:00");
    m_testElapsedTimer.restart();

    if (m_testDurationTimer) {
        m_testDurationTimer->start(1000);
    }
}

void MainWindow::stopTestDurationTimer()
{
    if (m_testDurationTimer) {
        m_testDurationTimer->stop();
    }

    updateTestDuration();
}

void MainWindow::updateTestDuration()
{
    const qint64 seconds = m_testElapsedTimer.elapsed() / 1000;
    ui->lblTestDuration->setText(QString("测试时长：%1").arg(formatDuration(seconds)));
}

QString MainWindow::formatDuration(qint64 seconds) const
{
    const qint64 h = seconds / 3600;
    const qint64 m = (seconds % 3600) / 60;
    const qint64 s = seconds % 60;

    return QString("%1:%2:%3")
            .arg(h, 2, 10, QLatin1Char('0'))
            .arg(m, 2, 10, QLatin1Char('0'))
            .arg(s, 2, 10, QLatin1Char('0'));
}
