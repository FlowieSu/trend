#ifndef DYNAMIC_CSV_EXPORTER_H
#define DYNAMIC_CSV_EXPORTER_H

#include <QString>
#include <QVector>

#include "dynamic_result_types.h"

/*
 * DynamicCsvExporter
 *
 * 适配当前新动态测试流程：
 *   DynamicTestController -> DynamicProductResult -> DynamicCsvExporter
 *
 * 不依赖 usbcanfd_200u / sensor / AllInfo。
 *
 * 保存要求：
 *   1. 位置1/位置2单独保存；
 *   2. GBK编码；
 *   3. 文件名：条码_动态测试_yyyyMMdd.csv；
 *   4. 路径：D:/动态测试结果/yyyy年MM月；
 *   5. 文件存在则追加，不覆盖，不重复写表头；
 *   6. 表头只保留简化字段。
 */
class DynamicCsvExporter
{
public:
    static bool exportResults(const QVector<DynamicProductResult> &results,
                              const QString &filePath,
                              QString *errorMessage = nullptr);

    static bool appendProductResult(const DynamicProductResult &result,
                                    const QString &filePath,
                                    QString *errorMessage = nullptr);

    static bool autoSaveProductResult(const DynamicProductResult &result,
                                      QString *savedFilePath = nullptr,
                                      QString *errorMessage = nullptr);

    static bool autoSaveResults(const QVector<DynamicProductResult> &results,
                                QVector<QString> *savedFilePaths = nullptr,
                                QString *errorMessage = nullptr);

    static QString makeDefaultFileName(const QString &directory,
                                       const QString &prefix = "dynamic_result");

private:
    static QString headerLine();
    static QStringList productRecordLines(const DynamicProductResult &result);

    static QString autoFilePath(const QString &productCode);
    static QString monthlyDir(const QString &rootDir);
    static QString safeFileNamePart(const QString &text);

    static bool ensureParentDir(const QString &filePath,
                                QString *errorMessage);

    static bool appendLinesGbk(const QString &filePath,
                               const QString &header,
                               const QStringList &lines,
                               QString *errorMessage);

    static QString escapeCsv(const QString &text);
    static QString boolText(bool value);
    static QString passText(bool pass);
};

#endif // DYNAMIC_CSV_EXPORTER_H
