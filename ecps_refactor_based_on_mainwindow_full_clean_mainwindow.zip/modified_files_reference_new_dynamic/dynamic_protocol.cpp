#include "dynamic_protocol.h"

#include <QStringList>

namespace
{
static int positiveMod(int value, int mod)
{
    int r = value % mod;
    if (r < 0) {
        r += mod;
    }
    return r;
}

static int u8At(const QByteArray &data, int index)
{
    return static_cast<int>(static_cast<unsigned char>(data.at(index)));
}

static int u16LeAt(const QByteArray &data, int index)
{
    const int low = u8At(data, index);
    const int high = u8At(data, index + 1);
    return (high << 8) | low;
}

static int s16LeAt(const QByteArray &data, int index)
{
    const int u = u16LeAt(data, index);
    return static_cast<qint16>(u);
}

static void putU16Le(QByteArray &data, int index, int value)
{
    data[index] = static_cast<char>(value & 0xFF);
    data[index + 1] = static_cast<char>((value >> 8) & 0xFF);
}
}

DynamicProtocol::ChannelConfig DynamicProtocol::channelConfig(DynamicChannel channel)
{
    switch (channel) {
    case DynamicChannel::Channel110:
        return { channel, 0x110, 0x201, 1, 0x0002, "通道110" };

    case DynamicChannel::Channel112:
        return { channel, 0x112, 0x301, 2, 0x0002, "通道112" };

    case DynamicChannel::Channel114:
        return { channel, 0x114, 0x401, 1, 0x0002, "通道114" };

    case DynamicChannel::Channel116:
        return { channel, 0x116, 0x501, 2, 0x0002, "通道116" };
    }

    return {};
}

QString DynamicProtocol::channelName(DynamicChannel channel)
{
    return channelConfig(channel).name;
}

QByteArray DynamicProtocol::buildResetFrame()
{
    QByteArray data;
    data.resize(8);
    data[0] = static_cast<char>(0x00);
    data[1] = static_cast<char>(0xE1);
    data[2] = static_cast<char>(0x00);
    data[3] = static_cast<char>(0x00);
    data[4] = static_cast<char>(0x00);
    data[5] = static_cast<char>(0x00);
    data[6] = static_cast<char>(0x00);
    data[7] = static_cast<char>(0x00);
    return data;
}

QByteArray DynamicProtocol::buildStartFrame(int thresholdFlag,
                                            int seed)
{
    QByteArray data;
    data.resize(8);

    data[0] = static_cast<char>(0x01);
    data[1] = static_cast<char>(0xE1);

    putU16Le(data, 2, thresholdFlag);

    data[4] = static_cast<char>(seed & 0xFF);

    data[5] = static_cast<char>(0x00);
    data[6] = static_cast<char>(0x00);
    data[7] = static_cast<char>(0x00);

    return data;
}

DynamicProtocol::ParsedFrame DynamicProtocol::parseFrame(quint32 canId,
                                                         const QByteArray &data,
                                                         int expectedSeed)
{
    ParsedFrame frame;
    frame.canId = canId;

    if (data.size() < 8) {
        frame.errorMessage = QString("接收帧长度不足 8 字节，当前长度=%1。").arg(data.size());
        return frame;
    }

    frame.seq = u8At(data, 0);
    frame.seed = u8At(data, 1);
    frame.value = s16LeAt(data, 2);
    frame.groupCnt = u16LeAt(data, 4);
    frame.checkValue = u16LeAt(data, 6);

    frame.valid = true;
    frame.seedOk = (frame.seed == (expectedSeed & 0xFF));

    if (!frame.seedOk) {
        frame.errorMessage = QString("seed 不一致：期望=%1，实际=%2。")
                             .arg(expectedSeed & 0xFF)
                             .arg(frame.seed);
        return frame;
    }

    if (isNormalDataSeq(frame.seq)) {
        const int calc = calcSingleFrameCheck(frame.seq,
                                              frame.seed,
                                              frame.value,
                                              frame.groupCnt);
        frame.checkOk = (calc == frame.checkValue);

        if (!frame.checkOk) {
            frame.errorMessage = QString("单帧校验失败：seq=%1，value=%2，group=%3，calc=%4，board=%5。")
                                 .arg(frame.seq)
                                 .arg(frame.value)
                                 .arg(frame.groupCnt)
                                 .arg(calc)
                                 .arg(frame.checkValue);
        }

        return frame;
    }

    if (isGroupCheckSeq(frame.seq)) {
        /*
         * 组校验需要已缓存的 0~60 数据，因此这里只解析，不在这里判断。
         */
        frame.checkOk = true;
        return frame;
    }

    frame.errorMessage = QString("未知数据序号：seq=%1。").arg(frame.seq);
    return frame;
}

int DynamicProtocol::calcSingleFrameCheck(int seq,
                                          int seed,
                                          int value,
                                          int groupCnt)
{
    return positiveMod(seq + seed + value + groupCnt, 30000);
}

int DynamicProtocol::calcGroupCheck(const int values[61],
                                    int seed,
                                    int groupCnt)
{
    int sum = 0;
    for (int i = 0; i <= 60; ++i) {
        sum += values[i];
    }

    return positiveMod(sum + kGroupCheckSeq + seed + groupCnt, 30000);
}

bool DynamicProtocol::isNormalDataSeq(int seq)
{
    return seq >= kMinDataSeq && seq <= kMaxDataSeq;
}

bool DynamicProtocol::isGroupCheckSeq(int seq)
{
    return seq == kGroupCheckSeq;
}

bool DynamicProtocol::isDetectInProgressSeq(int seq)
{
    return seq == kDetectInProgressSeq;
}

QString DynamicProtocol::canIdToString(quint32 canId)
{
    return QString("0x%1").arg(canId, 3, 16, QLatin1Char('0')).toUpper();
}

QString DynamicProtocol::frameDataToString(const QByteArray &data)
{
    QStringList parts;
    parts.reserve(data.size());

    for (unsigned char byte : data) {
        parts << QString("%1")
                 .arg(static_cast<int>(byte), 2, 16, QLatin1Char('0'))
                 .toUpper();
    }

    return parts.join(" ");
}
