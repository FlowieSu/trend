/*
 * mainwindow.h 增量片段
 *
 * 注意：
 *   这是针对新动态流程的片段：
 *   DynamicTestController / DynamicProductResult / DynamicCsvExporter
 *
 *   不包含 usbcanfd_200u / sensor / AllInfo。
 */

#include <QElapsedTimer>
#include <QTimer>

#include "dynamicparamconfigdialog.h"
#include "dynamic_result_types.h"

class DeviceConnectionDialog;
class DynamicParamConfigDialog;
class LogWindow;

/* private slots 增加 */
void onActionDeviceConnectionTriggered();
void onActionDynamicParamConfigTriggered();
void onActionManualDynamicTestTriggered();
void onActionManualStaticTestTriggered();
void onActionPlcPointTestTriggered();
void onActionLogWindowTriggered();

void updateTestDuration();
void onBarcode1Changed(const QString &text);

/* DeviceConnectionDialog 信号对应槽 */
void onDeviceDialogConnectPlcRequested(QString portName);
void onDeviceDialogConnectMeterRequested(QString visaAddress);
void onDeviceDialogConnectCanRequested(ZlgCanOpenConfig config);
void onDeviceDialogCloseCanRequested();

/* private 增加 */
void initDebugMenu();
void initProductionUiState();

void setRowResultColor(QTableWidget *table, int row, bool pass);
void setOverallResultLabel(QLabel *label, bool pass);
void resetOverallResultLabel(QLabel *label, const QString &text);

void startTestDurationTimer();
void stopTestDurationTimer();
QString formatDuration(qint64 seconds) const;

void autoSaveStaticResults();
void autoSaveDynamicResults(const QVector<DynamicProductResult> &results);

void displayDynamicProductResult(const DynamicProductResult &result);

/* private 成员增加 */
DeviceConnectionDialog *m_deviceConnectionDialog = nullptr;
DynamicParamConfigDialog *m_dynamicParamConfigDialog = nullptr;
LogWindow *m_logWindow = nullptr;

DynamicParamConfig m_dynamicParamConfig;

int m_connectorPlugCount = 0;
QElapsedTimer m_testElapsedTimer;
QTimer *m_testDurationTimer = nullptr;

QVector<DynamicProductResult> m_lastDynamicResults;
