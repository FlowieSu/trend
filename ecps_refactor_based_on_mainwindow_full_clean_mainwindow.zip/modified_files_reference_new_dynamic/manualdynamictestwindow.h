#ifndef MANUALDYNAMICTESTWINDOW_H
#define MANUALDYNAMICTESTWINDOW_H

#include <QWidget>
#include <QVector>

#include "dynamicparamconfigdialog.h"
#include "dynamic_result_types.h"

namespace Ui {
class ManualDynamicTestWindow;
}

class DynamicTestController;

/*
 * 手动动态测试窗口
 *
 * 方案 B：
 *   不在窗口里选择 110/112/114/116；
 *   直接使用“动态检测参数配置”中的全局配置；
 *   不依赖 PLC，不操作 M26/M27，只验证动态 CAN 流程。
 */
class ManualDynamicTestWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ManualDynamicTestWindow(DynamicTestController *controller,
                                     const DynamicParamConfig &config,
                                     const QString &productCode1,
                                     const QString &productCode2,
                                     QWidget *parent = nullptr);
    ~ManualDynamicTestWindow() override;

private slots:
    void onStartClicked();
    void onStopClicked();
    void onClearClicked();

    void onProductProgressChanged(int productId,
                                  int progress,
                                  int groupCnt);

    void onProductFinished(DynamicProductResult result);

    void onAllFinished(bool allPass,
                       QVector<DynamicProductResult> results);

    void appendLog(const QString &message);

private:
    void initUi(const QString &productCode1,
                const QString &productCode2);

    void initResultTable();
    void initConnections();

    bool validateProductCodes(QString *productCode1,
                              QString *productCode2) const;

    void displayProductResult(const DynamicProductResult &result);
    void addResultRow(const DynamicProductResult &product,
                      const DynamicItemResult &item);

    void clearResultTable();

    void setRunningState(bool running);
    void setRowColor(int row, bool pass);

    QString passText(bool pass) const;

private:
    Ui::ManualDynamicTestWindow *ui = nullptr;

    DynamicTestController *m_controller = nullptr;
    DynamicParamConfig m_config;

    bool m_running = false;
};

#endif // MANUALDYNAMICTESTWINDOW_H
