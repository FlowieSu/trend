#include "mainwindow.h"

#include "mitsubishi_plc.h"
#include "scpi_controller.h"
#include "test_config.h"

#include <QApplication>
#include <QComboBox>
#include <QDateTime>
#include <QFormLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSerialPortInfo>
#include <QSpinBox>
#include <QStringList>
#include <QTableWidget>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QThread>

#include <cmath>

namespace
{
constexpr int RELAY_STABLE_DELAY_MS = 500;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    m_plc = new MitsubishiPLC(this);
    m_dmm = new SCPIController(this);

    connect(m_plc, &MitsubishiPLC::logMessage,
            this, &MainWindow::appendLog);
    connect(m_dmm, &SCPIController::logMessage,
            this, &MainWindow::appendLog);

    buildUi();
    refreshSerialPorts();
    loadTestItems();
    updateCurrentItemInfo();
}

MainWindow::~MainWindow() = default;

void MainWindow::buildUi()
{
    setWindowTitle("阻容单条测试上位机 - Qt 5.14.2 MinGW / FX3U USB-SC09 / 动态VISA");

    QWidget *central = new QWidget(this);
    setCentralWidget(central);

    QVBoxLayout *rootLayout = new QVBoxLayout(central);

    QHBoxLayout *topLayout = new QHBoxLayout();
    rootLayout->addLayout(topLayout);

    QVBoxLayout *plcSideLayout = new QVBoxLayout();

    QGroupBox *plcGroup = new QGroupBox("PLC连接配置：FX3U / USB-SC09 / COM");
    QFormLayout *plcForm = new QFormLayout(plcGroup);

    m_plcPortCombo = new QComboBox();
    m_btnRefreshPorts = new QPushButton("刷新串口");

    QHBoxLayout *portLayout = new QHBoxLayout();
    portLayout->addWidget(m_plcPortCombo);
    portLayout->addWidget(m_btnRefreshPorts);

    m_mResetStartSpin = new QSpinBox();
    m_mResetStartSpin->setRange(0, 7999);
    m_mResetStartSpin->setValue(0);

    m_mResetCountSpin = new QSpinBox();
    m_mResetCountSpin->setRange(1, 512);
    m_mResetCountSpin->setValue(13);

    QLabel *serialParamLabel = new QLabel("固定参数：9600 bps, 7E1, 无流控");

    QHBoxLayout *plcButtonLayout = new QHBoxLayout();
    m_btnConnectPlc = new QPushButton("连接PLC");
    m_btnDisconnectPlc = new QPushButton("断开PLC");
    plcButtonLayout->addWidget(m_btnConnectPlc);
    plcButtonLayout->addWidget(m_btnDisconnectPlc);

    plcForm->addRow("PLC串口", portLayout);
    plcForm->addRow("串口参数", serialParamLabel);
    plcForm->addRow("复位起始M点", m_mResetStartSpin);
    plcForm->addRow("复位M点数量", m_mResetCountSpin);
    plcForm->addRow(plcButtonLayout);

    plcSideLayout->addWidget(plcGroup);

    QGroupBox *singleMGroup = new QGroupBox("PLC M点单独测试");
    QGridLayout *singleMLayout = new QGridLayout(singleMGroup);

    m_testMSpin = new QSpinBox();
    m_testMSpin->setRange(0, 7999);
    m_testMSpin->setValue(100);

    m_pulseMsSpin = new QSpinBox();
    m_pulseMsSpin->setRange(10, 10000);
    m_pulseMsSpin->setValue(500);
    m_pulseMsSpin->setSuffix(" ms");

    m_btnMOn = new QPushButton("当前M点 ON");
    m_btnMOff = new QPushButton("当前M点 OFF");
    m_btnMPulse = new QPushButton("当前M点脉冲");
    m_btnM100 = new QPushButton("测试 M100");
    m_btnM20 = new QPushButton("测试 M20");
    m_btnM19 = new QPushButton("测试 M19");

    singleMLayout->addWidget(new QLabel("M点编号"), 0, 0);
    singleMLayout->addWidget(m_testMSpin, 0, 1);
    singleMLayout->addWidget(new QLabel("脉冲时间"), 0, 2);
    singleMLayout->addWidget(m_pulseMsSpin, 0, 3);

    singleMLayout->addWidget(m_btnMOn, 1, 0);
    singleMLayout->addWidget(m_btnMOff, 1, 1);
    singleMLayout->addWidget(m_btnMPulse, 1, 2);
    singleMLayout->addWidget(m_btnM100, 2, 0);
    singleMLayout->addWidget(m_btnM20, 2, 1);
    singleMLayout->addWidget(m_btnM19, 2, 2);

    plcSideLayout->addWidget(singleMGroup);

    topLayout->addLayout(plcSideLayout, 1);

    QGroupBox *dmmGroup = new QGroupBox("万用表 USB/VISA 配置（MinGW动态加载visa64.dll）");
    QFormLayout *dmmForm = new QFormLayout(dmmGroup);

    m_visaAddressEdit = new QLineEdit("USB0::0x2A8D::0x1301::MY60051344::INSTR");
    m_resCommandEdit = new QLineEdit("CONF:RES");
    m_capCommandEdit = new QLineEdit("CONF:CAP");
    m_readCommandEdit = new QLineEdit("READ?");

    m_resDelaySpin = new QSpinBox();
    m_resDelaySpin->setRange(0, 60000);
    m_resDelaySpin->setValue(1000);
    m_resDelaySpin->setSuffix(" ms");

    m_capDelaySpin = new QSpinBox();
    m_capDelaySpin->setRange(0, 60000);
    m_capDelaySpin->setValue(1000);
    m_capDelaySpin->setSuffix(" ms");

    m_readTimeoutSpin = new QSpinBox();
    m_readTimeoutSpin->setRange(100, 60000);
    m_readTimeoutSpin->setValue(10000);
    m_readTimeoutSpin->setSuffix(" ms");

    QHBoxLayout *dmmButtonLayout = new QHBoxLayout();
    m_btnConnectDmm = new QPushButton("连接万用表");
    m_btnDisconnectDmm = new QPushButton("断开万用表");
    m_btnPingDmm = new QPushButton("*IDN?");
    dmmButtonLayout->addWidget(m_btnConnectDmm);
    dmmButtonLayout->addWidget(m_btnDisconnectDmm);
    dmmButtonLayout->addWidget(m_btnPingDmm);

    dmmForm->addRow("VISA地址", m_visaAddressEdit);
    dmmForm->addRow("电阻配置指令", m_resCommandEdit);
    dmmForm->addRow("电容配置指令", m_capCommandEdit);
    dmmForm->addRow("读取指令", m_readCommandEdit);
    dmmForm->addRow("电阻等待", m_resDelaySpin);
    dmmForm->addRow("电容等待", m_capDelaySpin);
    dmmForm->addRow("READ超时", m_readTimeoutSpin);
    dmmForm->addRow(dmmButtonLayout);

    topLayout->addWidget(dmmGroup, 1);

    QGroupBox *testGroup = new QGroupBox("单条阻容测试");
    QGridLayout *testLayout = new QGridLayout(testGroup);

    m_itemCombo = new QComboBox();
    m_directionCombo = new QComboBox();
    m_directionCombo->addItem("红黑");
    m_directionCombo->addItem("黑红");

    m_standardLabel = new QLabel("-");
    m_standardLabel->setWordWrap(true);

    m_mPointsLabel = new QLabel("-");
    m_mPointsLabel->setWordWrap(true);

    m_btnConnectM = new QPushButton("接通当前M点");
    m_btnResetM = new QPushButton("断开全部M点");
    m_btnMeasureRes = new QPushButton("测电阻");
    m_btnMeasureCap = new QPushButton("测电容");
    m_btnOneShot = new QPushButton("单条阻容测试");

    m_resistanceLabel = new QLabel("电阻：-");
    m_capacitanceLabel = new QLabel("电容：-");
    m_resultLabel = new QLabel("结果：-");
    m_resultLabel->setMinimumHeight(36);
    m_resultLabel->setStyleSheet("font-size:18px;font-weight:bold;color:#333333;");

    testLayout->addWidget(new QLabel("测试点位"), 0, 0);
    testLayout->addWidget(m_itemCombo, 0, 1);
    testLayout->addWidget(new QLabel("方向"), 0, 2);
    testLayout->addWidget(m_directionCombo, 0, 3);

    testLayout->addWidget(new QLabel("检测标准"), 1, 0);
    testLayout->addWidget(m_standardLabel, 1, 1, 1, 3);

    testLayout->addWidget(new QLabel("当前M点"), 2, 0);
    testLayout->addWidget(m_mPointsLabel, 2, 1, 1, 3);

    testLayout->addWidget(m_btnConnectM, 3, 0);
    testLayout->addWidget(m_btnResetM, 3, 1);
    testLayout->addWidget(m_btnMeasureRes, 3, 2);
    testLayout->addWidget(m_btnMeasureCap, 3, 3);
    testLayout->addWidget(m_btnOneShot, 3, 4);

    testLayout->addWidget(m_resistanceLabel, 4, 0, 1, 2);
    testLayout->addWidget(m_capacitanceLabel, 4, 2, 1, 2);
    testLayout->addWidget(m_resultLabel, 4, 4);

    rootLayout->addWidget(testGroup);

    m_resultTable = new QTableWidget(0, 7);
    m_resultTable->setHorizontalHeaderLabels({
        "时间", "测试点位", "方向", "类型", "数值", "标准", "结果"
    });
    m_resultTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rootLayout->addWidget(m_resultTable, 1);

    QHBoxLayout *logTitleLayout = new QHBoxLayout();
    QLabel *logTitle = new QLabel("详细日志");
    QPushButton *clearLogButton = new QPushButton("清空日志");
    logTitleLayout->addWidget(logTitle);
    logTitleLayout->addStretch();
    logTitleLayout->addWidget(clearLogButton);
    rootLayout->addLayout(logTitleLayout);

    m_logEdit = new QTextEdit();
    m_logEdit->setReadOnly(true);
    rootLayout->addWidget(m_logEdit, 2);

    connect(m_btnRefreshPorts, &QPushButton::clicked,
            this, &MainWindow::refreshSerialPorts);
    connect(m_btnConnectPlc, &QPushButton::clicked,
            this, &MainWindow::connectPlc);
    connect(m_btnDisconnectPlc, &QPushButton::clicked,
            this, &MainWindow::disconnectPlc);

    connect(m_btnMOn, &QPushButton::clicked,
            this, &MainWindow::testMRelayOn);
    connect(m_btnMOff, &QPushButton::clicked,
            this, &MainWindow::testMRelayOff);
    connect(m_btnMPulse, &QPushButton::clicked,
            this, &MainWindow::testMRelayPulse);
    connect(m_btnM100, &QPushButton::clicked,
            this, &MainWindow::testPresetM100);
    connect(m_btnM20, &QPushButton::clicked,
            this, &MainWindow::testPresetM20);
    connect(m_btnM19, &QPushButton::clicked,
            this, &MainWindow::testPresetM19);

    connect(m_btnConnectDmm, &QPushButton::clicked,
            this, &MainWindow::connectDmm);
    connect(m_btnDisconnectDmm, &QPushButton::clicked,
            this, &MainWindow::disconnectDmm);
    connect(m_btnPingDmm, &QPushButton::clicked,
            this, &MainWindow::pingDmm);

    connect(m_itemCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onTestItemChanged);
    connect(m_directionCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onTestItemChanged);

    connect(m_btnConnectM, &QPushButton::clicked,
            this, &MainWindow::connectSelectedMPoints);
    connect(m_btnResetM, &QPushButton::clicked,
            this, &MainWindow::resetAllMPoints);
    connect(m_btnMeasureRes, &QPushButton::clicked,
            this, &MainWindow::measureResistance);
    connect(m_btnMeasureCap, &QPushButton::clicked,
            this, &MainWindow::measureCapacitance);
    connect(m_btnOneShot, &QPushButton::clicked,
            this, &MainWindow::runOneShotTest);
    connect(clearLogButton, &QPushButton::clicked,
            this, &MainWindow::clearLog);
}

void MainWindow::refreshSerialPorts()
{
    const QString current = m_plcPortCombo->currentText();
    m_plcPortCombo->clear();

    const QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();

    for (const QSerialPortInfo &info : ports) {
        QString text = info.portName();

        if (!info.description().isEmpty()) {
            text += QString("  [%1]").arg(info.description());
        }

        m_plcPortCombo->addItem(text, info.portName());
    }

    const int index = m_plcPortCombo->findData(current);
    if (index >= 0) {
        m_plcPortCombo->setCurrentIndex(index);
    }

    appendLog(QString("已刷新串口列表，共 %1 个。").arg(m_plcPortCombo->count()));
}

void MainWindow::loadTestItems()
{
    QString message;
    m_items = TestConfig::loadOrDefault(&message);
    appendLog(message);

    m_itemCombo->clear();

    for (const TestPointConfig &item : m_items) {
        m_itemCombo->addItem(item.name);
    }
}

void MainWindow::connectPlc()
{
    const QString portName = m_plcPortCombo->currentData().toString().trimmed();

    appendLog(QString("准备连接 FX3U PLC，串口=%1，协议=FX编程口，参数=9600 7E1。")
              .arg(portName));

    m_plc->connectDevice(portName);
}

void MainWindow::disconnectPlc()
{
    m_plc->disconnectDevice();
}

void MainWindow::testMRelayOn()
{
    if (!ensurePlcConnected()) {
        return;
    }

    const int m = m_testMSpin->value();
    appendLog(QString("单独测试：M%1 ON。").arg(m));
    m_plc->setMRelay(m, true);
}

void MainWindow::testMRelayOff()
{
    if (!ensurePlcConnected()) {
        return;
    }

    const int m = m_testMSpin->value();
    appendLog(QString("单独测试：M%1 OFF。").arg(m));
    m_plc->setMRelay(m, false);
}

void MainWindow::testMRelayPulse()
{
    if (!ensurePlcConnected()) {
        return;
    }

    const int m = m_testMSpin->value();
    appendLog(QString("单独测试：M%1 脉冲，持续 %2 ms。")
              .arg(m)
              .arg(m_pulseMsSpin->value()));
    m_plc->pulseMRelay(m, m_pulseMsSpin->value());
}

void MainWindow::testPresetM100()
{
    setAndPulsePresetM(100);
}

void MainWindow::testPresetM20()
{
    setAndPulsePresetM(20);
}

void MainWindow::testPresetM19()
{
    setAndPulsePresetM(19);
}

void MainWindow::setAndPulsePresetM(int mNumber)
{
    m_testMSpin->setValue(mNumber);

    if (!ensurePlcConnected()) {
        return;
    }

    appendLog(QString("快捷测试 M%1：先ON，保持%2 ms，再OFF。")
              .arg(mNumber)
              .arg(m_pulseMsSpin->value()));
    m_plc->pulseMRelay(mNumber, m_pulseMsSpin->value());
}

void MainWindow::connectDmm()
{
    applyDmmUiSettings();
    m_dmm->connectInstrument(m_visaAddressEdit->text().trimmed());
}

void MainWindow::disconnectDmm()
{
    m_dmm->disconnectInstrument();
    appendLog("万用表已断开。");
}

void MainWindow::pingDmm()
{
    if (!ensureDmmConnected()) {
        return;
    }

    applyDmmUiSettings();
    m_dmm->ping();
}

void MainWindow::onTestItemChanged(int)
{
    updateCurrentItemInfo();
}

void MainWindow::connectSelectedMPoints()
{
    if (!ensurePlcConnected()) {
        return;
    }

    const TestPointConfig item = currentItem();
    const QVector<int> points = currentMPoints();

    appendLog(QString("准备接通测试点位：%1，方向：%2。")
              .arg(item.name, currentDirectionText()));
    appendLog(QString("本次需要闭合M点：%1。").arg(mPointListText(points)));

    if (m_plc->setMRelays(points,
                          m_mResetStartSpin->value(),
                          m_mResetCountSpin->value())) {
        appendLog(QString("继电器通道已接通，等待 %1 ms 稳定。")
                  .arg(RELAY_STABLE_DELAY_MS));
        QThread::msleep(RELAY_STABLE_DELAY_MS);
    }
}

void MainWindow::resetAllMPoints()
{
    if (!ensurePlcConnected()) {
        return;
    }

    m_plc->resetMRange(m_mResetStartSpin->value(),
                       m_mResetCountSpin->value());
}

void MainWindow::measureResistance()
{
    if (!ensureDmmConnected()) {
        return;
    }

    const TestPointConfig item = currentItem();

    if (!item.enableResistance) {
        appendLog(QString("当前测试项[%1]未启用电阻测试。").arg(item.name));
        return;
    }

    applyDmmUiSettings();

    appendLog(QString("开始测电阻：点位=%1，方向=%2，标准=%3~%4 kΩ。")
              .arg(item.name, currentDirectionText())
              .arg(item.resistanceMinKOhm, 0, 'f', 3)
              .arg(item.resistanceMaxKOhm, 0, 'f', 3));

    const double resistanceOhm = m_dmm->measureResistance(m_readTimeoutSpin->value());

    if (!std::isfinite(resistanceOhm)) {
        m_resistanceLabel->setText("电阻：无效");
        m_resultLabel->setText("结果：NG");
        appendLog("电阻测量失败或返回无效值。");
        appendResultRow(item.name, currentDirectionText(), "电阻",
                        resistanceOhm, "kΩ", false, item.standardText);
        return;
    }

    const double resistanceKOhm = resistanceOhm / 1000.0;
    const bool pass = resistanceKOhm >= item.resistanceMinKOhm &&
            resistanceKOhm <= item.resistanceMaxKOhm;

    m_resistanceLabel->setText(QString("电阻：%1 kΩ").arg(resistanceKOhm, 0, 'f', 6));
    m_resultLabel->setText(pass ? "结果：PASS" : "结果：NG");

    appendLog(QString("电阻换算：原始=%1 Ω，显示=%2 kΩ。")
              .arg(resistanceOhm, 0, 'E', 8)
              .arg(resistanceKOhm, 0, 'f', 6));
    appendLog(QString("电阻判定：%1 <= %2 <= %3，结果=%4。")
              .arg(item.resistanceMinKOhm, 0, 'f', 3)
              .arg(resistanceKOhm, 0, 'f', 6)
              .arg(item.resistanceMaxKOhm, 0, 'f', 3)
              .arg(pass ? "PASS" : "NG"));

    appendResultRow(item.name, currentDirectionText(), "电阻",
                    resistanceKOhm, "kΩ", pass, item.standardText);
}

void MainWindow::measureCapacitance()
{
    if (!ensureDmmConnected()) {
        return;
    }

    const TestPointConfig item = currentItem();

    if (!item.enableCapacitance) {
        appendLog(QString("当前测试项[%1]未启用电容测试。").arg(item.name));
        return;
    }

    applyDmmUiSettings();

    appendLog(QString("开始测电容：点位=%1，方向=%2，标准=%3~%4 nF。")
              .arg(item.name, currentDirectionText())
              .arg(item.capacitanceMinNf, 0, 'f', 3)
              .arg(item.capacitanceMaxNf, 0, 'f', 3));

    const double capacitanceF = m_dmm->measureCapacitance(m_readTimeoutSpin->value());

    if (!std::isfinite(capacitanceF)) {
        m_capacitanceLabel->setText("电容：无效");
        m_resultLabel->setText("结果：NG");
        appendLog("电容测量失败或返回无效值。");
        appendResultRow(item.name, currentDirectionText(), "电容",
                        capacitanceF, "nF", false, item.standardText);
        return;
    }

    const double capacitanceNf = capacitanceF * 1000000000.0;
    const bool pass = capacitanceNf >= item.capacitanceMinNf &&
            capacitanceNf <= item.capacitanceMaxNf;

    m_capacitanceLabel->setText(QString("电容：%1 nF").arg(capacitanceNf, 0, 'f', 6));
    m_resultLabel->setText(pass ? "结果：PASS" : "结果：NG");

    appendLog(QString("电容换算：原始=%1 F，显示=%2 nF。")
              .arg(capacitanceF, 0, 'E', 8)
              .arg(capacitanceNf, 0, 'f', 6));
    appendLog(QString("电容判定：%1 <= %2 <= %3，结果=%4。")
              .arg(item.capacitanceMinNf, 0, 'f', 3)
              .arg(capacitanceNf, 0, 'f', 6)
              .arg(item.capacitanceMaxNf, 0, 'f', 3)
              .arg(pass ? "PASS" : "NG"));

    appendResultRow(item.name, currentDirectionText(), "电容",
                    capacitanceNf, "nF", pass, item.standardText);
}

void MainWindow::runOneShotTest()
{
    const TestPointConfig item = currentItem();

    appendLog("========== 单条阻容测试开始 ==========");
    connectSelectedMPoints();

    if (item.enableResistance) {
        measureResistance();
    }

    if (item.enableCapacitance) {
        measureCapacitance();
    }

    appendLog("========== 单条阻容测试结束 ==========");
}

void MainWindow::clearLog()
{
    m_logEdit->clear();
}

void MainWindow::updateCurrentItemInfo()
{
    if (m_items.isEmpty() || m_itemCombo->currentIndex() < 0) {
        return;
    }

    const TestPointConfig item = currentItem();

    if (m_directionCombo->currentText() == "黑红" && !item.hasBlackRed) {
        m_directionCombo->setCurrentText("红黑");
    }

    m_standardLabel->setText(item.standardText);
    m_mPointsLabel->setText(mPointListText(currentMPoints()));
}

TestPointConfig MainWindow::currentItem() const
{
    const int index = m_itemCombo->currentIndex();

    if (index < 0 || index >= m_items.size()) {
        return TestPointConfig();
    }

    return m_items.at(index);
}

QVector<int> MainWindow::currentMPoints() const
{
    const TestPointConfig item = currentItem();

    if (currentDirectionText() == "黑红" && item.hasBlackRed) {
        return item.blackRedMPoints;
    }

    return item.redBlackMPoints;
}

QString MainWindow::currentDirectionText() const
{
    return m_directionCombo->currentText();
}

void MainWindow::applyDmmUiSettings()
{
    m_dmm->setResistanceCommand(m_resCommandEdit->text());
    m_dmm->setCapacitanceCommand(m_capCommandEdit->text());
    m_dmm->setReadCommand(m_readCommandEdit->text());
    m_dmm->setResistanceDelayMs(m_resDelaySpin->value());
    m_dmm->setCapacitanceDelayMs(m_capDelaySpin->value());
}

bool MainWindow::ensurePlcConnected() const
{
    if (!m_plc->isConnected()) {
        const_cast<MainWindow *>(this)->appendLog("PLC未连接。");
        return false;
    }

    return true;
}

bool MainWindow::ensureDmmConnected() const
{
    if (!m_dmm->isConnected()) {
        const_cast<MainWindow *>(this)->appendLog("万用表未连接。");
        return false;
    }

    return true;
}

void MainWindow::appendLog(const QString &message)
{
    const QString text = QString("[%1] %2")
            .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz"),
                 message);

    if (m_logEdit) {
        m_logEdit->append(text);
    }
}

void MainWindow::appendResultRow(const QString &itemName,
                                 const QString &direction,
                                 const QString &type,
                                 double value,
                                 const QString &unit,
                                 bool pass,
                                 const QString &standard)
{
    const int row = m_resultTable->rowCount();
    m_resultTable->insertRow(row);

    const QString valueText = std::isfinite(value)
            ? QString("%1 %2").arg(value, 0, 'f', 6).arg(unit)
            : QString("无效");

    m_resultTable->setItem(row, 0, new QTableWidgetItem(QDateTime::currentDateTime().toString("HH:mm:ss")));
    m_resultTable->setItem(row, 1, new QTableWidgetItem(itemName));
    m_resultTable->setItem(row, 2, new QTableWidgetItem(direction));
    m_resultTable->setItem(row, 3, new QTableWidgetItem(type));
    m_resultTable->setItem(row, 4, new QTableWidgetItem(valueText));
    m_resultTable->setItem(row, 5, new QTableWidgetItem(standard));
    m_resultTable->setItem(row, 6, new QTableWidgetItem(pass ? "PASS" : "NG"));
}

QString MainWindow::mPointName(int m) const
{
    switch (m) {
    case 0: return "5V";
    case 1: return "GND 红表笔侧";
    case 2: return "GND 黑表笔侧";
    case 3: return "SIN+ 红表笔侧";
    case 4: return "SIN+ 黑表笔侧";
    case 5: return "SIN- 红表笔侧";
    case 6: return "SIN- 黑表笔侧";
    case 7: return "COS+ 红表笔侧";
    case 8: return "预留";
    case 9: return "预留";
    case 10: return "COS+ 黑表笔侧";
    case 11: return "COS- 红表笔侧";
    case 12: return "COS- 黑表笔侧";
    case 19: return "快捷测试点";
    case 20: return "快捷测试点";
    case 100: return "快捷测试点";
    default: return "未定义点位";
    }
}

QString MainWindow::mPointListText(const QVector<int> &mPoints) const
{
    QStringList parts;

    for (int m : mPoints) {
        parts << QString("M%1(%2)").arg(m).arg(mPointName(m));
    }

    return parts.join("、");
}
