# 阻容单条测试上位机：Qt 5.14.2 MinGW + FX3U USB-SC09 + 动态VISA

## 1. 本版解决的问题

你只有：

```text
Qt_5_14_2_MinGW_64_bit
```

没有 MSVC 编译器。

上一版如果直接 `#include <visa.h>` 并链接 `visa64.lib`，MinGW 可能无法链接。  
本版改成：

```text
不包含 visa.h
不链接 visa64.lib
运行时用 QLibrary 动态加载 visa64.dll
```

所以 MinGW 可以直接编译。

## 2. 工程文件

```text
StaticSingleTester_FX3U_MinGW.pro
```

Qt 模块：

```text
widgets
serialport
```

不需要：

```text
serialbus
network
visa64.lib
MSVC
```

## 3. 运行要求

虽然编译不需要 VISA SDK/lib，但运行万用表时仍需要安装：

```text
NI-VISA Runtime
或 Keysight VISA Runtime
```

并确保系统里存在：

```text
C:/Windows/System32/visa64.dll
```

如果没有万用表，可以把 VISA 地址填：

```text
SIM
```

进入仿真模式。

## 4. PLC 通信

PLC：

```text
FX3U
USB-SC09 调制线
COM 串口
9600 bps
7 数据位
Even 偶校验
1 停止位
无流控
```

协议：

```text
FX 编程口协议
'7' = 强制 ON
'8' = 强制 OFF
```

M 点地址：

```text
M内部地址 = 0x0800 + M编号
发送地址低字节在前，高字节在后
```

快捷测试点：

```text
M100
M20
M19
```

界面中有三个按钮：

```text
测试 M100
测试 M20
测试 M19
```

点击后会：

```text
ON -> 保持设定脉冲时间 -> OFF
```

默认脉冲时间：

```text
500 ms
```

也可以通过：

```text
M点编号
当前M点 ON
当前M点 OFF
当前M点脉冲
```

手动测试任意 M 点。

## 5. M19 / M20 / M100 对应帧示例

### M19 ON

```text
M19 内部地址 = 0x0813
发送地址 = 1308
命令 = '7'
```

### M20 ON

```text
M20 内部地址 = 0x0814
发送地址 = 1408
命令 = '7'
```

### M100 ON

```text
M100 内部地址 = 0x0864
发送地址 = 6408
命令 = '7'
```

实际发送帧会在日志中完整打印，例如：

```text
发送 PLC 命令：M100 ON，帧：02 37 36 34 30 38 03 XX XX
PLC 响应 ACK：06
```

## 6. 万用表测试流程

电阻：

```text
清空残留响应
CONF:RES
等待 1000 ms
READ?
原始 Ω -> kΩ
```

电容：

```text
清空残留响应
CONF:CAP
等待 1000 ms
READ?
原始 F -> nF
```

## 7. 运行目录

`config/test_standard.ini` 放在 exe 同级目录：

```text
StaticSingleTester_FX3U_MinGW.exe
config/test_standard.ini
```

Qt Creator 调试时，要把 `config` 文件夹复制到 build 输出目录。

## 8. 建议测试步骤

```text
1. 先只连接 PLC 和 USB-SC09；
2. 打开软件，选择 COM 口，连接 PLC；
3. 点击 测试 M100，观察 PLC / 继电器 / 工装动作；
4. 点击 测试 M20；
5. 点击 测试 M19；
6. 确认 M 点动作正确后，再连接万用表；
7. VISA 地址填 SIM，先验证界面；
8. 再填真实 VISA 地址做实际阻容测量。
```
