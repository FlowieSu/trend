#ifndef TEST_CONFIG_H
#define TEST_CONFIG_H

#include <QString>
#include <QVector>

struct TestPointConfig
{
    QString name;
    QString standardText;

    double resistanceMinKOhm = 0.0;
    double resistanceMaxKOhm = 0.0;

    double capacitanceMinNf = 0.0;
    double capacitanceMaxNf = 0.0;

    bool enableResistance = true;
    bool enableCapacitance = true;

    QVector<int> redBlackMPoints;
    QVector<int> blackRedMPoints;
    bool hasBlackRed = true;
};

class TestConfig
{
public:
    static QString defaultIniPath();
    static QVector<TestPointConfig> loadOrDefault(QString *message = nullptr);
    static QVector<TestPointConfig> defaultItems();

private:
    static QVector<TestPointConfig> loadFromIni(const QString &filePath,
                                                QString *errorMessage);
    static QVector<int> parseMPoints(const QString &text, bool *ok = nullptr);
};

#endif // TEST_CONFIG_H
