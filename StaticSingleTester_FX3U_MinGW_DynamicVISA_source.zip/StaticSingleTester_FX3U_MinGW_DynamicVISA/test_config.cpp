#include "test_config.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QSettings>
#include <QStringList>

QString TestConfig::defaultIniPath()
{
    return QDir(QCoreApplication::applicationDirPath())
            .filePath("config/test_standard.ini");
}

QVector<TestPointConfig> TestConfig::loadOrDefault(QString *message)
{
    const QString path = defaultIniPath();

    if (!QFileInfo::exists(path)) {
        if (message) {
            *message = QString("未找到配置文件：%1，使用内置默认测试项。").arg(path);
        }
        return defaultItems();
    }

    QString error;
    QVector<TestPointConfig> items = loadFromIni(path, &error);

    if (items.isEmpty()) {
        if (message) {
            *message = QString("配置文件加载失败：%1，使用内置默认测试项。错误：%2")
                    .arg(path, error);
        }
        return defaultItems();
    }

    if (message) {
        *message = QString("已加载配置文件：%1，共 %2 个测试项。")
                .arg(path)
                .arg(items.size());
    }

    return items;
}

QVector<TestPointConfig> TestConfig::defaultItems()
{
    QVector<TestPointConfig> items;

    auto addItem = [&](const QString &name,
                       const QString &standard,
                       double rMin,
                       double rMax,
                       double cMin,
                       double cMax,
                       const QVector<int> &rb,
                       const QVector<int> &br) {
        TestPointConfig item;
        item.name = name;
        item.standardText = standard;
        item.resistanceMinKOhm = rMin;
        item.resistanceMaxKOhm = rMax;
        item.capacitanceMinNf = cMin;
        item.capacitanceMaxNf = cMax;
        item.enableResistance = true;
        item.enableCapacitance = true;
        item.redBlackMPoints = rb;
        item.blackRedMPoints = br;
        item.hasBlackRed = true;
        items.append(item);
    };

    addItem("sin+ -> sin-", "阻值: 365±25 kΩ; 容值: 5±1.5 nF",
            340.0, 390.0, 3.5, 6.5, {3, 6}, {4, 5});

    addItem("cos+ -> cos-", "阻值: 365±25 kΩ; 容值: 5±1.5 nF",
            340.0, 390.0, 3.5, 6.5, {7, 12}, {10, 11});

    addItem("GND -> sin+", "阻值/容值标准请按现场修改",
            0.0, 999999.0, 0.0, 999999.0, {1, 4}, {2, 3});

    addItem("GND -> sin-", "阻值/容值标准请按现场修改",
            0.0, 999999.0, 0.0, 999999.0, {1, 6}, {2, 5});

    addItem("GND -> cos+", "阻值/容值标准请按现场修改",
            0.0, 999999.0, 0.0, 999999.0, {1, 10}, {2, 7});

    addItem("GND -> cos-", "阻值/容值标准请按现场修改",
            0.0, 999999.0, 0.0, 999999.0, {1, 12}, {2, 11});

    addItem("5V -> GND", "阻值/容值标准请按现场修改",
            0.0, 999999.0, 0.0, 999999.0, {0, 1}, {0, 2});

    return items;
}

QVector<TestPointConfig> TestConfig::loadFromIni(const QString &filePath,
                                                 QString *errorMessage)
{
    QVector<TestPointConfig> items;

    QSettings settings(filePath, QSettings::IniFormat);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    settings.setIniCodec("UTF-8");
#endif

    settings.beginGroup("Static");
    const int itemCount = settings.value("itemCount", 0).toInt();
    settings.endGroup();

    if (itemCount <= 0) {
        if (errorMessage) {
            *errorMessage = "Static/itemCount 无效。";
        }
        return items;
    }

    for (int i = 1; i <= itemCount; ++i) {
        const QString groupName = QString("StaticItem%1").arg(i);
        settings.beginGroup(groupName);

        TestPointConfig item;
        item.name = settings.value("name").toString().trimmed();
        item.standardText = settings.value("standardText").toString().trimmed();

        item.resistanceMinKOhm = settings.value("resistanceMinKOhm", 0.0).toDouble();
        item.resistanceMaxKOhm = settings.value("resistanceMaxKOhm", 0.0).toDouble();
        item.capacitanceMinNf = settings.value("capacitanceMinNf", 0.0).toDouble();
        item.capacitanceMaxNf = settings.value("capacitanceMaxNf", 0.0).toDouble();

        item.enableResistance = settings.value("enableResistance", true).toBool();
        item.enableCapacitance = settings.value("enableCapacitance", true).toBool();
        item.hasBlackRed = settings.value("hasBlackRed", true).toBool();

        bool redOk = false;
        bool blackOk = false;
        item.redBlackMPoints = parseMPoints(settings.value("redBlackMPoints").toString(), &redOk);
        item.blackRedMPoints = parseMPoints(settings.value("blackRedMPoints").toString(), &blackOk);

        settings.endGroup();

        if (item.name.isEmpty()) {
            if (errorMessage) {
                *errorMessage = QString("%1/name 为空。").arg(groupName);
            }
            items.clear();
            return items;
        }

        if (!redOk || item.redBlackMPoints.isEmpty()) {
            if (errorMessage) {
                *errorMessage = QString("%1/redBlackMPoints 无效。").arg(groupName);
            }
            items.clear();
            return items;
        }

        if (item.hasBlackRed && (!blackOk || item.blackRedMPoints.isEmpty())) {
            if (errorMessage) {
                *errorMessage = QString("%1/blackRedMPoints 无效。").arg(groupName);
            }
            items.clear();
            return items;
        }

        if (item.standardText.isEmpty()) {
            QStringList parts;
            if (item.enableResistance) {
                parts << QString("阻值: %1~%2 kΩ")
                         .arg(item.resistanceMinKOhm, 0, 'f', 3)
                         .arg(item.resistanceMaxKOhm, 0, 'f', 3);
            } else {
                parts << "阻值: 不测试";
            }

            if (item.enableCapacitance) {
                parts << QString("容值: %1~%2 nF")
                         .arg(item.capacitanceMinNf, 0, 'f', 3)
                         .arg(item.capacitanceMaxNf, 0, 'f', 3);
            } else {
                parts << "容值: 不测试";
            }

            item.standardText = parts.join("; ");
        }

        items.append(item);
    }

    return items;
}

QVector<int> TestConfig::parseMPoints(const QString &text, bool *ok)
{
    QVector<int> points;

    if (ok) {
        *ok = true;
    }

    const QString trimmed = text.trimmed();

    if (trimmed.isEmpty()) {
        return points;
    }

    const QStringList parts = trimmed.split(",", QString::SkipEmptyParts);

    for (const QString &part : parts) {
        bool oneOk = false;
        const int value = part.trimmed().toInt(&oneOk);

        if (!oneOk || value < 0) {
            if (ok) {
                *ok = false;
            }
            points.clear();
            return points;
        }

        points.append(value);
    }

    return points;
}
