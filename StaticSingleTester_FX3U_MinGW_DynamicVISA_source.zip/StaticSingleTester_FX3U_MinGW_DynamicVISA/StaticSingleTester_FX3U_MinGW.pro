QT += core gui widgets serialport

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17
CONFIG -= app_bundle

TARGET = StaticSingleTester_FX3U_MinGW
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    mitsubishi_plc.cpp \
    scpi_controller.cpp \
    test_config.cpp

HEADERS += \
    mainwindow.h \
    mitsubishi_plc.h \
    scpi_controller.h \
    test_config.h

# 说明：
# 1. 本工程适配 Qt_5_14_2_MinGW_64_bit。
# 2. PLC 使用 Qt SerialPort 控制 FX3U USB-SC09。
# 3. 万用表 VISA 不再链接 visa64.lib，而是在运行时通过 QLibrary 动态加载 visa64.dll。
# 4. 因此 MinGW 编译阶段不需要 MSVC 编译器，也不需要 VISA .lib。
# 5. 运行电脑仍需安装 NI-VISA Runtime 或 Keysight VISA Runtime，使 C:/Windows/System32/visa64.dll 存在。
