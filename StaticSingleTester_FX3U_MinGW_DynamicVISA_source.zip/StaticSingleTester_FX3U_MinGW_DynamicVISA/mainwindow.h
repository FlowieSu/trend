#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "test_config.h"

#include <QMainWindow>
#include <QVector>

class QLabel;
class QLineEdit;
class QPushButton;
class QComboBox;
class QTextEdit;
class QSpinBox;
class QTableWidget;

class MitsubishiPLC;
class SCPIController;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void refreshSerialPorts();

    void connectPlc();
    void disconnectPlc();

    void testMRelayOn();
    void testMRelayOff();
    void testMRelayPulse();
    void testPresetM100();
    void testPresetM20();
    void testPresetM19();

    void connectDmm();
    void disconnectDmm();
    void pingDmm();

    void onTestItemChanged(int index);
    void connectSelectedMPoints();
    void resetAllMPoints();

    void measureResistance();
    void measureCapacitance();
    void runOneShotTest();

    void clearLog();

private:
    void buildUi();
    void loadTestItems();
    void updateCurrentItemInfo();

    TestPointConfig currentItem() const;
    QVector<int> currentMPoints() const;
    QString currentDirectionText() const;

    void applyDmmUiSettings();

    bool ensurePlcConnected() const;
    bool ensureDmmConnected() const;

    void appendLog(const QString &message);
    void appendResultRow(const QString &itemName,
                         const QString &direction,
                         const QString &type,
                         double value,
                         const QString &unit,
                         bool pass,
                         const QString &standard);

    QString mPointName(int m) const;
    QString mPointListText(const QVector<int> &mPoints) const;
    void setAndPulsePresetM(int mNumber);

private:
    MitsubishiPLC *m_plc = nullptr;
    SCPIController *m_dmm = nullptr;

    QVector<TestPointConfig> m_items;

    QComboBox *m_plcPortCombo = nullptr;
    QPushButton *m_btnRefreshPorts = nullptr;
    QSpinBox *m_mResetStartSpin = nullptr;
    QSpinBox *m_mResetCountSpin = nullptr;
    QPushButton *m_btnConnectPlc = nullptr;
    QPushButton *m_btnDisconnectPlc = nullptr;

    QSpinBox *m_testMSpin = nullptr;
    QSpinBox *m_pulseMsSpin = nullptr;
    QPushButton *m_btnMOn = nullptr;
    QPushButton *m_btnMOff = nullptr;
    QPushButton *m_btnMPulse = nullptr;
    QPushButton *m_btnM100 = nullptr;
    QPushButton *m_btnM20 = nullptr;
    QPushButton *m_btnM19 = nullptr;

    QLineEdit *m_visaAddressEdit = nullptr;
    QLineEdit *m_resCommandEdit = nullptr;
    QLineEdit *m_capCommandEdit = nullptr;
    QLineEdit *m_readCommandEdit = nullptr;
    QSpinBox *m_resDelaySpin = nullptr;
    QSpinBox *m_capDelaySpin = nullptr;
    QSpinBox *m_readTimeoutSpin = nullptr;
    QPushButton *m_btnConnectDmm = nullptr;
    QPushButton *m_btnDisconnectDmm = nullptr;
    QPushButton *m_btnPingDmm = nullptr;

    QComboBox *m_itemCombo = nullptr;
    QComboBox *m_directionCombo = nullptr;
    QLabel *m_standardLabel = nullptr;
    QLabel *m_mPointsLabel = nullptr;

    QPushButton *m_btnConnectM = nullptr;
    QPushButton *m_btnResetM = nullptr;
    QPushButton *m_btnMeasureRes = nullptr;
    QPushButton *m_btnMeasureCap = nullptr;
    QPushButton *m_btnOneShot = nullptr;

    QLabel *m_resistanceLabel = nullptr;
    QLabel *m_capacitanceLabel = nullptr;
    QLabel *m_resultLabel = nullptr;

    QTableWidget *m_resultTable = nullptr;
    QTextEdit *m_logEdit = nullptr;
};

#endif // MAINWINDOW_H
