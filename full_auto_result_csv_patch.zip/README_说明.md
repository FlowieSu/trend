# 自动化测试完整结果 CSV 补丁

基于上一版 `repeated_barcode_daily_load_patch` 生成。

## 修改文件

```text
modified_files/mainwindow.h
modified_files/mainwindow.cpp
modified_files/mainwindow.ui
modified_files/daily_test_statistics.h
modified_files/daily_test_statistics.cpp
```

## 新增功能

自动化测试完成后，额外把本次自动化测试的完整结果追加保存到：

```text
D:/电涡流测试结果/自动化测试完整结果.csv
```

这个文件 **不按条码去重**，每完成一次自动化测试就追加一条或两条记录：

```text
单圈模式：追加位置1一行
双圈模式：追加位置1、位置2两行
```

## 固定基础列

```text
开始时间
结束时间
产品编码
是否合格
阻容是否合格
动态是否合格
位置
```

其中：

```text
开始时间 = 点击“开始自动化测试”并通过前置校验后的时间
结束时间 = 动态测试结束时的时间
```

## 后续明细列

后续列采用成对结构：

```text
阻容测试项1, 阻容测试标准1, 阻容测试项2, 阻容测试标准2, ...
动态测试项1, 动态测试标准1, 动态测试项2, 动态测试标准2, ...
```

阻容测试项列包含：

```text
测试项名称
方向
M点
电阻实测值
电容实测值
单项 PASS/NG
备注
```

阻容测试标准列来自：

```cpp
StaticTestResult::standardText
```

动态测试项列包含：

```text
序号
测试项名称
实测值
单位
单项 PASS/NG
```

动态测试标准列来自：

```cpp
DynamicItemResult::standardText
```

该字段由动态测试项元数据加载，标准文本来自 INI 中的 `standardText`。

## 新增/修改函数

`mainwindow.h` 新增：

```cpp
QString autoTestFullResultCsvPath() const;
QString staticFullResultItemText(const StaticTestResult &result) const;
QString dynamicFullResultItemText(const DynamicItemResult &result) const;
bool saveAutoTestFullResultCsv(const QDateTime &endTime);
```

`mainwindow.cpp` 新增对应实现，并在：

```cpp
MainWindow::onDynamicAllFinished(...)
```

中调用：

```cpp
saveAutoTestFullResultCsv(autoTestEndTime);
```

## 使用方式

1. 用 `modified_files` 里的文件覆盖工程同名文件；
2. 重新运行 qmake；
3. 清理项目；
4. 重新构建。

