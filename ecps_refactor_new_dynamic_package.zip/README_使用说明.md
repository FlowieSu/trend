# ECPS 重构代码包：适配新动态测试流程版本

这版代码已经按你当前实际状态修正：

- 动态测试已经完全使用 `dynamic_test_code_generated` 里的新文件；
- 不再引用 `usbcanfd_200u`；
- 不再引用 `sensor`；
- 动态结果使用 `DynamicProductResult / DynamicItemResult`；
- CAN 通信使用 `ZlgCanDevice`；
- 动态控制使用新版 `DynamicTestController`；
- 动态保存使用 `DynamicCsvExporter`；
- 阻容保存继续使用 `CsvExporter`。

## 1. 新增文件

```text
new_files/
├── deviceconnectiondialog.h/.cpp/.ui
├── dynamicparamconfigdialog.h/.cpp/.ui
└── logwindow.h/.cpp/.ui
```

## 2. 修改文件

```text
modified_files/
├── dynamic_test_controller.h/.cpp
├── dynamic_protocol.cpp
├── dynamic_csv_exporter.h/.cpp
├── csv_exporter.h/.cpp
├── manualdynamictestwindow.h/.cpp/.ui
├── mainwindow.ui
├── mainwindow_integration_snippets.h
└── mainwindow_integration_snippets.cpp
```

## 3. 关键修正

### 3.1 DynamicTestController

新增重载：

```cpp
void startDynamicTestWithChannels(const QString &productCode1,
                                  DynamicProtocol::DynamicChannel channel1,
                                  int thresholdFlag1,
                                  const QString &productCode2,
                                  DynamicProtocol::DynamicChannel channel2,
                                  int thresholdFlag2);
```

原接口保留：

```cpp
void startDynamicTestWithChannels(const QString &productCode1,
                                  DynamicProtocol::DynamicChannel channel1,
                                  const QString &productCode2,
                                  DynamicProtocol::DynamicChannel channel2);
```

原流程不变，只是新重载允许从“动态检测参数配置”窗口传入 thresholdFlag。

### 3.2 DynamicProtocol

`110 / 112 / 114 / 116` 默认 `thresholdFlag` 都改为 `2`。

### 3.3 DynamicParamConfigDialog

配置：

```text
位置1发送报文：110 / 112 / 114 / 116
位置1 thresholdFlag：默认 2
位置2发送报文：110 / 112 / 114 / 116
位置2 thresholdFlag：默认 2
```

### 3.4 ManualDynamicTestWindow

采用方案 B：

```text
手动动态测试窗口不再选择发送报文
直接使用“动态检测参数配置”的全局配置
不依赖 PLC
不操作 M26/M27
```

### 3.5 DynamicCsvExporter

动态 CSV 简化字段：

```text
测试时间
完成时间
产品位置
产品编码
通道
检测进度
检测项编号
检测项名称
原始检测值
单位
单项结果
```

删除：

```text
发送ID
接收ID
seed
groupCnt
产品总结结果
产品备注
合格标志seq
合格标志值
标志是否收到
标志校验
检测值seq
显示检测值
合格标准
单项备注
```

保存路径：

```text
D:/动态测试结果/yyyy年MM月/条码_动态测试_yyyyMMdd.csv
```

GBK 编码，文件存在则追加，不覆盖，不重复写表头。

### 3.6 CsvExporter

阻容自动保存：

```text
D:/阻容测试结果/yyyy年MM月/条码_阻容测试_yyyyMMdd.csv
```

GBK 编码，位置1/位置2单独保存，文件存在则追加，不覆盖，不重复写表头。

## 4. 合并注意

`mainwindow_integration_snippets.*` 是增量片段，不建议直接覆盖你的 `mainwindow.cpp/.h`。  
里面已有明确 TODO，需要把当前已经能跑的 PLC、万用表连接函数原样接进去。

## 5. 不再使用

这一版不要再使用之前包里的：

```text
usbcanfd_200u_threshold_support.patch.txt
```

也不要再把 `usbcanfd_200u.h/.cpp`、`sensor.h/.cpp` 加回工程。
