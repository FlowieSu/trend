#include "daily_test_statistics.h"

#include <QDate>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QXmlStreamReader>

#include <algorithm>

DailyTestStatistics::DailyTestStatistics()
{
}

void DailyTestStatistics::loadToday()
{
    m_records.clear();

    /*
     * 优先读取程序专用缓存文件。
     * 这个文件不是给人看的，是为了保证上位机重启后当天统计不会清零。
     *
     * 如果缓存不存在，再兼容读取 Excel XML 文件。
     */
    QString error;
    if (loadFromCache(&error)) {
        return;
    }

    loadFromExcelXml(&error);
}

void DailyTestStatistics::updateProduct(const QString &productCode,
                                        bool staticPass,
                                        bool dynamicPass,
                                        const QDateTime &time)
{
    const QString code = productCode.trimmed();

    if (code.isEmpty()) {
        return;
    }

    ProductDailyRecord record;
    record.time = time;
    record.productCode = code;
    record.staticPass = staticPass;
    record.dynamicPass = dynamicPass;
    record.finalPass = staticPass && dynamicPass;

    /*
     * 核心去重逻辑：
     * key = 产品编码。
     * 同一条码重复自动化测试，直接覆盖旧记录。
     */
    m_records[code] = record;
}

DailyTestSummary DailyTestStatistics::summary() const
{
    DailyTestSummary s;

    for (auto it = m_records.constBegin(); it != m_records.constEnd(); ++it) {
        const ProductDailyRecord &r = it.value();

        s.totalCount++;

        if (r.finalPass) {
            s.passCount++;
        } else {
            s.ngCount++;
        }

        if (r.staticPass) {
            s.staticPassCount++;
        } else {
            s.staticNgCount++;
        }

        if (r.dynamicPass) {
            s.dynamicPassCount++;
        } else {
            s.dynamicNgCount++;
        }
    }

    return s;
}

QVector<ProductDailyRecord> DailyTestStatistics::records() const
{
    QVector<ProductDailyRecord> list;

    for (auto it = m_records.constBegin(); it != m_records.constEnd(); ++it) {
        list.append(it.value());
    }

    std::sort(list.begin(), list.end(), [](const ProductDailyRecord &a,
                                           const ProductDailyRecord &b) {
        return a.time < b.time;
    });

    return list;
}

QString DailyTestStatistics::makeMonthDirPath() const
{
    const QDate today = QDate::currentDate();

    return QString("D:/电涡流测试结果/%1年%2月")
            .arg(today.year())
            .arg(today.month(), 2, 10, QChar('0'));
}

QString DailyTestStatistics::todayFilePath() const
{
    const QDate today = QDate::currentDate();

    /*
     * 使用 Excel XML 格式。
     * 扩展名 .xls，可以被 Excel/WPS 打开，并支持多个 Worksheet。
     */
    return QString("%1/%2测试结果.xls")
            .arg(makeMonthDirPath())
            .arg(today.toString("yyyyMMdd"));
}

QString DailyTestStatistics::cacheFilePath() const
{
    const QDate today = QDate::currentDate();

    /*
     * 程序专用缓存文件，用于重启后恢复当天统计。
     * 不建议人工编辑。
     */
    return QString("%1/%2测试结果_cache.csv")
            .arg(makeMonthDirPath())
            .arg(today.toString("yyyyMMdd"));
}

QString DailyTestStatistics::escapeXml(const QString &text) const
{
    /*
     * 把所有非 ASCII 字符写成 XML 数字字符引用。
     * 例如：“当” -> &#x5F53;
     *
     * 这样即使 Excel/WPS 忽略 UTF-8/UTF-16 编码声明，
     * 只要按 XML 解析，也能还原正确中文。
     */
    QString value;
    value.reserve(text.size() * 6);

    for (const QChar ch : text) {
        const ushort u = ch.unicode();

        switch (u) {
        case '&':
            value += "&amp;";
            break;
        case '<':
            value += "&lt;";
            break;
        case '>':
            value += "&gt;";
            break;
        case '"':
            value += "&quot;";
            break;
        case '\'':
            value += "&apos;";
            break;
        default:
            if (u < 0x80) {
                value += ch;
            } else {
                value += QString("&#x%1;")
                         .arg(QString::number(u, 16).toUpper());
            }
            break;
        }
    }

    return value;
}


QString DailyTestStatistics::resultText(bool pass) const
{
    return pass ? "PASS" : "NG";
}

bool DailyTestStatistics::parseBoolResultText(const QString &text) const
{
    const QString value = text.trimmed().toUpper();

    return value == "PASS"
            || value == "OK"
            || value == "1"
            || value == "合格";
}

bool DailyTestStatistics::loadFromCache(QString *errorMessage)
{
    QFile file(cacheFilePath());

    if (!file.exists()) {
        return false;
    }

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QString("打开当天统计缓存失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream in(&file);
    in.setCodec("UTF-8");

    bool firstLine = true;

    while (!in.atEnd()) {
        QString line = in.readLine();

        if (firstLine) {
            firstLine = false;
            line.remove(QChar(0xFEFF));

            if (line.startsWith("time,")) {
                continue;
            }
        }

        if (line.trimmed().isEmpty()) {
            continue;
        }

        /*
         * 缓存文件字段固定，不包含逗号：
         * time,productCode,finalPass,staticPass,dynamicPass
         */
        const QStringList cells = line.split(',');

        if (cells.size() < 5) {
            continue;
        }

        ProductDailyRecord record;
        record.time = QDateTime::fromString(cells.value(0).trimmed(),
                                            "yyyy-MM-dd HH:mm:ss");

        if (!record.time.isValid()) {
            record.time = QDateTime::currentDateTime();
        }

        record.productCode = cells.value(1).trimmed();
        record.finalPass = cells.value(2).trimmed() == "1";
        record.staticPass = cells.value(3).trimmed() == "1";
        record.dynamicPass = cells.value(4).trimmed() == "1";

        if (!record.productCode.isEmpty()) {
            m_records[record.productCode] = record;
        }
    }

    return true;
}

bool DailyTestStatistics::saveCache(QString *errorMessage) const
{
    const QString dirPath = makeMonthDirPath();

    QDir dir;
    if (!dir.mkpath(dirPath)) {
        if (errorMessage) {
            *errorMessage = QString("创建统计缓存目录失败：%1").arg(dirPath);
        }
        return false;
    }

    QFile file(cacheFilePath());

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        if (errorMessage) {
            *errorMessage = QString("打开统计缓存文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    out << "time,productCode,finalPass,staticPass,dynamicPass\n";

    const QVector<ProductDailyRecord> list = records();

    for (const ProductDailyRecord &r : list) {
        out << r.time.toString("yyyy-MM-dd HH:mm:ss") << ","
            << r.productCode << ","
            << (r.finalPass ? "1" : "0") << ","
            << (r.staticPass ? "1" : "0") << ","
            << (r.dynamicPass ? "1" : "0") << "\n";
    }

    file.close();
    return true;
}

bool DailyTestStatistics::loadFromExcelXml(QString *errorMessage)
{
    const QString filePath = todayFilePath();

    QFile file(filePath);

    if (!file.exists()) {
        /*
         * 当天第一次启动软件，还没有统计文件，这是正常情况。
         */
        return false;
    }

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QString("打开当天统计文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QXmlStreamReader xml(&file);

    bool inProductSheet = false;
    bool inData = false;
    bool firstRowIsHeader = true;

    QString currentData;
    QStringList currentRowCells;

    auto commitRow = [&]() {
        if (!inProductSheet) {
            currentRowCells.clear();
            return;
        }

        if (currentRowCells.isEmpty()) {
            return;
        }

        /*
         * 第一行是表头：
         * 时间、产品编码、测试结果、阻容测试结果、动态测试结果
         */
        if (firstRowIsHeader) {
            firstRowIsHeader = false;
            currentRowCells.clear();
            return;
        }

        if (currentRowCells.size() < 5) {
            currentRowCells.clear();
            return;
        }

        ProductDailyRecord record;

        record.time = QDateTime::fromString(currentRowCells.value(0).trimmed(),
                                            "yyyy-MM-dd HH:mm:ss");

        if (!record.time.isValid()) {
            record.time = QDateTime::currentDateTime();
        }

        record.productCode = currentRowCells.value(1).trimmed();
        record.finalPass = parseBoolResultText(currentRowCells.value(2));
        record.staticPass = parseBoolResultText(currentRowCells.value(3));
        record.dynamicPass = parseBoolResultText(currentRowCells.value(4));

        if (!record.productCode.isEmpty()) {
            /*
             * 如果文件中意外存在重复条码，以最后读到的记录为准。
             */
            m_records[record.productCode] = record;
        }

        currentRowCells.clear();
    };

    while (!xml.atEnd()) {
        xml.readNext();

        if (xml.isStartElement()) {
            const QString name = xml.name().toString();

            if (name == "Worksheet") {
                QString worksheetName;

                const QXmlStreamAttributes attributes = xml.attributes();

                for (const QXmlStreamAttribute &attribute : attributes) {
                    const QString attrName = attribute.name().toString();
                    const QString qualifiedName = attribute.qualifiedName().toString();

                    if (attrName == "Name" || qualifiedName == "ss:Name") {
                        worksheetName = attribute.value().toString();
                        break;
                    }
                }

                inProductSheet = worksheetName == "当日测试产品信息";
                firstRowIsHeader = true;
            } else if (name == "Row") {
                currentRowCells.clear();
            } else if (name == "Data") {
                inData = true;
                currentData.clear();
            }
        } else if (xml.isCharacters()) {
            if (inData) {
                currentData += xml.text().toString();
            }
        } else if (xml.isEndElement()) {
            const QString name = xml.name().toString();

            if (name == "Data") {
                inData = false;
                currentRowCells << currentData;
                currentData.clear();
            } else if (name == "Row") {
                commitRow();
            } else if (name == "Worksheet") {
                inProductSheet = false;
            }
        }
    }

    if (xml.hasError()) {
        if (errorMessage) {
            *errorMessage = QString("解析当天统计文件失败：%1").arg(xml.errorString());
        }
        return false;
    }

    return !m_records.isEmpty();
}

bool DailyTestStatistics::save(QString *errorMessage) const
{
    const QString dirPath = makeMonthDirPath();

    QDir dir;
    if (!dir.mkpath(dirPath)) {
        if (errorMessage) {
            *errorMessage = QString("创建统计目录失败：%1").arg(dirPath);
        }
        return false;
    }

    QFile file(todayFilePath());

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        if (errorMessage) {
            *errorMessage = QString("打开统计文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream out(&file);

    /*
     * 文件使用 UTF-8 + BOM。
     * 中文内容由 escapeXml() 转成 &#xXXXX; 数字字符引用，避免 Excel/WPS 乱码。
     */
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    const DailyTestSummary s = summary();
    const QVector<ProductDailyRecord> list = records();

    out << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";    out << "<?mso-application progid=\"Excel.Sheet\"?>\n";
    out << "<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\n";
    out << " xmlns:o=\"urn:schemas-microsoft-com:office:office\"\n";
    out << " xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\n";
    out << " xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">\n";

    /*
     * sheet1：当日测试情况
     */
    out << "<Worksheet ss:Name=\"" << escapeXml(QStringLiteral("当日测试情况")) << "\">\n";
    out << "<Table>\n";

    out << "<Row>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("日期")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("总测试数")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("PASS数量")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("NG数量")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("阻容PASS数量")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("阻容NG数量")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("动态PASS数量")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("动态NG数量")) << "</Data></Cell>"
        << "</Row>\n";

    out << "<Row>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QDate::currentDate().toString("yyyy-MM-dd")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.totalCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.passCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.ngCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.staticPassCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.staticNgCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.dynamicPassCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.dynamicNgCount << "</Data></Cell>"
        << "</Row>\n";

    out << "</Table>\n";
    out << "</Worksheet>\n";

    /*
     * sheet2：当日测试产品信息
     */
    out << "<Worksheet ss:Name=\"" << escapeXml(QStringLiteral("当日测试产品信息")) << "\">\n";
    out << "<Table>\n";

    out << "<Row>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("时间")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("产品编码")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("测试结果")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("阻容测试结果")) << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">" << escapeXml(QStringLiteral("动态测试结果")) << "</Data></Cell>"
        << "</Row>\n";

    for (const ProductDailyRecord &r : list) {
        out << "<Row>"
            << "<Cell><Data ss:Type=\"String\">" << escapeXml(r.time.toString("yyyy-MM-dd HH:mm:ss")) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << escapeXml(r.productCode) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << escapeXml(resultText(r.finalPass)) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << escapeXml(resultText(r.staticPass)) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << escapeXml(resultText(r.dynamicPass)) << "</Data></Cell>"
            << "</Row>\n";
    }

    out << "</Table>\n";
    out << "</Worksheet>\n";

    out << "</Workbook>\n";

    file.close();

    /*
     * 同步写程序专用缓存，保证重启后主界面统计不会清零。
     */
    QString cacheError;
    if (!saveCache(&cacheError)) {
        if (errorMessage) {
            *errorMessage = cacheError;
        }
        return false;
    }

    return true;
}
