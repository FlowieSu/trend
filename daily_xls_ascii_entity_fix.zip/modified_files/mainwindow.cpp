#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "mitsubishi_plc.h"
#include "scpi_controller.h"
#include "dynamic_test_controller.h"
#include "dynamic_csv_exporter.h"
#include "manualstatictestwindow.h"
#include "manualdynamictestwindow.h"
#include "plctestwindow.h"
#include "deviceconnectiondialog.h"
#include "dynamicparamconfigdialog.h"
#include "logwindow.h"
#include "csv_exporter.h"
#include "daily_test_statistics.h"

#include <QCloseEvent>
#include <QCoreApplication>
#include <QDateTime>
#include <QDate>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QHeaderView>
#include <QLabel>
#include <QAction>
#include <QMenu>
#include <QMessageBox>
#include <QPixmap>
#include <QColor>
#include <QSerialPortInfo>
#include <QSettings>
#include <QSignalBlocker>
#include <QTableWidgetItem>
#include <QTextStream>
#include <QThread>
#include <QTimer>
#include <QMap>
#include <QSet>

#include <cmath>

namespace
{
constexpr int M_RES_CAP_ENABLE = 19;
constexpr int M_RESET_CHANNEL = 100;

constexpr int M_DYNAMIC_MODE = 26;   // M26 -> Y26
constexpr int M_SERVO_POWER = 27;    // M27 -> Y27

constexpr int STATIC_RESET_DELAY_MS = 200;
constexpr int LINE_SWITCH_DELAY_MS = 300;
constexpr int SERVO_STABLE_DELAY_MS = 2000;

// 阻容结果列
constexpr int STATIC_COL_TIME = 0;
constexpr int STATIC_COL_PRODUCT_CODE = 1;
constexpr int STATIC_COL_POSITION = 2;
constexpr int STATIC_COL_TEST_NAME = 3;
constexpr int STATIC_COL_DIRECTION = 4;
constexpr int STATIC_COL_M_POINTS = 5;
constexpr int STATIC_COL_STANDARD = 6;
constexpr int STATIC_COL_RESISTANCE = 7;
constexpr int STATIC_COL_CAPACITANCE = 8;
constexpr int STATIC_COL_RESULT = 9;
constexpr int STATIC_COL_MESSAGE = 10;
constexpr int STATIC_COL_COUNT = 11;

// 动态明细结果列（按最新要求简化）
constexpr int DYN_COL_POSITION = 0;
constexpr int DYN_COL_PRODUCT_CODE = 1;
constexpr int DYN_COL_CHANNEL = 2;
constexpr int DYN_COL_PROGRESS = 3;
constexpr int DYN_COL_ITEM_NO = 4;
constexpr int DYN_COL_ITEM_NAME = 5;
constexpr int DYN_COL_VALUE = 6;
constexpr int DYN_COL_UNIT = 7;
constexpr int DYN_COL_STANDARD = 8;
constexpr int DYN_COL_RESULT = 9;
constexpr int DYN_COL_COUNT = 10;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      ui(new Ui::MainWindow),
      m_plc(new MitsubishiPLC(this)),
      m_dmm(new SCPIController(this)),
      m_dynamicController(new DynamicTestController(this))
{
    ui->setupUi(this);

    qRegisterMetaType<StaticTestResult>("StaticTestResult");
    qRegisterMetaType<DynamicItemResult>("DynamicItemResult");
    qRegisterMetaType<DynamicProductResult>("DynamicProductResult");
    qRegisterMetaType<QVector<DynamicProductResult>>("QVector<DynamicProductResult>");
    qRegisterMetaType<ZlgCanOpenConfig>("ZlgCanOpenConfig");
    qRegisterMetaType<ZlgCanFrame>("ZlgCanFrame");

    initUi();
    initResultTables();
    initConnections();
    initDebugMenu();
    initProductionStatusUi();

    m_testDurationTimer = new QTimer(this);
    connect(m_testDurationTimer,
            &QTimer::timeout,
            this,
            &MainWindow::updateTestDuration);

    refreshSerialPorts();

    appendLog("测试主界面已启动。阻容区域与动态区域均已加载。");
}

MainWindow::~MainWindow()
{
    safeStopAll("主界面析构");
    cleanupStaticThread();

    if (m_dynamicController) {
        m_dynamicController->requestStop();
        m_dynamicController->closeCanDevice();
    }

    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (m_autoTesting) {
        const QMessageBox::StandardButton ret =
                QMessageBox::question(this,
                                      "确认关闭",
                                      "当前测试仍在进行，关闭窗口会停止测试并执行安全停止。是否继续？",
                                      QMessageBox::Yes | QMessageBox::No,
                                      QMessageBox::No);

        if (ret != QMessageBox::Yes) {
            event->ignore();
            return;
        }
    }

    m_stopRequested = true;

    if (m_staticRunner) {
        m_staticRunner->requestInterrupt();
    }

    if (m_dynamicController) {
        m_dynamicController->requestStop();
    }

    safeStopAll("关闭主界面");
    event->accept();
}

void MainWindow::initUi()
{
    ui->lblPLCStatus->setText("PLC：未连接");
    ui->lblDMMStatus->setText("万用表/电桥：未连接");
    ui->lblCanStatus->setText("CAN：未连接");
    ui->lblOverallStatus->setText("待机");

    ui->editProductCode1->clear();
    ui->editProductCode2->clear();

    initCanUi();

    setCanConnectedState(false);
    setAutoTestingState(false);
}

void MainWindow::initCanUi()
{
    ui->cmbCanDeviceType->clear();
    ui->cmbCanDeviceType->addItem("USBCANFD-200U", static_cast<int>(ZlgCanDeviceType::UsbCanFd200U));
    ui->cmbCanDeviceType->addItem("USBCAN-II+", static_cast<int>(ZlgCanDeviceType::UsbCanIIPlus));

    auto fillChannelCombo = [](QComboBox *combo) {
        combo->clear();
        combo->addItem("0x110 -> 0x201", static_cast<int>(DynamicProtocol::DynamicChannel::Channel110));
        combo->addItem("0x112 -> 0x301", static_cast<int>(DynamicProtocol::DynamicChannel::Channel112));
        combo->addItem("0x114 -> 0x401", static_cast<int>(DynamicProtocol::DynamicChannel::Channel114));
        combo->addItem("0x116 -> 0x501", static_cast<int>(DynamicProtocol::DynamicChannel::Channel116));
    };

    fillChannelCombo(ui->cmbDynamicChannel1);
    fillChannelCombo(ui->cmbDynamicChannel2);
    ui->cmbDynamicChannel1->setCurrentIndex(0);
    ui->cmbDynamicChannel2->setCurrentIndex(1);

    ui->spinCanDeviceIndex->setRange(0, 16);
    ui->spinCanChannelIndex->setRange(0, 8);

    ui->spinCanBaudRate->setRange(10000, 1000000);
    ui->spinCanBaudRate->setValue(500000);

    ui->spinCanFdAbit->setRange(10000, 1000000);
    ui->spinCanFdAbit->setValue(500000);

    ui->spinCanFdDbit->setRange(10000, 8000000);
    ui->spinCanFdDbit->setValue(2000000);

    ui->spinDynamicTimeout->setRange(10, 600);
    ui->spinDynamicTimeout->setValue(180);

    ui->chkExtendedFrame->setChecked(true);
    ui->chkSendAsCanFd->setChecked(false);
    ui->chkReceiveCanFd->setChecked(false);
    ui->chkTerminalResistance->setChecked(false);
}


void MainWindow::initDebugMenu()
{
    QMenu *debugMenu = menuBar()->addMenu("调试");

    QAction *actDeviceConnection = debugMenu->addAction("设备连接");
    QAction *actDynamicParamConfig = debugMenu->addAction("动态检测参数配置");

    debugMenu->addSeparator();

    QAction *actManualDynamicTest = debugMenu->addAction("手动动态测试");
    QAction *actManualStaticTest = debugMenu->addAction("手动阻容测试");
    QAction *actPlcPointTest = debugMenu->addAction("PLC点位测试");

    debugMenu->addSeparator();

    QAction *actLogWindow = debugMenu->addAction("日志输出窗口");

    connect(actDeviceConnection,
            &QAction::triggered,
            this,
            &MainWindow::onActionDeviceConnectionTriggered);

    connect(actDynamicParamConfig,
            &QAction::triggered,
            this,
            &MainWindow::onActionDynamicParamConfigTriggered);

    connect(actManualDynamicTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionManualDynamicTestTriggered);

    connect(actManualStaticTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionManualStaticTestTriggered);

    connect(actPlcPointTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionPlcPointTestTriggered);

    connect(actLogWindow,
            &QAction::triggered,
            this,
            &MainWindow::onActionLogWindowTriggered);
}

void MainWindow::initProductionStatusUi()
{
    /*
     * 主界面只保留量产操作区。
     * PLC/仪表连接、CAN设备连接、日志输出不在主界面显示，统一放到“调试”菜单弹窗。
     *
     * 注意：为了不改当前已经能跑的设备连接函数，部分旧控件仍作为隐藏参数缓存存在，
     * 但运行界面上不会显示这些区域。
     */
    ui->groupBoxDevice->hide();
    ui->groupBoxCan->hide();
    ui->textLog->hide();

    ui->btnRefreshPorts->hide();
    ui->btnConnectDevices->hide();
    ui->btnConnectCan->hide();
    ui->btnDisconnectCan->hide();

    ui->btnManualStaticTest->hide();
    ui->btnManualDynamicTest->hide();
    ui->btnPlcTest->hide();

    ui->btnExportStaticCsv->hide();
    ui->btnExportDynamicCsv->hide();
    ui->btnClearResults->hide();

    ui->labelDynChannel1->hide();
    ui->labelDynChannel2->hide();
    ui->cmbDynamicChannel1->hide();
    ui->cmbDynamicChannel2->hide();

    ui->editProductCode1->setMaxLength(18);
    ui->editProductCode2->setMaxLength(18);
    ui->editProductCode1->setFocus();

    ui->progressTest->setRange(0, 100);
    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：待机");

    QSettings settings("ECPS", "StaticDynamicTester");
    m_connectorPlugCount =
            settings.value("runtime/connectorPlugCount", 0).toInt();

    ui->lblConnectorPlugCount->setText(
                QString("接插件插拔次数：%1").arg(m_connectorPlugCount));

    ui->lblTestDuration->setText("测试时长：00:00:00");

    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");
    hideFinalResultImage();

    initDailyStatisticsUi();

    ui->btnEmergencyStop->setStyleSheet(
        "QPushButton {"
        "background-color:#D32F2F;"
        "color:white;"
        "font-weight:bold;"
        "font-size:18px;"
        "border-radius:6px;"
        "padding:8px 16px;"
        "}"
        "QPushButton:pressed { background-color:#B71C1C; }"
    );
}

void MainWindow::initDailyStatisticsUi()
{
    /*
     * 当日统计 QLabel 已固定写在 mainwindow.ui 中。
     * 不再运行时动态 new QLabel。
     */
    m_dailyStatistics.loadToday();
    refreshDailyStatisticsUi();
}










void MainWindow::refreshDailyStatisticsUi()
{
    const DailyTestSummary s = m_dailyStatistics.summary();

    ui->lblDailyTotalCount->setText(QString::number(s.totalCount));
    ui->lblDailyPassCount->setText(QString::number(s.passCount));
    ui->lblDailyNgCount->setText(QString::number(s.ngCount));

    ui->lblDailyStaticPassCount->setText(QString::number(s.staticPassCount));
    ui->lblDailyStaticNgCount->setText(QString::number(s.staticNgCount));

    ui->lblDailyDynamicPassCount->setText(QString::number(s.dynamicPassCount));
    ui->lblDailyDynamicNgCount->setText(QString::number(s.dynamicNgCount));
}


bool MainWindow::staticPassForPosition(int position) const
{
    bool found = false;

    for (const StaticTestResult &result : m_staticResults) {
        if (result.position != position) {
            continue;
        }

        found = true;

        if (!result.pass) {
            return false;
        }
    }

    return found;
}

bool MainWindow::staticPassForProductCode(const QString &productCode) const
{
    const QString code = productCode.trimmed();

    if (code.isEmpty()) {
        return false;
    }

    return m_currentAutoStaticPassMap.value(code, false);
}

void MainWindow::updateDailyStatisticsAfterAutoTest(const QVector<DynamicProductResult> &results)
{
    /*
     * 只统计自动化测试。
     * 手动阻容测试、手动动态测试不会进入这里。
     */
    if (!m_autoTesting || m_stopRequested) {
        return;
    }

    m_currentAutoDynamicPassMap.clear();

    for (const DynamicProductResult &dynamicResult : results) {
        const QString code = dynamicResult.productCode.trimmed();

        if (code.isEmpty()) {
            continue;
        }

        /*
         * 动态未完成、超时、异常收尾时，本轮动态按 NG。
         * 如果是用户停止测试，前面的 m_stopRequested 已经 return，不会统计。
         */
        m_currentAutoDynamicPassMap[code] =
                dynamicResult.finished && dynamicResult.pass;
    }

    const QDateTime now = QDateTime::currentDateTime();

    auto updateOneCode = [&](const QString &productCode) {
        const QString code = productCode.trimmed();

        if (code.isEmpty()) {
            return;
        }

        const bool staticPass = m_currentAutoStaticPassMap.value(code, false);
        const bool dynamicPass = m_currentAutoDynamicPassMap.value(code, false);

        /*
         * DailyTestStatistics 内部按 productCode 覆盖旧记录：
         * 1. 同一条码多次 NG，只算 1 个 NG；
         * 2. 同一条码前几次 NG，最后 PASS，会覆盖为 PASS；
         * 3. 计数由唯一条码的最后一次自动化测试结果重新统计。
         */
        m_dailyStatistics.updateProduct(code,
                                        staticPass,
                                        dynamicPass,
                                        now);
    };

    updateOneCode(m_productCode1);

    if (!m_singleProductMode) {
        updateOneCode(m_productCode2);
    }

    QString error;
    if (!m_dailyStatistics.save(&error)) {
        appendLog(QString("当日测试统计保存失败：%1").arg(error));
    } else {
        appendLog(QString("当日测试统计已保存：%1")
                  .arg(m_dailyStatistics.todayFilePath()));
    }

    refreshDailyStatisticsUi();
}



void MainWindow::initResultTables()
{
    ui->tableStaticResults->clear();
    ui->tableStaticResults->setColumnCount(STATIC_COL_COUNT);
    ui->tableStaticResults->setRowCount(0);
    ui->tableStaticResults->setHorizontalHeaderLabels({
        "时间",
        "产品编码",
        "位置",
        "测试项",
        "方向",
        "M点",
        "标准",
        "电阻/kOhm",
        "电容/nF",
        "结果",
        "备注"
    });
    ui->tableStaticResults->horizontalHeader()->setStretchLastSection(false);
    ui->tableStaticResults->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableStaticResults->horizontalHeader()->setSectionResizeMode(STATIC_COL_STANDARD, QHeaderView::Stretch);
    ui->tableStaticResults->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableStaticResults->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableStaticResults->setAlternatingRowColors(true);

    ui->tableStaticResults->setColumnHidden(STATIC_COL_TIME, true);
    ui->tableStaticResults->setColumnHidden(STATIC_COL_PRODUCT_CODE, true);
    ui->tableStaticResults->setColumnHidden(STATIC_COL_DIRECTION, true);
    ui->tableStaticResults->setColumnHidden(STATIC_COL_M_POINTS, true);

    ui->tableDynamicResults->clear();
    ui->tableDynamicResults->setColumnCount(DYN_COL_COUNT);
    ui->tableDynamicResults->setRowCount(0);
    ui->tableDynamicResults->setHorizontalHeaderLabels({
        "位置",
        "产品编码",
        "通道",
        "检测进度",
        "检测项编号",
        "检测项名称",
        "检测值",
        "单位",
        "检测标准",
        "结果"
    });
    ui->tableDynamicResults->horizontalHeader()->setStretchLastSection(false);
    ui->tableDynamicResults->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableDynamicResults->horizontalHeader()->setSectionResizeMode(DYN_COL_STANDARD, QHeaderView::Stretch);
    ui->tableDynamicResults->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableDynamicResults->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableDynamicResults->setAlternatingRowColors(true);

    ui->tableDynamicResults->setColumnHidden(DYN_COL_PRODUCT_CODE, true);
    ui->tableDynamicResults->setColumnHidden(DYN_COL_CHANNEL, true);
    ui->tableDynamicResults->setColumnHidden(DYN_COL_PROGRESS, true);
}

void MainWindow::initConnections()
{
    connect(ui->btnRefreshPorts, &QPushButton::clicked, this, &MainWindow::onRefreshPorts);
    connect(ui->btnConnectDevices, &QPushButton::clicked, this, &MainWindow::onConnectDevices);

    connect(ui->btnConnectCan, &QPushButton::clicked, this, &MainWindow::onConnectCan);
    connect(ui->btnDisconnectCan, &QPushButton::clicked, this, &MainWindow::onDisconnectCan);

    connect(ui->btnStartAutoTest, &QPushButton::clicked, this, &MainWindow::onStartAutoTest);
    connect(ui->btnStopTest, &QPushButton::clicked, this, &MainWindow::onStopTest);

    connect(ui->btnManualStaticTest, &QPushButton::clicked, this, &MainWindow::onOpenManualStaticTestWindow);
    connect(ui->btnManualDynamicTest, &QPushButton::clicked, this, &MainWindow::onOpenManualDynamicTestWindow);
    connect(ui->btnPlcTest, &QPushButton::clicked, this, &MainWindow::onOpenPlcTestWindow);

    connect(ui->btnEmergencyStop, &QPushButton::clicked, this, &MainWindow::onEmergencyStop);
    connect(ui->btnExportStaticCsv, &QPushButton::clicked, this, &MainWindow::onExportStaticCsv);
    connect(ui->btnExportDynamicCsv, &QPushButton::clicked, this, &MainWindow::onExportDynamicCsv);
    connect(ui->btnClearResults, &QPushButton::clicked, this, &MainWindow::onClearResults);

    connect(ui->editProductCode1,
            &QLineEdit::textEdited,
            this,
            &MainWindow::onBarcode1Changed);

    connect(m_plc, &MitsubishiPLC::logMessage, this, &MainWindow::appendLog);
    connect(m_dmm, &SCPIController::logMessage, this, &MainWindow::appendLog);

    connect(m_dynamicController, &DynamicTestController::logMessage,
            this, &MainWindow::onDynamicLogMessage, Qt::UniqueConnection);

    connect(m_dynamicController, &DynamicTestController::canConnectedChanged,
            this, &MainWindow::onCanConnectedChanged, Qt::UniqueConnection);

    connect(m_dynamicController, &DynamicTestController::productProgressChanged,
            this, &MainWindow::onDynamicProductProgressChanged, Qt::UniqueConnection);

    connect(m_dynamicController, &DynamicTestController::productFrameUpdated,
            this, &MainWindow::onDynamicProductFrameUpdated, Qt::UniqueConnection);

    connect(m_dynamicController, &DynamicTestController::productFinished,
            this, &MainWindow::onDynamicProductFinished, Qt::UniqueConnection);

    connect(m_dynamicController, &DynamicTestController::allFinished,
            this, &MainWindow::onDynamicAllFinished, Qt::UniqueConnection);
}

void MainWindow::refreshSerialPorts()
{
    ui->cmbPlcPort->clear();

    const QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();

    for (const QSerialPortInfo &port : ports) {
        ui->cmbPlcPort->addItem(port.portName());
    }

    if (ui->cmbPlcPort->count() == 0) {
        ui->cmbPlcPort->addItem("未发现串口");
    }
}

void MainWindow::onRefreshPorts()
{
    refreshSerialPorts();
    appendLog("已刷新PLC串口列表。");
}

void MainWindow::onConnectDevices()
{
    const QString portName = ui->cmbPlcPort->currentText().trimmed();
    const QString visaAddress = ui->editVisaAddress->text().trimmed();

    if (portName.isEmpty() || portName == "未发现串口") {
        QMessageBox::warning(this, "提示", "请选择正确的PLC串口。");
        return;
    }

    if (visaAddress.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入万用表/电桥 VISA 地址。");
        return;
    }

    appendLog(QString("开始连接PLC：%1").arg(portName));

    if (!m_plc->connectDevice(portName)) {
        ui->lblPLCStatus->setText("PLC：连接失败");
        QMessageBox::critical(this, "PLC连接失败", m_plc->lastError());
        return;
    }

    if (!m_plc->ping()) {
        ui->lblPLCStatus->setText("PLC：通信异常");
        QMessageBox::critical(this, "PLC通信异常", m_plc->lastError());
        return;
    }

    ui->lblPLCStatus->setText("PLC：已连接");

    appendLog(QString("开始连接万用表/电桥：%1").arg(visaAddress));

    if (!m_dmm->connectInstrument(visaAddress)) {
        ui->lblDMMStatus->setText("万用表/电桥：连接失败");
        QMessageBox::critical(this, "万用表/电桥连接失败", m_dmm->lastError());
        return;
    }

    if (!m_dmm->ping()) {
        ui->lblDMMStatus->setText("万用表/电桥：通信异常");
        QMessageBox::critical(this, "万用表/电桥通信异常", m_dmm->lastError());
        return;
    }

    ui->lblDMMStatus->setText("万用表/电桥：已连接");

    appendLog("PLC与万用表/电桥连接完成。CAN设备请在右侧CAN区域单独连接。");
}

void MainWindow::onConnectCan()
{
    ZlgCanOpenConfig config = currentCanConfig();

    if (!m_dynamicController->openCanDevice(config)) {
        QMessageBox::warning(this,
                             "CAN连接失败",
                             "CAN设备打开失败，请检查设备类型、设备索引、通道、驱动和波特率设置。");
        return;
    }

    m_dynamicController->setTimeoutMs(ui->spinDynamicTimeout->value() * 1000);
}

void MainWindow::onDisconnectCan()
{
    if (m_autoTesting) {
        QMessageBox::warning(this, "提示", "测试运行中，不能断开CAN设备。");
        return;
    }

    m_dynamicController->closeCanDevice();
}

void MainWindow::onCanConnectedChanged(bool connected)
{
    setCanConnectedState(connected);
}

QString MainWindow::dailyRecordTextForCode(const QString &productCode) const
{
    const QString code = productCode.trimmed();

    if (code.isEmpty()) {
        return QString();
    }

    const QVector<ProductDailyRecord> recordList = m_dailyStatistics.records();

    for (const ProductDailyRecord &record : recordList) {
        if (record.productCode.trimmed() != code) {
            continue;
        }

        return QString("条码：%1\n"
                       "上次测试时间：%2\n"
                       "上次总结果：%3\n"
                       "上次阻容结果：%4\n"
                       "上次动态结果：%5")
                .arg(record.productCode)
                .arg(record.time.toString("yyyy-MM-dd HH:mm:ss"))
                .arg(record.finalPass ? "PASS" : "NG")
                .arg(record.staticPass ? "PASS" : "NG")
                .arg(record.dynamicPass ? "PASS" : "NG");
    }

    return QString();
}

bool MainWindow::confirmRepeatedBarcodesIfNeeded()
{
    QStringList repeatedMessages;

    const QString code1 = m_productCode1.trimmed();
    const QString code2 = m_productCode2.trimmed();

    const QString record1 = dailyRecordTextForCode(code1);

    if (!record1.isEmpty()) {
        repeatedMessages << QString("位置1产品当天已测试过：\n%1").arg(record1);
    }

    if (!m_singleProductMode) {
        const QString record2 = dailyRecordTextForCode(code2);

        if (!record2.isEmpty()) {
            repeatedMessages << QString("位置2产品当天已测试过：\n%1").arg(record2);
        }
    }

    if (repeatedMessages.isEmpty()) {
        return true;
    }

    const QString message =
            repeatedMessages.join("\n\n")
            + "\n\n继续测试会以本次自动化测试结果覆盖当天统计中的旧结果。\n"
              "是否继续？";

    const QMessageBox::StandardButton button =
            QMessageBox::question(this,
                                  "当日条码重复提示",
                                  message,
                                  QMessageBox::Yes | QMessageBox::No,
                                  QMessageBox::No);

    return button == QMessageBox::Yes;
}

bool MainWindow::validateProductCodes()
{
    m_productCode1 = ui->editProductCode1->text().trimmed();
    m_productCode2 = ui->editProductCode2->text().trimmed();

    if (m_productCode1.isEmpty()) {
        QMessageBox::warning(this, "提示", "请先扫描或输入位置1产品条码。");
        return false;
    }

    if (m_productCode1.length() != 18) {
        QMessageBox::warning(this, "提示", "位置1条码必须为18位。");
        return false;
    }

    /*
     * 位置2为空：单圈/单产品模式；
     * 位置2不为空：双圈/双产品模式。
     */
    m_singleProductMode = m_productCode2.isEmpty();

    if (!m_singleProductMode && m_productCode2.length() != 18) {
        QMessageBox::warning(this,
                             "提示",
                             "位置2条码必须为18位；如果只测单圈，请清空位置2条码。");
        return false;
    }

    /*
     * 双圈模式下，位置1和位置2不能是同一个条码。
     */
    if (!m_singleProductMode && m_productCode1 == m_productCode2) {
        QMessageBox::warning(this,
                             "提示",
                             "位置1和位置2产品条码相同，请检查扫码是否重复。");
        return false;
    }

    /*
     * 当日重复条码提示。
     * 这里只检查 DailyTestStatistics 中已有的自动化测试记录；
     * 手动阻容/手动动态不进入当天统计，所以不会触发这里的重复提示。
     */
    if (!confirmRepeatedBarcodesIfNeeded()) {
        appendLog("用户取消当日重复条码的自动化测试。");
        return false;
    }

    appendLog(QString("产品模式：%1。位置1=%2，位置2=%3。")
              .arg(m_singleProductMode ? "单圈/单产品" : "双圈/双产品")
              .arg(m_productCode1)
              .arg(m_singleProductMode ? "-" : m_productCode2));

    return true;
}



void MainWindow::onStartAutoTest()
{
    if (m_autoTesting) {
        QMessageBox::information(this, "提示", "自动化测试正在进行中。");
        return;
    }

    if (!m_plc || !m_plc->isConnected()) {
        QMessageBox::warning(this, "提示", "请先连接PLC。");
        return;
    }

    if (!m_dmm || !m_dmm->isConnected()) {
        QMessageBox::warning(this, "提示", "请先连接万用表/电桥。");
        return;
    }

    if (!m_dynamicController || !m_canConnected) {
        QMessageBox::warning(this, "提示", "请先连接CAN设备。");
        return;
    }

    if (!validateProductCodes()) {
        return;
    }

    if (!m_singleProductMode &&
            m_dynamicParamConfig.position1Channel == m_dynamicParamConfig.position2Channel) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能选择同一个动态通道，请先在“调试 -> 动态检测参数配置”中修改。");
        return;
    }

    m_staticResults.clear();
    m_dynamicResults.clear();
    ui->tableStaticResults->setRowCount(0);
    ui->tableDynamicResults->setRowCount(0);

    m_staticHasFailed = false;
    m_dynamicHasFailed = false;
    m_stopRequested = false;

    m_currentAutoStaticPassMap.clear();
    m_currentAutoDynamicPassMap.clear();

    /*
     * 自动化测试完整结果 CSV 的开始时间：
     * 记录本次点击“开始自动化测试”并通过前置校验后的时间。
     */
    m_autoTestStartDateTime = QDateTime::currentDateTime();

    m_readyToClearProductCodesOnNextInput = false;
    m_adjustingProductCode1Text = false;
    m_lastCompletedProductCode1.clear();
    m_lastCompletedProductCode2.clear();
    hideFinalResultImage();

    ++m_connectorPlugCount;

    QSettings settings("ECPS", "StaticDynamicTester");
    settings.setValue("runtime/connectorPlugCount", m_connectorPlugCount);

    ui->lblConnectorPlugCount->setText(
                QString("接插件插拔次数：%1").arg(m_connectorPlugCount));

    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：阻容测试");
    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");
    startTestDurationTimer();

    setAutoTestingState(true);
    updateOverallStatus("自动化测试：准备阻容测试");

    if (!prepareStaticMode()) {
        safeStopAll("自动化测试进入阻容模式失败");
        setAutoTestingState(false);
        updateOverallStatus("准备失败");
        return;
    }

    startStaticAutoTest();
}

void MainWindow::startStaticAutoTest()
{
    cleanupStaticThread();

    m_staticThread = new QThread(this);
    m_staticRunner = new TestRunner(m_plc, m_dmm);

    m_staticRunner->moveToThread(m_staticThread);

    connect(m_staticThread, &QThread::finished, m_staticRunner, &QObject::deleteLater);
    connect(m_staticThread, &QThread::finished, m_staticThread, &QObject::deleteLater);

    QThread *threadPtr = m_staticThread;
    TestRunner *runnerPtr = m_staticRunner;

    connect(m_staticThread, &QThread::finished, this, [this, threadPtr, runnerPtr]() {
        if (m_staticThread == threadPtr) {
            m_staticThread = nullptr;
        }

        if (m_staticRunner == runnerPtr) {
            m_staticRunner = nullptr;
        }
    });

    connect(m_staticRunner, &TestRunner::logMessage, this, &MainWindow::appendLog);
    connect(m_staticRunner, &TestRunner::testStarted, this, &MainWindow::onStaticTestStarted);
    connect(m_staticRunner, &TestRunner::testCompleted, this, &MainWindow::onStaticTestCompleted);
    connect(m_staticRunner, &TestRunner::staticTestResultReady, this, &MainWindow::onStaticTestResultReady);
    connect(m_staticRunner, &TestRunner::allStaticTestsFinished, this, &MainWindow::onStaticTestsFinished);

    connect(m_staticThread, &QThread::started, m_staticRunner, [this, runnerPtr]() {
        if (m_singleProductMode) {
            appendLog("单圈模式：阻容测试只执行位置1。");
            runnerPtr->runStaticTestsForProduct(1,
                                                m_productCode1,
                                                allStaticTestIndices());
        } else {
            appendLog("双圈模式：阻容测试执行位置1和位置2。");
            runnerPtr->runStaticTestsForTwoProducts(m_productCode1,
                                                    m_productCode2,
                                                    allStaticTestIndices());
        }
    });

    appendLog("启动阻容测试线程。");
    updateOverallStatus("自动化测试：阻容测试中");
    m_staticThread->start();
}

void MainWindow::onStopTest()
{
    if (!m_autoTesting) {
        return;
    }

    appendLog("用户请求停止测试。");
    m_stopRequested = true;

    if (m_staticRunner) {
        m_staticRunner->requestInterrupt();
    }

    if (m_dynamicController) {
        m_dynamicController->requestStop();
    }

    safeStopAll("用户停止测试");
    setAutoTestingState(false);
    updateOverallStatus("已停止");
}

void MainWindow::onStaticTestStarted(const QString &testName)
{
    appendLog(QString("阻容测试开始：%1").arg(testName));
}

void MainWindow::onStaticTestCompleted(const QString &testName,
                                       int position,
                                       const QString &standardText,
                                       double forwardResistanceKOhm,
                                       double reverseResistanceKOhm,
                                       double forwardCapacitanceNf,
                                       double reverseCapacitanceNf,
                                       bool pass,
                                       const QString &message)
{
    addStaticSummaryRow(testName,
                        position,
                        standardText,
                        forwardResistanceKOhm,
                        reverseResistanceKOhm,
                        forwardCapacitanceNf,
                        reverseCapacitanceNf,
                        pass,
                        message);
}

void MainWindow::onStaticTestResultReady(const StaticTestResult &result)
{
    m_staticResults.append(result);

    const int row = ui->tableStaticResults->rowCount();
    ui->tableStaticResults->insertRow(row);

    ui->tableStaticResults->setItem(row, STATIC_COL_TIME, new QTableWidgetItem(result.timestamp));
    ui->tableStaticResults->setItem(row, STATIC_COL_PRODUCT_CODE, new QTableWidgetItem(result.productCode));
    ui->tableStaticResults->setItem(row, STATIC_COL_POSITION, new QTableWidgetItem(positionText(result.position)));
    ui->tableStaticResults->setItem(row, STATIC_COL_TEST_NAME, new QTableWidgetItem(result.testName));
    ui->tableStaticResults->setItem(row, STATIC_COL_DIRECTION, new QTableWidgetItem(result.directionName));
    ui->tableStaticResults->setItem(row, STATIC_COL_M_POINTS, new QTableWidgetItem(result.mPointsText));
    ui->tableStaticResults->setItem(row, STATIC_COL_STANDARD, new QTableWidgetItem(result.standardText));
    ui->tableStaticResults->setItem(row, STATIC_COL_RESISTANCE, new QTableWidgetItem(formatValue(result.resistanceKOhm)));
    ui->tableStaticResults->setItem(row, STATIC_COL_CAPACITANCE, new QTableWidgetItem(formatValue(result.capacitanceNf)));
    ui->tableStaticResults->setItem(row, STATIC_COL_RESULT, new QTableWidgetItem(passText(result.pass)));
    ui->tableStaticResults->setItem(row, STATIC_COL_MESSAGE, new QTableWidgetItem(result.message));

    setRowResultColor(ui->tableStaticResults, row, result.pass);

    ui->tableStaticResults->scrollToBottom();

    if (m_autoTesting) {
        QString code = result.productCode.trimmed();

        if (code.isEmpty()) {
            if (result.position == 1) {
                code = m_productCode1.trimmed();
            } else if (result.position == 2) {
                code = m_productCode2.trimmed();
            }
        }

        if (!code.isEmpty()) {
            if (!m_currentAutoStaticPassMap.contains(code)) {
                m_currentAutoStaticPassMap.insert(code, true);
            }

            /*
             * 一个产品有多个阻容测试项；
             * 任意一项 NG，则该产品本轮阻容结果为 NG。
             */
            m_currentAutoStaticPassMap[code] =
                    m_currentAutoStaticPassMap.value(code, true) && result.pass;
        }
    }
}

void MainWindow::onStaticTestsFinished(bool interrupted, bool hasFailed)
{
    appendLog(QString("阻容测试结束：interrupted=%1, hasFailed=%2。")
              .arg(interrupted ? "true" : "false")
              .arg(hasFailed ? "true" : "false"));

    if (m_staticThread && m_staticThread->isRunning()) {
        m_staticThread->quit();
    }

    m_staticHasFailed = hasFailed;

    ui->progressTest->setValue(50);
    setOverallResultLabel(ui->lblStaticOverallResult, !hasFailed);
    autoSaveStaticResults();

    if (interrupted || m_stopRequested) {
        safeStopAll("阻容测试中断");
        setAutoTestingState(false);
        updateOverallStatus("测试中断");
        return;
    }

    updateOverallStatus("自动化测试：准备动态测试");

    if (!prepareDynamicMode()) {
        safeStopAll("进入动态测试模式失败");
        setAutoTestingState(false);
        updateOverallStatus("动态模式准备失败");
        return;
    }

    startDynamicAutoTest();
}

void MainWindow::startDynamicAutoTest()
{
    if (!m_dynamicController || !m_canConnected) {
        appendLog("动态测试启动失败：CAN设备未连接。");
        finishDynamicMode();
        setAutoTestingState(false);
        updateOverallStatus("CAN未连接");
        return;
    }

    updateOverallStatus("自动化测试：等待伺服稳定");

    QTimer::singleShot(SERVO_STABLE_DELAY_MS, this, [this]() {
        if (!m_autoTesting || m_stopRequested) {
            finishDynamicMode();
            setAutoTestingState(false);
            updateOverallStatus("测试已停止");
            return;
        }

        appendLog("伺服稳定等待完成，启动动态检测。");
        updateOverallStatus("自动化测试：动态检测中");

        m_dynamicController->setTimeoutMs(ui->spinDynamicTimeout->value() * 1000);
        ui->lblCurrentTestStage->setText("当前测试：动态测试");

        if (m_singleProductMode) {
            appendLog("单圈模式：动态测试只发送 0x110，只接收 0x201。");

            m_dynamicController->startSingleProductTest(
                        m_productCode1,
                        DynamicProtocol::DynamicChannel::Channel110,
                        m_dynamicParamConfig.position1ThresholdFlag);
        } else {
            appendLog("双圈模式：动态测试执行位置1和位置2。");

            m_dynamicController->startDynamicTestWithChannels(
                        m_productCode1,
                        m_dynamicParamConfig.position1Channel,
                        m_dynamicParamConfig.position1ThresholdFlag,
                        m_productCode2,
                        m_dynamicParamConfig.position2Channel,
                        m_dynamicParamConfig.position2ThresholdFlag);
        }
    });
}

void MainWindow::onDynamicLogMessage(const QString &message)
{
    appendLog(QString("[动态] %1").arg(message));
}

void MainWindow::onDynamicProductProgressChanged(int productId,
                                                 int progress,
                                                 int groupCnt)
{
    appendLog(QString("位置%1动态进度：%2%，轮询组=%3。")
              .arg(productId)
              .arg(progress)
              .arg(groupCnt));
}

void MainWindow::onDynamicProductFrameUpdated(int productId,
                                              int seq,
                                              int value,
                                              int groupCnt)
{
    Q_UNUSED(productId)
    Q_UNUSED(seq)
    Q_UNUSED(value)
    Q_UNUSED(groupCnt)
}

void MainWindow::onDynamicProductFinished(DynamicProductResult result)
{
    appendLog(QString("位置%1动态检测完成，产品=%2，结果=%3。")
              .arg(result.productId)
              .arg(result.productCode)
              .arg(passText(result.pass)));

    addDynamicProductResult(result);
}

void MainWindow::onDynamicAllFinished(bool allPass,
                                      QVector<DynamicProductResult> results)
{
    appendLog(QString("动态测试结束，总结果=%1。").arg(passText(allPass)));

    finishDynamicMode();

    m_dynamicResults = results;
    ui->tableDynamicResults->setRowCount(0);

    for (const DynamicProductResult &result : m_dynamicResults) {
        addDynamicProductResult(result);
    }

    ui->progressTest->setValue(100);
    ui->lblCurrentTestStage->setText("当前测试：测试完成");
    setOverallResultLabel(ui->lblDynamicOverallResult, allPass);
    autoSaveDynamicResults(m_dynamicResults);
    stopTestDurationTimer();

    m_dynamicHasFailed = !allPass;

    const QDateTime autoTestEndTime = QDateTime::currentDateTime();

    if (m_autoTesting && !m_stopRequested) {
        updateDailyStatisticsAfterAutoTest(m_dynamicResults);
        saveAutoTestFullResultCsv(autoTestEndTime);
    }

    const bool finalPass = !m_staticHasFailed && !m_dynamicHasFailed;

    setAutoTestingState(false);

    showFinalResultImage(finalPass);

    if (finalPass) {
        updateOverallStatus("自动化测试完成：PASS");
    } else {
        updateOverallStatus("自动化测试完成：NG");
    }

    prepareNextBarcodeInput();
}

bool MainWindow::prepareStaticMode()
{
    appendLog("准备阻容测试模式：M27 OFF，M26 OFF，M19 OFF，M100复位。");

    if (!setServoPower(false)) {
        return false;
    }

    QThread::msleep(LINE_SWITCH_DELAY_MS);

    if (!setDynamicMode(false)) {
        return false;
    }

    if (!m_plc->setMRelay(M_RES_CAP_ENABLE, false)) {
        appendLog(QString("M19 OFF 失败：%1").arg(m_plc->lastError()));
        return false;
    }

    if (!m_plc->pulseMRelay(M_RESET_CHANNEL, 100)) {
        appendLog(QString("M100 脉冲复位失败：%1").arg(m_plc->lastError()));
        return false;
    }

    QThread::msleep(STATIC_RESET_DELAY_MS);
    return true;
}

bool MainWindow::prepareDynamicMode()
{
    appendLog("准备动态测试模式：M19 OFF，M100复位，M26 ON，M27 ON。");

    if (!m_plc->setMRelay(M_RES_CAP_ENABLE, false)) {
        appendLog(QString("M19 OFF 失败：%1").arg(m_plc->lastError()));
        return false;
    }

    if (!m_plc->pulseMRelay(M_RESET_CHANNEL, 100)) {
        appendLog(QString("M100 脉冲复位失败：%1").arg(m_plc->lastError()));
        return false;
    }

    QThread::msleep(STATIC_RESET_DELAY_MS);

    if (!setDynamicMode(true)) {
        return false;
    }

    QThread::msleep(LINE_SWITCH_DELAY_MS);

    if (!setServoPower(true)) {
        setDynamicMode(false);
        return false;
    }

    return true;
}

void MainWindow::finishDynamicMode()
{
    appendLog("动态测试收尾：M27 OFF -> M26 OFF。");

    setServoPower(false);

    QThread::msleep(LINE_SWITCH_DELAY_MS);

    setDynamicMode(false);
}

bool MainWindow::setDynamicMode(bool on)
{
    appendLog(QString("设置 M26 = %1，%2。")
              .arg(on ? "ON" : "OFF")
              .arg(on ? "切换到动态测试线路" : "切换回阻容测试线路"));

    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法设置 M26。");
        return false;
    }

    if (!m_plc->setMRelay(M_DYNAMIC_MODE, on)) {
        appendLog(QString("M26 设置失败：%1").arg(m_plc->lastError()));
        return false;
    }

    return true;
}

bool MainWindow::setServoPower(bool on)
{
    appendLog(QString("设置 M27 = %1，%2。")
              .arg(on ? "ON" : "OFF")
              .arg(on ? "打开伺服电机" : "关闭伺服电机"));

    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法设置 M27。");
        return false;
    }

    if (!m_plc->setMRelay(M_SERVO_POWER, on)) {
        appendLog(QString("M27 设置失败：%1").arg(m_plc->lastError()));
        return false;
    }

    return true;
}

bool MainWindow::emergencyStopServo(const QString &reason)
{
    appendLog(QString("紧急关闭伺服：%1，执行 M27 OFF。").arg(reason));

    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法发送 M27 OFF。");
        return false;
    }

    if (!m_plc->setMRelay(M_SERVO_POWER, false)) {
        appendLog(QString("M27 OFF 失败：%1").arg(m_plc->lastError()));
        return false;
    }

    appendLog("M27 OFF 成功，伺服电机关闭。");
    return true;
}

void MainWindow::safeStopAll(const QString &reason)
{
    appendLog(QString("执行安全停止：%1。").arg(reason));

    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，跳过安全停止命令。");
        return;
    }

    setServoPower(false);

    QThread::msleep(LINE_SWITCH_DELAY_MS);

    setDynamicMode(false);

    m_plc->setMRelay(M_RES_CAP_ENABLE, false);
    m_plc->pulseMRelay(M_RESET_CHANNEL, 100);
}

void MainWindow::onEmergencyStop()
{
    emergencyStopServo("用户点击主界面紧急关闭按钮");
}

void MainWindow::onOpenManualStaticTestWindow()
{
    if (!m_plc || !m_plc->isConnected()) {
        QMessageBox::warning(this, "提示", "请先连接PLC。");
        return;
    }

    if (!m_dmm || !m_dmm->isConnected()) {
        QMessageBox::warning(this, "提示", "请先连接万用表/电桥。");
        return;
    }

    auto *window = new ManualStaticTestWindow(m_plc, m_dmm, nullptr);
    window->setAttribute(Qt::WA_DeleteOnClose);
    window->setWindowTitle("手动阻容测试");
    window->show();
    window->raise();
    window->activateWindow();
}

void MainWindow::onOpenManualDynamicTestWindow()
{
    if (!m_dynamicController) {
        QMessageBox::warning(this, "提示", "动态检测控制器未初始化。");
        return;
    }

    if (m_manualDynamicWindow) {
        m_manualDynamicWindow->show();
        m_manualDynamicWindow->raise();
        m_manualDynamicWindow->activateWindow();
        return;
    }

    m_productCode1 = ui->editProductCode1->text().trimmed();
    m_productCode2 = ui->editProductCode2->text().trimmed();

    m_manualDynamicWindow = new ManualDynamicTestWindow(m_dynamicController,
                                                        m_dynamicParamConfig,
                                                        m_productCode1,
                                                        m_productCode2,
                                                        nullptr);
    m_manualDynamicWindow->setAttribute(Qt::WA_DeleteOnClose);
    m_manualDynamicWindow->setWindowTitle("手动动态测试");

    connect(m_manualDynamicWindow, &QObject::destroyed, this, [this]() {
        m_manualDynamicWindow = nullptr;
    });

    m_manualDynamicWindow->show();
    m_manualDynamicWindow->raise();
    m_manualDynamicWindow->activateWindow();
}

void MainWindow::onOpenPlcTestWindow()
{
    if (!m_plc || !m_plc->isConnected()) {
        QMessageBox::warning(this, "提示", "请先连接PLC。");
        return;
    }

    auto *window = new PlcTestWindow(m_plc, nullptr);
    window->setAttribute(Qt::WA_DeleteOnClose);
    window->setWindowTitle("PLC点位测试");
    window->show();
    window->raise();
    window->activateWindow();
}

void MainWindow::onExportStaticCsv()
{
    if (m_staticResults.isEmpty()) {
        QMessageBox::information(this, "提示", "当前没有阻容测试结果可导出。");
        return;
    }

    const QString filePath = QFileDialog::getSaveFileName(
                this,
                "导出阻容测试CSV",
                QDir(defaultCsvDir()).filePath(
                    QString("阻容测试结果_%1.csv")
                    .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"))),
                "CSV Files (*.csv)");

    if (filePath.isEmpty()) {
        return;
    }

    if (saveStaticCsv(filePath)) {
        QMessageBox::information(this, "提示", "阻容测试CSV导出完成。");
    }
}

void MainWindow::onExportDynamicCsv()
{
    if (m_dynamicResults.isEmpty()) {
        QMessageBox::information(this, "提示", "当前没有动态测试结果可导出。");
        return;
    }

    const QString filePath = QFileDialog::getSaveFileName(
                this,
                "导出动态测试CSV",
                QDir(defaultCsvDir()).filePath(
                    QString("动态测试结果_%1.csv")
                    .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"))),
                "CSV Files (*.csv)");

    if (filePath.isEmpty()) {
        return;
    }

    if (saveDynamicCsv(filePath)) {
        QMessageBox::information(this, "提示", "动态测试CSV导出完成。");
    }
}

void MainWindow::onClearResults()
{
    if (m_autoTesting) {
        QMessageBox::warning(this, "提示", "测试运行中，不能清空结果。");
        return;
    }

    m_staticResults.clear();
    m_dynamicResults.clear();
    ui->tableStaticResults->setRowCount(0);
    ui->tableDynamicResults->setRowCount(0);
    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");
    updateOverallStatus("待机");
    appendLog("已清空阻容和动态显示结果。");

    hideFinalResultImage();
}

void MainWindow::addStaticSummaryRow(const QString &testName,
                                     int position,
                                     const QString &standardText,
                                     double forwardResistanceKOhm,
                                     double reverseResistanceKOhm,
                                     double forwardCapacitanceNf,
                                     double reverseCapacitanceNf,
                                     bool pass,
                                     const QString &message)
{
    appendLog(QString("阻容测试项完成：%1，%2，结果=%3，%4。")
              .arg(positionText(position))
              .arg(testName)
              .arg(passText(pass))
              .arg(message));

    Q_UNUSED(standardText)
    Q_UNUSED(forwardResistanceKOhm)
    Q_UNUSED(reverseResistanceKOhm)
    Q_UNUSED(forwardCapacitanceNf)
    Q_UNUSED(reverseCapacitanceNf)
}

void MainWindow::addDynamicProductResult(const DynamicProductResult &productResult)
{
    for (const DynamicItemResult &item : productResult.itemResults) {
        addDynamicItemResultRow(productResult, item);
    }

    ui->tableDynamicResults->scrollToBottom();
}

void MainWindow::addDynamicItemResultRow(const DynamicProductResult &productResult,
                                         const DynamicItemResult &itemResult)
{
    const int row = ui->tableDynamicResults->rowCount();
    ui->tableDynamicResults->insertRow(row);

    ui->tableDynamicResults->setItem(row, DYN_COL_POSITION, new QTableWidgetItem(positionText(productResult.productId)));
    ui->tableDynamicResults->setItem(row, DYN_COL_PRODUCT_CODE, new QTableWidgetItem(productResult.productCode));
    ui->tableDynamicResults->setItem(row, DYN_COL_CHANNEL, new QTableWidgetItem(productResult.channelName));
    ui->tableDynamicResults->setItem(row, DYN_COL_PROGRESS, new QTableWidgetItem(QString::number(productResult.detectProgress)));
    ui->tableDynamicResults->setItem(row, DYN_COL_ITEM_NO, new QTableWidgetItem(QString::number(itemResult.itemNo)));
    ui->tableDynamicResults->setItem(row, DYN_COL_ITEM_NAME, new QTableWidgetItem(itemResult.itemName));
    ui->tableDynamicResults->setItem(row, DYN_COL_VALUE, new QTableWidgetItem(QString::number(itemResult.rawValue)));
    ui->tableDynamicResults->setItem(row, DYN_COL_UNIT, new QTableWidgetItem(itemResult.unit));
    ui->tableDynamicResults->setItem(row, DYN_COL_STANDARD, new QTableWidgetItem(itemResult.standardText));
    ui->tableDynamicResults->setItem(row, DYN_COL_RESULT, new QTableWidgetItem(passText(itemResult.pass)));

    setRowResultColor(ui->tableDynamicResults, row, itemResult.pass);
}

ZlgCanOpenConfig MainWindow::currentCanConfig() const
{
    ZlgCanOpenConfig config;

    config.deviceType = static_cast<ZlgCanDeviceType>(ui->cmbCanDeviceType->currentData().toInt());
    config.deviceIndex = ui->spinCanDeviceIndex->value();
    config.channelIndex = ui->spinCanChannelIndex->value();
    config.canBaudRate = ui->spinCanBaudRate->value();
    config.canFdAbitBaudRate = ui->spinCanFdAbit->value();
    config.canFdDbitBaudRate = ui->spinCanFdDbit->value();
    config.extendedFrame = ui->chkExtendedFrame->isChecked();
    config.sendAsCanFd = ui->chkSendAsCanFd->isChecked();
    config.receiveCanFd = ui->chkReceiveCanFd->isChecked();
    config.terminalResistance = ui->chkTerminalResistance->isChecked();
    config.pollIntervalMs = 10;

    return config;
}

DynamicProtocol::DynamicChannel MainWindow::currentDynamicChannel1() const
{
    return static_cast<DynamicProtocol::DynamicChannel>(ui->cmbDynamicChannel1->currentData().toInt());
}

DynamicProtocol::DynamicChannel MainWindow::currentDynamicChannel2() const
{
    return static_cast<DynamicProtocol::DynamicChannel>(ui->cmbDynamicChannel2->currentData().toInt());
}


void MainWindow::onActionDeviceConnectionTriggered()
{
    if (!m_deviceConnectionDialog) {
        m_deviceConnectionDialog = new DeviceConnectionDialog(this);
        m_deviceConnectionDialog->setAttribute(Qt::WA_DeleteOnClose);

        connect(m_deviceConnectionDialog, &QObject::destroyed, this, [this]() {
            m_deviceConnectionDialog = nullptr;
        });

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::refreshPlcPortsRequested,
                this,
                [this]() {
                    QStringList ports;
                    for (const QSerialPortInfo &port : QSerialPortInfo::availablePorts()) {
                        ports << port.portName();
                    }

                    if (m_deviceConnectionDialog) {
                        m_deviceConnectionDialog->setAvailablePlcPorts(ports);
                    }
                });

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectPlcRequested,
                this,
                &MainWindow::onDeviceDialogConnectPlcRequested);

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectMeterRequested,
                this,
                &MainWindow::onDeviceDialogConnectMeterRequested);

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectCanRequested,
                this,
                &MainWindow::onDeviceDialogConnectCanRequested);

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::closeCanRequested,
                this,
                &MainWindow::onDeviceDialogCloseCanRequested);
    }

    QStringList ports;
    for (const QSerialPortInfo &port : QSerialPortInfo::availablePorts()) {
        ports << port.portName();
    }

    m_deviceConnectionDialog->setAvailablePlcPorts(ports);
    m_deviceConnectionDialog->show();
    m_deviceConnectionDialog->raise();
    m_deviceConnectionDialog->activateWindow();
}

void MainWindow::onActionDynamicParamConfigTriggered()
{
    if (!m_dynamicParamConfigDialog) {
        m_dynamicParamConfigDialog = new DynamicParamConfigDialog(this);
        m_dynamicParamConfigDialog->setAttribute(Qt::WA_DeleteOnClose);
        m_dynamicParamConfigDialog->setConfig(m_dynamicParamConfig);

        connect(m_dynamicParamConfigDialog, &QObject::destroyed, this, [this]() {
            m_dynamicParamConfigDialog = nullptr;
        });

        connect(m_dynamicParamConfigDialog,
                &DynamicParamConfigDialog::configApplied,
                this,
                [this](DynamicParamConfig config) {
                    m_dynamicParamConfig = config;

                    appendLog(QString("动态检测参数已应用：位置1=%1 threshold=%2；位置2=%3 threshold=%4。")
                              .arg(DynamicProtocol::channelName(config.position1Channel))
                              .arg(config.position1ThresholdFlag)
                              .arg(DynamicProtocol::channelName(config.position2Channel))
                              .arg(config.position2ThresholdFlag));
                });
    }

    m_dynamicParamConfigDialog->show();
    m_dynamicParamConfigDialog->raise();
    m_dynamicParamConfigDialog->activateWindow();
}

void MainWindow::onActionManualDynamicTestTriggered()
{
    onOpenManualDynamicTestWindow();
}

void MainWindow::onActionManualStaticTestTriggered()
{
    onOpenManualStaticTestWindow();
}

void MainWindow::onActionPlcPointTestTriggered()
{
    onOpenPlcTestWindow();
}

void MainWindow::onActionLogWindowTriggered()
{
    if (!m_logWindow) {
        m_logWindow = new LogWindow(nullptr);
        m_logWindow->setAttribute(Qt::WA_DeleteOnClose);

        connect(m_logWindow, &QObject::destroyed, this, [this]() {
            m_logWindow = nullptr;
        });
    }

    m_logWindow->show();
    m_logWindow->raise();
    m_logWindow->activateWindow();
}

void MainWindow::onDeviceDialogConnectPlcRequested(QString portName)
{
    if (portName.isEmpty() || portName == "未发现串口") {
        QMessageBox::warning(this, "提示", "请选择正确的PLC串口。");
        return;
    }

    int index = ui->cmbPlcPort->findText(portName);
    if (index < 0) {
        ui->cmbPlcPort->addItem(portName);
        index = ui->cmbPlcPort->findText(portName);
    }
    ui->cmbPlcPort->setCurrentIndex(index);

    appendLog(QString("开始连接PLC：%1").arg(portName));

    if (!m_plc->connectDevice(portName)) {
        ui->lblPLCStatus->setText("PLC：连接失败");
        QMessageBox::critical(this, "PLC连接失败", m_plc->lastError());
        return;
    }

    if (!m_plc->ping()) {
        ui->lblPLCStatus->setText("PLC：通信异常");
        QMessageBox::critical(this, "PLC通信异常", m_plc->lastError());
        return;
    }

    ui->lblPLCStatus->setText("PLC：已连接");

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setPlcStatusText(ui->lblPLCStatus->text());
    }

    appendLog("PLC连接完成。");
}

void MainWindow::onDeviceDialogConnectMeterRequested(QString visaAddress)
{
    if (visaAddress.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入万用表/电桥 VISA 地址。");
        return;
    }

    ui->editVisaAddress->setText(visaAddress);

    appendLog(QString("开始连接万用表/电桥：%1").arg(visaAddress));

    if (!m_dmm->connectInstrument(visaAddress)) {
        ui->lblDMMStatus->setText("万用表/电桥：连接失败");
        QMessageBox::critical(this, "万用表/电桥连接失败", m_dmm->lastError());
        return;
    }

    if (!m_dmm->ping()) {
        ui->lblDMMStatus->setText("万用表/电桥：通信异常");
        QMessageBox::critical(this, "万用表/电桥通信异常", m_dmm->lastError());
        return;
    }

    ui->lblDMMStatus->setText("万用表/电桥：已连接");

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setMeterStatusText(ui->lblDMMStatus->text());
    }

    appendLog("万用表/电桥连接完成。");
}

void MainWindow::onDeviceDialogConnectCanRequested(ZlgCanOpenConfig config)
{
    int typeIndex = ui->cmbCanDeviceType->findData(static_cast<int>(config.deviceType));
    if (typeIndex >= 0) {
        ui->cmbCanDeviceType->setCurrentIndex(typeIndex);
    }

    ui->spinCanDeviceIndex->setValue(config.deviceIndex);
    ui->spinCanChannelIndex->setValue(config.channelIndex);
    ui->spinCanBaudRate->setValue(config.canBaudRate);
    ui->spinCanFdAbit->setValue(config.canFdAbitBaudRate);
    ui->spinCanFdDbit->setValue(config.canFdDbitBaudRate);
    ui->chkExtendedFrame->setChecked(config.extendedFrame);
    ui->chkSendAsCanFd->setChecked(config.sendAsCanFd);
    ui->chkReceiveCanFd->setChecked(config.receiveCanFd);
    ui->chkTerminalResistance->setChecked(config.terminalResistance);

    /*
     * 不改现有 CAN 连接函数：复用当前 onConnectCan()。
     */
    onConnectCan();

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setCanStatusText(ui->lblCanStatus->text());
    }
}

void MainWindow::onDeviceDialogCloseCanRequested()
{
    onDisconnectCan();

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setCanStatusText(ui->lblCanStatus->text());
    }
}

void MainWindow::onBarcode1Changed(const QString &text)
{
    if (m_adjustingProductCode1Text) {
        return;
    }

    QString currentText = text;

    /*
     * 自动化测试完成后，位置1仍保留上一次条码。
     * 此时下一次扫码可能出现两种情况：
     *
     * 1. 文本被选中后扫码：新条码直接替换旧条码；
     * 2. 文本没有被替换而是追加：旧条码 + 新输入。
     *
     * 这里在检测到位置1第一次用户输入时，清空位置1/位置2旧条码，
     * 同时保留这一次已经输入进来的新内容。
     */
    if (m_readyToClearProductCodesOnNextInput) {
        m_readyToClearProductCodesOnNextInput = false;

        QString preservedText = currentText;

        if (!m_lastCompletedProductCode1.isEmpty()
                && preservedText.length() > m_lastCompletedProductCode1.length()
                && preservedText.startsWith(m_lastCompletedProductCode1)) {
            preservedText = preservedText.mid(m_lastCompletedProductCode1.length());
        }

        m_adjustingProductCode1Text = true;

        {
            QSignalBlocker blocker1(ui->editProductCode1);
            QSignalBlocker blocker2(ui->editProductCode2);

            ui->editProductCode1->clear();
            ui->editProductCode2->clear();
            ui->editProductCode1->setText(preservedText);
        }

        m_adjustingProductCode1Text = false;

        ui->editProductCode1->setFocus();
        ui->editProductCode1->setCursorPosition(ui->editProductCode1->text().length());

        currentText = preservedText;
    }

    if (currentText.trimmed().length() == 18) {
        ui->editProductCode2->setFocus();
        ui->editProductCode2->selectAll();
    }
}


void MainWindow::prepareNextBarcodeInput()
{
    m_lastCompletedProductCode1 = ui->editProductCode1->text();
    m_lastCompletedProductCode2 = ui->editProductCode2->text();
    m_readyToClearProductCodesOnNextInput = true;
    m_adjustingProductCode1Text = false;

    ui->editProductCode1->setFocus();
    ui->editProductCode1->selectAll();
}

QString MainWindow::finalResultImagePath(bool pass) const
{
    const QString fileName = pass ? QStringLiteral("pass.png")
                                  : QStringLiteral("ng.png");

    const QString appPath =
            QCoreApplication::applicationDirPath() + QLatin1Char('/') + fileName;

    if (QFileInfo::exists(appPath)) {
        return appPath;
    }

    const QString currentPath =
            QDir::currentPath() + QLatin1Char('/') + fileName;

    if (QFileInfo::exists(currentPath)) {
        return currentPath;
    }

    /*
     * 如果后续把图片加入 Qt 资源文件，也兼容资源路径。
     */
    const QString resourcePath = QStringLiteral(":/images/") + fileName;

    if (QFileInfo::exists(resourcePath)) {
        return resourcePath;
    }

    return appPath;
}

void MainWindow::hideFinalResultImage()
{
    ui->lblFinalResultImage->clear();
    ui->lblFinalResultImage->hide();
}

void MainWindow::showFinalResultImage(bool pass)
{
    const QString path = finalResultImagePath(pass);

    QPixmap pixmap(path);

    if (pixmap.isNull()) {
        /*
         * 防御逻辑：图片缺失时不影响测试流程，退化为文字显示。
         */
        ui->lblFinalResultImage->setPixmap(QPixmap());
        ui->lblFinalResultImage->setText(pass ? "PASS" : "NG");
        ui->lblFinalResultImage->setAlignment(Qt::AlignCenter);
        ui->lblFinalResultImage->setStyleSheet(pass
                                               ? "QLabel { background-color:#1B5E20; color:white; font-size:32px; font-weight:bold; border-radius:8px; }"
                                               : "QLabel { background-color:#B71C1C; color:white; font-size:32px; font-weight:bold; border-radius:8px; }");
        ui->lblFinalResultImage->show();

        appendLog(QString("最终结果图片加载失败，已使用文字显示。图片路径：%1").arg(path));
        return;
    }

    QSize targetSize = ui->lblFinalResultImage->size();

    if (targetSize.width() < 80 || targetSize.height() < 50) {
        targetSize = QSize(180, 100);
    }

    ui->lblFinalResultImage->setText(QString());
    ui->lblFinalResultImage->setStyleSheet("QLabel { background: transparent; }");
    ui->lblFinalResultImage->setAlignment(Qt::AlignCenter);
    ui->lblFinalResultImage->setPixmap(
                pixmap.scaled(targetSize,
                              Qt::KeepAspectRatio,
                              Qt::SmoothTransformation));
    ui->lblFinalResultImage->show();
}

QString MainWindow::autoTestFullResultCsvPath() const
{
    return QStringLiteral("D:/电涡流测试结果/自动化测试完整结果.csv");
}

QString MainWindow::staticFullResultItemText(const StaticTestResult &result) const
{
    /*
     * 自动化完整结果 CSV 中，阻容测试项列只写测试项名称。
     * 例如：sin+->sin-、GND->sin+。
     *
     * 如果后续出现同一测试项多方向都需要记录，为避免列名看不出来方向，
     * 这里在 directionName 有效且不等于测试项本身时追加方向。
     */
    QString name = result.testName.trimmed();

    if (name.isEmpty()) {
        name = QString("位置%1阻容测试项").arg(result.position);
    }

    const QString direction = result.directionName.trimmed();

    if (!direction.isEmpty() && !name.contains(direction)) {
        name += QString("（%1）").arg(direction);
    }

    return name;
}

QString MainWindow::staticFullResultValueText(double value, const QString &unit) const
{
    if (value < 0.0 || !std::isfinite(value)) {
        return QString();
    }

    return QString("%1 %2").arg(formatValue(value)).arg(unit);
}




QString MainWindow::dynamicFullResultItemText(const DynamicItemResult &result) const
{
    /*
     * 自动化完整结果 CSV 中，动态测试项列只写测试项名称。
     * 测试标准单独写到下一列，测试值单独写到再下一列。
     */
    QString name = result.itemName.trimmed();

    if (name.isEmpty()) {
        name = QString("动态测试项%1").arg(result.itemNo);
    }

    return name;
}


void MainWindow::appendStaticFullResultTriples(const QVector<StaticTestResult> &items,
                                              QStringList &cells,
                                              int maxTripleCount) const
{
    /*
     * 自动化完整结果 CSV 的阻容明细按“三列一组”展开：
     *
     * 测试项 | 测试值 | 测试标准
     *
     * 一个阻容测试项如果同时有电阻和电容，就拆成两组：
     * sin+->sin- 电阻 | 300 kΩ | INI里的standardText
     * sin+->sin- 电容 | 6 nF   | INI里的standardText
     *
     * 这样不会把电阻、电容等测试值挤在同一个单元格里。
     */
    QStringList triples;

    for (const StaticTestResult &item : items) {
        const QString baseName = staticFullResultItemText(item);
        const QString standard = item.standardText.trimmed();

        if (item.resistanceKOhm >= 0.0 && std::isfinite(item.resistanceKOhm)) {
            triples << QString("%1 电阻").arg(baseName)
                    << staticFullResultValueText(item.resistanceKOhm, "kΩ")
                    << standard;
        }

        if (item.capacitanceNf >= 0.0 && std::isfinite(item.capacitanceNf)) {
            triples << QString("%1 电容").arg(baseName)
                    << staticFullResultValueText(item.capacitanceNf, "nF")
                    << standard;
        }
    }

    const int currentTripleCount = triples.size() / 3;

    for (int i = 0; i < maxTripleCount; ++i) {
        if (i < currentTripleCount) {
            cells << triples.at(i * 3)
                  << triples.at(i * 3 + 1)
                  << triples.at(i * 3 + 2);
        } else {
            cells << QString()
                  << QString()
                  << QString();
        }
    }
}

bool MainWindow::saveAutoTestFullResultCsv(const QDateTime &endTime)
{
    /*
     * 本文件用于记录每一次自动化测试明细，不按条码去重。
     * 和 DailyTestStatistics 的当日去重统计文件分开。
     */
    const QString filePath = autoTestFullResultCsvPath();

    QFileInfo fileInfo(filePath);
    QDir dir = fileInfo.dir();

    if (!dir.exists() && !dir.mkpath(".")) {
        appendLog(QString("创建自动化测试完整结果目录失败：%1").arg(dir.absolutePath()));
        return false;
    }

    const bool needHeader = !fileInfo.exists() || fileInfo.size() == 0;

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Append)) {
        appendLog(QString("打开自动化测试完整结果文件失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
#endif

    if (needHeader) {
        out << QChar(0xFEFF);
    }

    struct ProductFullRow
    {
        int position = 0;
        QString productCode;
        bool staticPass = false;
        bool dynamicPass = false;
        QVector<StaticTestResult> staticItems;
        QVector<DynamicItemResult> dynamicItems;
    };

    QVector<ProductFullRow> rows;

    auto buildRow = [&](int position, const QString &productCode) {
        ProductFullRow row;
        row.position = position;
        row.productCode = productCode.trimmed();

        if (row.productCode.isEmpty()) {
            return;
        }

        bool staticFound = false;
        bool staticPass = true;

        for (const StaticTestResult &result : m_staticResults) {
            const QString resultCode = result.productCode.trimmed();

            if ((!resultCode.isEmpty() && resultCode == row.productCode)
                    || (resultCode.isEmpty() && result.position == position)) {
                row.staticItems.append(result);
                staticFound = true;

                if (!result.pass) {
                    staticPass = false;
                }
            }
        }

        row.staticPass = staticFound && staticPass;

        bool dynamicFound = false;
        bool dynamicPass = false;

        for (const DynamicProductResult &productResult : m_dynamicResults) {
            const QString resultCode = productResult.productCode.trimmed();

            if ((!resultCode.isEmpty() && resultCode == row.productCode)
                    || (resultCode.isEmpty() && productResult.productId == position)) {
                row.dynamicItems = productResult.itemResults;
                dynamicFound = true;
                dynamicPass = productResult.finished && productResult.pass;
                break;
            }
        }

        row.dynamicPass = dynamicFound && dynamicPass;

        rows.append(row);
    };

    buildRow(1, m_productCode1);

    if (!m_singleProductMode) {
        buildRow(2, m_productCode2);
    }

    int maxStaticTripleCount = 0;
    int maxDynamicItemCount = 0;

    for (const ProductFullRow &row : rows) {
        int staticTripleCount = 0;

        for (const StaticTestResult &item : row.staticItems) {
            if (item.resistanceKOhm >= 0.0 && std::isfinite(item.resistanceKOhm)) {
                staticTripleCount++;
            }

            if (item.capacitanceNf >= 0.0 && std::isfinite(item.capacitanceNf)) {
                staticTripleCount++;
            }
        }

        maxStaticTripleCount = qMax(maxStaticTripleCount, staticTripleCount);
        maxDynamicItemCount = qMax(maxDynamicItemCount, row.dynamicItems.size());
    }

    QStringList header;
    header << "开始时间"
           << "结束时间"
           << "产品编码"
           << "是否合格"
           << "阻容是否合格"
           << "动态是否合格"
           << "位置";

    /*
     * 阻容明细列按“三列一组”展开：
     * 测试项、测试值、测试标准。
     *
     * 例如：
     * 阻容测试项1 = sin+->sin- 电阻
     * 阻容测试值1 = 300 kΩ
     * 阻容测试标准1 = INI里的standardText
     *
     * 如果同一个测试项同时有电阻和电容，会拆成两组，不会把所有测试值写在一个格子里。
     */
    for (int i = 0; i < maxStaticTripleCount; ++i) {
        header << QString("阻容测试项%1").arg(i + 1)
               << QString("阻容测试值%1").arg(i + 1)
               << QString("阻容测试标准%1").arg(i + 1);
    }

    /*
     * 动态明细列也按“三列一组”展开：
     * 测试项、测试值、测试标准。
     *
     * 动态测试标准来自 DynamicItemResult::standardText，
     * 该字段由动态检测项配置加载，standardText 来源于 INI。
     */
    for (int i = 0; i < maxDynamicItemCount; ++i) {
        header << QString("动态测试项%1").arg(i + 1)
               << QString("动态测试值%1").arg(i + 1)
               << QString("动态测试标准%1").arg(i + 1);
    }

    if (needHeader) {
        for (int i = 0; i < header.size(); ++i) {
            if (i > 0) {
                out << ",";
            }

            out << quoteCsvField(header.at(i));
        }

        out << "\n";
    }

    const QString startTimeText =
            m_autoTestStartDateTime.isValid()
            ? m_autoTestStartDateTime.toString("yyyy-MM-dd HH:mm:ss")
            : QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");

    const QString endTimeText = endTime.toString("yyyy-MM-dd HH:mm:ss");

    for (const ProductFullRow &row : rows) {
        const bool finalPass = row.staticPass && row.dynamicPass;

        QStringList cells;
        cells << startTimeText
              << endTimeText
              << row.productCode
              << passText(finalPass)
              << passText(row.staticPass)
              << passText(row.dynamicPass)
              << positionText(row.position);

        appendStaticFullResultTriples(row.staticItems,
                                      cells,
                                      maxStaticTripleCount);

        for (int i = 0; i < maxDynamicItemCount; ++i) {
            if (i < row.dynamicItems.size()) {
                const DynamicItemResult &item = row.dynamicItems.at(i);

                const QString valueText =
                        item.unit.trimmed().isEmpty()
                        ? QString::number(item.rawValue)
                        : QString("%1 %2").arg(item.rawValue).arg(item.unit.trimmed());

                cells << dynamicFullResultItemText(item)
                      << valueText
                      << item.standardText;
            } else {
                cells << QString()
                      << QString()
                      << QString();
            }
        }

        for (int i = 0; i < cells.size(); ++i) {
            if (i > 0) {
                out << ",";
            }

            out << quoteCsvField(cells.at(i));
        }

        out << "\n";
    }

    file.close();

    appendLog(QString("自动化测试完整结果已保存：%1").arg(filePath));
    return true;
}

void MainWindow::autoSaveStaticResults()
{
    QString path;
    QString error;

    if (CsvExporter::autoSaveStaticResultsForPosition(m_staticResults,
                                                       1,
                                                       m_productCode1,
                                                       &path,
                                                       &error)) {
        appendLog(QString("位置1阻容结果已自动保存：%1").arg(path));
    } else {
        appendLog(QString("位置1阻容结果自动保存失败：%1").arg(error));
    }

    if (m_singleProductMode) {
        appendLog("单圈模式：跳过位置2阻容结果保存。");
        return;
    }

    if (CsvExporter::autoSaveStaticResultsForPosition(m_staticResults,
                                                       2,
                                                       m_productCode2,
                                                       &path,
                                                       &error)) {
        appendLog(QString("位置2阻容结果已自动保存：%1").arg(path));
    } else {
        appendLog(QString("位置2阻容结果自动保存失败：%1").arg(error));
    }
}


void MainWindow::autoSaveDynamicResults(const QVector<DynamicProductResult> &results)
{
    QVector<QString> paths;
    QString error;

    if (DynamicCsvExporter::autoSaveResults(results, &paths, &error)) {
        for (const QString &path : paths) {
            appendLog(QString("动态结果已自动保存：%1").arg(path));
        }
    } else {
        appendLog(QString("动态结果自动保存失败：%1").arg(error));
    }
}

void MainWindow::setRowResultColor(QTableWidget *table, int row, bool pass)
{
    const QColor color = pass ? QColor(0, 128, 0) : QColor(200, 0, 0);

    for (int col = 0; col < table->columnCount(); ++col) {
        QTableWidgetItem *item = table->item(row, col);
        if (item) {
            item->setForeground(color);
        }
    }
}

void MainWindow::setOverallResultLabel(QLabel *label, bool pass)
{
    QString prefix = "结果";

    if (label == ui->lblStaticOverallResult) {
        prefix = "阻容";
    } else if (label == ui->lblDynamicOverallResult) {
        prefix = "动态";
    }

    label->setText(QString("%1：%2").arg(prefix, pass ? "PASS" : "NG"));
    label->setMinimumWidth(160);
    label->setStyleSheet(pass
                         ? "background-color:#1B5E20;color:white;font-size:20px;font-weight:bold;padding:4px 8px;"
                         : "background-color:#B71C1C;color:white;font-size:20px;font-weight:bold;padding:4px 8px;");
}

void MainWindow::resetOverallResultLabel(QLabel *label, const QString &text)
{
    label->setText(text);
    label->setMinimumWidth(160);
    label->setStyleSheet("background-color:#EEEEEE;color:#333333;font-size:18px;font-weight:bold;padding:4px 8px;");
}

void MainWindow::startTestDurationTimer()
{
    ui->lblTestDuration->setText("测试时长：00:00:00");
    m_testElapsedTimer.restart();

    if (m_testDurationTimer) {
        m_testDurationTimer->start(1000);
    }
}

void MainWindow::stopTestDurationTimer()
{
    if (m_testDurationTimer) {
        m_testDurationTimer->stop();
    }

    updateTestDuration();
}

void MainWindow::updateTestDuration()
{
    const qint64 seconds = m_testElapsedTimer.elapsed() / 1000;
    ui->lblTestDuration->setText(QString("测试时长：%1").arg(formatDuration(seconds)));
}

QString MainWindow::formatDuration(qint64 seconds) const
{
    const qint64 h = seconds / 3600;
    const qint64 m = (seconds % 3600) / 60;
    const qint64 s = seconds % 60;

    return QString("%1:%2:%3")
            .arg(h, 2, 10, QLatin1Char('0'))
            .arg(m, 2, 10, QLatin1Char('0'))
            .arg(s, 2, 10, QLatin1Char('0'));
}

bool MainWindow::saveStaticCsv(const QString &filePath)
{
    QDir().mkpath(QFileInfo(filePath).absolutePath());

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        appendLog(QString("阻容CSV保存失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
#endif
    out << QChar(0xFEFF);

    out << "测试类型,产品编码,测试位置,测试项,测试方向,M点,测试标准,电阻/kOhm,电容/nF,状态,备注,测试时间\n";

    for (const StaticTestResult &r : m_staticResults) {
        out << quoteCsvField("阻容测试") << ","
            << quoteCsvField(r.productCode) << ","
            << quoteCsvField(positionText(r.position)) << ","
            << quoteCsvField(r.testName) << ","
            << quoteCsvField(r.directionName) << ","
            << quoteCsvField(r.mPointsText) << ","
            << quoteCsvField(r.standardText) << ","
            << quoteCsvField(formatValue(r.resistanceKOhm)) << ","
            << quoteCsvField(formatValue(r.capacitanceNf)) << ","
            << quoteCsvField(passText(r.pass)) << ","
            << quoteCsvField(r.message) << ","
            << quoteCsvField(r.timestamp) << "\n";
    }

    return true;
}

bool MainWindow::saveDynamicCsv(const QString &filePath)
{
    QString error;

    if (!DynamicCsvExporter::exportResults(m_dynamicResults, filePath, &error)) {
        appendLog(QString("动态CSV保存失败：%1").arg(error));
        return false;
    }

    return true;
}

QString MainWindow::defaultCsvDir() const
{
    QDir dir(QCoreApplication::applicationDirPath());

    if (!dir.exists("results")) {
        dir.mkdir("results");
    }

    return dir.filePath("results");
}

QString MainWindow::quoteCsvField(const QString &text) const
{
    QString s = text;
    s.replace("\"", "\"\"");

    if (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r')) {
        s = "\"" + s + "\"";
    }

    return s;
}

QString MainWindow::formatValue(double value, int precision) const
{
    if (std::isnan(value) || value < 0.0) {
        return "-";
    }

    return QString::number(value, 'f', precision);
}

QString MainWindow::positionText(int position) const
{
    if (position == 1) {
        return "位置1";
    }

    if (position == 2) {
        return "位置2";
    }

    return QString("位置%1").arg(position);
}

QString MainWindow::passText(bool pass) const
{
    return pass ? "PASS" : "NG";
}

QString MainWindow::boolText(bool value) const
{
    return value ? "是" : "否";
}

QString MainWindow::timestampNow() const
{
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
}

QString MainWindow::canIdText(quint32 canId) const
{
    return DynamicProtocol::canIdToString(canId);
}

void MainWindow::appendLog(const QString &message)
{
    const QString line = QString("[%1] %2")
            .arg(QDateTime::currentDateTime().toString("HH:mm:ss.zzz"))
            .arg(message);

    /*
     * 主界面不再显示日志区域。保留隐藏 textLog 只是为了兼容旧逻辑，
     * 真正查看日志请从“调试 -> 日志输出窗口”打开。
     */
    ui->textLog->append(line);

    if (m_logWindow) {
        m_logWindow->appendLog(message);
    }
}

void MainWindow::setAutoTestingState(bool running)
{
    m_autoTesting = running;

    ui->btnStartAutoTest->setEnabled(!running);
    ui->btnStopTest->setEnabled(running);

    ui->btnConnectDevices->setEnabled(!running);
    ui->btnConnectCan->setEnabled(!running && !m_canConnected);
    ui->btnDisconnectCan->setEnabled(!running && m_canConnected);

    ui->btnManualStaticTest->setEnabled(!running);
    ui->btnManualDynamicTest->setEnabled(!running && m_canConnected);
    ui->btnPlcTest->setEnabled(!running);

    ui->btnExportStaticCsv->setEnabled(!running);
    ui->btnExportDynamicCsv->setEnabled(!running);
    ui->btnClearResults->setEnabled(!running);

    ui->editProductCode1->setEnabled(!running);
    ui->editProductCode2->setEnabled(!running);
    ui->cmbDynamicChannel1->setEnabled(!running);
    ui->cmbDynamicChannel2->setEnabled(!running);
}

void MainWindow::setCanConnectedState(bool connected)
{
    m_canConnected = connected;

    ui->lblCanStatus->setText(connected ? "CAN：已连接" : "CAN：未连接");

    ui->btnConnectCan->setEnabled(!connected && !m_autoTesting);
    ui->btnDisconnectCan->setEnabled(connected && !m_autoTesting);
    ui->btnManualDynamicTest->setEnabled(!m_autoTesting);

    ui->cmbCanDeviceType->setEnabled(!connected && !m_autoTesting);
    ui->spinCanDeviceIndex->setEnabled(!connected && !m_autoTesting);
    ui->spinCanChannelIndex->setEnabled(!connected && !m_autoTesting);
    ui->spinCanBaudRate->setEnabled(!connected && !m_autoTesting);
    ui->spinCanFdAbit->setEnabled(!connected && !m_autoTesting);
    ui->spinCanFdDbit->setEnabled(!connected && !m_autoTesting);
    ui->chkExtendedFrame->setEnabled(!connected && !m_autoTesting);
    ui->chkSendAsCanFd->setEnabled(!connected && !m_autoTesting);
    ui->chkReceiveCanFd->setEnabled(!connected && !m_autoTesting);
    ui->chkTerminalResistance->setEnabled(!connected && !m_autoTesting);
}

void MainWindow::updateOverallStatus(const QString &status)
{
    ui->lblOverallStatus->setText(status);
    appendLog(QString("状态更新：%1").arg(status));
}

QList<int> MainWindow::allStaticTestIndices() const
{
    return {0, 1, 2, 3, 4, 5, 6};
}

void MainWindow::cleanupStaticThread()
{
    if (m_staticRunner) {
        m_staticRunner->requestInterrupt();
    }

    if (m_staticThread) {
        m_staticThread->quit();
        m_staticThread->wait(3000);
        m_staticThread = nullptr;
        m_staticRunner = nullptr;
    }
}
