# DailyTestStatistics XLS 中文乱码修复

基于上一版 `full_result_item_value_standard_fix` 生成。

## 本次修复

`DailyTestStatistics::escapeXml()` 改成把所有非 ASCII 字符写成 XML 数字字符引用。

例如：

```text
当 -> &#x5F53;
日 -> &#x65E5;
```

这样生成的 xls/xml 主体基本是 ASCII 字节。即使 Excel/WPS 忽略 UTF-8/UTF-16 声明，
只要它按 XML 解析，就会还原出正确中文。

## 修改文件

```text
modified_files/daily_test_statistics.cpp
```

补丁包里保留了上一版其它文件，方便整包覆盖。

## 使用方式

1. 覆盖工程同名文件；
2. 重新 qmake；
3. 清理并重新构建；
4. 关闭 Excel/WPS；
5. 删除当天已经乱码的旧 xls；
6. 重新跑一次自动化测试生成新 xls。
