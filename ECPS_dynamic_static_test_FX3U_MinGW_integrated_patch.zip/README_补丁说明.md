# ECPS 动静态上位机：阻容/PLC/万用表集成补丁说明

本补丁把 `StaticSingleTester_FX3U_MinGW_DynamicVISA_source` 中验证过的阻容测试通信逻辑，整合到当前 `ECPS_StaticAndDynamic_Test` 工程。

## 1. PLC 通信修改

原工程中的 PLC 通信层为 Modbus RTU/ASCII 风格，并保留了 `setYRelay()`。

本补丁改为：

```text
FX3U + USB-SC09 + COM串口
9600 bps, 7E1, 无流控
FX 编程口协议
'7' = 强制 ON
'8' = 强制 OFF
```

保留接口：

```cpp
setMRelay(int mNumber, bool on)
pulseMRelay(int mNumber, int pulseMs)
resetMRange(int startM, int count)
setMRelays(...)
```

不再提供：

```cpp
setYRelay()
```

原来 Y26/Y27 的逻辑已经统一改成：

```text
M26：动态/阻容线路切换
M27：伺服开关
```

## 2. 万用表通信修改

原工程中的 `SCPIController` 是 TCP 版。

本补丁改为 MinGW 友好的 USB/VISA 版：

```text
不 include visa.h
不链接 visa64.lib
运行时通过 QLibrary 动态加载 visa64.dll
```

所以可用：

```text
Qt_5_14_2_MinGW_64_bit
```

直接编译。

运行电脑仍需安装：

```text
NI-VISA Runtime 或 Keysight VISA Runtime
```

如果没有万用表，VISA 地址填 `SIM` 可进入仿真模式。

默认测量流程：

```text
电阻：CONF:RES -> 等待 1000 ms -> READ?
电容：CONF:CAP -> 等待 1000 ms -> READ?
```

`TestRunner` 中 `READ?` 超时为 10000 ms。

## 3. 阻容测试项规则修改

新规则：

```text
1. GND -> sin+
2. GND -> sin-
3. GND -> cos+
4. GND -> cos-
```

以上 GND 相关项只测：

```text
黑红 / 负正方向
```

其它项：

```text
sin+ -> sin-
cos+ -> cos-
5V -> GND
```

只测：

```text
红黑方向
```

其中：

```text
5V -> GND 只测电容，不测电阻。
```

除 `5V -> GND` 外，其它测试项均测：

```text
电阻 + 电容
```

## 4. 修改文件

```text
mitsubishi_plc.h
mitsubishi_plc.cpp
scpi_controller.h
scpi_controller.cpp
test_runner.h
test_runner.cpp
manualstatictestwindow.h
manualstatictestwindow.cpp
plctestwindow.h
plctestwindow.cpp
plctestwindow.ui
config/test_standard.ini
```

## 5. 使用方式

将 `modified_files` 里的文件覆盖当前工程同名文件，然后重新运行 qmake，清理并重新构建。

如需完整工程，也可以使用压缩包内的 `full_project` 目录。
