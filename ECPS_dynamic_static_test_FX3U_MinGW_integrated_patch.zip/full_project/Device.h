#ifndef DEVICE_H
#define DEVICE_H

#include "typedef.h"
#include "zlgcan.h"

#include <cstddef>
#include <string>
#include <vector>

/*
 * Device.h
 *
 * ZLG USBCANFD-200U 设备底层封装。
 *
 * 本版本用于合并台架后的动态检测模块，已清理旧示例代码中的空函数、
 * 无限接收循环、空指针风险和明显笔误。
 *
 * 主要保留：
 * 1. 打开 / 初始化 / 启动 / 复位 / 关闭设备；
 * 2. 设置 CANFD 仲裁域、数据域波特率；
 * 3. 普通 CAN / CANFD 发送帧封装；
 * 4. 发送队列模式、清队列、清接收缓存；
 * 5. 兼容旧工程中使用的函数名。
 */

struct DeviceInfo
{
    UINT device_type = 0;
    UINT channel_count = 0;
};

BOOL Open_Device(UINT device_type,
                 DEVICE_HANDLE *device_handle,
                 int device_index);

BOOL IsNetCAN(UINT type);
BOOL IsNetCANFD(UINT type);
BOOL IsNetTCP(UINT type);
BOOL IsNetUDP(UINT type);

BOOL SetBaudrate(int channel_index,
                 int baud_rate,
                 DEVICE_HANDLE device_handle);

BOOL SetCanfdBaudrate(int channel_index,
                      int abit_baud_rate,
                      int dbit_baud_rate,
                      DEVICE_HANDLE device_handle);

BOOL SetCustomBaudrate(int channel_index,
                       int custom_baud_rate,
                       DEVICE_HANDLE device_handle);

BOOL SetResistanceEnable(DEVICE_HANDLE device_handle,
                         int channel_index,
                         BOOL resistance_enable);

BOOL Init_UsbCanFD(DEVICE_HANDLE device_handle,
                   CHANNEL_HANDLE *channel_handle,
                   int channel_index,
                   int abit_baud_rate,
                   int dbit_baud_rate,
                   int filter_mode,
                   const std::string &acc_code,
                   const std::string &acc_mask,
                   BOOL resistance_enable);

BOOL Start_Channel(CHANNEL_HANDLE channel_handle);
BOOL Reset_Channel(CHANNEL_HANDLE channel_handle);
BOOL Close_DeviceAndChannel(DEVICE_HANDLE device_handle,
                            CHANNEL_HANDLE channel_handle);

size_t split(std::vector<std::string> &dst,
             const std::string &src,
             char delimiter);

size_t split(BYTE *dst,
             size_t max_len,
             const std::string &src,
             char delimiter,
             int base);

UINT Send_Msg_FD(CHANNEL_HANDLE channel_handle,
                 const std::string &id,
                 const std::string &data,
                 int frame_type_index,
                 BOOL add_delay_flag,
                 BOOL frame_delay_flag,
                 int frame_delay_time,
                 int send_type_index,
                 int canfd_exp_index,
                 int send_count);

UINT Send_Msg(CHANNEL_HANDLE channel_handle,
              const std::string &id,
              const std::string &data,
              int frame_type_index,
              BOOL add_delay_flag,
              BOOL frame_delay_flag,
              int frame_delay_time,
              int send_type_index,
              int canfd_exp_index,
              int send_count);

BOOL GetViewCANFrame(const std::string &id,
                     const std::string &data,
                     int frame_type_index,
                     ZCAN_Transmit_Data &can_data,
                     BOOL add_delay_flag,
                     BOOL frame_delay_flag,
                     int frame_delay_time,
                     int send_type_index,
                     int canfd_exp_index);

BOOL GetViewCANFrame(const std::string &id,
                     const std::string &data,
                     int frame_type_index,
                     ZCAN_TransmitFD_Data &canfd_data,
                     BOOL add_delay_flag,
                     BOOL frame_delay_flag,
                     int frame_delay_time,
                     int send_type_index,
                     int canfd_exp_index);

BOOL SetQueueSendMode(DEVICE_HANDLE device_handle,
                      int value,
                      int channel_index);

BOOL GetQueueSpace(DEVICE_HANDLE device_handle,
                   int channel_index,
                   int *space);

BOOL ClearQueue(DEVICE_HANDLE device_handle,
                int channel_index);

BOOL GetSendMode(DEVICE_HANDLE device_handle,
                 int channel_index,
                 int *mode);

BOOL ClearBuffer(CHANNEL_HANDLE channel_handle);

#endif // DEVICE_H
