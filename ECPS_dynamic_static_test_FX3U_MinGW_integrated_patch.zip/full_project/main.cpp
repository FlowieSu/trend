#include "mainwindow.h"

#include <QApplication>
#include <QCoreApplication>
#include <QTextCodec>

/*
 * ECPS_StaticAndDynamic_Test
 *
 * 静态阻容 + 动态 CAN 检测上位机入口。
 *
 * 设备连接、PLC、VISA/SCPI、CAN 初始化均由 MainWindow 负责。
 */
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
#endif

    QCoreApplication::setOrganizationName("BYD");
    QCoreApplication::setApplicationName("ECPS_StaticAndDynamic_Test");
    QCoreApplication::setApplicationVersion("1.0.0");

    MainWindow window;
    window.show();

    return app.exec();
}
