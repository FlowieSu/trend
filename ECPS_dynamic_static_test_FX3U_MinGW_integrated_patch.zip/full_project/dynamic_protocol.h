#ifndef DYNAMIC_PROTOCOL_H
#define DYNAMIC_PROTOCOL_H

#include <QByteArray>
#include <QString>
#include <QtGlobal>

/*
 * 动态检测 CAN 交互协议。
 *
 * 这是检测板协议，不区分新旧协议。
 * 四组发送/接收 ID 都属于同一份协议：
 *
 *   发送 0x110 -> 接收 0x201
 *   发送 0x112 -> 接收 0x301
 *   发送 0x114 -> 接收 0x401
 *   发送 0x116 -> 接收 0x501
 *
 * 接收帧格式：
 *   Byte1       数据序号 seq
 *   Byte2       seed
 *   Byte3~Byte4 当前序号对应的数据 value，小端
 *   Byte5~Byte6 当前轮询组 groupCnt，小端
 *   Byte7~Byte8 校验值 check，小端
 *
 * 普通数据帧校验：
 *   check = (seq + seed + value + groupCnt) % 30000
 *
 * 检测完成判据：
 *   DetectInProgressFlag == 100
 */

namespace DynamicProtocol
{
    enum class DynamicChannel
    {
        Channel110,
        Channel112,
        Channel114,
        Channel116
    };

    struct ChannelConfig
    {
        DynamicChannel channel = DynamicChannel::Channel110;

        quint32 txId = 0;
        quint32 rxId = 0;

        int productId = 0;

        /*
         * 开始检测报文 Byte3~Byte4，小端。
         * 该值来自协议中的“阈值设定标志位”。
         */
        int thresholdFlag = 0;

        QString name;
    };

    struct ParsedFrame
    {
        quint32 canId = 0;

        int seq = -1;
        int seed = 0;
        int value = 0;
        int groupCnt = 0;
        int checkValue = 0;

        bool valid = false;
        bool seedOk = false;
        bool checkOk = false;

        QString errorMessage;
    };

    constexpr int kMinDataSeq = 0;
    constexpr int kMaxDataSeq = 60;
    constexpr int kGroupCheckSeq = 255;

    /*
     * Excel 中 DetectInProgressFlag 对应数据序号 3。
     */
    constexpr int kDetectInProgressSeq = 3;
    constexpr int kDetectFinishedValue = 100;

    ChannelConfig channelConfig(DynamicChannel channel);

    QString channelName(DynamicChannel channel);

    QByteArray buildResetFrame();

    QByteArray buildStartFrame(int thresholdFlag,
                               int seed);

    ParsedFrame parseFrame(quint32 canId,
                           const QByteArray &data,
                           int expectedSeed);

    int calcSingleFrameCheck(int seq,
                             int seed,
                             int value,
                             int groupCnt);

    int calcGroupCheck(const int values[61],
                       int seed,
                       int groupCnt);

    bool isNormalDataSeq(int seq);
    bool isGroupCheckSeq(int seq);
    bool isDetectInProgressSeq(int seq);

    QString canIdToString(quint32 canId);
    QString frameDataToString(const QByteArray &data);
}

#endif // DYNAMIC_PROTOCOL_H
