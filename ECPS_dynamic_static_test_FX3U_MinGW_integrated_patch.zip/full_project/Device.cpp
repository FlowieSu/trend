#include "Device.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace
{
inline BOOL isOk(int ret)
{
    return (ret == STATUS_OK || ret == 1) ? TRUE : FALSE;
}

inline BYTE lowByte(int value)
{
    return static_cast<BYTE>(value & 0xFF);
}

inline BYTE highByte(int value)
{
    return static_cast<BYTE>((value >> 8) & 0xFF);
}

BOOL setDeviceValue(DEVICE_HANDLE device_handle,
                    const char *path,
                    const char *value)
{
    if (!device_handle || !path || !value) {
        return FALSE;
    }

    const int ret = ZCAN_SetValue(device_handle, path, value);
    return isOk(ret);
}

BOOL writeIntValue(DEVICE_HANDLE device_handle,
                   int channel_index,
                   const char *key,
                   int value)
{
    if (!device_handle || !key) {
        return FALSE;
    }

    char path[64] = {0};
    char text[64] = {0};

    std::snprintf(path, sizeof(path), "%d/%s", channel_index, key);
    std::snprintf(text, sizeof(text), "%d", value);

    return setDeviceValue(device_handle, path, text);
}

UINT parseCanId(const std::string &id)
{
    if (id.empty()) {
        return 0;
    }

    return static_cast<UINT>(std::strtoul(id.c_str(), nullptr, 16));
}

} // namespace

BOOL Open_Device(UINT device_type,
                 DEVICE_HANDLE *device_handle,
                 int device_index)
{
    if (device_handle == nullptr) {
        return FALSE;
    }

    *device_handle = ZCAN_OpenDevice(device_type, device_index, 0);

    return (*device_handle != nullptr) ? TRUE : FALSE;
}

BOOL IsNetCAN(UINT type)
{
    return (type == ZCAN_CANETUDP ||
            type == ZCAN_CANETTCP ||
            type == ZCAN_WIFICAN_TCP ||
            type == ZCAN_WIFICAN_UDP ||
            type == ZCAN_CANDTU_NET ||
            type == ZCAN_CANDTU_NET_400) ? TRUE : FALSE;
}

BOOL IsNetCANFD(UINT type)
{
    return (type == ZCAN_CANFDNET_TCP ||
            type == ZCAN_CANFDNET_UDP ||
            type == ZCAN_CANFDNET_400U_TCP ||
            type == ZCAN_CANFDNET_400U_UDP ||
            type == ZCAN_CANFDWIFI_TCP ||
            type == ZCAN_CANFDWIFI_UDP) ? TRUE : FALSE;
}

BOOL IsNetTCP(UINT type)
{
    return (type == ZCAN_CANETTCP ||
            type == ZCAN_WIFICAN_TCP ||
            type == ZCAN_CANDTU_NET ||
            type == ZCAN_CANDTU_NET_400 ||
            type == ZCAN_CANFDNET_TCP ||
            type == ZCAN_CANFDNET_400U_TCP ||
            type == ZCAN_CANFDWIFI_TCP) ? TRUE : FALSE;
}

BOOL IsNetUDP(UINT type)
{
    return (type == ZCAN_CANETUDP ||
            type == ZCAN_WIFICAN_UDP ||
            type == ZCAN_CANFDNET_UDP ||
            type == ZCAN_CANFDNET_400U_UDP ||
            type == ZCAN_CANFDWIFI_UDP) ? TRUE : FALSE;
}

BOOL SetBaudrate(int channel_index,
                 int baud_rate,
                 DEVICE_HANDLE device_handle)
{
    return writeIntValue(device_handle, channel_index, "baud_rate", baud_rate);
}

BOOL SetCanfdBaudrate(int channel_index,
                      int abit_baud_rate,
                      int dbit_baud_rate,
                      DEVICE_HANDLE device_handle)
{
    if (!device_handle) {
        return FALSE;
    }

    const BOOL retA = writeIntValue(device_handle,
                                    channel_index,
                                    "canfd_abit_baud_rate",
                                    abit_baud_rate);

    const BOOL retD = writeIntValue(device_handle,
                                    channel_index,
                                    "canfd_dbit_baud_rate",
                                    dbit_baud_rate);

    return (retA && retD) ? TRUE : FALSE;
}

BOOL SetCustomBaudrate(int channel_index,
                       int custom_baud_rate,
                       DEVICE_HANDLE device_handle)
{
    return writeIntValue(device_handle,
                         channel_index,
                         "baud_rate_custom",
                         custom_baud_rate);
}

BOOL SetResistanceEnable(DEVICE_HANDLE device_handle,
                         int channel_index,
                         BOOL resistance_enable)
{
    /*
     * ZLG 参数名实际使用 "initenal_resistance"。
     * 虽然英文拼写看起来像 internal 的笔误，但厂商库通常按这个字符串识别。
     */
    return writeIntValue(device_handle,
                         channel_index,
                         "initenal_resistance",
                         resistance_enable ? 1 : 0);
}

BOOL Init_UsbCanFD(DEVICE_HANDLE device_handle,
                   CHANNEL_HANDLE *channel_handle,
                   int channel_index,
                   int abit_baud_rate,
                   int dbit_baud_rate,
                   int filter_mode,
                   const std::string &acc_code,
                   const std::string &acc_mask,
                   BOOL resistance_enable)
{
    if (!device_handle || channel_handle == nullptr) {
        return FALSE;
    }

    *channel_handle = nullptr;

    /*
     * canfd_standard = 0：ISO CANFD。
     */
    writeIntValue(device_handle, channel_index, "canfd_standard", 0);

    if (!SetCanfdBaudrate(channel_index,
                          abit_baud_rate,
                          dbit_baud_rate,
                          device_handle)) {
        return FALSE;
    }

    ZCAN_CHANNEL_INIT_CONFIG config;
    std::memset(&config, 0, sizeof(config));

    config.can_type = TYPE_CANFD;
    config.canfd.mode = 0;
    config.canfd.filter = filter_mode;
    config.canfd.acc_code = static_cast<UINT>(std::strtoul(acc_code.c_str(), nullptr, 16));
    config.canfd.acc_mask = static_cast<UINT>(std::strtoul(acc_mask.c_str(), nullptr, 16));

    *channel_handle = ZCAN_InitCAN(device_handle, channel_index, &config);

    if (*channel_handle == nullptr) {
        return FALSE;
    }

    if (!SetResistanceEnable(device_handle,
                             channel_index,
                             resistance_enable)) {
        return FALSE;
    }

    return TRUE;
}

BOOL Start_Channel(CHANNEL_HANDLE channel_handle)
{
    if (!channel_handle) {
        return FALSE;
    }

    return (ZCAN_StartCAN(channel_handle) == STATUS_OK) ? TRUE : FALSE;
}

BOOL Reset_Channel(CHANNEL_HANDLE channel_handle)
{
    if (!channel_handle) {
        return TRUE;
    }

    return (ZCAN_ResetCAN(channel_handle) == STATUS_OK) ? TRUE : FALSE;
}

BOOL Close_DeviceAndChannel(DEVICE_HANDLE device_handle,
                            CHANNEL_HANDLE channel_handle)
{
    BOOL resetOk = TRUE;

    if (channel_handle) {
        resetOk = Reset_Channel(channel_handle);
    }

    if (!device_handle) {
        return resetOk;
    }

    const BOOL closeOk = (ZCAN_CloseDevice(device_handle) == STATUS_OK) ? TRUE : FALSE;

    return (resetOk && closeOk) ? TRUE : FALSE;
}

UINT Send_Msg_FD(CHANNEL_HANDLE channel_handle,
                 const std::string &id,
                 const std::string &data,
                 int frame_type_index,
                 BOOL add_delay_flag,
                 BOOL frame_delay_flag,
                 int frame_delay_time,
                 int send_type_index,
                 int canfd_exp_index,
                 int send_count)
{
    if (!channel_handle || send_count <= 0) {
        return 0;
    }

    ZCAN_TransmitFD_Data canfdData;
    if (!GetViewCANFrame(id,
                         data,
                         frame_type_index,
                         canfdData,
                         add_delay_flag,
                         frame_delay_flag,
                         frame_delay_time,
                         send_type_index,
                         canfd_exp_index)) {
        return 0;
    }

    std::vector<ZCAN_TransmitFD_Data> frames(static_cast<size_t>(send_count),
                                             canfdData);

    return ZCAN_TransmitFD(channel_handle,
                           frames.data(),
                           static_cast<UINT>(frames.size()));
}

UINT Send_Msg(CHANNEL_HANDLE channel_handle,
              const std::string &id,
              const std::string &data,
              int frame_type_index,
              BOOL add_delay_flag,
              BOOL frame_delay_flag,
              int frame_delay_time,
              int send_type_index,
              int canfd_exp_index,
              int send_count)
{
    if (!channel_handle || send_count <= 0) {
        return 0;
    }

    ZCAN_Transmit_Data canData;
    if (!GetViewCANFrame(id,
                         data,
                         frame_type_index,
                         canData,
                         add_delay_flag,
                         frame_delay_flag,
                         frame_delay_time,
                         send_type_index,
                         canfd_exp_index)) {
        return 0;
    }

    std::vector<ZCAN_Transmit_Data> frames(static_cast<size_t>(send_count),
                                           canData);

    return ZCAN_Transmit(channel_handle,
                         frames.data(),
                         static_cast<UINT>(frames.size()));
}

BOOL GetViewCANFrame(const std::string &id,
                     const std::string &data,
                     int frame_type_index,
                     ZCAN_Transmit_Data &can_data,
                     BOOL add_delay_flag,
                     BOOL frame_delay_flag,
                     int frame_delay_time,
                     int send_type_index,
                     int canfd_exp_index)
{
    (void)canfd_exp_index;

    std::memset(&can_data, 0, sizeof(can_data));

    const UINT canId = parseCanId(id);

    can_data.frame.can_id = MAKE_CAN_ID(canId, frame_type_index, 0, 0);
    can_data.frame.can_dlc = static_cast<BYTE>(
                split(can_data.frame.data,
                      CAN_MAX_DLEN,
                      data,
                      ' ',
                      16));

    can_data.transmit_type = send_type_index;

    if (add_delay_flag && frame_delay_flag) {
        can_data.frame.__pad |= TX_DELAY_SEND_FLAG;
        can_data.frame.__res0 = lowByte(frame_delay_time);
        can_data.frame.__res1 = highByte(frame_delay_time);
    }

    return TRUE;
}

BOOL GetViewCANFrame(const std::string &id,
                     const std::string &data,
                     int frame_type_index,
                     ZCAN_TransmitFD_Data &canfd_data,
                     BOOL add_delay_flag,
                     BOOL frame_delay_flag,
                     int frame_delay_time,
                     int send_type_index,
                     int canfd_exp_index)
{
    std::memset(&canfd_data, 0, sizeof(canfd_data));

    const UINT canId = parseCanId(id);

    canfd_data.frame.can_id = MAKE_CAN_ID(canId, frame_type_index, 0, 0);
    canfd_data.frame.len = static_cast<BYTE>(
                split(canfd_data.frame.data,
                      CANFD_MAX_DLEN,
                      data,
                      ' ',
                      16));

    canfd_data.transmit_type = send_type_index;

    if (canfd_exp_index) {
        canfd_data.frame.flags |= CANFD_BRS;
    }

    if (add_delay_flag && frame_delay_flag) {
        canfd_data.frame.flags |= TX_DELAY_SEND_FLAG;
        canfd_data.frame.__res0 = lowByte(frame_delay_time);
        canfd_data.frame.__res1 = highByte(frame_delay_time);
    }

    return TRUE;
}

BOOL SetQueueSendMode(DEVICE_HANDLE device_handle,
                      int value,
                      int channel_index)
{
    return writeIntValue(device_handle,
                         channel_index,
                         "set_send_mode",
                         value);
}

BOOL GetQueueSpace(DEVICE_HANDLE device_handle,
                   int channel_index,
                   int *space)
{
    if (!device_handle || space == nullptr) {
        return FALSE;
    }

    char path[80] = {0};
    std::snprintf(path,
                  sizeof(path),
                  "%d/get_device_available_tx_count/1",
                  channel_index);

    const char *ret = static_cast<const char *>(ZCAN_GetValue(device_handle, path));

    if (!ret) {
        return FALSE;
    }

    *space = *reinterpret_cast<const int *>(ret);
    return TRUE;
}

BOOL ClearQueue(DEVICE_HANDLE device_handle,
                int channel_index)
{
    if (!device_handle) {
        return FALSE;
    }

    char path[80] = {0};
    char value[8] = {0};

    std::snprintf(path,
                  sizeof(path),
                  "%d/clear_delay_send_queue",
                  channel_index);

    const int ret = ZCAN_SetValue(device_handle, path, value);
    return (ret != STATUS_ERR) ? TRUE : FALSE;
}

BOOL GetSendMode(DEVICE_HANDLE device_handle,
                 int channel_index,
                 int *mode)
{
    if (!device_handle || mode == nullptr) {
        return FALSE;
    }

    char path[80] = {0};
    std::snprintf(path,
                  sizeof(path),
                  "%d/get_send_mode/1",
                  channel_index);

    const char *ret = static_cast<const char *>(ZCAN_GetValue(device_handle, path));

    if (!ret) {
        return FALSE;
    }

    *mode = *reinterpret_cast<const int *>(ret);
    return TRUE;
}

BOOL ClearBuffer(CHANNEL_HANDLE channel_handle)
{
    if (!channel_handle) {
        return FALSE;
    }

    return (ZCAN_ClearBuffer(channel_handle) == STATUS_OK) ? TRUE : FALSE;
}

size_t split(std::vector<std::string> &dst,
             const std::string &src,
             char delimiter)
{
    dst.clear();

    if (src.empty()) {
        return 0;
    }

    size_t start = 0;

    while (start <= src.size()) {
        const size_t pos = src.find(delimiter, start);
        const size_t end = (pos == std::string::npos) ? src.size() : pos;

        std::string item = src.substr(start, end - start);

        /*
         * 去掉首尾空格，避免 "01 E1 00" 被解析出空字符串。
         */
        const auto first = item.find_first_not_of(" \t\r\n");
        const auto last = item.find_last_not_of(" \t\r\n");

        if (first != std::string::npos && last != std::string::npos) {
            dst.push_back(item.substr(first, last - first + 1));
        }

        if (pos == std::string::npos) {
            break;
        }

        start = pos + 1;
    }

    return dst.size();
}

size_t split(BYTE *dst,
             size_t max_len,
             const std::string &src,
             char delimiter,
             int base)
{
    if (dst == nullptr || max_len == 0 || src.empty()) {
        return 0;
    }

    std::vector<std::string> items;
    split(items, src, delimiter);

    const size_t count = std::min(max_len, items.size());

    for (size_t i = 0; i < count; ++i) {
        dst[i] = static_cast<BYTE>(std::strtoul(items[i].c_str(), nullptr, base));
    }

    return count;
}
