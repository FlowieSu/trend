#ifndef DYNAMIC_RESULT_TYPES_H
#define DYNAMIC_RESULT_TYPES_H

#include <QMetaType>
#include <QString>
#include <QVector>

/*
 * 动态检测结果结构。
 *
 * 该文件只定义数据结构，不包含 CAN 设备通信，也不包含 UI 逻辑。
 * UI 显示和 CSV 保存都使用这里的结果结构。
 */

struct DynamicItemResult
{
    int itemNo = 0;

    QString itemName;
    QString standardText;
    QString unit;

    int flagSeq = -1;
    int valueSeq = -1;

    int flagValue = 1;
    int rawValue = 0;
    double displayValue = 0.0;

    bool flagReceived = false;
    bool valueReceived = false;

    bool flagCheckOk = false;
    bool valueCheckOk = false;

    bool pass = false;

    QString message;
};

struct DynamicProductResult
{
    int productId = 0;
    QString productCode;

    QString channelName;

    quint32 txId = 0;
    quint32 rxId = 0;

    int seed = 0;
    int groupCnt = 0;
    int detectProgress = 0;

    int receivedCount = 0;
    int checkOkCount = 0;

    bool finished = false;
    bool pass = false;

    bool groupCheckReceived = false;
    bool groupCheckPassed = false;

    QString startTime;
    QString finishTime;
    QString message;

    QVector<DynamicItemResult> itemResults;
};

Q_DECLARE_METATYPE(DynamicItemResult)
Q_DECLARE_METATYPE(DynamicProductResult)
Q_DECLARE_METATYPE(QVector<DynamicProductResult>)

#endif // DYNAMIC_RESULT_TYPES_H
