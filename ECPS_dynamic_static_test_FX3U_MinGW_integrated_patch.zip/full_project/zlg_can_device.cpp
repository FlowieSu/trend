#include "zlg_can_device.h"

#include <QDateTime>
#include <QDebug>

#include <algorithm>
#include <cstdlib>
#include <cstring>

namespace
{
constexpr unsigned int kMaxReceiveCount = 100;
constexpr int kReceiveTimeoutMs = 10;

static std::string toStdString(const QString &text)
{
    return text.toStdString();
}

static unsigned int strToUIntHex(const QString &text)
{
    return static_cast<unsigned int>(std::strtoul(text.toStdString().c_str(),
                                                  nullptr,
                                                  16));
}

static int clampDataSize(const QByteArray &data, int maxSize)
{
    return std::max(0, std::min(data.size(), maxSize));
}

static bool isFdDeviceType(ZlgCanDeviceType type)
{
    return type == ZlgCanDeviceType::UsbCanFd200U;
}

static bool isClassicUsbCanType(ZlgCanDeviceType type)
{
    return type == ZlgCanDeviceType::UsbCanIIPlus;
}
} // namespace

ZlgCanDevice::ZlgCanDevice(QObject *parent)
    : QObject(parent)
{
    qRegisterMetaType<ZlgCanDeviceType>("ZlgCanDeviceType");
    qRegisterMetaType<ZlgCanOpenConfig>("ZlgCanOpenConfig");
    qRegisterMetaType<ZlgCanFrame>("ZlgCanFrame");

    m_receiveTimer = new QTimer(this);
    m_receiveTimer->setTimerType(Qt::PreciseTimer);

    connect(m_receiveTimer,
            &QTimer::timeout,
            this,
            &ZlgCanDevice::pollReceive);
}

ZlgCanDevice::~ZlgCanDevice()
{
    closeDevice();
}

bool ZlgCanDevice::openDevice(const ZlgCanOpenConfig &config)
{
    closeDevice();

    m_config = config;

    if (m_config.pollIntervalMs <= 0) {
        m_config.pollIntervalMs = 10;
    }

    emit logMessage(QString("正在打开 CAN 设备：%1，设备索引=%2，通道=%3。")
                    .arg(deviceTypeName(m_config.deviceType))
                    .arg(m_config.deviceIndex)
                    .arg(m_config.channelIndex));

    if (!openZlgDevice()) {
        emit connectedChanged(false);
        return false;
    }

    if (!initChannel()) {
        closeDevice();
        emit connectedChanged(false);
        return false;
    }

    if (!startChannel()) {
        closeDevice();
        emit connectedChanged(false);
        return false;
    }

    clearBuffer();

    m_deviceOpened = true;
    m_channelStarted = true;

    emit connectedChanged(true);
    emit logMessage(QString("CAN 设备已连接：%1。")
                    .arg(deviceTypeName(m_config.deviceType)));

    startReceive();

    return true;
}

void ZlgCanDevice::closeDevice()
{
    stopReceive();

    if (m_channelHandle) {
        ZCAN_ResetCAN(m_channelHandle);
    }

    if (m_deviceHandle) {
        ZCAN_CloseDevice(m_deviceHandle);
    }

    clearHandles();

    emit connectedChanged(false);
}

bool ZlgCanDevice::isOpen() const
{
    return m_deviceOpened && m_deviceHandle != nullptr;
}

bool ZlgCanDevice::isChannelStarted() const
{
    return m_channelStarted && m_channelHandle != nullptr;
}

QString ZlgCanDevice::lastError() const
{
    return m_lastError;
}

ZlgCanOpenConfig ZlgCanDevice::config() const
{
    return m_config;
}

bool ZlgCanDevice::resetChannel()
{
    if (!m_channelHandle) {
        setError("复位 CAN 通道失败：通道未打开。");
        return false;
    }

    const bool ok = (ZCAN_ResetCAN(m_channelHandle) == STATUS_OK);

    if (!ok) {
        setError("复位 CAN 通道失败。");
        return false;
    }

    m_channelStarted = false;
    return true;
}

bool ZlgCanDevice::clearBuffer()
{
    if (!m_channelHandle) {
        setError("清空 CAN 接收缓存失败：通道未打开。");
        return false;
    }

    const bool ok = (ZCAN_ClearBuffer(m_channelHandle) == STATUS_OK);

    if (!ok) {
        setError("清空 CAN 接收缓存失败。");
    }

    return ok;
}

bool ZlgCanDevice::sendFrame(quint32 canId, const QByteArray &data)
{
    if (m_config.sendAsCanFd) {
        return sendCanFdFrame(canId, data);
    }

    return sendClassicFrame(canId, data);
}

bool ZlgCanDevice::sendClassicFrame(quint32 canId, const QByteArray &data)
{
    const bool ok = transmitClassic(canId, data);

    emit sendFinished(canId,
                      ok,
                      ok ? QString("CAN 发送成功。")
                         : QString("CAN 发送失败：%1").arg(m_lastError));

    return ok;
}

bool ZlgCanDevice::sendCanFdFrame(quint32 canId, const QByteArray &data)
{
    const bool ok = transmitCanFd(canId, data);

    emit sendFinished(canId,
                      ok,
                      ok ? QString("CANFD 发送成功。")
                         : QString("CANFD 发送失败：%1").arg(m_lastError));

    return ok;
}

QString ZlgCanDevice::deviceTypeName(ZlgCanDeviceType type)
{
    switch (type) {
    case ZlgCanDeviceType::UsbCanFd200U:
        return "USBCANFD-200U";
    case ZlgCanDeviceType::UsbCanIIPlus:
        return "USBCAN-II+";
    }

    return "Unknown";
}

QString ZlgCanDevice::idToString(quint32 canId)
{
    return QString("0x%1")
            .arg(canId, 3, 16, QLatin1Char('0'))
            .toUpper();
}

QString ZlgCanDevice::dataToString(const QByteArray &data)
{
    QStringList parts;
    parts.reserve(data.size());

    for (unsigned char byte : data) {
        parts << QString("%1")
                 .arg(static_cast<int>(byte), 2, 16, QLatin1Char('0'))
                 .toUpper();
    }

    return parts.join(" ");
}

void ZlgCanDevice::startReceive()
{
    if (!m_channelHandle) {
        emit logMessage("启动 CAN 接收失败：通道未打开。");
        return;
    }

    m_receiving.store(true);

    if (m_receiveTimer && !m_receiveTimer->isActive()) {
        m_receiveTimer->start(m_config.pollIntervalMs);
    }

    emit logMessage(QString("CAN 接收已启动，轮询周期=%1ms。")
                    .arg(m_config.pollIntervalMs));
}

void ZlgCanDevice::stopReceive()
{
    m_receiving.store(false);

    if (m_receiveTimer && m_receiveTimer->isActive()) {
        m_receiveTimer->stop();
    }
}

void ZlgCanDevice::pollReceive()
{
    if (!m_receiving.load() || !m_channelHandle) {
        return;
    }

    receiveClassicFrames();

    /*
     * 当前动态检测使用 8 字节普通 CAN 帧。
     * 仅在配置允许，且设备为 USBCANFD-200U 时读取 CANFD 缓冲。
     */
    if (m_config.receiveCanFd && isFdDeviceType(m_config.deviceType)) {
        receiveCanFdFrames();
    }
}

bool ZlgCanDevice::openZlgDevice()
{
    const unsigned int deviceType = zlgDeviceTypeValue();

    m_deviceHandle = ZCAN_OpenDevice(deviceType,
                                     m_config.deviceIndex,
                                     0);

    if (!m_deviceHandle) {
        setError(QString("打开 %1 失败，ZLG deviceType=%2。")
                 .arg(deviceTypeName(m_config.deviceType))
                 .arg(deviceType));
        return false;
    }

    m_deviceOpened = true;
    return true;
}

bool ZlgCanDevice::initChannel()
{
    if (isFdDeviceType(m_config.deviceType)) {
        return initUsbCanFd200U();
    }

    if (isClassicUsbCanType(m_config.deviceType)) {
        return initUsbCanIIPlus();
    }

    setError("未知 CAN 设备类型。");
    return false;
}

bool ZlgCanDevice::initUsbCanFd200U()
{
    if (!m_deviceHandle) {
        setError("初始化 USBCANFD-200U 失败：设备未打开。");
        return false;
    }

    /*
     * canfd_standard = 0：ISO CANFD。
     * 即使当前发送普通 CAN，也按 CANFD 设备通道初始化。
     */
    char path[64] = {0};
    char value[64] = {0};

#ifdef _MSC_VER
    sprintf_s(path, "%d/canfd_standard", m_config.channelIndex);
    sprintf_s(value, "%d", 0);
#else
    std::snprintf(path, sizeof(path), "%d/canfd_standard", m_config.channelIndex);
    std::snprintf(value, sizeof(value), "%d", 0);
#endif

    ZCAN_SetValue(m_deviceHandle, path, value);

    if (!SetCanfdBaudrate(m_config.channelIndex,
                          m_config.canFdAbitBaudRate,
                          m_config.canFdDbitBaudRate,
                          m_deviceHandle)) {
        setError("设置 USBCANFD-200U 仲裁域/数据域波特率失败。");
        return false;
    }

    ZCAN_CHANNEL_INIT_CONFIG initConfig;
    std::memset(&initConfig, 0, sizeof(initConfig));

    initConfig.can_type = TYPE_CANFD;
    initConfig.canfd.mode = 0;
    initConfig.canfd.filter = m_config.filterMode;
    initConfig.canfd.acc_code = strToUIntHex(m_config.accCode);
    initConfig.canfd.acc_mask = strToUIntHex(m_config.accMask);

    m_channelHandle = ZCAN_InitCAN(m_deviceHandle,
                                   m_config.channelIndex,
                                   &initConfig);

    if (!m_channelHandle) {
        setError("初始化 USBCANFD-200U 通道失败。");
        return false;
    }

    SetResistanceEnable(m_deviceHandle,
                        m_config.channelIndex,
                        m_config.terminalResistance ? TRUE : FALSE);

    return true;
}

bool ZlgCanDevice::initUsbCanIIPlus()
{
    if (!m_deviceHandle) {
        setError("初始化 USBCAN-II+ 失败：设备未打开。");
        return false;
    }

    if (!SetBaudrate(m_config.channelIndex,
                     m_config.canBaudRate,
                     m_deviceHandle)) {
        setError(QString("设置 USBCAN-II+ 波特率失败：%1。")
                 .arg(m_config.canBaudRate));
        return false;
    }

    ZCAN_CHANNEL_INIT_CONFIG initConfig;
    std::memset(&initConfig, 0, sizeof(initConfig));

    initConfig.can_type = TYPE_CAN;
    initConfig.can.mode = 0;
    initConfig.can.filter = m_config.filterMode;
    initConfig.can.acc_code = strToUIntHex(m_config.accCode);
    initConfig.can.acc_mask = strToUIntHex(m_config.accMask);

    m_channelHandle = ZCAN_InitCAN(m_deviceHandle,
                                   m_config.channelIndex,
                                   &initConfig);

    if (!m_channelHandle) {
        setError("初始化 USBCAN-II+ 通道失败。");
        return false;
    }

    SetResistanceEnable(m_deviceHandle,
                        m_config.channelIndex,
                        m_config.terminalResistance ? TRUE : FALSE);

    return true;
}

bool ZlgCanDevice::startChannel()
{
    if (!m_channelHandle) {
        setError("启动 CAN 通道失败：通道未初始化。");
        return false;
    }

    if (ZCAN_StartCAN(m_channelHandle) != STATUS_OK) {
        setError("启动 CAN 通道失败。");
        return false;
    }

    m_channelStarted = true;
    return true;
}

unsigned int ZlgCanDevice::zlgDeviceTypeValue() const
{
    if (m_config.deviceTypeOverride != 0) {
        return m_config.deviceTypeOverride;
    }

    switch (m_config.deviceType) {
    case ZlgCanDeviceType::UsbCanFd200U:
        return ZCAN_USBCANFD_200U;

    case ZlgCanDeviceType::UsbCanIIPlus:
        /*
         * 多数 ZLG 库中，USBCAN-II / USBCAN-II+ 对应 ZCAN_USBCAN2。
         * 如果你现场库里的 II+ 对应其它宏，可以通过 config.deviceTypeOverride 覆盖。
         */
        return ZCAN_USBCAN2;
    }

    return ZCAN_USBCANFD_200U;
}

void ZlgCanDevice::setError(const QString &message)
{
    m_lastError = message;
    emit logMessage(message);
}

void ZlgCanDevice::clearHandles()
{
    m_deviceHandle = nullptr;
    m_channelHandle = nullptr;
    m_deviceOpened = false;
    m_channelStarted = false;
}

bool ZlgCanDevice::transmitClassic(quint32 canId, const QByteArray &data)
{
    if (!m_channelHandle || !m_channelStarted) {
        setError(QString("发送 CAN 帧失败：通道未启动。ID=%1")
                 .arg(idToString(canId)));
        return false;
    }

    if (data.isEmpty() || data.size() > 8) {
        setError(QString("发送 CAN 帧失败：数据长度非法，len=%1。")
                 .arg(data.size()));
        return false;
    }

    ZCAN_Transmit_Data frame;
    std::memset(&frame, 0, sizeof(frame));

    frame.frame.can_id = MAKE_CAN_ID(canId,
                                     m_config.extendedFrame ? 1 : 0,
                                     0,
                                     0);

    const int len = clampDataSize(data, 8);
    frame.frame.can_dlc = static_cast<BYTE>(len);

    for (int i = 0; i < len; ++i) {
        frame.frame.data[i] = static_cast<BYTE>(
                    static_cast<unsigned char>(data.at(i)));
    }

    frame.transmit_type = 0;

    const unsigned int sent = ZCAN_Transmit(m_channelHandle,
                                            &frame,
                                            1);

    const bool ok = (sent == 1);

    emit logMessage(QString("发送 CAN：ID=%1，DATA=%2，%3。")
                    .arg(idToString(canId))
                    .arg(dataToString(data))
                    .arg(ok ? "成功" : "失败"));

    if (!ok) {
        setError(QString("ZCAN_Transmit 返回 %1。").arg(sent));
    }

    return ok;
}

bool ZlgCanDevice::transmitCanFd(quint32 canId, const QByteArray &data)
{
    if (!isFdDeviceType(m_config.deviceType)) {
        setError("发送 CANFD 失败：当前设备不是 USBCANFD-200U。");
        return false;
    }

    if (!m_channelHandle || !m_channelStarted) {
        setError(QString("发送 CANFD 帧失败：通道未启动。ID=%1")
                 .arg(idToString(canId)));
        return false;
    }

    if (data.isEmpty() || data.size() > 64) {
        setError(QString("发送 CANFD 帧失败：数据长度非法，len=%1。")
                 .arg(data.size()));
        return false;
    }

    ZCAN_TransmitFD_Data frame;
    std::memset(&frame, 0, sizeof(frame));

    frame.frame.can_id = MAKE_CAN_ID(canId,
                                     m_config.extendedFrame ? 1 : 0,
                                     0,
                                     0);

    const int len = clampDataSize(data, 64);
    frame.frame.len = static_cast<BYTE>(len);

    for (int i = 0; i < len; ++i) {
        frame.frame.data[i] = static_cast<BYTE>(
                    static_cast<unsigned char>(data.at(i)));
    }

    if (m_config.canFdBrs) {
        frame.frame.flags |= CANFD_BRS;
    }

    frame.transmit_type = 0;

    const unsigned int sent = ZCAN_TransmitFD(m_channelHandle,
                                              &frame,
                                              1);

    const bool ok = (sent == 1);

    emit logMessage(QString("发送 CANFD：ID=%1，DATA=%2，%3。")
                    .arg(idToString(canId))
                    .arg(dataToString(data))
                    .arg(ok ? "成功" : "失败"));

    if (!ok) {
        setError(QString("ZCAN_TransmitFD 返回 %1。").arg(sent));
    }

    return ok;
}

void ZlgCanDevice::receiveClassicFrames()
{
    const unsigned int pending = ZCAN_GetReceiveNum(m_channelHandle,
                                                    TYPE_CAN);

    if (pending == 0) {
        return;
    }

    const unsigned int count = ZCAN_Receive(m_channelHandle,
                                            m_canData,
                                            kMaxReceiveCount,
                                            kReceiveTimeoutMs);

    for (unsigned int i = 0; i < count; ++i) {
        const ZlgCanFrame frame = makeClassicFrame(m_canData[i]);

        emit frameDetailReceived(frame);
        emit frameReceived(frame.canId, frame.data);
    }
}

void ZlgCanDevice::receiveCanFdFrames()
{
    const unsigned int pending = ZCAN_GetReceiveNum(m_channelHandle,
                                                    TYPE_CANFD);

    if (pending == 0) {
        return;
    }

    const unsigned int count = ZCAN_ReceiveFD(m_channelHandle,
                                              m_canFdData,
                                              kMaxReceiveCount,
                                              kReceiveTimeoutMs);

    for (unsigned int i = 0; i < count; ++i) {
        const ZlgCanFrame frame = makeCanFdFrame(m_canFdData[i]);

        emit frameDetailReceived(frame);
        emit frameReceived(frame.canId, frame.data);
    }
}

ZlgCanFrame ZlgCanDevice::makeClassicFrame(const ZCAN_Receive_Data &raw) const
{
    ZlgCanFrame frame;
    frame.canId = GET_ID(raw.frame.can_id);
    frame.isCanFd = false;
    frame.isExtended = m_config.extendedFrame;

    const int len = std::min<int>(raw.frame.can_dlc, 8);
    frame.data.resize(len);

    for (int i = 0; i < len; ++i) {
        frame.data[i] = static_cast<char>(raw.frame.data[i]);
    }

    return frame;
}

ZlgCanFrame ZlgCanDevice::makeCanFdFrame(const ZCAN_ReceiveFD_Data &raw) const
{
    ZlgCanFrame frame;
    frame.canId = GET_ID(raw.frame.can_id);
    frame.isCanFd = true;
    frame.isExtended = m_config.extendedFrame;

    const int len = std::min<int>(raw.frame.len, 64);
    frame.data.resize(len);

    for (int i = 0; i < len; ++i) {
        frame.data[i] = static_cast<char>(raw.frame.data[i]);
    }

    return frame;
}
