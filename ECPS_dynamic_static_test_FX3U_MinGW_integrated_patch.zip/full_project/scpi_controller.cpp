#include "scpi_controller.h"

#include <QByteArray>
#include <QRegularExpression>
#include <QThread>
#include <QStringList>

#include <cmath>
#include <limits>

namespace
{
constexpr int VISA_OPEN_TIMEOUT_MS = 5000;
constexpr int VISA_DEFAULT_TIMEOUT_MS = 10000;
constexpr int SCPI_COMMAND_TIMEOUT_MS = 1000;
constexpr int SCPI_BUFFER_CLEAR_WAIT_MS = 50;

constexpr quint32 VI_NULL_VALUE = 0;
constexpr qint32 VI_SUCCESS_VALUE = 0;
constexpr qint32 VI_SUCCESS_TERM_CHAR_VALUE = 0x3FFF0005;
constexpr qint32 VI_SUCCESS_MAX_CNT_VALUE = 0x3FFF0006;
constexpr qint32 VI_ERROR_TMO_VALUE = -1073807339; // 0xBFFF0015

constexpr quint32 VI_ATTR_TMO_VALUE_ID = 0x3FFF001A;
constexpr quint32 VI_ATTR_TERMCHAR_ID = 0x3FFF0018;
constexpr quint32 VI_ATTR_TERMCHAR_EN_ID = 0x3FFF0038;
constexpr quint32 VI_ATTR_SEND_END_EN_ID = 0x3FFF0016;

inline bool isVisaError(qint32 status)
{
    return status < VI_SUCCESS_VALUE;
}
}

SCPIController::SCPIController(QObject *parent)
    : QObject(parent)
{
}

SCPIController::~SCPIController()
{
    disconnectInstrument();
    unloadVisaLibrary();
}

bool SCPIController::connectInstrument(const QString &visaAddress)
{
    clearLastError();
    disconnectInstrument();

    m_address = visaAddress.trimmed();

    if (m_address.isEmpty()) {
        setLastError("万用表VISA地址为空。");
        return false;
    }

    if (m_address.compare("SIM", Qt::CaseInsensitive) == 0 ||
            m_address.compare("DEMO", Qt::CaseInsensitive) == 0) {
        m_simulationMode = true;
        emit logMessage("万用表仿真模式已连接。");
        emit connectedChanged(true);
        return true;
    }

    m_simulationMode = false;

    if (!loadVisaLibrary()) {
        emit connectedChanged(false);
        return false;
    }

    if (!openVisaInstrument(m_address)) {
        emit connectedChanged(false);
        return false;
    }

    emit connectedChanged(true);
    return true;
}

void SCPIController::disconnectInstrument()
{
    m_simulationMode = false;

    if (m_viClose && m_instrument != VI_NULL_VALUE) {
        m_viClose(m_instrument);
        m_instrument = VI_NULL_VALUE;
    }

    if (m_viClose && m_defaultRm != VI_NULL_VALUE) {
        m_viClose(m_defaultRm);
        m_defaultRm = VI_NULL_VALUE;
    }

    emit connectedChanged(false);
}

bool SCPIController::isConnected() const
{
    return m_simulationMode || m_instrument != VI_NULL_VALUE;
}

bool SCPIController::ping()
{
    clearLastError();

    if (m_simulationMode) {
        emit logMessage("万用表仿真模式：*IDN? = SIMULATED,DMM,0001,1.0");
        return true;
    }

    QString response;

    if (!query("*IDN?", &response, VISA_DEFAULT_TIMEOUT_MS)) {
        return false;
    }

    emit logMessage(QString("万用表识别信息：%1").arg(response));
    return true;
}

void SCPIController::setResistanceCommand(const QString &configCommand)
{
    m_resistanceCommand = configCommand.trimmed().isEmpty()
            ? QString("CONF:RES")
            : configCommand.trimmed();
}

void SCPIController::setCapacitanceCommand(const QString &configCommand)
{
    m_capacitanceCommand = configCommand.trimmed().isEmpty()
            ? QString("CONF:CAP")
            : configCommand.trimmed();
}

void SCPIController::setReadCommand(const QString &readCommand)
{
    m_readCommand = readCommand.trimmed().isEmpty()
            ? QString("READ?")
            : readCommand.trimmed();
}

void SCPIController::setResistanceDelayMs(int delayMs)
{
    m_resistanceDelayMs = qMax(0, delayMs);
}

void SCPIController::setCapacitanceDelayMs(int delayMs)
{
    m_capacitanceDelayMs = qMax(0, delayMs);
}

double SCPIController::measureResistance(int timeoutMs)
{
    clearLastError();

    if (m_simulationMode) {
        emit logMessage("仿真电阻原始返回：+3.65000000E+05");
        return 365000.0;
    }

    if (!configureMeasurementMode(m_resistanceCommand,
                                  m_resistanceDelayMs,
                                  SCPI_COMMAND_TIMEOUT_MS)) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    QString response;

    if (!query(m_readCommand, &response, timeoutMs)) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    emit logMessage(QString("电阻原始响应：%1").arg(response));

    bool ok = false;
    const double value = parseDoubleResponse(response, &ok);

    if (!ok) {
        setLastError(QString("电阻响应无法解析为数字：%1").arg(response));
        return std::numeric_limits<double>::quiet_NaN();
    }

    return value;
}

double SCPIController::measureCapacitance(int timeoutMs)
{
    clearLastError();

    if (m_simulationMode) {
        emit logMessage("仿真电容原始返回：+5.00000000E-09");
        return 5.0e-9;
    }

    if (!configureMeasurementMode(m_capacitanceCommand,
                                  m_capacitanceDelayMs,
                                  SCPI_COMMAND_TIMEOUT_MS)) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    QString response;

    if (!query(m_readCommand, &response, timeoutMs)) {
        return std::numeric_limits<double>::quiet_NaN();
    }

    emit logMessage(QString("电容原始响应：%1").arg(response));

    bool ok = false;
    const double value = parseDoubleResponse(response, &ok);

    if (!ok) {
        setLastError(QString("电容响应无法解析为数字：%1").arg(response));
        return std::numeric_limits<double>::quiet_NaN();
    }

    return value;
}

QString SCPIController::lastError() const
{
    return m_lastError;
}

bool SCPIController::loadVisaLibrary()
{
    if (m_visaLibrary.isLoaded()) {
        return true;
    }

    QStringList candidates;

#if defined(_WIN64) || defined(Q_PROCESSOR_X86_64)
    candidates << "visa64.dll"
               << "visa64"
               << "C:/Windows/System32/visa64.dll";
#else
    candidates << "visa32.dll"
               << "visa32"
               << "C:/Windows/SysWOW64/visa32.dll";
#endif

    QStringList errors;

    for (const QString &name : candidates) {
        m_visaLibrary.setFileName(name);

        if (!m_visaLibrary.load()) {
            errors << QString("%1: %2").arg(name, m_visaLibrary.errorString());
            continue;
        }

        m_viOpenDefaultRM = reinterpret_cast<ViOpenDefaultRMFn>(m_visaLibrary.resolve("viOpenDefaultRM"));
        m_viOpen = reinterpret_cast<ViOpenFn>(m_visaLibrary.resolve("viOpen"));
        m_viClose = reinterpret_cast<ViCloseFn>(m_visaLibrary.resolve("viClose"));
        m_viWrite = reinterpret_cast<ViWriteFn>(m_visaLibrary.resolve("viWrite"));
        m_viRead = reinterpret_cast<ViReadFn>(m_visaLibrary.resolve("viRead"));
        m_viSetAttribute = reinterpret_cast<ViSetAttributeFn>(m_visaLibrary.resolve("viSetAttribute"));
        m_viGetAttribute = reinterpret_cast<ViGetAttributeFn>(m_visaLibrary.resolve("viGetAttribute"));
        m_viStatusDesc = reinterpret_cast<ViStatusDescFn>(m_visaLibrary.resolve("viStatusDesc"));

        if (m_viOpenDefaultRM &&
                m_viOpen &&
                m_viClose &&
                m_viWrite &&
                m_viRead &&
                m_viSetAttribute &&
                m_viGetAttribute &&
                m_viStatusDesc) {
            emit logMessage(QString("VISA动态库加载成功：%1").arg(name));
            return true;
        }

        errors << QString("%1: VISA函数解析不完整。").arg(name);
        m_visaLibrary.unload();
    }

    setLastError(QString("VISA动态库加载失败。请安装 NI-VISA Runtime 或 Keysight VISA Runtime。尝试结果：%1")
                 .arg(errors.join(" | ")));
    return false;
}

void SCPIController::unloadVisaLibrary()
{
    m_viOpenDefaultRM = nullptr;
    m_viOpen = nullptr;
    m_viClose = nullptr;
    m_viWrite = nullptr;
    m_viRead = nullptr;
    m_viSetAttribute = nullptr;
    m_viGetAttribute = nullptr;
    m_viStatusDesc = nullptr;

    if (m_visaLibrary.isLoaded()) {
        m_visaLibrary.unload();
    }
}

bool SCPIController::openVisaInstrument(const QString &address)
{
    if (!m_viOpenDefaultRM || !m_viOpen) {
        setLastError("VISA函数未加载。");
        return false;
    }

    ViStatus status = m_viOpenDefaultRM(&m_defaultRm);

    if (isVisaError(status)) {
        setLastError(QString("viOpenDefaultRM失败：%1").arg(visaStatusText(status)));
        return false;
    }

    QByteArray visaAddress = address.toLatin1();

    status = m_viOpen(m_defaultRm,
                      visaAddress.data(),
                      0,
                      VISA_OPEN_TIMEOUT_MS,
                      &m_instrument);

    if (isVisaError(status)) {
        setLastError(QString("viOpen失败，地址=%1，错误=%2")
                     .arg(address)
                     .arg(visaStatusText(status)));

        if (m_viClose && m_defaultRm != VI_NULL_VALUE) {
            m_viClose(m_defaultRm);
        }

        m_defaultRm = VI_NULL_VALUE;
        return false;
    }

    setVisaTimeout(VISA_DEFAULT_TIMEOUT_MS);
    m_viSetAttribute(m_instrument, VI_ATTR_TERMCHAR_ID, static_cast<ViAttrState>('\n'));
    m_viSetAttribute(m_instrument, VI_ATTR_TERMCHAR_EN_ID, static_cast<ViAttrState>(1));
    m_viSetAttribute(m_instrument, VI_ATTR_SEND_END_EN_ID, static_cast<ViAttrState>(1));

    emit logMessage(QString("万用表VISA连接成功：%1").arg(address));
    return true;
}

bool SCPIController::sendCommand(const QString &command, int timeoutMs)
{
    if (!isConnected()) {
        setLastError("万用表未连接。");
        return false;
    }

    emit logMessage(QString("万用表 << %1").arg(command));

    if (m_simulationMode) {
        return true;
    }

    setVisaTimeout(timeoutMs);

    QByteArray data = command.trimmed().toLatin1();
    data.append('\n');

    ViUInt32 written = 0;
    ViStatus status = m_viWrite(m_instrument,
                                reinterpret_cast<unsigned char *>(data.data()),
                                static_cast<ViUInt32>(data.size()),
                                &written);

    if (isVisaError(status)) {
        setLastError(QString("SCPI指令发送失败：%1，错误=%2")
                     .arg(command)
                     .arg(visaStatusText(status)));
        return false;
    }

    if (written != static_cast<ViUInt32>(data.size())) {
        setLastError(QString("SCPI指令未完整发送：%1，written=%2，expected=%3")
                     .arg(command)
                     .arg(written)
                     .arg(data.size()));
        return false;
    }

    return true;
}

bool SCPIController::query(const QString &command, QString *response, int timeoutMs)
{
    if (response) {
        response->clear();
    }

    clearReadBuffer(SCPI_BUFFER_CLEAR_WAIT_MS);

    if (!sendCommand(command, timeoutMs)) {
        return false;
    }

    return readResponse(response, timeoutMs);
}

bool SCPIController::readResponse(QString *response, int timeoutMs)
{
    if (!isConnected()) {
        setLastError("万用表未连接。");
        return false;
    }

    if (m_simulationMode) {
        if (response) {
            *response = "0";
        }
        return true;
    }

    setVisaTimeout(timeoutMs);

    QByteArray buffer;

    while (true) {
        unsigned char raw[512] = {0};
        ViUInt32 readCount = 0;

        const ViStatus status = m_viRead(m_instrument,
                                         raw,
                                         static_cast<ViUInt32>(sizeof(raw)),
                                         &readCount);

        if (readCount > 0) {
            buffer.append(reinterpret_cast<const char *>(raw),
                          static_cast<int>(readCount));
        }

        if (status == VI_SUCCESS_TERM_CHAR_VALUE ||
                buffer.contains('\n') ||
                buffer.contains('\r')) {
            break;
        }

        if (status == VI_SUCCESS_MAX_CNT_VALUE) {
            continue;
        }

        if (status == VI_ERROR_TMO_VALUE) {
            if (!buffer.isEmpty()) {
                break;
            }

            setLastError(QString("万用表读取超时，timeout=%1 ms。").arg(timeoutMs));
            return false;
        }

        if (isVisaError(status)) {
            setLastError(QString("万用表读取失败：%1").arg(visaStatusText(status)));
            return false;
        }

        if (status == VI_SUCCESS_VALUE) {
            break;
        }
    }

    if (buffer.isEmpty()) {
        setLastError("万用表无响应。");
        return false;
    }

    const QString text = QString::fromLatin1(buffer).trimmed();

    if (response) {
        *response = text;
    }

    emit logMessage(QString("万用表 >> %1").arg(text));
    return true;
}

bool SCPIController::clearReadBuffer(int maxWaitMs)
{
    if (m_simulationMode) {
        return true;
    }

    if (!isConnected()) {
        return false;
    }

    ViAttrState oldTimeout = VISA_DEFAULT_TIMEOUT_MS;
    m_viGetAttribute(m_instrument, VI_ATTR_TMO_VALUE_ID, &oldTimeout);
    setVisaTimeout(maxWaitMs);

    QByteArray dropped;

    while (true) {
        unsigned char raw[256] = {0};
        ViUInt32 readCount = 0;

        const ViStatus status = m_viRead(m_instrument,
                                         raw,
                                         static_cast<ViUInt32>(sizeof(raw)),
                                         &readCount);

        if (readCount > 0) {
            dropped.append(reinterpret_cast<const char *>(raw),
                           static_cast<int>(readCount));
        }

        if (status == VI_SUCCESS_MAX_CNT_VALUE) {
            continue;
        }

        if (status == VI_ERROR_TMO_VALUE) {
            break;
        }

        if (isVisaError(status) || readCount == 0) {
            break;
        }

        if (status == VI_SUCCESS_TERM_CHAR_VALUE ||
                dropped.contains('\n') ||
                dropped.contains('\r')) {
            break;
        }
    }

    m_viSetAttribute(m_instrument, VI_ATTR_TMO_VALUE_ID, oldTimeout);

    if (!dropped.trimmed().isEmpty()) {
        emit logMessage(QString("已清空万用表残留响应：%1")
                        .arg(QString::fromLatin1(dropped).trimmed()));
    }

    return true;
}

bool SCPIController::configureMeasurementMode(const QString &command,
                                              int settleDelayMs,
                                              int timeoutMs)
{
    clearReadBuffer(SCPI_BUFFER_CLEAR_WAIT_MS);

    if (!sendCommand(command, timeoutMs)) {
        return false;
    }

    emit logMessage(QString("万用表配置完成：%1，等待 %2 ms 后读取。")
                    .arg(command)
                    .arg(settleDelayMs));

    if (settleDelayMs > 0) {
        QThread::msleep(static_cast<unsigned long>(settleDelayMs));
    }

    return true;
}

double SCPIController::parseDoubleResponse(const QString &response, bool *ok) const
{
    QString text = response.trimmed();

    const int commaIndex = text.indexOf(',');

    if (commaIndex >= 0) {
        text = text.left(commaIndex).trimmed();
    }

    const QRegularExpression numberRegex("[-+]?\\d*\\.?\\d+(?:[Ee][-+]?\\d+)?");
    const QRegularExpressionMatch match = numberRegex.match(text);

    if (!match.hasMatch()) {
        if (ok) {
            *ok = false;
        }

        return std::numeric_limits<double>::quiet_NaN();
    }

    bool localOk = false;
    const double value = match.captured(0).toDouble(&localOk);

    if (ok) {
        *ok = localOk;
    }

    return value;
}

bool SCPIController::setVisaTimeout(int timeoutMs)
{
    if (m_instrument == VI_NULL_VALUE || !m_viSetAttribute) {
        return false;
    }

    const ViStatus status = m_viSetAttribute(m_instrument,
                                             VI_ATTR_TMO_VALUE_ID,
                                             static_cast<ViAttrState>(timeoutMs));

    if (isVisaError(status)) {
        setLastError(QString("设置VISA超时失败：%1").arg(visaStatusText(status)));
        return false;
    }

    return true;
}

QString SCPIController::visaStatusText(ViStatus status) const
{
    char description[256] = {0};
    const ViSession session = m_instrument != VI_NULL_VALUE ? m_instrument : m_defaultRm;

    if (m_viStatusDesc &&
            session != VI_NULL_VALUE &&
            m_viStatusDesc(session, status, description) >= VI_SUCCESS_VALUE) {
        return QString("%1 (%2)")
                .arg(QString::fromLocal8Bit(description))
                .arg(status);
    }

    return QString("VISA状态码=%1").arg(status);
}

void SCPIController::setLastError(const QString &error)
{
    m_lastError = error;

    if (!error.isEmpty()) {
        emit logMessage(error);
    }
}

void SCPIController::clearLastError()
{
    m_lastError.clear();
}
