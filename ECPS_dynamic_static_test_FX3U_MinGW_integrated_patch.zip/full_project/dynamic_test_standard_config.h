#ifndef DYNAMIC_TEST_STANDARD_CONFIG_H
#define DYNAMIC_TEST_STANDARD_CONFIG_H

#include <QString>
#include <QVector>

#include "dynamic_test_item_config.h"

/*
 * DynamicTestStandardConfig
 *
 * 作用：
 *   从程序目录/config/test_standard.ini 读取动态检测项配置。
 *
 * 注意：
 *   1. 动态测试 PASS/NG 仍然以检测板返回 flag 为准；
 *   2. standardText 只用于界面显示和 CSV 保存，不参与软件端二次判定；
 *   3. 如果 INI 不存在或格式错误，dynamic_test_item_config.cpp 会回退到内置默认项。
 */
class DynamicTestStandardConfig
{
public:
    static bool loadDynamicItems(const QString &iniFilePath,
                                 QVector<DynamicTestItemMeta> *items,
                                 QString *errorMessage = nullptr);

    /*
     * 默认路径：
     *   程序目录/config/test_standard.ini
     */
    static QString defaultIniFilePath();

private:
    static bool readOneItem(class QSettings &settings,
                            int index,
                            DynamicTestItemMeta *item,
                            QString *errorMessage);

    static void setError(QString *errorMessage,
                         const QString &message);
};

#endif // DYNAMIC_TEST_STANDARD_CONFIG_H
