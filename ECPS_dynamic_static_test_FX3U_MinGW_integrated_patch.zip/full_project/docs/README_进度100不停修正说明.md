# 动态测试进度到 100 但不停：修正补丁

## 问题原因

上一版为了避免不同轮询组混入同一个 item，把完成条件改成：

```text
DetectInProgressFlag == 100
并且
seq=255 组校验通过
```

但你现场测试表现为：

```text
进度条已经到 100
动态测试一直不停止
只能手动停止
```

这说明检测板当前可能：

```text
1. 没有发送 seq=255 组校验帧；
2. 或者上位机没有收到/识别到组校验帧；
3. 或者组校验帧的 groupCnt 与当前 activeGroupCnt 不一致，被忽略。
```

所以 `m_finished` 一直没有置为 true。

## 本次修正

仍然保证：

```text
一个 item 的 flag 和 rec 来自同一个 groupCnt
DetectInProgressFlag 必须到 100
```

但不再强依赖 `seq=255`。

新增逻辑：

```text
如果当前 active group 的 DetectInProgressFlag 已经等于 100，
并且收到了下一组 groupCnt 的第一帧，
说明上一组轮询已经结束。

此时锁定上一组数据为最终结果。
```

也就是：

```text
完成条件 A：
    DetectInProgressFlag == 100
    且 seq=255 组校验通过

完成条件 B：
    DetectInProgressFlag == 100
    且下一组 groupCnt 已经开始
```

满足任一条件即可停止。

## 修改文件

```text
dynamic_product_context.h
dynamic_product_context.cpp
```

不新增工程文件，不需要改 `.pro`。

## 关键代码

```cpp
if (frame.groupCnt != m_activeGroupCnt) {
    if (m_detectProgress == DynamicProtocol::kDetectFinishedValue) {
        lockActiveGroupAsFinished("DetectInProgressFlag=100 and next group started");
        return false;
    }

    startNewGroup(frame.groupCnt);
    return true;
}
```

注意：

```text
return false 表示这帧新组数据不再塞进当前结果缓存。
DynamicTestController 随后会 checkProductFinished()，并 buildResult()。
```

## 验证输出

修正后，当进度到 100 并检测到下一组开始时，Qt Creator 应用程序输出会出现：

```text
[DynamicFinish] product=xxx channel=通道110 activeGroup=12 detectProgress=100 reason=DetectInProgressFlag=100 and next group started groupCheckReceived=false groupCheckPassed=false
```

随后应触发：

```text
位置x动态检测完成
双产品动态检测完成
```
