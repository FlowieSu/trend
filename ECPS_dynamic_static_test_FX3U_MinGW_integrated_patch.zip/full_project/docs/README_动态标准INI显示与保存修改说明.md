# 动态检测标准显示与保存：最小修改说明

## 目标

动态检测 PASS/NG 仍然由检测板返回的 flag 决定，软件不重新用标准上下限判定。

本次只增加：

```text
1. 动态检测项标准从 INI 读取
2. 主界面动态结果表显示“检测标准”
3. 动态 CSV 保存“检测标准”
```

例如：

```text
SpeedFlucRec
检测值：2038
单位：rpm
检测标准：2000±50 rpm
结果：PASS/NG
```

## 新增文件

```text
dynamic_test_standard_config.h
dynamic_test_standard_config.cpp
```

作用：

```text
读取 程序目录/config/test_standard.ini 中的 [Dynamic] / [DynamicItemX]
生成 QVector<DynamicTestItemMeta>
```

## 修改文件

```text
dynamic_test_item_config.h
dynamic_test_item_config.cpp
dynamic_csv_exporter.h
dynamic_csv_exporter.cpp
mainwindow.cpp
```

其中：

```text
dynamic_result_types.h
```

当前已经包含：

```cpp
QString standardText;
```

如果你本地没有这个字段，需要加到 `DynamicItemResult` 里。

## 修改点 1：dynamic_test_item_config.cpp

原来：

```text
createDefaultDynamicTestItemMetas()
    直接返回代码写死的动态检测项
```

现在：

```text
createDefaultDynamicTestItemMetas()
    优先读取 config/test_standard.ini
    读取失败则回退 createBuiltInDefaultDynamicTestItemMetas()
```

## 修改点 2：mainwindow.cpp

动态结果表从 9 列改为 10 列：

```text
位置
产品编码
通道
检测进度
检测项编号
检测项名称
检测值
单位
检测标准
结果
```

新增列：

```text
检测标准
```

填充内容：

```cpp
itemResult.standardText
```

## 修改点 3：dynamic_csv_exporter.cpp

动态 CSV 表头新增：

```text
检测标准
```

保存内容新增：

```cpp
item.standardText
```

## INI 示例

完整示例在：

```text
config/test_standard.ini
```

动态部分示例：

```ini
[DynamicItem6]
itemNo=6
itemName=SpeedFlucRec
flagSeq=6
valueSeq=33
unit=rpm
scale=1.0
standardText=2000±50 rpm
affectsProductPass=true
isProgressItem=false
progressFinishedValue=100
```

含义：

```text
flagSeq=6：
    PASS/NG 仍然看检测板返回的 seq=6 flag，0=合格，1=不合格。

valueSeq=33：
    当前检测值来自 seq=33。

standardText=2000±50 rpm：
    只用于界面和 CSV，让检测员知道该项标准。
```

## .pro 增加

```qmake
SOURCES += \
    dynamic_test_standard_config.cpp

HEADERS += \
    dynamic_test_standard_config.h
```

## 验证方式

在 Qt Creator 应用程序输出里看：

```text
[DynamicStandard] INI加载成功，检测项数量 = 31
```

或者把 INI 中：

```ini
standardText=2000±50 rpm
```

临时改成：

```ini
standardText=【INI已加载】2000±50 rpm
```

运行一次动态测试，看主界面动态结果表和 CSV 是否显示这段文本。
