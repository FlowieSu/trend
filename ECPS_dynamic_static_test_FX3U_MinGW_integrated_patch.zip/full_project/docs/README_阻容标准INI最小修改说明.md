# 阻容测试标准外部 INI 最小修改说明

## 目标

把当前写死在 `TestRunner::initTestItems()` 里的阻容测试标准外置到：

```text
程序目录/config/test_standard.ini
```

并保持以下逻辑不变：

```text
1. 自动化流程不变
2. PLC点位动作流程不变
3. 万用表/电桥测量流程不变
4. executeDirection() 判定流程不变
5. 红黑/黑红共用同一个测试项的合格范围
```

## 新增文件

```text
static_test_standard_config.h
static_test_standard_config.cpp
config/test_standard.ini
```

## 修改文件

```text
test_runner.h
test_runner.cpp
.pro
```

## 修改点 1：test_runner.h

### 新增 include

```cpp
#include "static_test_standard_config.h"
```

### 新增 private 函数

```cpp
void initDefaultTestItems();
void appendConfigItem(const StaticStandardItem &configItem);
```

## 修改点 2：test_runner.cpp

### 新增 include

```cpp
#include "static_test_standard_config.h"
```

### 修改 `TestRunner::initTestItems()`

原来：

```cpp
void TestRunner::initTestItems()
{
    m_testItems.clear();

    // 直接写死所有阻容测试项
}
```

现在：

```cpp
void TestRunner::initTestItems()
{
    m_testItems.clear();

    QVector<StaticStandardItem> configItems;
    QString errorMessage;

    if (StaticTestStandardConfig::loadStaticItems(StaticTestStandardConfig::defaultIniFilePath(),
                                                  &configItems,
                                                  &errorMessage)) {
        for (const StaticStandardItem &item : configItems) {
            appendConfigItem(item);
        }

        emit logMessage(QString("阻容测试标准已从 INI 加载，共 %1 项。")
                        .arg(m_testItems.size()));
        return;
    }

    emit logMessage(QString("阻容测试标准 INI 加载失败，使用内置默认标准：%1")
                    .arg(errorMessage));

    initDefaultTestItems();
}
```

### 新增 `appendConfigItem()`

把 INI 读取到的 `StaticStandardItem` 转成 `TestRunner` 内部的 `LogicalTestItem`。

### 新增 `initDefaultTestItems()`

把原来 `initTestItems()` 中写死的 7 个测试项整体移动到这里，作为兜底默认值。

## 修改点 3：.pro

增加：

```qmake
SOURCES += \
    static_test_standard_config.cpp

HEADERS += \
    static_test_standard_config.h
```

## INI 结构说明

一个测试项一个 section：

```ini
[StaticItem1]
name=sin+ -> sin-
resistanceMinKOhm=10.000
resistanceMaxKOhm=20.000
capacitanceMinNf=1.000
capacitanceMaxNf=5.000
standardText=阻值: 10.000~20.000 kOhm; 容值: 1.000~5.000 nF
redBlackMPoints=3,6
blackRedMPoints=4,5
hasBlackRed=true
```

含义：

```text
测试项：sin+ -> sin-

合格标准：
    电阻：10.000~20.000 kOhm
    电容：1.000~5.000 nF

红黑方向：
    M3 + M6
    使用上面同一个电阻/电容标准

黑红方向：
    M4 + M5
    使用上面同一个电阻/电容标准
```

## 运行结果

启动时：

```text
如果 config/test_standard.ini 存在且格式正确：
    使用 INI 标准

如果 INI 不存在或格式错误：
    自动回退到内置默认标准
```

这样不会破坏当前能跑的阻容测试流程。


## 本次新增修改：5V -> GND 不进行电阻测试

### 修改 1：INI 增加两个字段

每个 `StaticItem` 支持：

```ini
enableResistance=true
enableCapacitance=true
```

其中 `5V -> GND` 配置为：

```ini
[StaticItem7]
name=5V -> GND
resistanceMinKOhm=0.000
resistanceMaxKOhm=0.000
capacitanceMinNf=1.000
capacitanceMaxNf=5.000
standardText=阻值: 不测试; 容值: 1.000~5.000 nF
enableResistance=false
enableCapacitance=true
redBlackMPoints=0,1
blackRedMPoints=0,2
hasBlackRed=true
```

含义：

```text
5V -> GND：
    红黑方向：不测电阻，只测电容
    黑红方向：不测电阻，只测电容
    两个方向共用同一个电容范围 1.000~5.000 nF
```

### 修改 2：StaticStandardItem 增加字段

```cpp
bool enableResistance = true;
bool enableCapacitance = true;
```

### 修改 3：TestRunner::TestStandard 增加字段

```cpp
bool enableResistance = true;
bool enableCapacitance = true;
```

### 修改 4：TestRunner::executeDirection()

原逻辑：

```text
每个方向都测电阻 + 测电容
电阻PASS && 电容PASS -> 方向PASS
```

新逻辑：

```text
enableResistance=true：
    测电阻，并参与判定

enableResistance=false：
    跳过电阻测量
    resistanceKOhm = -1.0
    resistancePass = true
    不输出“电阻NG”

enableCapacitance=true：
    测电容，并参与判定
```

所以 5V -> GND 最终判定为：

```text
电容PASS -> 方向PASS
电容NG   -> 方向NG
```

不再因为电阻未测或电阻不在范围而 NG。
