# 5V -> GND 不进行电阻测试：修改说明

## 需要修改的文件

```text
static_test_standard_config.h
static_test_standard_config.cpp
test_runner.h
test_runner.cpp
config/test_standard.ini
```

## 1. static_test_standard_config.h

在 `StaticStandardItem` 中新增：

```cpp
bool enableResistance = true;
bool enableCapacitance = true;
```

作用：

```text
从 INI 读取是否需要执行电阻/电容测试。
```

## 2. static_test_standard_config.cpp

在 `readOneItem()` 中新增读取：

```cpp
item->enableResistance = settings.value("enableResistance", true).toBool();
item->enableCapacitance = settings.value("enableCapacitance", true).toBool();
```

并增加校验：

```cpp
enableResistance=false 时，不校验电阻上下限；
enableCapacitance=false 时，不校验电容上下限；
两者不能同时为 false。
```

## 3. test_runner.h

在 `TestRunner::TestStandard` 中新增：

```cpp
bool enableResistance = true;
bool enableCapacitance = true;
```

## 4. test_runner.cpp

### 4.1 appendConfigItem()

把 INI 读取到的开关赋值给内部标准：

```cpp
standard.enableResistance = configItem.enableResistance;
standard.enableCapacitance = configItem.enableCapacitance;
```

### 4.2 executeDirection()

原来每个方向都固定：

```text
测电阻
测电容
电阻PASS && 电容PASS
```

现在改为：

```text
enableResistance=true  -> 测电阻并判定
enableResistance=false -> 跳过电阻测量，电阻判定按 true 处理

enableCapacitance=true -> 测电容并判定
enableCapacitance=false-> 跳过电容测量，电容判定按 true 处理
```

### 4.3 initDefaultTestItems()

内置默认标准中，`5V -> GND` 改为：

```cpp
TestStandard fiveVoltGndStandard = windingStandard;
fiveVoltGndStandard.enableResistance = false;
fiveVoltGndStandard.enableCapacitance = true;
fiveVoltGndStandard.text = "阻值: 不测试; 容值: 1.000~5.000 nF";
```

## 5. config/test_standard.ini

`5V -> GND` 配置为：

```ini
[StaticItem7]
name=5V -> GND
resistanceMinKOhm=0.000
resistanceMaxKOhm=0.000
capacitanceMinNf=1.000
capacitanceMaxNf=5.000
standardText=阻值: 不测试; 容值: 1.000~5.000 nF
enableResistance=false
enableCapacitance=true
redBlackMPoints=0,1
blackRedMPoints=0,2
hasBlackRed=true
```
