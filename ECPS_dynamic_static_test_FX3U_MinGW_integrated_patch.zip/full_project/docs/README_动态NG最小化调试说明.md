# 动态检测 NG 最小化 qDebug 调试补丁

## 目的

当动态检测结果不合格时，自动在 Qt Creator「应用程序输出」中打印：

```text
1. 产品总结果信息；
2. 每个不合格 item 的 flag 信息；
3. 不合格 flag 对应的原始 CAN 报文；
4. 该原始报文解析后的结果；
5. item 对应 value/rec 的原始报文和解析结果；
6. 当前界面显示结果所属 active groupCnt 的所有报文。
```

用于排查：

```text
1. flagSeq/valueSeq 是否配错；
2. flag 和 rec 是否来自同一轮询组；
3. 当前界面显示的 item 数据到底来自哪一组报文；
4. QualiFlag=0 但产品显示 NG 时，究竟是哪一项拉低了结果。
```

## 修改文件

```text
dynamic_product_context.h
dynamic_product_context.cpp
```

本补丁基于“轮询组一致性修正”后的版本生成，里面已经包含：

```text
1. activeGroupCnt；
2. groupCnt 变化时清空缓存；
3. DetectInProgressFlag==100 后等待组校验通过才锁定结果。
```

## 输出示例

当某个产品 NG 时，你会看到类似：

```text
[DynamicNG][Product] product=xxx channel=通道110 finished=true detectProgress=100 activeGroup=12 groupCheckReceived=true groupCheckPassed=true

[DynamicNG][Item] product=xxx channel=通道110 activeGroup=12 itemNo=6 itemName=SpeedFlucRec pass=false message=检测项不合格

[DynamicNG][Flag] item=SpeedFlucRec flagSeq=6 flagValue=1 flagReceived=true flagCheckOk=true

[DynamicNG][FlagRaw] item=SpeedFlucRec type=NORMAL canId=0x201 raw=[06 01 01 00 0C 00 14 00] parsed={seq=6, seed=1, value=1, groupCnt=12, checkValue=20, valid=true, seedOk=true, checkOk=true}

[DynamicNG][Value] item=SpeedFlucRec valueSeq=33 rawValue=2075 displayValue=2075 valueReceived=true valueCheckOk=true unit=rpm standard=2000±50 rpm

[DynamicNG][ValueRaw] item=SpeedFlucRec type=NORMAL canId=0x201 raw=[21 01 1B 08 0C 00 41 08] parsed={seq=33, seed=1, value=2075, groupCnt=12, checkValue=2113, valid=true, seedOk=true, checkOk=true}

[DynamicNG][GroupDumpBegin] reason=product NG product=xxx channel=通道110 activeGroup=12 frameCount=62 detectProgress=100 groupCheckReceived=true groupCheckPassed=true

[DynamicNG][GroupFrame][0] type=NORMAL canId=0x201 raw=[...] parsed={...}
...
[DynamicNG][GroupDumpEnd] product=xxx activeGroup=12
```

## 如何用它排查

### 1. 排查 flagSeq 是否错

看：

```text
[DynamicNG][Item] itemName=SpeedFlucRec
[DynamicNG][Flag] flagSeq=xxx flagValue=xxx
[DynamicNG][FlagRaw] raw=[...]
```

如果 `SpeedFlucRec` 打印出来的 flagRaw 不是你认为的 `SpeedFlucFlag`，说明 INI 里的 `flagSeq` 配错。

### 2. 排查 valueSeq 是否错

看：

```text
[DynamicNG][Value] valueSeq=xxx rawValue=xxx
[DynamicNG][ValueRaw] raw=[...]
```

如果 rawValue 不是该 item 的真实 Rec，说明 INI 里的 `valueSeq` 配错。

### 3. 排查是否混组

看：

```text
[DynamicNG][FlagRaw] parsed={..., groupCnt=12, ...}
[DynamicNG][ValueRaw] parsed={..., groupCnt=12, ...}
```

以及：

```text
[DynamicNG][GroupDumpBegin] activeGroup=12
```

如果 flagRaw 和 valueRaw 的 groupCnt 都等于 activeGroup，说明没有混组。

## 注意

这是调试补丁，日志会比较多。问题定位完成后，可以删除或用宏包起来，例如：

```cpp
#define DYNAMIC_NG_DEBUG 1
```
