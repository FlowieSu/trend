QT += core gui widgets serialport network concurrent

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

TARGET = ECPS_StaticAndDynamic_Test
TEMPLATE = app

DEFINES += QT_DEPRECATED_WARNINGS

# ============================================================
# 工程路径
# ============================================================

PROJECT_ROOT = E:/workspace/Qt_workspace/ECPS_StaticAndDynamic_Test
ZLG_ROOT = E:/workspace/LIBS/zlgcan_x64

INCLUDEPATH += \
    $$PWD \
    $$ZLG_ROOT

DEPENDPATH += \
    $$PWD \
    $$ZLG_ROOT

# ============================================================
# ZLG CAN 库
# ============================================================
# 按你的库文件实际名称保留一个即可。
# 如果 zlgcan_x64 下是 ControlCAN.lib，就用 ControlCAN.lib。
# 如果是 usbcanfd.lib，就把 ControlCAN.lib 注释掉，打开 usbcanfd.lib。

win32 {
    LIBS += $$ZLG_ROOT/ControlCAN.lib

    # LIBS += $$ZLG_ROOT/usbcanfd.lib
}

# ============================================================
# 源文件
# ============================================================

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    test_runner.cpp \
    static_test_standard_config.cpp \
    mitsubishi_plc.cpp \
    scpi_controller.cpp \
    csv_exporter.cpp \
    Device.cpp \
    zlg_can_device.cpp \
    dynamic_protocol.cpp \
    dynamic_test_standard_config.cpp \
    dynamic_test_item_config.cpp \
    dynamic_product_context.cpp \
    dynamic_test_controller.cpp \
    dynamic_csv_exporter.cpp \
    manualstatictestwindow.cpp \
    manualdynamictestwindow.cpp \
    deviceconnectiondialog.cpp \
    dynamicparamconfigdialog.cpp \
    logwindow.cpp \
    plctestwindow.cpp

# ============================================================
# 头文件
# ============================================================

HEADERS += \
    mainwindow.h \
    test_runner.h \
    static_test_standard_config.h \
    mitsubishi_plc.h \
    scpi_controller.h \
    csv_exporter.h \
    Device.h \
    zlg_can_device.h \
    dynamic_protocol.h \
    dynamic_test_standard_config.h \
    dynamic_test_item_config.h \
    dynamic_result_types.h \
    dynamic_product_context.h \
    dynamic_test_controller.h \
    dynamic_csv_exporter.h \
    manualstatictestwindow.h \
    manualdynamictestwindow.h \
    deviceconnectiondialog.h \
    dynamicparamconfigdialog.h \
    logwindow.h \
    plctestwindow.h

# ============================================================
# UI 文件
# ============================================================

FORMS += \
    mainwindow.ui \
    manualstatictestwindow.ui \
    manualdynamictestwindow.ui \
    deviceconnectiondialog.ui \
    dynamicparamconfigdialog.ui \
    logwindow.ui \
    plctestwindow.ui

# ============================================================
# 运行时配置
# ============================================================
# 程序运行时需要：
#   exe同级目录/config/test_standard.ini
#
# Qt Creator 调试时，如没有自动复制 config 目录，
# 请手动把本工程 config 文件夹复制到 Debug/Release exe 同级目录。

# ============================================================
# 不要再加入旧动态业务文件
# ============================================================
# usbcanfd_200u.cpp / usbcanfd_200u.h
# sensor.cpp / sensor.h
# AllInfo / BaseInfo 相关旧结构
