#include "mitsubishi_plc.h"

#include <QSerialPort>
#include <QThread>
#include <QElapsedTimer>
#include <QIODevice>
#include <QDebug>

MitsubishiPLC::MitsubishiPLC(QObject *parent)
    : QObject(parent),
      m_serialPort(new QSerialPort(this))
{
}

MitsubishiPLC::~MitsubishiPLC()
{
    disconnectDevice();
}

bool MitsubishiPLC::connectDevice(const QString &portName)
{
    if (portName.trimmed().isEmpty()) {
        setLastError("PLC 串口名称为空");
        emit logMessage(m_lastError);
        return false;
    }

    if (m_serialPort->isOpen()) {
        m_serialPort->close();
    }

    m_serialPort->setPortName(portName);

    // USB-SC09-FX / FX 编程口常用参数：
    // 9600 bps, 7 数据位, 偶校验, 1 停止位, 无流控
    m_serialPort->setBaudRate(QSerialPort::Baud9600);
    m_serialPort->setDataBits(QSerialPort::Data7);
    m_serialPort->setParity(QSerialPort::EvenParity);
    m_serialPort->setStopBits(QSerialPort::OneStop);
    m_serialPort->setFlowControl(QSerialPort::NoFlowControl);

    emit logMessage(QString("PLC 串口参数：%1, 9600, 7E1, NoFlowControl。")
                    .arg(portName));

    if (!m_serialPort->open(QIODevice::ReadWrite)) {
        setLastError(QString("打开 PLC 串口失败：%1").arg(m_serialPort->errorString()));
        emit logMessage(m_lastError);
        emit connectedChanged(false);
        return false;
    }

    m_serialPort->clear(QSerialPort::AllDirections);

    if (!ping()) {
        setLastError("PLC ping 失败");
        emit logMessage(m_lastError);
        m_serialPort->close();
        emit connectedChanged(false);
        return false;
    }

    emit logMessage(QString("PLC 串口连接成功：%1").arg(portName));
    emit connectedChanged(true);
    return true;
}

void MitsubishiPLC::disconnectDevice()
{
    if (m_serialPort && m_serialPort->isOpen()) {
        m_serialPort->close();
        emit logMessage("PLC 串口已断开");
    }

    emit connectedChanged(false);
}

bool MitsubishiPLC::isConnected() const
{
    return m_serialPort && m_serialPort->isOpen();
}

bool MitsubishiPLC::setMRelay(int mNumber, bool on)
{
    if (!isConnected()) {
        setLastError("PLC 串口未连接");
        emit logMessage(m_lastError);
        return false;
    }

    if (!isValidMNumber(mNumber)) {
        setLastError(QString("M 点编号超出范围：M%1，有效范围 M0 ~ M%2")
                         .arg(mNumber)
                         .arg(kMaxMRelay));
        emit logMessage(m_lastError);
        return false;
    }

    QByteArray frame = buildForceMCommand(mNumber, on);

    emit logMessage(QString("发送 PLC 命令：M%1 %2，帧：%3")
                        .arg(mNumber)
                        .arg(on ? "ON" : "OFF")
                        .arg(bytesToHexString(frame)));

    bool ok = sendFrameAndWaitAck(frame, 1000);

    if (ok) {
        emit logMessage(QString("PLC 执行成功：M%1 %2")
                            .arg(mNumber)
                            .arg(on ? "ON" : "OFF"));
    } else {
        emit logMessage(QString("PLC 执行失败：M%1 %2，错误：%3")
                            .arg(mNumber)
                            .arg(on ? "ON" : "OFF")
                            .arg(m_lastError));
    }

    return ok;
}

bool MitsubishiPLC::pulseMRelay(int mNumber, int pulseMs)
{
    if (pulseMs <= 0) {
        pulseMs = 100;
    }

    emit logMessage(QString("准备脉冲 M%1，持续 %2 ms。").arg(mNumber).arg(pulseMs));

    if (!setMRelay(mNumber, true)) {
        return false;
    }

    QThread::msleep(static_cast<unsigned long>(pulseMs));

    if (!setMRelay(mNumber, false)) {
        return false;
    }

    emit logMessage(QString("M%1 脉冲完成。").arg(mNumber));
    return true;
}

bool MitsubishiPLC::resetMRange(int startM, int count)
{
    if (count <= 0) {
        return true;
    }

    emit logMessage(QString("准备复位 M 点：M%1 ~ M%2")
                    .arg(startM)
                    .arg(startM + count - 1));

    for (int i = 0; i < count; ++i) {
        const int m = startM + i;

        if (!setMRelay(m, false)) {
            emit logMessage(QString("复位 M%1 失败，中止。").arg(m));
            return false;
        }

        QThread::msleep(20);
    }

    emit logMessage("M 点复位完成。");
    return true;
}

bool MitsubishiPLC::setMRelays(const QVector<int> &mNumbers,
                               int resetStartM,
                               int resetCount)
{
    if (!resetMRange(resetStartM, resetCount)) {
        return false;
    }

    emit logMessage("开始闭合目标 M 点。");

    for (int m : mNumbers) {
        if (!setMRelay(m, true)) {
            emit logMessage(QString("闭合 M%1 失败，中止。").arg(m));
            return false;
        }

        QThread::msleep(20);
    }

    emit logMessage("目标 M 点闭合完成。");
    return true;
}

bool MitsubishiPLC::ping()
{
    /*
     * 当前版本不主动写 PLC 软元件作为 ping，避免误动作。
     *
     * 已确认 FX 编程口协议命令：
     *   '7'：强制 ON
     *   '8'：强制 OFF
     *
     * 为避免 ping 时改变 PLC 状态，此处仅校验串口是否已成功打开。
     */
    if (!m_serialPort || !m_serialPort->isOpen()) {
        setLastError("PLC 串口未打开");
        return false;
    }

    return true;
}

QString MitsubishiPLC::lastError() const
{
    return m_lastError;
}

QByteArray MitsubishiPLC::buildForceMCommand(int mNumber, bool on) const
{
    QString addrStr = buildMAddressString(mNumber);

    QByteArray body;

    // FX 编程口协议：
    // '7' = 强制 ON
    // '8' = 强制 OFF
    body.append(on ? '7' : '8');

    // 4 位 ASCII HEX 地址，例如：
    // M0   -> "0008"
    // M100 -> "6408"
    // M200 -> "C808"
    body.append(addrStr.toLatin1());

    // ETX
    body.append(char(0x03));

    QString sumStr = calcSum(body);

    QByteArray frame;

    // STX
    frame.append(char(0x02));

    // CMD + ADDR + ETX
    frame.append(body);

    // SUM，两位 ASCII HEX
    frame.append(sumStr.toLatin1());

    return frame;
}

QString MitsubishiPLC::buildMAddressString(int mNumber) const
{
    /*
     * FX 编程口协议 M 点地址规则：
     *
     * M 内部地址 = 0x0800 + M编号
     *
     * 发送地址时必须低字节在前，高字节在后。
     *
     * 例如：
     * M0:
     *   内部地址 = 0x0800
     *   低字节 = 00
     *   高字节 = 08
     *   发送地址 = "0008"
     *
     * M19:
     *   内部地址 = 0x0813
     *   低字节 = 13
     *   高字节 = 08
     *   发送地址 = "1308"
     *
     * M20:
     *   内部地址 = 0x0814
     *   低字节 = 14
     *   高字节 = 08
     *   发送地址 = "1408"
     *
     * M100:
     *   内部地址 = 0x0864
     *   低字节 = 64
     *   高字节 = 08
     *   发送地址 = "6408"
     */

    quint16 absAddr = static_cast<quint16>(0x0800 + mNumber);

    quint8 lowByte = static_cast<quint8>(absAddr & 0xFF);
    quint8 highByte = static_cast<quint8>((absAddr >> 8) & 0xFF);

    QString addrStr = QString("%1%2")
            .arg(lowByte, 2, 16, QChar('0'))
            .arg(highByte, 2, 16, QChar('0'))
            .toUpper();

    return addrStr;
}

QString MitsubishiPLC::calcSum(const QByteArray &body) const
{
    /*
     * 校验和计算：
     * 从 CMD 开始累加，到 ETX 结束。
     * 取低 8 位，转换为 2 位大写 ASCII HEX。
     */

    quint8 sum = 0;

    for (char ch : body) {
        sum = static_cast<quint8>(sum + static_cast<quint8>(ch));
    }

    return QString("%1")
            .arg(sum, 2, 16, QChar('0'))
            .toUpper();
}

bool MitsubishiPLC::sendFrameAndWaitAck(const QByteArray &frame, int timeoutMs)
{
    if (!m_serialPort || !m_serialPort->isOpen()) {
        setLastError("PLC 串口未打开");
        return false;
    }

    if (frame.isEmpty()) {
        setLastError("发送帧为空");
        return false;
    }

    // 清空旧数据，避免上次残留的 0x15 / 0x06 干扰本次判断
    m_serialPort->clear(QSerialPort::Input);

    qint64 written = m_serialPort->write(frame);

    if (written != frame.size()) {
        setLastError(QString("PLC 串口写入长度异常，应写 %1 字节，实际写 %2 字节")
                         .arg(frame.size())
                         .arg(written));
        return false;
    }

    if (!m_serialPort->waitForBytesWritten(timeoutMs)) {
        setLastError(QString("PLC 串口发送超时：%1").arg(m_serialPort->errorString()));
        return false;
    }

    QByteArray response;
    QElapsedTimer timer;
    timer.start();

    while (timer.elapsed() < timeoutMs) {
        int remainMs = timeoutMs - static_cast<int>(timer.elapsed());
        int waitMs = remainMs > 50 ? 50 : remainMs;

        if (waitMs <= 0) {
            break;
        }

        if (m_serialPort->bytesAvailable() <= 0) {
            m_serialPort->waitForReadyRead(waitMs);
        }

        QByteArray chunk = m_serialPort->readAll();

        if (!chunk.isEmpty()) {
            response.append(chunk);

            for (char ch : chunk) {
                unsigned char value = static_cast<unsigned char>(ch);

                if (value == 0x06) {
                    // ACK
                    emit logMessage(QString("PLC 响应 ACK：%1").arg(bytesToHexString(response)));
                    return true;
                }

                if (value == 0x15) {
                    // NAK
                    setLastError(QString("PLC 返回 NAK：%1").arg(bytesToHexString(response)));
                    return false;
                }
            }
        }
    }

    if (response.isEmpty()) {
        setLastError("PLC 响应超时，未收到 ACK/NAK");
    } else {
        setLastError(QString("PLC 响应异常：%1").arg(bytesToHexString(response)));
    }

    return false;
}

bool MitsubishiPLC::isValidMNumber(int mNumber) const
{
    return mNumber >= 0 && mNumber <= kMaxMRelay;
}

QString MitsubishiPLC::bytesToHexString(const QByteArray &data) const
{
    return QString::fromLatin1(data.toHex(' ').toUpper());
}

void MitsubishiPLC::setLastError(const QString &error)
{
    m_lastError = error;
}
