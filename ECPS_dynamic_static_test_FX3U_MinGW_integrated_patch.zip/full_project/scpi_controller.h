#ifndef SCPI_CONTROLLER_H
#define SCPI_CONTROLLER_H

#include <QObject>
#include <QLibrary>
#include <QString>
#include <QtGlobal>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

#ifndef WINAPI
#define WINAPI
#endif

class SCPIController : public QObject
{
    Q_OBJECT

public:
    explicit SCPIController(QObject *parent = nullptr);
    ~SCPIController() override;

    bool connectInstrument(const QString &visaAddress);
    void disconnectInstrument();
    bool isConnected() const;

    bool ping();

    void setResistanceCommand(const QString &configCommand);
    void setCapacitanceCommand(const QString &configCommand);
    void setReadCommand(const QString &readCommand);
    void setResistanceDelayMs(int delayMs);
    void setCapacitanceDelayMs(int delayMs);

    double measureResistance(int timeoutMs);
    double measureCapacitance(int timeoutMs);

    QString lastError() const;

signals:
    void logMessage(const QString &message);
    void connectedChanged(bool connected);

private:
    using ViStatus = qint32;
    using ViSession = quint32;
    using ViObject = quint32;
    using ViUInt32 = quint32;
    using ViAccessMode = quint32;
    using ViAttr = quint32;
    using ViAttrState = quint64;

    using ViOpenDefaultRMFn = ViStatus (WINAPI *)(ViSession *sesn);
    using ViOpenFn = ViStatus (WINAPI *)(ViSession sesn,
                                         char *rsrcName,
                                         ViAccessMode accessMode,
                                         ViUInt32 openTimeout,
                                         ViSession *vi);
    using ViCloseFn = ViStatus (WINAPI *)(ViObject vi);
    using ViWriteFn = ViStatus (WINAPI *)(ViSession vi,
                                          unsigned char *buf,
                                          ViUInt32 count,
                                          ViUInt32 *retCount);
    using ViReadFn = ViStatus (WINAPI *)(ViSession vi,
                                         unsigned char *buf,
                                         ViUInt32 count,
                                         ViUInt32 *retCount);
    using ViSetAttributeFn = ViStatus (WINAPI *)(ViObject vi,
                                                 ViAttr attrName,
                                                 ViAttrState attrValue);
    using ViGetAttributeFn = ViStatus (WINAPI *)(ViObject vi,
                                                 ViAttr attrName,
                                                 ViAttrState *attrValue);
    using ViStatusDescFn = ViStatus (WINAPI *)(ViObject vi,
                                               ViStatus status,
                                               char *desc);

private:
    bool loadVisaLibrary();
    void unloadVisaLibrary();

    bool openVisaInstrument(const QString &address);
    bool sendCommand(const QString &command, int timeoutMs);
    bool query(const QString &command, QString *response, int timeoutMs);
    bool readResponse(QString *response, int timeoutMs);
    bool clearReadBuffer(int maxWaitMs = 50);
    bool configureMeasurementMode(const QString &command, int settleDelayMs, int timeoutMs);

    double parseDoubleResponse(const QString &response, bool *ok) const;

    bool setVisaTimeout(int timeoutMs);
    QString visaStatusText(ViStatus status) const;

    void setLastError(const QString &error);
    void clearLastError();

private:
    QLibrary m_visaLibrary;

    ViOpenDefaultRMFn m_viOpenDefaultRM = nullptr;
    ViOpenFn m_viOpen = nullptr;
    ViCloseFn m_viClose = nullptr;
    ViWriteFn m_viWrite = nullptr;
    ViReadFn m_viRead = nullptr;
    ViSetAttributeFn m_viSetAttribute = nullptr;
    ViGetAttributeFn m_viGetAttribute = nullptr;
    ViStatusDescFn m_viStatusDesc = nullptr;

    ViSession m_defaultRm = 0;
    ViSession m_instrument = 0;

    QString m_address;
    QString m_lastError;

    QString m_resistanceCommand = "CONF:RES";
    QString m_capacitanceCommand = "CONF:CAP";
    QString m_readCommand = "READ?";

    int m_resistanceDelayMs = 1000;
    int m_capacitanceDelayMs = 1000;

    bool m_simulationMode = false;
};

#endif // SCPI_CONTROLLER_H
