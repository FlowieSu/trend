#ifndef PLCTESTWINDOW_H
#define PLCTESTWINDOW_H

#include <QWidget>

namespace Ui {
class PlcTestWindow;
}

class MitsubishiPLC;

/*
 * PlcTestWindow
 *
 * PLC 点位测试窗口。
 *
 * 功能：
 * 1. 测试 M 点 ON / OFF / 脉冲；
 * 2. 测试 M26/M27 等映射点 ON / OFF；
 * 3. 快捷选择常用 M 点；
 * 4. 用于验证 PLC 通信、继电器动作、Y26/Y27 台架切换动作是否正常。
 *
 * 当前点位约定：
 * M19  ：阻容测试总使能
 * M20  ：测试位置选择，OFF=位置1，ON=位置2
 * M100 ：阻容测试通道复位脉冲
 *
 * M26  ：测试线路切换，OFF=阻容测试线路，ON=动态测试线路
 * M27  ：伺服电机控制，OFF=伺服关闭，ON=伺服打开
 *
 * 注意：
 * M27 ON 会打开两套伺服电机，窗口中对 M27 ON 增加了二次确认。
 */
class PlcTestWindow : public QWidget
{
    Q_OBJECT

public:
    explicit PlcTestWindow(MitsubishiPLC *plc,
                           QWidget *parent = nullptr);
    ~PlcTestWindow() override;

private slots:
    void onMOn();
    void onMOff();
    void onMPulse();

    void onYOn();
    void onYOff();

    void onSelectM19();
    void onSelectM20();
    void onSelectM100();

    void onSelectY26();
    void onSelectY27();

    void onClearLog();

private:
    void initUiState();
    void initConnections();

    bool checkPlcReady();
    bool confirmDangerousYOn(int yNumber);

    int currentMNumber() const;
    int currentYNumber() const;
    int currentPulseMs() const;

    void appendLog(const QString &message);

private:
    Ui::PlcTestWindow *ui = nullptr;
    MitsubishiPLC *m_plc = nullptr;
};

#endif // PLCTESTWINDOW_H
