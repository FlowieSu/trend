#include "plctestwindow.h"
#include "ui_plctestwindow.h"

#include "mitsubishi_plc.h"

#include <QDateTime>
#include <QMessageBox>

namespace
{
constexpr int M_RES_CAP_ENABLE = 19;
constexpr int M_POSITION_SELECT = 20;
constexpr int M_RESET_CHANNEL = 100;

constexpr int M_DYNAMIC_MODE = 26;
constexpr int M_SERVO_POWER = 27;
}

PlcTestWindow::PlcTestWindow(MitsubishiPLC *plc,
                             QWidget *parent)
    : QWidget(parent),
      ui(new Ui::PlcTestWindow),
      m_plc(plc)
{
    ui->setupUi(this);

    initUiState();
    initConnections();

    appendLog("PLC点位测试窗口已打开。");
}

PlcTestWindow::~PlcTestWindow()
{
    delete ui;
}

void PlcTestWindow::initUiState()
{
    setWindowTitle("PLC点位测试");

    ui->spinMNumber->setRange(0, 9999);
    ui->spinMNumber->setValue(M_RES_CAP_ENABLE);

    ui->spinYNumber->setRange(0, 999);
    ui->spinYNumber->setValue(M_DYNAMIC_MODE);

    ui->spinPulseMs->setRange(20, 5000);
    ui->spinPulseMs->setValue(100);

    ui->labelMHint->setText("M点：M19 阻容总使能，M20 位置选择，M100 通道复位");
    ui->labelYHint->setText("M点：M26 OFF=阻容/ON=动态；M27 OFF=伺服关闭/ON=伺服打开");
}

void PlcTestWindow::initConnections()
{
    connect(ui->btnMOn, &QPushButton::clicked, this, &PlcTestWindow::onMOn);
    connect(ui->btnMOff, &QPushButton::clicked, this, &PlcTestWindow::onMOff);
    connect(ui->btnMPulse, &QPushButton::clicked, this, &PlcTestWindow::onMPulse);

    connect(ui->btnYOn, &QPushButton::clicked, this, &PlcTestWindow::onYOn);
    connect(ui->btnYOff, &QPushButton::clicked, this, &PlcTestWindow::onYOff);

    connect(ui->btnM19, &QPushButton::clicked, this, &PlcTestWindow::onSelectM19);
    connect(ui->btnM20, &QPushButton::clicked, this, &PlcTestWindow::onSelectM20);
    connect(ui->btnM100, &QPushButton::clicked, this, &PlcTestWindow::onSelectM100);

    connect(ui->btnY26, &QPushButton::clicked, this, &PlcTestWindow::onSelectY26);
    connect(ui->btnY27, &QPushButton::clicked, this, &PlcTestWindow::onSelectY27);

    connect(ui->btnClearLog, &QPushButton::clicked, this, &PlcTestWindow::onClearLog);
    connect(ui->btnClose, &QPushButton::clicked, this, &QWidget::close);
}

bool PlcTestWindow::checkPlcReady()
{
    if (!m_plc) {
        QMessageBox::warning(this, "提示", "PLC对象为空，无法测试点位。");
        return false;
    }

    if (!m_plc->isConnected()) {
        QMessageBox::warning(this, "提示", "PLC未连接，请先在主界面连接PLC。");
        return false;
    }

    return true;
}

bool PlcTestWindow::confirmDangerousYOn(int yNumber)
{
    if (yNumber != M_SERVO_POWER) {
        return true;
    }

    int ret = QMessageBox::warning(this,
                                   "安全确认",
                                   "即将执行 M27 ON，伺服电机将打开。\n\n请确认台架周围安全、产品已正确安装。",
                                   QMessageBox::Ok | QMessageBox::Cancel,
                                   QMessageBox::Cancel);

    return ret == QMessageBox::Ok;
}

int PlcTestWindow::currentMNumber() const
{
    return ui->spinMNumber->value();
}

int PlcTestWindow::currentYNumber() const
{
    return ui->spinYNumber->value();
}

int PlcTestWindow::currentPulseMs() const
{
    return ui->spinPulseMs->value();
}

void PlcTestWindow::onMOn()
{
    if (!checkPlcReady()) {
        return;
    }

    const int mNumber = currentMNumber();

    appendLog(QString("发送命令：M%1 ON。").arg(mNumber));

    if (!m_plc->setMRelay(mNumber, true)) {
        appendLog(QString("M%1 ON 失败：%2").arg(mNumber).arg(m_plc->lastError()));
        return;
    }

    appendLog(QString("M%1 ON 命令发送成功。").arg(mNumber));
}

void PlcTestWindow::onMOff()
{
    if (!checkPlcReady()) {
        return;
    }

    const int mNumber = currentMNumber();

    appendLog(QString("发送命令：M%1 OFF。").arg(mNumber));

    if (!m_plc->setMRelay(mNumber, false)) {
        appendLog(QString("M%1 OFF 失败：%2").arg(mNumber).arg(m_plc->lastError()));
        return;
    }

    appendLog(QString("M%1 OFF 命令发送成功。").arg(mNumber));
}

void PlcTestWindow::onMPulse()
{
    if (!checkPlcReady()) {
        return;
    }

    const int mNumber = currentMNumber();
    const int pulseMs = currentPulseMs();

    appendLog(QString("发送命令：M%1 脉冲，持续 %2 ms。").arg(mNumber).arg(pulseMs));

    if (!m_plc->pulseMRelay(mNumber, pulseMs)) {
        appendLog(QString("M%1 脉冲失败：%2").arg(mNumber).arg(m_plc->lastError()));
        return;
    }

    appendLog(QString("M%1 脉冲命令发送成功。").arg(mNumber));
}

void PlcTestWindow::onYOn()
{
    if (!checkPlcReady()) {
        return;
    }

    const int yNumber = currentYNumber();

    if (!confirmDangerousYOn(yNumber)) {
        appendLog(QString("用户取消 M%1 ON。").arg(yNumber));
        return;
    }

    appendLog(QString("发送命令：M%1 ON。").arg(yNumber));

    if (!m_plc->setMRelay(yNumber, true)) {
        appendLog(QString("M%1 ON 失败：%2").arg(yNumber).arg(m_plc->lastError()));
        return;
    }

    appendLog(QString("M%1 ON 命令发送成功。").arg(yNumber));

    if (yNumber == M_DYNAMIC_MODE) {
        appendLog("M26 ON：当前测试线路已切换到动态测试线路。");
    } else if (yNumber == M_SERVO_POWER) {
        appendLog("M27 ON：伺服电机已打开。");
    }
}

void PlcTestWindow::onYOff()
{
    if (!checkPlcReady()) {
        return;
    }

    const int yNumber = currentYNumber();

    appendLog(QString("发送命令：M%1 OFF。").arg(yNumber));

    if (!m_plc->setMRelay(yNumber, false)) {
        appendLog(QString("M%1 OFF 失败：%2").arg(yNumber).arg(m_plc->lastError()));
        return;
    }

    appendLog(QString("M%1 OFF 命令发送成功。").arg(yNumber));

    if (yNumber == M_DYNAMIC_MODE) {
        appendLog("M26 OFF：当前测试线路已切换回阻容测试线路。");
    } else if (yNumber == M_SERVO_POWER) {
        appendLog("M27 OFF：伺服电机已关闭。");
    }
}

void PlcTestWindow::onSelectM19()
{
    ui->spinMNumber->setValue(M_RES_CAP_ENABLE);
    appendLog("已选择 M19：阻容测试总使能。");
}

void PlcTestWindow::onSelectM20()
{
    ui->spinMNumber->setValue(M_POSITION_SELECT);
    appendLog("已选择 M20：测试位置选择，OFF=位置1，ON=位置2。");
}

void PlcTestWindow::onSelectM100()
{
    ui->spinMNumber->setValue(M_RESET_CHANNEL);
    appendLog("已选择 M100：阻容测试通道复位脉冲。");
}

void PlcTestWindow::onSelectY26()
{
    ui->spinYNumber->setValue(M_DYNAMIC_MODE);
    appendLog("已选择 Y26：OFF=阻容测试线路，ON=动态测试线路。");
}

void PlcTestWindow::onSelectY27()
{
    ui->spinYNumber->setValue(M_SERVO_POWER);
    appendLog("已选择 Y27：OFF=伺服关闭，ON=伺服打开。");
}

void PlcTestWindow::onClearLog()
{
    ui->textLog->clear();
}

void PlcTestWindow::appendLog(const QString &message)
{
    const QString timeText = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    ui->textLog->append(QString("[%1] %2").arg(timeText, message));
}
