#include "dynamic_csv_exporter.h"

#include <QDate>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>

bool DynamicCsvExporter::exportResults(const QVector<DynamicProductResult> &results,
                                        const QString &filePath,
                                        QString *errorMessage)
{
    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QString("打开 CSV 文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream stream(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    stream.setCodec("GBK");
#endif

    stream << headerLine() << "\n";

    for (const DynamicProductResult &product : results) {
        const QStringList lines = productRecordLines(product);
        for (const QString &line : lines) {
            stream << line << "\n";
        }
    }

    return true;
}

bool DynamicCsvExporter::appendProductResult(const DynamicProductResult &result,
                                             const QString &filePath,
                                             QString *errorMessage)
{
    return appendLinesGbk(filePath,
                          headerLine(),
                          productRecordLines(result),
                          errorMessage);
}

bool DynamicCsvExporter::autoSaveProductResult(const DynamicProductResult &result,
                                               QString *savedFilePath,
                                               QString *errorMessage)
{
    const QString filePath = autoFilePath(result.productCode);

    const bool ok = appendProductResult(result,
                                        filePath,
                                        errorMessage);

    if (ok && savedFilePath) {
        *savedFilePath = filePath;
    }

    return ok;
}

bool DynamicCsvExporter::autoSaveResults(const QVector<DynamicProductResult> &results,
                                         QVector<QString> *savedFilePaths,
                                         QString *errorMessage)
{
    bool allOk = true;

    if (savedFilePaths) {
        savedFilePaths->clear();
    }

    for (const DynamicProductResult &result : results) {
        QString path;
        QString err;

        const bool ok = autoSaveProductResult(result,
                                              &path,
                                              &err);

        if (ok) {
            if (savedFilePaths) {
                savedFilePaths->append(path);
            }
        } else {
            allOk = false;
            if (errorMessage) {
                if (!errorMessage->isEmpty()) {
                    *errorMessage += "\n";
                }
                *errorMessage += QString("位置%1保存失败：%2")
                                 .arg(result.productId)
                                 .arg(err);
            }
        }
    }

    return allOk;
}

QString DynamicCsvExporter::makeDefaultFileName(const QString &directory,
                                                const QString &prefix)
{
    QDir dir(directory);
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    const QString timeText =
            QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");

    return dir.filePath(QString("%1_%2.csv").arg(prefix, timeText));
}

QString DynamicCsvExporter::headerLine()
{
    QStringList header;
    header << "测试时间"
           << "完成时间"
           << "产品位置"
           << "产品编码"
           << "通道"
           << "检测进度"
           << "检测项编号"
           << "检测项名称"
           << "原始检测值"
           << "单位"
           << "检测标准"
           << "单项结果";

    return header.join(",");
}

QStringList DynamicCsvExporter::productRecordLines(const DynamicProductResult &product)
{
    QStringList lines;

    for (const DynamicItemResult &item : product.itemResults) {
        QStringList row;

        row << escapeCsv(product.startTime)
            << escapeCsv(product.finishTime)
            << escapeCsv(QString("位置%1").arg(product.productId))
            << escapeCsv(product.productCode)
            << escapeCsv(product.channelName)
            << QString::number(product.detectProgress)
            << QString::number(item.itemNo)
            << escapeCsv(item.itemName)
            << QString::number(item.rawValue)
            << escapeCsv(item.unit)
            << escapeCsv(item.standardText)
            << escapeCsv(passText(item.pass));

        lines << row.join(",");
    }

    return lines;
}

QString DynamicCsvExporter::autoFilePath(const QString &productCode)
{
    const QString rootDir = "D:/动态测试结果";
    const QString dir = monthlyDir(rootDir);
    const QString dateText = QDate::currentDate().toString("yyyyMMdd");
    const QString fileName = QString("%1_动态测试_%2.csv")
                             .arg(safeFileNamePart(productCode))
                             .arg(dateText);

    return QDir(dir).filePath(fileName);
}

QString DynamicCsvExporter::monthlyDir(const QString &rootDir)
{
    const QDate now = QDate::currentDate();

    const QString monthDir =
            QString("%1年%2月")
            .arg(now.year())
            .arg(now.month(), 2, 10, QLatin1Char('0'));

    return QDir(rootDir).filePath(monthDir);
}

QString DynamicCsvExporter::safeFileNamePart(const QString &text)
{
    QString s = text.trimmed();

    if (s.isEmpty()) {
        s = "未扫码";
    }

    const QString invalid = "\\/:*?\"<>|";
    for (const QChar &ch : invalid) {
        s.replace(ch, "_");
    }

    return s;
}

bool DynamicCsvExporter::ensureParentDir(const QString &filePath,
                                         QString *errorMessage)
{
    const QFileInfo info(filePath);
    const QString dirPath = info.absolutePath();

    if (dirPath.isEmpty()) {
        return true;
    }

    QDir dir;
    if (!dir.mkpath(dirPath)) {
        if (errorMessage) {
            *errorMessage = QString("创建目录失败：%1").arg(dirPath);
        }
        return false;
    }

    return true;
}

bool DynamicCsvExporter::appendLinesGbk(const QString &filePath,
                                        const QString &header,
                                        const QStringList &lines,
                                        QString *errorMessage)
{
    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    const bool fileExists = QFile::exists(filePath);

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QString("打开 CSV 文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream stream(&file);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    stream.setCodec("GBK");
#endif

    if (!fileExists || file.size() == 0) {
        stream << header << "\n";
    }

    for (const QString &line : lines) {
        stream << line << "\n";
    }

    return true;
}

QString DynamicCsvExporter::escapeCsv(const QString &text)
{
    QString escaped = text;
    escaped.replace("\"", "\"\"");

    if (escaped.contains(",")
            || escaped.contains("\"")
            || escaped.contains("\n")
            || escaped.contains("\r")) {
        escaped = "\"" + escaped + "\"";
    }

    return escaped;
}

QString DynamicCsvExporter::boolText(bool value)
{
    return value ? "是" : "否";
}

QString DynamicCsvExporter::passText(bool pass)
{
    return pass ? "PASS" : "NG";
}
