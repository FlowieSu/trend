#ifndef ZLG_CAN_DEVICE_H
#define ZLG_CAN_DEVICE_H

#include <QObject>
#include <QByteArray>
#include <QString>
#include <QTimer>
#include <QtGlobal>
#include <QMetaType>

#include <atomic>

#include "Device.h"

/*
 * zlg_can_device.h
 *
 * ZLG CAN 设备统一通信类。
 *
 * 设计目的：
 * 1. 同一套动态检测 CAN 协议同时支持 USBCANFD-200U 和 USBCAN-II+；
 * 2. 两种设备的区别只体现在设备类型、初始化参数、是否支持 CANFD；
 * 3. 上层 DynamicTestController 只调用 openDevice / sendFrame，并接收 frameReceived；
 * 4. 本类不解析动态检测协议，不判断检测项，不保存结果。
 *
 * 当前动态检测协议是 8 字节 CAN 报文，因此默认按普通 CAN 帧发送。
 */

enum class ZlgCanDeviceType
{
    UsbCanFd200U = 0,
    UsbCanIIPlus = 1
};

struct ZlgCanOpenConfig
{
    ZlgCanDeviceType deviceType = ZlgCanDeviceType::UsbCanFd200U;

    /*
     * 设备索引和通道索引。
     * 通常台架只有一台设备时 deviceIndex = 0。
     * 双通道设备一般 channelIndex = 0 或 1。
     */
    int deviceIndex = 0;
    int channelIndex = 0;

    /*
     * 普通 CAN 波特率。
     * USBCAN-II+ 使用该参数。
     */
    int canBaudRate = 500000;

    /*
     * CANFD 仲裁域和数据域波特率。
     * USBCANFD-200U 使用该参数。
     */
    int canFdAbitBaudRate = 500000;
    int canFdDbitBaudRate = 2000000;

    int filterMode = 0;
    QString accCode = "00000000";
    QString accMask = "FFFFFFFF";

    bool terminalResistance = false;

    /*
     * 当前动态检测默认发普通 CAN 帧。
     * 如后续确实需要 CANFD，可把 sendAsCanFd 置 true。
     */
    bool sendAsCanFd = false;
    bool receiveCanFd = false;
    bool canFdBrs = false;

    /*
     * 是否用扩展帧。
     * 旧动态检测代码默认 m_frameTypeIndex = 1，等价于扩展帧。
     * 如果检测板协议确认使用标准帧，将该值改为 false。
     */
    bool extendedFrame = true;

    int pollIntervalMs = 10;

    /*
     * 可选：直接覆盖 ZLG 设备类型值。
     * 一般不需要设置。
     * 如果现场 USBCAN-II+ 在 zlgcan.h 中对应的宏不是 ZCAN_USBCAN2，
     * 可用该字段直接传入设备类型。
     */
    unsigned int deviceTypeOverride = 0;
};

struct ZlgCanFrame
{
    quint32 canId = 0;
    QByteArray data;
    bool isCanFd = false;
    bool isExtended = false;
};

class ZlgCanDevice : public QObject
{
    Q_OBJECT

public:
    explicit ZlgCanDevice(QObject *parent = nullptr);
    ~ZlgCanDevice() override;

    bool openDevice(const ZlgCanOpenConfig &config);
    void closeDevice();

    bool isOpen() const;
    bool isChannelStarted() const;
    QString lastError() const;

    ZlgCanOpenConfig config() const;

    bool resetChannel();
    bool clearBuffer();

    /*
     * 发送一帧 CAN/CANFD。
     * 默认根据 openDevice 时的 config.sendAsCanFd 决定发送类型。
     */
    Q_INVOKABLE bool sendFrame(quint32 canId,
                               const QByteArray &data);

    Q_INVOKABLE bool sendClassicFrame(quint32 canId,
                                      const QByteArray &data);

    Q_INVOKABLE bool sendCanFdFrame(quint32 canId,
                                    const QByteArray &data);

    static QString deviceTypeName(ZlgCanDeviceType type);
    static QString idToString(quint32 canId);
    static QString dataToString(const QByteArray &data);

public slots:
    void startReceive();
    void stopReceive();

signals:
    void logMessage(const QString &message);

    void connectedChanged(bool connected);

    /*
     * 推荐上层使用该信号。
     */
    void frameReceived(quint32 canId,
                       QByteArray data);

    /*
     * 如果后续需要区分 CAN/CANFD 或扩展帧，可使用该信号。
     */
    void frameDetailReceived(ZlgCanFrame frame);

    void sendFinished(quint32 canId,
                      bool ok,
                      QString message);

private slots:
    void pollReceive();

private:
    bool openZlgDevice();
    bool initChannel();
    bool initUsbCanFd200U();
    bool initUsbCanIIPlus();
    bool startChannel();

    unsigned int zlgDeviceTypeValue() const;

    void setError(const QString &message);
    void clearHandles();

    bool transmitClassic(quint32 canId,
                         const QByteArray &data);

    bool transmitCanFd(quint32 canId,
                       const QByteArray &data);

    void receiveClassicFrames();
    void receiveCanFdFrames();

    ZlgCanFrame makeClassicFrame(const ZCAN_Receive_Data &raw) const;
    ZlgCanFrame makeCanFdFrame(const ZCAN_ReceiveFD_Data &raw) const;

private:
    ZlgCanOpenConfig m_config;

    DEVICE_HANDLE m_deviceHandle = nullptr;
    CHANNEL_HANDLE m_channelHandle = nullptr;

    bool m_deviceOpened = false;
    bool m_channelStarted = false;

    QString m_lastError;

    QTimer *m_receiveTimer = nullptr;

    std::atomic_bool m_receiving { false };

    ZCAN_Receive_Data m_canData[100] {};
    ZCAN_ReceiveFD_Data m_canFdData[100] {};
};

Q_DECLARE_METATYPE(ZlgCanDeviceType)
Q_DECLARE_METATYPE(ZlgCanOpenConfig)
Q_DECLARE_METATYPE(ZlgCanFrame)

#endif // ZLG_CAN_DEVICE_H
