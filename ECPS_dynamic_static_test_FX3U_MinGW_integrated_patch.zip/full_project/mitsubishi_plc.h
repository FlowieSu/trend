#ifndef MITSUBISHI_PLC_H
#define MITSUBISHI_PLC_H

#include <QObject>
#include <QByteArray>
#include <QString>
#include <QVector>

class QSerialPort;

class MitsubishiPLC : public QObject
{
    Q_OBJECT

public:
    explicit MitsubishiPLC(QObject *parent = nullptr);
    ~MitsubishiPLC() override;

    bool connectDevice(const QString &portName);
    void disconnectDevice();
    bool isConnected() const;

    bool setMRelay(int mNumber, bool on);
    bool pulseMRelay(int mNumber, int pulseMs = 100);

    bool resetMRange(int startM, int count);
    bool setMRelays(const QVector<int> &mNumbers,
                    int resetStartM,
                    int resetCount);

    bool ping();

    QString lastError() const;

signals:
    void logMessage(const QString &message);
    void connectedChanged(bool connected);

private:
    QByteArray buildForceMCommand(int mNumber, bool on) const;
    QString buildMAddressString(int mNumber) const;
    QString calcSum(const QByteArray &body) const;
    bool sendFrameAndWaitAck(const QByteArray &frame, int timeoutMs);
    bool isValidMNumber(int mNumber) const;
    QString bytesToHexString(const QByteArray &data) const;
    void setLastError(const QString &error);

private:
    static constexpr int kMaxMRelay = 7999;

    QSerialPort *m_serialPort = nullptr;
    QString m_lastError;
};

#endif // MITSUBISHI_PLC_H
