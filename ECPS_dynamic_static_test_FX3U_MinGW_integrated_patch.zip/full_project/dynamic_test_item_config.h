#ifndef DYNAMIC_TEST_ITEM_CONFIG_H
#define DYNAMIC_TEST_ITEM_CONFIG_H

#include <QString>
#include <QVector>

/*
 * 动态检测项配置表。
 *
 * flagSeq：合格标志位序号，来自 Excel “上位机接收报文”中的 1~31。
 * valueSeq：具体检测值序号，来自 Excel “上位机接收报文”中的 32~60。
 *
 * 注意：
 * 1. DetectInProgressFlag 是检测进度，不作为产品 PASS/NG 判定项；
 * 2. QualiFlag 是总合格标志，可参与 PASS/NG；
 * 3. 具体工艺上下限未在当前协议表里给出，所以 standardText 先按“标志位=0合格”描述。
 */

struct DynamicTestItemMeta
{
    int itemNo = 0;

    QString itemName;
    QString standardText;
    QString unit;

    int flagSeq = -1;
    int valueSeq = -1;

    double scale = 1.0;

    bool affectsProductPass = true;

    bool isProgressItem = false;
    int progressFinishedValue = 100;
};

/*
 * 创建动态检测项。
 *
 * 优先读取：
 *   程序目录/config/test_standard.ini
 *
 * 读取失败时，自动回退到 createBuiltInDefaultDynamicTestItemMetas()。
 */
QVector<DynamicTestItemMeta> createDefaultDynamicTestItemMetas();

QVector<DynamicTestItemMeta> createBuiltInDefaultDynamicTestItemMetas();

#endif // DYNAMIC_TEST_ITEM_CONFIG_H
