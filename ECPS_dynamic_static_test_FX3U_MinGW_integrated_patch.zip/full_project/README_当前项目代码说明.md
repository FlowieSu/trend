# ECPS_StaticAndDynamic_Test 当前项目代码包

## 代码范围

本包是当前对话中整理的“静态阻容 + 动态 CAN 检测”项目代码。

包含：

```text
主界面 MainWindow
静态阻容 TestRunner
阻容标准 INI 外部化
5V -> GND 不测电阻
动态 CAN 协议链路
动态检测标准 INI 外部化
动态结果表显示“检测标准”
动态 CSV 保存“检测标准”
动态结果按 groupCnt 缓存，避免不同轮询组混入同一个 item
动态 NG 时 qDebug 打印不合格 item、flag 原始报文、value 原始报文、当前轮询组所有报文
进度到 100 后，如果没有 seq=255 组校验帧，则在下一组 groupCnt 开始时锁定上一组结果
PLC 点位测试窗口
三菱 PLC Modbus RTU/ASCII 最小封装
SCPI TCPIP/SIM 最小封装
```

## ZLG 库路径

`.pro` 已按你给出的路径配置：

```qmake
ZLG_ROOT = E:/workspace/LIBS/zlgcan_x64
INCLUDEPATH += $$ZLG_ROOT
LIBS += $$ZLG_ROOT/ControlCAN.lib
```

如果你的实际库名是 `usbcanfd.lib`，请在 `.pro` 中把：

```qmake
LIBS += $$ZLG_ROOT/ControlCAN.lib
```

改成：

```qmake
LIBS += $$ZLG_ROOT/usbcanfd.lib
```

运行时还需要把对应 DLL 放到 exe 同级目录。

## 运行时配置文件

程序运行时需要：

```text
exe同级目录/config/test_standard.ini
```

如果 Qt Creator 没有自动复制，请手动复制本包中的 `config` 文件夹到 Debug/Release 输出目录。

## SCPI 说明

当前 `scpi_controller.*` 是最小化 TCPIP/SIM 版本：

```text
SIM / DEMO：无仪器流程调试
TCPIP0::IP::inst0::INSTR：LAN SCPI，端口 5025
直接 IP：LAN SCPI，端口 5025
```

如果你现场用 USBTMC / GPIB / NI-VISA，需要用你本地原 VISA 版本替换 `scpi_controller.*`，或在本类中接入 `visa.h`。

## 当前动态调试说明

当产品动态结果为 NG 时，Qt Creator 输出会打印：

```text
[DynamicNG][Product]
[DynamicNG][Item]
[DynamicNG][Flag]
[DynamicNG][FlagRaw]
[DynamicNG][Value]
[DynamicNG][ValueRaw]
[DynamicNG][GroupDumpBegin]
[DynamicNG][GroupFrame]
[DynamicNG][GroupDumpEnd]
```

用于排查：

```text
flagSeq 是否配错
valueSeq 是否配错
45/49 是否被收到但 check 失败
flag 和 rec 是否属于同一个 groupCnt
结果是否锁定太早
```

## 仍需现场确认

目前 `config/test_standard.ini` 中动态项的 `flagSeq/valueSeq` 仍按当前记录生成。
你前面提到 `valueSeq=45` 和 `valueSeq=49` 在 CANAnalyzer 中能看到，但上位机显示未收到。
这需要结合 `[DynamicNG]` 输出继续确认：

```text
是否进入上位机
seedOk 是否为 true
checkOk 是否为 true
groupCnt 是否等于 activeGroup
是否在结果锁定后才到达
```

如果确认是 check 计算问题，再修改 `dynamic_protocol.cpp` 中 value 的有符号/无符号解析。
