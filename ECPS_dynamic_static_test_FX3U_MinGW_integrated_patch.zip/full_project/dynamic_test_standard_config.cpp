#include "dynamic_test_standard_config.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QSettings>

bool DynamicTestStandardConfig::loadDynamicItems(const QString &iniFilePath,
                                                 QVector<DynamicTestItemMeta> *items,
                                                 QString *errorMessage)
{
    if (!items) {
        setError(errorMessage, "items 指针为空。");
        return false;
    }

    items->clear();

    const QString filePath = iniFilePath.trimmed().isEmpty()
            ? defaultIniFilePath()
            : iniFilePath;

    if (!QFileInfo::exists(filePath)) {
        setError(errorMessage, QString("动态标准 INI 文件不存在：%1").arg(filePath));
        return false;
    }

    QSettings settings(filePath, QSettings::IniFormat);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    settings.setIniCodec("UTF-8");
#endif

    settings.beginGroup("Dynamic");
    const int itemCount = settings.value("itemCount", 0).toInt();
    settings.endGroup();

    if (itemCount <= 0) {
        setError(errorMessage, "Dynamic/itemCount 无效或未配置。");
        return false;
    }

    QVector<DynamicTestItemMeta> loadedItems;

    for (int i = 1; i <= itemCount; ++i) {
        DynamicTestItemMeta item;
        QString error;

        if (!readOneItem(settings, i, &item, &error)) {
            setError(errorMessage,
                     QString("读取 DynamicItem%1 失败：%2").arg(i).arg(error));
            return false;
        }

        loadedItems.append(item);
    }

    if (loadedItems.isEmpty()) {
        setError(errorMessage, "未读取到任何动态检测项。");
        return false;
    }

    *items = loadedItems;
    return true;
}

QString DynamicTestStandardConfig::defaultIniFilePath()
{
    return QDir(QCoreApplication::applicationDirPath())
            .filePath("config/test_standard.ini");
}

bool DynamicTestStandardConfig::readOneItem(QSettings &settings,
                                            int index,
                                            DynamicTestItemMeta *item,
                                            QString *errorMessage)
{
    if (!item) {
        setError(errorMessage, "item 指针为空。");
        return false;
    }

    const QString groupName = QString("DynamicItem%1").arg(index);

    settings.beginGroup(groupName);

    item->itemNo = settings.value("itemNo", index).toInt();

    item->itemName = settings.value("itemName").toString().trimmed();
    item->standardText = settings.value("standardText").toString().trimmed();
    item->unit = settings.value("unit", "-").toString().trimmed();

    item->flagSeq = settings.value("flagSeq", -1).toInt();
    item->valueSeq = settings.value("valueSeq", -1).toInt();

    item->scale = settings.value("scale", 1.0).toDouble();

    item->affectsProductPass = settings.value("affectsProductPass", true).toBool();

    item->isProgressItem = settings.value("isProgressItem", false).toBool();
    item->progressFinishedValue = settings.value("progressFinishedValue", 100).toInt();

    settings.endGroup();

    if (item->itemNo <= 0) {
        setError(errorMessage, "itemNo 必须大于 0。");
        return false;
    }

    if (item->itemName.isEmpty()) {
        setError(errorMessage, "itemName 为空。");
        return false;
    }

    /*
     * 进度项当前使用 flagSeq=3，也就是 DetectInProgressFlag。
     * 普通检测项也必须有 flagSeq，因为 PASS/NG 由检测板返回 flag 决定。
     */
    if (item->flagSeq < 1 || item->flagSeq > 31) {
        setError(errorMessage, "flagSeq 必须在 1~31 之间。");
        return false;
    }

    /*
     * valueSeq=-1 表示该项没有具体检测值，只显示 flag。
     * 有检测值时，对应协议中的 seq 32~60。
     */
    if (item->valueSeq != -1 && (item->valueSeq < 32 || item->valueSeq > 60)) {
        setError(errorMessage, "valueSeq 必须为 -1 或 32~60。");
        return false;
    }

    if (item->scale == 0.0) {
        setError(errorMessage, "scale 不能为 0。");
        return false;
    }

    if (item->standardText.isEmpty()) {
        item->standardText = "按检测板内部标准判定；flag=0合格，1=不合格";
    }

    if (item->unit.isEmpty()) {
        item->unit = "-";
    }

    return true;
}

void DynamicTestStandardConfig::setError(QString *errorMessage,
                                         const QString &message)
{
    if (errorMessage) {
        *errorMessage = message;
    }
}
