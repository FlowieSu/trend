#ifndef STATIC_TEST_STANDARD_CONFIG_H
#define STATIC_TEST_STANDARD_CONFIG_H

#include <QString>
#include <QVector>

/*
 * StaticTestStandardConfig
 *
 * 只负责读取阻容测试标准 INI。
 *
 * 设计目的：
 *   1. 不改 TestRunner 的执行流程；
 *   2. 不改红黑/黑红共用同一个合格范围的判定逻辑；
 *   3. 只把 TestRunner::initTestItems() 中写死的标准外置。
 *
 * 注意：
 *   这里没有直接使用 TestRunner::LogicalTestItem，
 *   因为 LogicalTestItem 是 TestRunner 的 private 内部结构。
 *   Loader 先输出 StaticStandardItem，TestRunner 再转换成自己的内部结构。
 */
struct StaticStandardItem
{
    QString name;

    double resistanceMinKOhm = 0.0;
    double resistanceMaxKOhm = 0.0;

    double capacitanceMinNf = 0.0;
    double capacitanceMaxNf = 0.0;

    QString standardText;

    QVector<int> redBlackMPoints;
    QVector<int> blackRedMPoints;

    bool hasBlackRed = true;
};

class StaticTestStandardConfig
{
public:
    static bool loadStaticItems(const QString &iniFilePath,
                                QVector<StaticStandardItem> *items,
                                QString *errorMessage = nullptr);

    /*
     * 默认路径：
     *   程序目录/config/test_standard.ini
     */
    static QString defaultIniFilePath();

private:
    static QVector<int> parseMPoints(const QString &text,
                                     bool *ok = nullptr);

    static bool readOneItem(class QSettings &settings,
                            int index,
                            StaticStandardItem *item,
                            QString *errorMessage);

    static void setError(QString *errorMessage,
                         const QString &message);
};

#endif // STATIC_TEST_STANDARD_CONFIG_H
