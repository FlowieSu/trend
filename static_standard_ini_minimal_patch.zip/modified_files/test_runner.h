#ifndef TEST_RUNNER_H
#define TEST_RUNNER_H

#include <QObject>
#include <QList>
#include <QVector>
#include <QString>
#include <QMetaType>
#include <atomic>

#include "static_test_standard_config.h"

class MitsubishiPLC;
class SCPIController;

/*
 * TestRunner
 *
 * 自动化阻容测试执行器。
 *
 * 职责：
 * 1. 只负责阻容静态测试，不涉及动态测试、CANFD、Y26/Y27；
 * 2. 按位置1/位置2依次测试；
 * 3. 每个测试项内部执行红黑、黑红两个方向；
 * 4. 每个方向均测电阻和电容；
 * 5. 测试结果通过信号返回给 MainWindow，由 MainWindow 统一保存 CSV；
 * 6. 中断时及时退出，并发出 allStaticTestsFinished。
 *
 * 点位约定：
 * M19  ：阻容测试总使能
 * M20  ：测试位置选择，OFF=位置1，ON=位置2
 * M100 ：阻容测试通道复位脉冲
 *
 * Y26/Y27 由 MainWindow 在进入/退出阻容或动态流程时统一控制。
 */

struct StaticTestResult
{
    QString productCode;
    int position = 0;

    QString testName;
    QString directionName;
    QString mPointsText;
    QString standardText;

    double resistanceKOhm = -1.0;
    double capacitanceNf = -1.0;

    bool resistancePass = false;
    bool capacitancePass = false;
    bool pass = false;

    QString message;
    QString timestamp;
};

Q_DECLARE_METATYPE(StaticTestResult)

class TestRunner : public QObject
{
    Q_OBJECT

public:
    explicit TestRunner(MitsubishiPLC *plc,
                        SCPIController *dmm,
                        QObject *parent = nullptr);

public slots:
    /*
     * 旧接口兼容：
     * 执行单个位置的阻容测试，不绑定产品编码。
     */
    void runStaticTests(int position,
                        QList<int> selectedIndices);

    /*
     * 新接口：
     * 执行单个位置的阻容测试，结果绑定 productCode。
     */
    void runStaticTestsForProduct(int position,
                                  const QString &productCode,
                                  QList<int> selectedIndices);

    /*
     * 自动化主流程推荐接口：
     * 依次执行位置1、位置2阻容测试，结果分别绑定产品编码。
     */
    void runStaticTestsForTwoProducts(const QString &productCode1,
                                      const QString &productCode2,
                                      QList<int> selectedIndices);

    void requestInterrupt();

signals:
    void logMessage(const QString &message);

    void testStarted(const QString &testName);

    /*
     * 兼容当前 MainWindow::onTestResult(...) 的 9 参数接口。
     * 每个逻辑测试项发一次：
     * - forward = 红黑
     * - reverse = 黑红
     *
     * 注意：这个信号不包含 productCode。如需保存产品编码，优先使用
     * staticTestResultReady(result)。
     */
    void testCompleted(const QString &testName,
                       int position,
                       const QString &standardText,
                       double forwardResistanceKOhm,
                       double reverseResistanceKOhm,
                       double forwardCapacitanceNf,
                       double reverseCapacitanceNf,
                       bool pass,
                       const QString &message);

    /*
     * 新结果信号：
     * 每个方向发一次，包含产品编码、方向、M点、电阻、电容、PASS/NG。
     * MainWindow / CsvExporter 建议使用这个信号保存阻容 CSV。
     */
    void staticTestResultReady(const StaticTestResult &result);

    void allStaticTestsFinished(bool interrupted, bool hasFailed);

private:
    struct TestStandard
    {
        double resistanceMinKOhm = 0.0;
        double resistanceMaxKOhm = 0.0;
        double capacitanceMinNf = 0.0;
        double capacitanceMaxNf = 0.0;
        QString text;
    };

    struct DirectionConfig
    {
        QString name;
        QVector<int> mPoints;
    };

    struct LogicalTestItem
    {
        QString name;
        TestStandard standard;
        DirectionConfig redBlack;
        DirectionConfig blackRed;
        bool hasBlackRed = true;
    };

    struct DirectionMeasureResult
    {
        bool measureOk = false;

        double resistanceKOhm = -1.0;
        double capacitanceNf = -1.0;

        bool resistancePass = false;
        bool capacitancePass = false;
        bool pass = false;

        QString message;
    };

private:
    /*
     * 修改点1：
     * initTestItems() 现在优先读取 config/test_standard.ini。
     * 读取失败时，回退到 initDefaultTestItems() 里的原始写死标准。
     */
    void initTestItems();

    /*
     * 修改点2：
     * 原 initTestItems() 里的写死测试项整体移动到这里，作为兜底。
     */
    void initDefaultTestItems();

    /*
     * 修改点3：
     * 把外部 INI 读取到的 StaticStandardItem 转换为 TestRunner 内部 LogicalTestItem。
     */
    void appendConfigItem(const StaticStandardItem &configItem);

    bool runOneProduct(int position,
                       const QString &productCode,
                       const QList<int> &selectedIndices,
                       bool &hasFailed);

    bool executeOneLogicalItem(int position,
                               const QString &productCode,
                               const LogicalTestItem &item,
                               bool &hasFailed);

    DirectionMeasureResult executeDirection(int position,
                                            const QString &productCode,
                                            const LogicalTestItem &item,
                                            const DirectionConfig &direction);

    bool prepareDirection(int position,
                          const DirectionConfig &direction,
                          QString *errorMessage = nullptr);

    bool resetStaticChannels(QString *errorMessage = nullptr);

    bool measureResistance(double &resistanceKOhm,
                           QString &errorMessage);

    bool measureCapacitance(double &capacitanceNf,
                            QString &errorMessage);

    bool isValueInRange(double value,
                        double minValue,
                        double maxValue) const;

    bool sleepWithInterruptCheck(int totalMs);

    bool checkInterrupted() const;

    QList<int> normalizeIndices(const QList<int> &selectedIndices) const;

    QString positionText(int position) const;
    QString mPointsText(const QVector<int> &mPoints) const;
    QString passText(bool pass) const;
    QString timestampNow() const;

    void emitDirectionResult(const QString &productCode,
                             int position,
                             const LogicalTestItem &item,
                             const DirectionConfig &direction,
                             const DirectionMeasureResult &result);

private:
    MitsubishiPLC *m_plc = nullptr;
    SCPIController *m_dmm = nullptr;

    QVector<LogicalTestItem> m_testItems;

    std::atomic_bool m_interrupted { false };
};

#endif // TEST_RUNNER_H
