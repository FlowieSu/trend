# 完整自动化结果格式 + 每日统计编码/重启恢复修复补丁

基于上一版 `full_auto_result_csv_patch` 生成。

## 解决的问题

### 1. 自动化测试完整结果 CSV 的阻容列格式不对

原来是：

```text
阻容测试项1, 阻容测试标准1
```

且测试项列里混了 M 点、值、结果等信息。

现在改成：

```text
阻容测试项1, 阻容测试标准1, 电阻测试值1, 电容测试值1
```

示例：

```text
sin+->sin-, INI里的standardText, 300 kΩ, 6 nF
```

### 2. 自动化测试完整结果 CSV 的动态列格式不对

原来是：

```text
动态测试项1, 动态测试标准1
```

现在改成：

```text
动态测试项1, 动态测试标准1, 动态测试值1
```

动态测试标准来自：

```cpp
DynamicItemResult::standardText
```

该字段来自 INI 中的 `standardText`。

### 3. 每日测试结果 sheet 名和列名乱码

`DailyTestStatistics::save()` 已改为：

```cpp
out.setCodec("UTF-8");
out.setGenerateByteOrderMark(true);
```

也就是 UTF-8 + BOM，Excel/WPS 打开时更稳定。

### 4. 重启上位机后每日统计清零

新增程序专用缓存文件：

```text
D:/电涡流测试结果/yyyy年MM月/yyyyMMdd测试结果_cache.csv
```

这个文件用于程序启动时恢复 `m_records`，不按这个文件给人看。

启动逻辑：

```text
优先读取 cache.csv
cache 不存在时，再兼容读取 xls 的 当日测试产品信息 sheet
```

保存逻辑：

```text
保存每日 xls
同步保存 cache.csv
```

这样重启上位机后，主界面的每日统计不会因为内存清空而置零。

## 修改文件

```text
modified_files/mainwindow.cpp
modified_files/mainwindow.h
modified_files/mainwindow.ui
modified_files/daily_test_statistics.h
modified_files/daily_test_statistics.cpp
```

## 使用方式

1. 用 `modified_files` 覆盖工程同名文件；
2. 重新运行 qmake；
3. 清理项目；
4. 重新构建。

注意：如果你当天已经生成过乱码的 `yyyyMMdd测试结果.xls`，建议先关闭 Excel/WPS，然后运行一次新的自动化测试，让程序重新保存一次 xls 和 cache 文件。
