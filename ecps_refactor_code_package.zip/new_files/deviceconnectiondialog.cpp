#include "deviceconnectiondialog.h"
#include "ui_deviceconnectiondialog.h"

#include <QMessageBox>
#include <QSettings>

DeviceConnectionDialog::DeviceConnectionDialog(QWidget *parent)
    : QDialog(parent),
      ui(new Ui::DeviceConnectionDialog)
{
    ui->setupUi(this);
    initUi();
    loadFromSettings();

    connect(ui->btnRefreshPorts,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onRefreshPortsClicked);

    connect(ui->btnConnect,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::onConnectClicked);

    connect(ui->btnClose,
            &QPushButton::clicked,
            this,
            &DeviceConnectionDialog::close);
}

DeviceConnectionDialog::~DeviceConnectionDialog()
{
    delete ui;
}

void DeviceConnectionDialog::initUi()
{
    setWindowTitle("设备连接");

    ui->lblPlcStatus->setText("PLC：未连接");
    ui->lblDmmStatus->setText("万用表/电桥：未连接");
    ui->lblCanStatus->setText("动态模块：未连接");

    ui->editVisaAddress->setPlaceholderText("例如：USB0::0x2A8D::0x0101::MYxxxx::INSTR");

    /*
     * CAN 参数页先作为配置展示区。
     * 如果你当前 CANFD 连接函数参数是写死的，不要在这里改底层连接逻辑。
     */
    ui->cmbCanDeviceType->clear();
    ui->cmbCanDeviceType->addItem("USBCANFD-200U");
    ui->cmbCanDeviceType->addItem("USBCAN-II+");

    ui->spinCanDeviceIndex->setRange(0, 16);
    ui->spinCanChannelIndex->setRange(0, 8);
    ui->spinCanBaudRate->setRange(10000, 1000000);
    ui->spinCanBaudRate->setValue(500000);
    ui->spinCanFdAbit->setRange(10000, 1000000);
    ui->spinCanFdAbit->setValue(500000);
    ui->spinCanFdDbit->setRange(10000, 8000000);
    ui->spinCanFdDbit->setValue(2000000);
}

QString DeviceConnectionDialog::plcPortName() const
{
    return ui->cmbPlcPort->currentText().trimmed();
}

QString DeviceConnectionDialog::visaAddress() const
{
    return ui->editVisaAddress->text().trimmed();
}

void DeviceConnectionDialog::setPlcStatusText(const QString &text)
{
    ui->lblPlcStatus->setText(text);
}

void DeviceConnectionDialog::setDmmStatusText(const QString &text)
{
    ui->lblDmmStatus->setText(text);
}

void DeviceConnectionDialog::setCanStatusText(const QString &text)
{
    ui->lblCanStatus->setText(text);
}

void DeviceConnectionDialog::setAvailablePlcPorts(const QStringList &ports)
{
    const QString current = ui->cmbPlcPort->currentText();

    ui->cmbPlcPort->clear();

    if (ports.isEmpty()) {
        ui->cmbPlcPort->addItem("未发现串口");
        return;
    }

    ui->cmbPlcPort->addItems(ports);

    const int index = ui->cmbPlcPort->findText(current);
    if (index >= 0) {
        ui->cmbPlcPort->setCurrentIndex(index);
    }
}

void DeviceConnectionDialog::onRefreshPortsClicked()
{
    emit refreshPlcPortsRequested();
}

void DeviceConnectionDialog::onConnectClicked()
{
    const QString port = plcPortName();
    const QString visa = visaAddress();

    if (port.isEmpty() || port == "未发现串口") {
        QMessageBox::warning(this, "提示", "请选择正确的 PLC 串口。");
        return;
    }

    if (visa.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入万用表/电桥 VISA 地址。");
        return;
    }

    saveToSettings();
    emit connectDevicesRequested(port, visa);
}

void DeviceConnectionDialog::loadFromSettings()
{
    QSettings settings("ECPS", "StaticDynamicTester");

    ui->editVisaAddress->setText(settings.value("device/visaAddress", "").toString());

    const QString lastPort = settings.value("device/plcPort", "").toString();
    if (!lastPort.isEmpty() && ui->cmbPlcPort->findText(lastPort) < 0) {
        ui->cmbPlcPort->addItem(lastPort);
    }

    const int index = ui->cmbPlcPort->findText(lastPort);
    if (index >= 0) {
        ui->cmbPlcPort->setCurrentIndex(index);
    }
}

void DeviceConnectionDialog::saveToSettings() const
{
    QSettings settings("ECPS", "StaticDynamicTester");
    settings.setValue("device/plcPort", plcPortName());
    settings.setValue("device/visaAddress", visaAddress());
}
