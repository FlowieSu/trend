#ifndef DEVICECONNECTIONDIALOG_H
#define DEVICECONNECTIONDIALOG_H

#include <QDialog>
#include <QString>

/*
 * 设备连接窗口
 *
 * 菜单入口：
 *   调试 -> 设备连接
 *
 * 设计原则：
 *   - 不修改现有 PLC / 万用表 / CAN 连接实现；
 *   - 本窗口只收集参数并发出信号；
 *   - MainWindow 收到信号后调用当前已经能跑的连接函数。
 *
 * 当前项目实际：
 *   PLC：只需要 COM 口，其它参数在 PLC 类里写死；
 *   万用表：只需要 VISA 地址；
 *   CAN：当前旧 CANFD 工作线程如果参数写死，可先只显示配置，不改变原连接函数。
 */

namespace Ui {
class DeviceConnectionDialog;
}

class DeviceConnectionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DeviceConnectionDialog(QWidget *parent = nullptr);
    ~DeviceConnectionDialog() override;

    QString plcPortName() const;
    QString visaAddress() const;

    void setPlcStatusText(const QString &text);
    void setDmmStatusText(const QString &text);
    void setCanStatusText(const QString &text);

signals:
    void refreshPlcPortsRequested();
    void connectDevicesRequested(QString plcPortName,
                                 QString visaAddress);

private slots:
    void onRefreshPortsClicked();
    void onConnectClicked();

public slots:
    void setAvailablePlcPorts(const QStringList &ports);

private:
    void initUi();
    void loadFromSettings();
    void saveToSettings() const;

private:
    Ui::DeviceConnectionDialog *ui = nullptr;
};

#endif // DEVICECONNECTIONDIALOG_H
