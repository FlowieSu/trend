#ifndef DYNAMICPARAMCONFIGDIALOG_H
#define DYNAMICPARAMCONFIGDIALOG_H

#include <QDialog>
#include <QString>

/*
 * 动态检测参数配置窗口
 *
 * 菜单入口：
 *   调试 -> 动态检测参数配置
 *
 * 当前只负责配置：
 *   1. 位置1发送报文：110/112/114/116
 *   2. 位置2发送报文：110/112/114/116
 *   3. 位置1 thresholdFlag
 *   4. 位置2 thresholdFlag
 *
 * 注意：
 *   - 110~116 的默认 thresholdFlag 均为 2。
 *   - 本窗口不启动动态测试，不操作 CAN。
 */

namespace Ui {
class DynamicParamConfigDialog;
}

struct DynamicParamConfig
{
    QString position1TxId = "00000110";
    QString position2TxId = "00000112";

    int position1ThresholdFlag = 2;
    int position2ThresholdFlag = 2;
};

class DynamicParamConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DynamicParamConfigDialog(QWidget *parent = nullptr);
    ~DynamicParamConfigDialog() override;

    DynamicParamConfig config() const;
    void setConfig(const DynamicParamConfig &config);

signals:
    void configApplied(DynamicParamConfig config);

private slots:
    void onApplyClicked();
    void onOkClicked();

private:
    void initUi();
    void loadFromSettings();
    void saveToSettings() const;

    QString currentTxId1() const;
    QString currentTxId2() const;

    void setComboByTxId(class QComboBox *combo, const QString &txId);

private:
    Ui::DynamicParamConfigDialog *ui = nullptr;
};

#endif // DYNAMICPARAMCONFIGDIALOG_H
