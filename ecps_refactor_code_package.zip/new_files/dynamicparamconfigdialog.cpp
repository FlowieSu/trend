#include "dynamicparamconfigdialog.h"
#include "ui_dynamicparamconfigdialog.h"

#include <QComboBox>
#include <QMessageBox>
#include <QSettings>

DynamicParamConfigDialog::DynamicParamConfigDialog(QWidget *parent)
    : QDialog(parent),
      ui(new Ui::DynamicParamConfigDialog)
{
    ui->setupUi(this);
    initUi();
    loadFromSettings();

    connect(ui->btnApply,
            &QPushButton::clicked,
            this,
            &DynamicParamConfigDialog::onApplyClicked);

    connect(ui->btnOk,
            &QPushButton::clicked,
            this,
            &DynamicParamConfigDialog::onOkClicked);

    connect(ui->btnCancel,
            &QPushButton::clicked,
            this,
            &DynamicParamConfigDialog::reject);
}

DynamicParamConfigDialog::~DynamicParamConfigDialog()
{
    delete ui;
}

void DynamicParamConfigDialog::initUi()
{
    auto initCombo = [](QComboBox *combo) {
        combo->clear();
        combo->addItem("发送 110，接收 201", "00000110");
        combo->addItem("发送 112，接收 301", "00000112");
        combo->addItem("发送 114，接收 401", "00000114");
        combo->addItem("发送 116，接收 501", "00000116");
    };

    initCombo(ui->cmbPosition1TxId);
    initCombo(ui->cmbPosition2TxId);

    ui->cmbPosition1TxId->setCurrentIndex(0);
    ui->cmbPosition2TxId->setCurrentIndex(1);

    ui->spinPosition1ThresholdFlag->setRange(0, 65535);
    ui->spinPosition2ThresholdFlag->setRange(0, 65535);

    /*
     * 按最新要求，110~116 默认 thresholdFlag 均为 2。
     */
    ui->spinPosition1ThresholdFlag->setValue(2);
    ui->spinPosition2ThresholdFlag->setValue(2);
}

DynamicParamConfig DynamicParamConfigDialog::config() const
{
    DynamicParamConfig c;
    c.position1TxId = currentTxId1();
    c.position2TxId = currentTxId2();
    c.position1ThresholdFlag = ui->spinPosition1ThresholdFlag->value();
    c.position2ThresholdFlag = ui->spinPosition2ThresholdFlag->value();
    return c;
}

void DynamicParamConfigDialog::setConfig(const DynamicParamConfig &config)
{
    setComboByTxId(ui->cmbPosition1TxId, config.position1TxId);
    setComboByTxId(ui->cmbPosition2TxId, config.position2TxId);

    ui->spinPosition1ThresholdFlag->setValue(config.position1ThresholdFlag);
    ui->spinPosition2ThresholdFlag->setValue(config.position2ThresholdFlag);
}

void DynamicParamConfigDialog::onApplyClicked()
{
    const DynamicParamConfig c = config();

    if (c.position1TxId == c.position2TxId) {
        QMessageBox::warning(this, "提示", "位置1和位置2不能选择同一个发送报文。");
        return;
    }

    saveToSettings();
    emit configApplied(c);
}

void DynamicParamConfigDialog::onOkClicked()
{
    onApplyClicked();

    if (currentTxId1() != currentTxId2()) {
        accept();
    }
}

void DynamicParamConfigDialog::loadFromSettings()
{
    QSettings settings("ECPS", "StaticDynamicTester");

    DynamicParamConfig c;
    c.position1TxId = settings.value("dynamic/position1TxId", "00000110").toString();
    c.position2TxId = settings.value("dynamic/position2TxId", "00000112").toString();
    c.position1ThresholdFlag = settings.value("dynamic/position1ThresholdFlag", 2).toInt();
    c.position2ThresholdFlag = settings.value("dynamic/position2ThresholdFlag", 2).toInt();

    setConfig(c);
}

void DynamicParamConfigDialog::saveToSettings() const
{
    const DynamicParamConfig c = config();

    QSettings settings("ECPS", "StaticDynamicTester");
    settings.setValue("dynamic/position1TxId", c.position1TxId);
    settings.setValue("dynamic/position2TxId", c.position2TxId);
    settings.setValue("dynamic/position1ThresholdFlag", c.position1ThresholdFlag);
    settings.setValue("dynamic/position2ThresholdFlag", c.position2ThresholdFlag);
}

QString DynamicParamConfigDialog::currentTxId1() const
{
    return ui->cmbPosition1TxId->currentData().toString();
}

QString DynamicParamConfigDialog::currentTxId2() const
{
    return ui->cmbPosition2TxId->currentData().toString();
}

void DynamicParamConfigDialog::setComboByTxId(QComboBox *combo,
                                              const QString &txId)
{
    const int index = combo->findData(txId);
    if (index >= 0) {
        combo->setCurrentIndex(index);
    }
}
