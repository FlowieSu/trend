#ifndef CSV_EXPORTER_H
#define CSV_EXPORTER_H

#include <QString>
#include <QVector>

#include <memory>

#include "test_runner.h"

class AllInfo;

/*
 * CsvExporter
 *
 * 继续使用现有 CsvExporter，不新增 AutoResultSaver / StaticCsvExporter。
 *
 * 新增能力：
 * 1. 阻容结果按产品条码、按位置单独自动保存；
 * 2. 动态结果按产品条码、按位置单独自动保存；
 * 3. 自动保存使用 GBK 编码；
 * 4. 文件存在时追加记录，不覆盖，不重复写表头；
 * 5. 文件不存在时创建目录、创建文件并写表头。
 */

struct CsvDynamicResult
{
    int productId = 0;                 // 1=位置1，2=位置2
    QString productCode;
    bool pass = false;
    std::shared_ptr<AllInfo> allInfo;
    QString timestamp;
    QString message;
};

struct CsvDynamicDisplayRow
{
    QString testTime;
    QString finishTime;
    QString positionText;
    QString productCode;
    QString channelText;
    QString progressText;
    int itemNo = 0;
    QString itemName;
    QString rawValue;
    QString unit;
    bool pass = false;
};

class CsvExporter
{
public:
    /*
     * 原导出接口保留，避免影响旧调用。
     */
    static bool exportStaticResults(const QVector<StaticTestResult> &results,
                                    const QString &filePath,
                                    QString *errorMessage = nullptr);

    static bool exportDynamicResults(const QVector<CsvDynamicResult> &results,
                                     const QString &filePath,
                                     QString *errorMessage = nullptr);

    /*
     * 新增：阻容自动保存。
     * 只保存指定 position 的结果。
     * 路径：
     *   D:/阻容测试结果/yyyy年MM月/条码_阻容测试_yyyyMMdd.csv
     */
    static bool autoSaveStaticResultsForPosition(const QVector<StaticTestResult> &allResults,
                                                 int position,
                                                 const QString &productCode,
                                                 QString *savedFilePath = nullptr,
                                                 QString *errorMessage = nullptr);

    /*
     * 新增：动态自动保存。
     * 路径：
     *   D:/动态测试结果/yyyy年MM月/条码_动态测试_yyyyMMdd.csv
     */
    static bool autoSaveDynamicResultForProduct(const CsvDynamicResult &result,
                                                QString *savedFilePath = nullptr,
                                                QString *errorMessage = nullptr);

    /*
     * 给主界面动态显示表使用。
     * 输出字段对应界面表头：
     *   位置 / 产品编码 / 通道 / 检测进度 / 检测项编号 / 检测项名称 / 检测值 / 单位 / 结果
     */
    static QVector<CsvDynamicDisplayRow> buildDynamicDisplayRows(const CsvDynamicResult &result);

    static QString defaultResultDir();

    static QString buildStaticFileName(const QString &productCode1,
                                       const QString &productCode2);

    static QString buildDynamicFileName(const QString &productCode1,
                                        const QString &productCode2);

    static QString quoteCsvField(const QString &text);
    static QString formatValue(double value, int precision = 6);
    static QString passText(bool pass);
    static QString positionText(int position);
    static QString timestampNow();

private:
    static QString monthlyDir(const QString &rootDir);
    static QString autoFilePath(const QString &rootDir,
                                const QString &productCode,
                                const QString &testType);

    static bool ensureParentDir(const QString &filePath,
                                QString *errorMessage);

    static bool appendTextFileGbk(const QString &filePath,
                                  const QString &headerLine,
                                  const QStringList &recordLines,
                                  QString *errorMessage);

    static void setError(QString *errorMessage,
                         const QString &message);
};

#endif // CSV_EXPORTER_H
