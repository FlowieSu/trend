/*
 * mainwindow.cpp 增量修改片段
 *
 * 原则：
 *   1. 不改当前能跑的 PLC / 万用表 / CAN 连接函数内部逻辑；
 *   2. 不改自动测试整体顺序；
 *   3. 只把按钮入口迁移到菜单弹窗；
 *   4. 在阻容完成、动态完成节点追加自动保存、进度条和醒目 PASS/NG 显示。
 */

#include "deviceconnectiondialog.h"
#include "dynamicparamconfigdialog.h"
#include "logwindow.h"
#include "csv_exporter.h"

#include <QMenuBar>
#include <QSettings>
#include <QSerialPortInfo>

/* 构造函数中，在 initUi(); 后增加 */
initDebugMenu();
initProductionUiState();

m_testDurationTimer = new QTimer(this);
connect(m_testDurationTimer,
        &QTimer::timeout,
        this,
        &MainWindow::updateTestDuration);

/* initConnections() 中增加条码焦点逻辑 */
connect(ui->editProductCode1,
        &QLineEdit::textChanged,
        this,
        &MainWindow::onBarcode1Changed);

/* initDebugMenu() 新增 */
void MainWindow::initDebugMenu()
{
    QMenu *debugMenu = menuBar()->addMenu("调试");

    QAction *actDeviceConnection = debugMenu->addAction("设备连接");
    QAction *actDynamicParamConfig = debugMenu->addAction("动态检测参数配置");
    debugMenu->addSeparator();
    QAction *actManualDynamicTest = debugMenu->addAction("手动动态测试");
    QAction *actManualStaticTest = debugMenu->addAction("手动阻容测试");
    QAction *actPlcPointTest = debugMenu->addAction("PLC点位测试");
    debugMenu->addSeparator();
    QAction *actLogWindow = debugMenu->addAction("日志输出窗口");

    connect(actDeviceConnection,
            &QAction::triggered,
            this,
            &MainWindow::onActionDeviceConnectionTriggered);

    connect(actDynamicParamConfig,
            &QAction::triggered,
            this,
            &MainWindow::onActionDynamicParamConfigTriggered);

    connect(actManualDynamicTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionManualDynamicTestTriggered);

    connect(actManualStaticTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionManualStaticTestTriggered);

    connect(actPlcPointTest,
            &QAction::triggered,
            this,
            &MainWindow::onActionPlcPointTestTriggered);

    connect(actLogWindow,
            &QAction::triggered,
            this,
            &MainWindow::onActionLogWindowTriggered);
}

/* initProductionUiState() 新增 */
void MainWindow::initProductionUiState()
{
    ui->editProductCode1->setMaxLength(18);
    ui->editProductCode2->setMaxLength(18);
    ui->editProductCode1->setFocus();

    ui->progressTest->setRange(0, 100);
    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：待机");

    QSettings settings("ECPS", "StaticDynamicTester");
    m_connectorPlugCount = settings.value("runtime/connectorPlugCount", 0).toInt();
    ui->lblConnectorPlugCount->setText(QString("接插件插拔次数：%1").arg(m_connectorPlugCount));
    ui->lblTestDuration->setText("测试时长：00:00:00");

    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");

    ui->btnEmergencyStop->setStyleSheet(
        "QPushButton {"
        "background-color:#D32F2F;"
        "color:white;"
        "font-weight:bold;"
        "font-size:18px;"
        "border-radius:6px;"
        "padding:8px 16px;"
        "}"
        "QPushButton:pressed { background-color:#B71C1C; }"
    );
}

void MainWindow::onBarcode1Changed(const QString &text)
{
    if (text.length() == 18) {
        ui->editProductCode2->setFocus();
        ui->editProductCode2->selectAll();
    }
}

/* 设备连接菜单 */
void MainWindow::onActionDeviceConnectionTriggered()
{
    if (!m_deviceConnectionDialog) {
        m_deviceConnectionDialog = new DeviceConnectionDialog(this);
        m_deviceConnectionDialog->setAttribute(Qt::WA_DeleteOnClose);

        connect(m_deviceConnectionDialog,
                &QObject::destroyed,
                this,
                [this]() {
                    m_deviceConnectionDialog = nullptr;
                });

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::refreshPlcPortsRequested,
                this,
                [this]() {
                    QStringList ports;
                    for (const QSerialPortInfo &port : QSerialPortInfo::availablePorts()) {
                        ports << port.portName();
                    }

                    if (m_deviceConnectionDialog) {
                        m_deviceConnectionDialog->setAvailablePlcPorts(ports);
                    }
                });

        connect(m_deviceConnectionDialog,
                &DeviceConnectionDialog::connectDevicesRequested,
                this,
                &MainWindow::onDeviceDialogConnectRequested);
    }

    QStringList ports;
    for (const QSerialPortInfo &port : QSerialPortInfo::availablePorts()) {
        ports << port.portName();
    }
    m_deviceConnectionDialog->setAvailablePlcPorts(ports);

    m_deviceConnectionDialog->show();
    m_deviceConnectionDialog->raise();
    m_deviceConnectionDialog->activateWindow();
}

void MainWindow::onDeviceDialogConnectRequested(QString plcPortName,
                                                QString visaAddress)
{
    connectDevicesByParams(plcPortName, visaAddress);

    if (m_deviceConnectionDialog) {
        m_deviceConnectionDialog->setPlcStatusText(ui->lblPLCStatus->text());
        m_deviceConnectionDialog->setDmmStatusText(ui->lblDMMStatus->text());
        m_deviceConnectionDialog->setCanStatusText(ui->lblCanStatus->text());
    }
}

/*
 * 把你当前 onConnectDevices() 内部代码原样搬到这里，只把：
 *   ui->cmbPlcPort->currentText()
 *   ui->editVisaAddress->text()
 * 替换为入参 portName / visaAddress。
 *
 * 这样设备连接逻辑不变，只是入口从主界面按钮变成弹窗。
 */
bool MainWindow::connectDevicesByParams(const QString &portName,
                                        const QString &visaAddress)
{
    if (portName.isEmpty() || portName == "未发现串口") {
        QMessageBox::warning(this, "提示", "请选择正确的PLC串口。");
        return false;
    }

    if (visaAddress.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入万用表/电桥 VISA 地址。");
        return false;
    }

    appendLog(QString("开始连接PLC：%1").arg(portName));

    if (!m_plc->connectDevice(portName)) {
        ui->lblPLCStatus->setText("PLC：连接失败");
        QMessageBox::critical(this, "PLC连接失败", m_plc->lastError());
        return false;
    }

    if (!m_plc->ping()) {
        ui->lblPLCStatus->setText("PLC：通信异常");
        QMessageBox::critical(this, "PLC通信异常", m_plc->lastError());
        return false;
    }

    ui->lblPLCStatus->setText("PLC：已连接");

    appendLog(QString("开始连接万用表/电桥：%1").arg(visaAddress));

    if (!m_dmm->connectInstrument(visaAddress)) {
        ui->lblDMMStatus->setText("万用表/电桥：连接失败");
        QMessageBox::critical(this, "万用表/电桥连接失败", m_dmm->lastError());
        return false;
    }

    if (!m_dmm->ping()) {
        ui->lblDMMStatus->setText("万用表/电桥：通信异常");
        QMessageBox::critical(this, "万用表/电桥通信异常", m_dmm->lastError());
        return false;
    }

    ui->lblDMMStatus->setText("万用表/电桥：已连接");

    if (m_dynamicController) {
        appendLog("启动动态 CANFD 控制器。");
        m_dynamicController->startCanWorker();
        ui->lblCanStatus->setText("动态模块：已启动");
    }

    appendLog("设备连接完成。");
    return true;
}

/* 动态检测参数配置 */
void MainWindow::onActionDynamicParamConfigTriggered()
{
    if (!m_dynamicParamConfigDialog) {
        m_dynamicParamConfigDialog = new DynamicParamConfigDialog(this);
        m_dynamicParamConfigDialog->setAttribute(Qt::WA_DeleteOnClose);
        m_dynamicParamConfigDialog->setConfig(m_dynamicParamConfig);

        connect(m_dynamicParamConfigDialog,
                &QObject::destroyed,
                this,
                [this]() {
                    m_dynamicParamConfigDialog = nullptr;
                });

        connect(m_dynamicParamConfigDialog,
                &DynamicParamConfigDialog::configApplied,
                this,
                [this](DynamicParamConfig config) {
                    m_dynamicParamConfig = config;
                    appendLog(QString("动态参数已应用：位置1=%1 threshold=%2；位置2=%3 threshold=%4。")
                              .arg(config.position1TxId)
                              .arg(config.position1ThresholdFlag)
                              .arg(config.position2TxId)
                              .arg(config.position2ThresholdFlag));
                });
    }

    m_dynamicParamConfigDialog->show();
    m_dynamicParamConfigDialog->raise();
    m_dynamicParamConfigDialog->activateWindow();
}

void MainWindow::onActionManualDynamicTestTriggered()
{
    if (!m_dynamicController) {
        QMessageBox::warning(this, "提示", "动态测试控制器未初始化。");
        return;
    }

    auto *window = new ManualDynamicTestWindow(m_dynamicController,
                                               m_dynamicParamConfig,
                                               ui->editProductCode1->text().trimmed(),
                                               ui->editProductCode2->text().trimmed(),
                                               nullptr);
    window->setAttribute(Qt::WA_DeleteOnClose);
    window->show();
}

void MainWindow::onActionManualStaticTestTriggered()
{
    onOpenManualStaticTestWindow();
}

void MainWindow::onActionPlcPointTestTriggered()
{
    onOpenPlcTestWindow();
}

void MainWindow::onActionLogWindowTriggered()
{
    if (!m_logWindow) {
        m_logWindow = new LogWindow(nullptr);
        m_logWindow->setAttribute(Qt::WA_DeleteOnClose);
        connect(m_logWindow, &QObject::destroyed, this, [this]() {
            m_logWindow = nullptr;
        });
    }

    m_logWindow->show();
    m_logWindow->raise();
    m_logWindow->activateWindow();
}

/*
 * appendLog() 修改：
 * 保留原有日志输出，如果主界面 textLog 已删除，可删掉 ui->textLog 这一句。
 */
void MainWindow::appendLog(const QString &message)
{
    const QString timeText = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");

    if (ui->textLog) {
        ui->textLog->append(QString("[%1] %2").arg(timeText, message));
    }

    if (m_logWindow) {
        m_logWindow->appendLog(message);
    }
}

/*
 * onStartAutoTest() 中，在检查通过、开始清空结果前增加：
 */
{
    ++m_connectorPlugCount;
    QSettings settings("ECPS", "StaticDynamicTester");
    settings.setValue("runtime/connectorPlugCount", m_connectorPlugCount);
    ui->lblConnectorPlugCount->setText(QString("接插件插拔次数：%1").arg(m_connectorPlugCount));

    ui->progressTest->setValue(0);
    ui->lblCurrentTestStage->setText("当前测试：阻容测试");
    resetOverallResultLabel(ui->lblStaticOverallResult, "阻容：-");
    resetOverallResultLabel(ui->lblDynamicOverallResult, "动态：-");

    startTestDurationTimer();
}

/*
 * validateProductCodes() 中增加 18 位校验：
 */
{
    if (m_productCode1.length() != 18) {
        QMessageBox::warning(this, "提示", "位置1条码必须为18位。");
        return false;
    }

    if (m_productCode2.length() != 18) {
        QMessageBox::warning(this, "提示", "位置2条码必须为18位。");
        return false;
    }
}

/*
 * onStaticTestResultReady() 末尾增加颜色：
 */
setRowResultColor(ui->tableStaticResults, row, result.pass);

/*
 * onStaticTestsFinished() 中，原 saveStaticCsv(filePath) 替换为：
 */
autoSaveStaticResults();
setOverallResultLabel(ui->lblStaticOverallResult, !hasFailed);
ui->progressTest->setValue(50);

/*
 * startDynamicAutoTest() 中，在 updateOverallStatus("自动化测试：动态测试中") 附近增加：
 */
ui->lblCurrentTestStage->setText("当前测试：动态测试");

/*
 * 启动动态时，把：
 *   m_dynamicController->startDynamicTest(m_productCode1, m_productCode2);
 * 替换为：
 */
m_dynamicController->startDynamicTestWithParams(m_productCode1,
                                                m_productCode2,
                                                m_dynamicParamConfig.position1TxId,
                                                m_dynamicParamConfig.position1ThresholdFlag,
                                                m_dynamicParamConfig.position2TxId,
                                                m_dynamicParamConfig.position2ThresholdFlag);

/*
 * onDynamicAllFinished() 中，原 saveDynamicCsv(filePath) 替换为：
 */
autoSaveDynamicResults();
setOverallResultLabel(ui->lblDynamicOverallResult, allPass);
ui->progressTest->setValue(100);
ui->lblCurrentTestStage->setText("当前测试：测试完成");
stopTestDurationTimer();

/*
 * addDynamicSummaryRow() 建议整段替换为：
 */
void MainWindow::addDynamicSummaryRow(int productId,
                                      bool pass,
                                      std::shared_ptr<AllInfo> allInfo)
{
    CsvDynamicResult result;
    result.productId = productId;
    result.productCode = (productId == 1) ? m_productCode1 : m_productCode2;
    result.pass = pass;
    result.allInfo = allInfo;
    result.timestamp = timestampNow();

    const QVector<CsvDynamicDisplayRow> rows =
            CsvExporter::buildDynamicDisplayRows(result);

    for (const CsvDynamicDisplayRow &r : rows) {
        const int row = ui->tableDynamicResults->rowCount();
        ui->tableDynamicResults->insertRow(row);

        ui->tableDynamicResults->setItem(row, 0, new QTableWidgetItem(r.positionText));
        ui->tableDynamicResults->setItem(row, 1, new QTableWidgetItem(r.productCode));
        ui->tableDynamicResults->setItem(row, 2, new QTableWidgetItem(r.channelText));
        ui->tableDynamicResults->setItem(row, 3, new QTableWidgetItem(r.progressText));
        ui->tableDynamicResults->setItem(row, 4, new QTableWidgetItem(QString::number(r.itemNo)));
        ui->tableDynamicResults->setItem(row, 5, new QTableWidgetItem(r.itemName));
        ui->tableDynamicResults->setItem(row, 6, new QTableWidgetItem(r.rawValue));
        ui->tableDynamicResults->setItem(row, 7, new QTableWidgetItem(r.unit));
        ui->tableDynamicResults->setItem(row, 8, new QTableWidgetItem(passText(r.pass)));

        setRowResultColor(ui->tableDynamicResults, row, r.pass);
    }

    ui->tableDynamicResults->scrollToBottom();
}

/* 新增自动保存函数 */
void MainWindow::autoSaveStaticResults()
{
    QString path;
    QString error;

    if (CsvExporter::autoSaveStaticResultsForPosition(m_staticResults, 1, m_productCode1, &path, &error)) {
        appendLog(QString("位置1阻容结果已自动保存：%1").arg(path));
    } else {
        appendLog(QString("位置1阻容结果自动保存失败：%1").arg(error));
    }

    if (CsvExporter::autoSaveStaticResultsForPosition(m_staticResults, 2, m_productCode2, &path, &error)) {
        appendLog(QString("位置2阻容结果已自动保存：%1").arg(path));
    } else {
        appendLog(QString("位置2阻容结果自动保存失败：%1").arg(error));
    }
}

void MainWindow::autoSaveDynamicResults()
{
    QString path;
    QString error;

    for (const DynamicResult &r : m_dynamicResults) {
        CsvDynamicResult csv;
        csv.productId = r.productId;
        csv.productCode = r.productCode;
        csv.pass = r.pass;
        csv.allInfo = r.allInfo;
        csv.timestamp = r.timestamp;
        csv.message = r.pass ? "OK" : "动态测试NG";

        if (CsvExporter::autoSaveDynamicResultForProduct(csv, &path, &error)) {
            appendLog(QString("位置%1动态结果已自动保存：%2").arg(r.productId).arg(path));
        } else {
            appendLog(QString("位置%1动态结果自动保存失败：%2").arg(r.productId).arg(error));
        }
    }
}

/* 新增显示工具函数 */
void MainWindow::setRowResultColor(QTableWidget *table, int row, bool pass)
{
    const QColor color = pass ? QColor(0, 128, 0) : QColor(200, 0, 0);

    for (int col = 0; col < table->columnCount(); ++col) {
        QTableWidgetItem *item = table->item(row, col);
        if (item) {
            item->setForeground(color);
        }
    }
}

void MainWindow::setOverallResultLabel(QLabel *label, bool pass)
{
    label->setText(pass ? "PASS" : "NG");
    label->setStyleSheet(pass
                         ? "background-color:#1B5E20;color:white;font-size:30px;font-weight:bold;padding:8px;"
                         : "background-color:#B71C1C;color:white;font-size:30px;font-weight:bold;padding:8px;");
}

void MainWindow::resetOverallResultLabel(QLabel *label, const QString &text)
{
    label->setText(text);
    label->setStyleSheet("background-color:#EEEEEE;color:#333333;font-size:24px;font-weight:bold;padding:8px;");
}

void MainWindow::startTestDurationTimer()
{
    ui->lblTestDuration->setText("测试时长：00:00:00");
    m_testElapsedTimer.restart();

    if (m_testDurationTimer) {
        m_testDurationTimer->start(1000);
    }
}

void MainWindow::stopTestDurationTimer()
{
    if (m_testDurationTimer) {
        m_testDurationTimer->stop();
    }
    updateTestDuration();
}

void MainWindow::updateTestDuration()
{
    const qint64 seconds = m_testElapsedTimer.elapsed() / 1000;
    ui->lblTestDuration->setText(QString("测试时长：%1").arg(formatDuration(seconds)));
}

QString MainWindow::formatDuration(qint64 seconds) const
{
    const qint64 h = seconds / 3600;
    const qint64 m = (seconds % 3600) / 60;
    const qint64 s = seconds % 60;

    return QString("%1:%2:%3")
            .arg(h, 2, 10, QLatin1Char('0'))
            .arg(m, 2, 10, QLatin1Char('0'))
            .arg(s, 2, 10, QLatin1Char('0'));
}
