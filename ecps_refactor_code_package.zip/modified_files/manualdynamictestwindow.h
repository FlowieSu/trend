#ifndef MANUALDYNAMICTESTWINDOW_H
#define MANUALDYNAMICTESTWINDOW_H

#include <QWidget>
#include <QString>
#include <memory>

#include "dynamicparamconfigdialog.h"

namespace Ui {
class ManualDynamicTestWindow;
}

class DynamicTestController;
class AllInfo;
class QCloseEvent;

/*
 * ManualDynamicTestWindow
 *
 * 方案B：
 *   - 手动动态测试窗口不再选择 110/112/114/116；
 *   - 直接使用“调试 -> 动态检测参数配置”里的全局配置；
 *   - 手动动态测试不依赖 PLC，不操作 M26/M27；
 *   - 用于动态测试台架验证 CAN 通讯和动态协议。
 */
class ManualDynamicTestWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ManualDynamicTestWindow(DynamicTestController *dynamicController,
                                     const DynamicParamConfig &dynamicParamConfig,
                                     const QString &productCode1,
                                     const QString &productCode2,
                                     QWidget *parent = nullptr);
    ~ManualDynamicTestWindow() override;

signals:
    void manualDynamicProductFinished(int productId,
                                      bool pass,
                                      std::shared_ptr<AllInfo> allInfo);

    void manualDynamicAllFinished(bool allPass);

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onStartClicked();
    void onStopClicked();
    void onCloseClicked();

    void onDynamicLogMessage(const QString &message);

    void onDynamicProductFinished(int productId,
                                  bool pass,
                                  std::shared_ptr<AllInfo> allInfo);

    void onDynamicAllFinished(bool allPass);

private:
    void initUiState();
    void initConnections();

    bool checkReady();
    bool confirmBeforeStart();

    void setBusyState(bool busy);
    void appendLog(const QString &message);
    QString passText(bool pass) const;

private:
    Ui::ManualDynamicTestWindow *ui = nullptr;

    DynamicTestController *m_dynamicController = nullptr;
    DynamicParamConfig m_dynamicParamConfig;

    QString m_productCode1;
    QString m_productCode2;

    bool m_running = false;
};

#endif // MANUALDYNAMICTESTWINDOW_H
