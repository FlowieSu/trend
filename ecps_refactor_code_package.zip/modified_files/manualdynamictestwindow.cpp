#include "manualdynamictestwindow.h"
#include "ui_manualdynamictestwindow.h"

#include "dynamic_test_controller.h"
#include "sensor.h"

#include <QCloseEvent>
#include <QDateTime>
#include <QMessageBox>

ManualDynamicTestWindow::ManualDynamicTestWindow(DynamicTestController *dynamicController,
                                                 const DynamicParamConfig &dynamicParamConfig,
                                                 const QString &productCode1,
                                                 const QString &productCode2,
                                                 QWidget *parent)
    : QWidget(parent),
      ui(new Ui::ManualDynamicTestWindow),
      m_dynamicController(dynamicController),
      m_dynamicParamConfig(dynamicParamConfig),
      m_productCode1(productCode1),
      m_productCode2(productCode2)
{
    ui->setupUi(this);

    initUiState();
    initConnections();

    appendLog("手动动态测试窗口已打开。");
}

ManualDynamicTestWindow::~ManualDynamicTestWindow()
{
    delete ui;
}

void ManualDynamicTestWindow::initUiState()
{
    setWindowTitle("手动动态测试");

    ui->editProductCode1->setText(m_productCode1);
    ui->editProductCode2->setText(m_productCode2);

    ui->lblStatus->setText("待开始");
    ui->lblProduct1Result->setText("-");
    ui->lblProduct2Result->setText("-");

    ui->lblDynamicParam->setText(
                QString("位置1：%1 threshold=%2；位置2：%3 threshold=%4")
                .arg(m_dynamicParamConfig.position1TxId)
                .arg(m_dynamicParamConfig.position1ThresholdFlag)
                .arg(m_dynamicParamConfig.position2TxId)
                .arg(m_dynamicParamConfig.position2ThresholdFlag));

    setBusyState(false);
}

void ManualDynamicTestWindow::initConnections()
{
    connect(ui->btnStart,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onStartClicked);

    connect(ui->btnStop,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onStopClicked);

    connect(ui->btnClose,
            &QPushButton::clicked,
            this,
            &ManualDynamicTestWindow::onCloseClicked);

    if (m_dynamicController) {
        connect(m_dynamicController,
                &DynamicTestController::logMessage,
                this,
                &ManualDynamicTestWindow::onDynamicLogMessage,
                Qt::UniqueConnection);

        connect(m_dynamicController,
                &DynamicTestController::dynamicProductFinished,
                this,
                &ManualDynamicTestWindow::onDynamicProductFinished,
                Qt::UniqueConnection);

        connect(m_dynamicController,
                &DynamicTestController::dynamicAllFinished,
                this,
                &ManualDynamicTestWindow::onDynamicAllFinished,
                Qt::UniqueConnection);
    }
}

bool ManualDynamicTestWindow::checkReady()
{
    if (!m_dynamicController) {
        QMessageBox::warning(this, "提示", "动态测试控制器为空，无法执行动态测试。");
        return false;
    }

    m_productCode1 = ui->editProductCode1->text().trimmed();
    m_productCode2 = ui->editProductCode2->text().trimmed();

    if (m_productCode1.isEmpty()) {
        QMessageBox::warning(this, "提示", "位置1产品条码为空。");
        return false;
    }

    if (m_productCode2.isEmpty()) {
        QMessageBox::warning(this, "提示", "位置2产品条码为空。");
        return false;
    }

    if (m_dynamicParamConfig.position1TxId == m_dynamicParamConfig.position2TxId) {
        QMessageBox::warning(this, "提示", "位置1和位置2动态发送报文重复，请先在动态检测参数配置中修改。");
        return false;
    }

    return true;
}

bool ManualDynamicTestWindow::confirmBeforeStart()
{
    int ret = QMessageBox::question(this,
                                    "确认",
                                    "确认产品已在动态测试台架正确安装，是否开始手动动态检测？",
                                    QMessageBox::Ok | QMessageBox::Cancel,
                                    QMessageBox::Cancel);

    return ret == QMessageBox::Ok;
}

void ManualDynamicTestWindow::onStartClicked()
{
    if (m_running) {
        QMessageBox::information(this, "提示", "手动动态测试正在进行中。");
        return;
    }

    if (!checkReady()) {
        return;
    }

    if (!confirmBeforeStart()) {
        appendLog("用户取消手动动态测试。");
        return;
    }

    ui->lblProduct1Result->setText("-");
    ui->lblProduct2Result->setText("-");

    setBusyState(true);
    ui->lblStatus->setText("动态测试进行中");

    appendLog(QString("开始手动动态测试：位置1=%1，%2 threshold=%3；位置2=%4，%5 threshold=%6。")
              .arg(m_productCode1)
              .arg(m_dynamicParamConfig.position1TxId)
              .arg(m_dynamicParamConfig.position1ThresholdFlag)
              .arg(m_productCode2)
              .arg(m_dynamicParamConfig.position2TxId)
              .arg(m_dynamicParamConfig.position2ThresholdFlag));

    m_dynamicController->startDynamicTestWithParams(m_productCode1,
                                                    m_productCode2,
                                                    m_dynamicParamConfig.position1TxId,
                                                    m_dynamicParamConfig.position1ThresholdFlag,
                                                    m_dynamicParamConfig.position2TxId,
                                                    m_dynamicParamConfig.position2ThresholdFlag);
}

void ManualDynamicTestWindow::onStopClicked()
{
    if (!m_running) {
        return;
    }

    appendLog("用户停止手动动态测试。");

    if (m_dynamicController) {
        m_dynamicController->requestStop();
    }

    setBusyState(false);
    ui->lblStatus->setText("已停止");
}

void ManualDynamicTestWindow::onDynamicLogMessage(const QString &message)
{
    appendLog(message);
}

void ManualDynamicTestWindow::onDynamicProductFinished(int productId,
                                                       bool pass,
                                                       std::shared_ptr<AllInfo> allInfo)
{
    if (productId == 1) {
        ui->lblProduct1Result->setText(passText(pass));
    } else if (productId == 2) {
        ui->lblProduct2Result->setText(passText(pass));
    }

    appendLog(QString("位置%1动态测试完成，结果：%2。")
              .arg(productId)
              .arg(passText(pass)));

    emit manualDynamicProductFinished(productId, pass, allInfo);
}

void ManualDynamicTestWindow::onDynamicAllFinished(bool allPass)
{
    appendLog(QString("两个产品动态测试全部完成，总结果：%1。")
              .arg(passText(allPass)));

    setBusyState(false);
    ui->lblStatus->setText(allPass ? "动态测试完成：PASS" : "动态测试完成：NG");

    emit manualDynamicAllFinished(allPass);
}

void ManualDynamicTestWindow::setBusyState(bool busy)
{
    m_running = busy;

    ui->btnStart->setEnabled(!busy);
    ui->btnStop->setEnabled(busy);
    ui->btnClose->setEnabled(!busy);
    ui->editProductCode1->setEnabled(!busy);
    ui->editProductCode2->setEnabled(!busy);
}

void ManualDynamicTestWindow::onCloseClicked()
{
    close();
}

void ManualDynamicTestWindow::closeEvent(QCloseEvent *event)
{
    if (m_running && m_dynamicController) {
        appendLog("窗口关闭时检测到动态测试仍在运行，发送停止请求。");
        m_dynamicController->requestStop();
    }

    QWidget::closeEvent(event);
}

void ManualDynamicTestWindow::appendLog(const QString &message)
{
    const QString timeText = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    ui->textLog->append(QString("[%1] %2").arg(timeText, message));
}

QString ManualDynamicTestWindow::passText(bool pass) const
{
    return pass ? "PASS" : "NG";
}
