#include "dynamic_test_controller.h"

#include "usbcanfd_200u.h"
#include "sensor.h"

#include <QMetaObject>
#include <QThread>
#include <QTimer>

DynamicTestController::DynamicTestController(QObject *parent)
    : QObject(parent)
{
}

DynamicTestController::~DynamicTestController()
{
    stopCanWorker();
}

bool DynamicTestController::isCanWorkerRunning() const
{
    return m_canWorkerRunning;
}

bool DynamicTestController::isDynamicRunning() const
{
    return m_dynamicRunning;
}

void DynamicTestController::setUseNewProtocol(bool enabled)
{
    m_useNewProtocol = enabled;

    emit logMessage(QString("动态测试协议已设置为：%1。")
                    .arg(enabled ? "114/116" : "110/112"));
}

bool DynamicTestController::useNewProtocol() const
{
    return m_useNewProtocol;
}

void DynamicTestController::startCanWorker()
{
    if (m_canWorkerRunning && m_canThread && m_canWorker) {
        emit logMessage("CANFD 工作线程已启动，无需重复启动。");
        return;
    }

    createWorkerIfNeeded();

    if (!m_canThread || !m_canWorker) {
        emit logMessage("CANFD 工作线程创建失败。");
        return;
    }

    emit logMessage("正在启动 CANFD 工作线程。");

    m_canThread->start();

    m_canWorkerRunning = true;
    emit canWorkerStateChanged(true);
}

void DynamicTestController::createWorkerIfNeeded()
{
    if (m_canThread || m_canWorker) {
        return;
    }

    m_canThread = new QThread();
    m_canWorker = new USBCanFd_200U();

    m_canWorker->moveToThread(m_canThread);

    connect(m_canThread,
            &QThread::started,
            m_canWorker,
            &USBCanFd_200U::runn);

    connect(m_canThread,
            &QThread::finished,
            m_canWorker,
            &QObject::deleteLater);

    connect(m_canThread,
            &QThread::finished,
            m_canThread,
            &QObject::deleteLater);

    connect(m_canThread,
            &QThread::finished,
            this,
            [this]() {
                m_canThread = nullptr;
                m_canWorker = nullptr;
                m_canWorkerRunning = false;
                m_dynamicRunning = false;
                emit canWorkerStateChanged(false);
                emit logMessage("CANFD 工作线程已结束。");
            });

    connect(m_canWorker,
            &USBCanFd_200U::signal_logMessage,
            this,
            &DynamicTestController::logMessage,
            Qt::QueuedConnection);

    connect(m_canWorker,
            &USBCanFd_200U::signal_canfdIsConnected,
            this,
            &DynamicTestController::onCanfdConnected,
            Qt::QueuedConnection);

    connect(m_canWorker,
            &USBCanFd_200U::signal_dynamicProductFinished,
            this,
            &DynamicTestController::onWorkerDynamicProductFinished,
            Qt::QueuedConnection);

    connect(m_canWorker,
            &USBCanFd_200U::signal_allDynamicFinished,
            this,
            &DynamicTestController::onWorkerAllDynamicFinished,
            Qt::QueuedConnection);

    connect(this,
            &DynamicTestController::signal_prepareTwoProducts,
            m_canWorker,
            &USBCanFd_200U::prepareTwoProducts,
            Qt::QueuedConnection);

    connect(this,
            &DynamicTestController::signal_prepareTwoProductsWithParams,
            m_canWorker,
            &USBCanFd_200U::prepareTwoProductsWithParams,
            Qt::QueuedConnection);

    connect(this,
            &DynamicTestController::signal_startCheckingTwoProducts,
            m_canWorker,
            &USBCanFd_200U::startCheckingTwoProducts,
            Qt::QueuedConnection);
}

void DynamicTestController::stopCanWorker()
{
    if (!m_canThread && !m_canWorker) {
        return;
    }

    emit logMessage("正在停止 CANFD 工作线程。");

    if (m_canWorker) {
        m_canWorker->requestStop();
    }

    if (m_canThread) {
        m_canThread->requestInterruption();
        m_canThread->quit();
        m_canThread->wait(3000);
    }

    m_canWorkerRunning = false;
    m_dynamicRunning = false;
}

void DynamicTestController::requestStop()
{
    emit logMessage("收到动态测试停止请求。");

    m_dynamicRunning = false;

    if (m_canWorker) {
        m_canWorker->requestStop();
    }

    if (m_canThread) {
        m_canThread->requestInterruption();
    }
}

void DynamicTestController::startDynamicTest(const QString &productCode1,
                                             const QString &productCode2)
{
    const QString tx1 = m_useNewProtocol ? "00000114" : "00000110";
    const QString tx2 = m_useNewProtocol ? "00000116" : "00000112";

    /*
     * 最新要求：110/112/114/116 默认 thresholdFlag 均为 2。
     */
    startDynamicTestWithParams(productCode1,
                               productCode2,
                               tx1,
                               2,
                               tx2,
                               2);
}

void DynamicTestController::startDynamicTestWithParams(const QString &productCode1,
                                                       const QString &productCode2,
                                                       const QString &position1TxId,
                                                       int position1ThresholdFlag,
                                                       const QString &position2TxId,
                                                       int position2ThresholdFlag)
{
    const QString code1 = productCode1.trimmed();
    const QString code2 = productCode2.trimmed();

    if (code1.isEmpty()) {
        emit logMessage("位置1产品编码为空，无法启动动态测试。");
        emit dynamicAllFinished(false);
        return;
    }

    if (code2.isEmpty()) {
        emit logMessage("位置2产品编码为空，无法启动动态测试。");
        emit dynamicAllFinished(false);
        return;
    }

    if (position1TxId == position2TxId) {
        emit logMessage("位置1和位置2动态发送报文重复，无法启动动态测试。");
        emit dynamicAllFinished(false);
        return;
    }

    if (!m_canWorkerRunning || !m_canThread || !m_canWorker) {
        emit logMessage("CANFD 工作线程未启动，先自动启动。");
        startCanWorker();
    }

    if (!m_canThread || !m_canWorker) {
        emit logMessage("CANFD 工作对象无效，无法启动动态测试。");
        emit dynamicAllFinished(false);
        return;
    }

    resetDynamicState();

    m_dynamicRunning = true;

    emit logMessage(QString("准备双产品动态测试：位置1=%1[%2, threshold=%3]，位置2=%4[%5, threshold=%6]。")
                    .arg(code1)
                    .arg(position1TxId)
                    .arg(position1ThresholdFlag)
                    .arg(code2)
                    .arg(position2TxId)
                    .arg(position2ThresholdFlag));

    emit signal_prepareTwoProductsWithParams(code1,
                                             code2,
                                             position1TxId,
                                             position1ThresholdFlag,
                                             position2TxId,
                                             position2ThresholdFlag);

    QTimer::singleShot(100,
                       this,
                       [this]() {
                           if (!m_dynamicRunning) {
                               emit logMessage("动态测试已取消，跳过开始检测帧。");
                               return;
                           }

                           emit logMessage("发送双产品动态测试开始检测帧。");
                           emit signal_startCheckingTwoProducts();
                       });
}

void DynamicTestController::resetDynamicState()
{
    m_product1Done = false;
    m_product2Done = false;
    m_product1Pass = false;
    m_product2Pass = false;
}

void DynamicTestController::onCanfdConnected(bool connected)
{
    emit canDeviceConnected(connected);

    if (connected) {
        emit logMessage("CANFD 设备已连接并开始接收。");
    } else {
        emit logMessage("CANFD 设备已断开。");
    }
}

void DynamicTestController::onWorkerDynamicProductFinished(int productId,
                                                           bool pass,
                                                           std::shared_ptr<AllInfo> allInfo)
{
    if (productId == 1) {
        m_product1Done = true;
        m_product1Pass = pass;
    } else if (productId == 2) {
        m_product2Done = true;
        m_product2Pass = pass;
    }

    emit logMessage(QString("动态测试控制器收到位置%1结果：%2。")
                    .arg(productId)
                    .arg(pass ? "PASS" : "NG"));

    emit dynamicProductFinished(productId, pass, allInfo);
}

void DynamicTestController::onWorkerAllDynamicFinished(bool allPass)
{
    m_dynamicRunning = false;

    emit logMessage(QString("动态测试控制器收到全部完成信号，总结果：%1。")
                    .arg(allPass ? "PASS" : "NG"));

    emit dynamicAllFinished(allPass);
}
