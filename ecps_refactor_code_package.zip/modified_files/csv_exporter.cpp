#include "csv_exporter.h"

#include "sensor.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStringList>
#include <QTextStream>

#include <cmath>

namespace
{
QString intTextOrDash(bool valid, int value)
{
    return valid ? QString::number(value) : QString("-");
}

QString recordTextOrDash(bool valid, int value)
{
    return valid ? QString::number(value) : QString("-");
}

QString safeProductCode(const QString &productCode, int position = 0)
{
    QString code = productCode.trimmed();

    if (code.isEmpty()) {
        code = position > 0 ? QString("位置%1").arg(position) : QString("未扫码");
    }

    const QString invalidChars = "\\/:*?\"<>|";
    for (const QChar &ch : invalidChars) {
        code.replace(ch, "_");
    }

    return code;
}

struct DynamicItemMeta
{
    int itemNo;
    const char *name;
    const char *unit;
    int flagValue;
    bool flagValid;
    QString rawValue;
};

void appendDynamicRow(QVector<CsvDynamicDisplayRow> &rows,
                      const CsvDynamicResult &result,
                      int itemNo,
                      const QString &itemName,
                      const QString &rawValue,
                      const QString &unit,
                      bool pass)
{
    const std::shared_ptr<AllInfo> info = result.allInfo;
    const bool hasBase = info && info->baseInfo;

    QString productCode = result.productCode;
    if (info && !info->productCode.isEmpty()) {
        productCode = info->productCode;
    }

    CsvDynamicDisplayRow row;
    row.testTime = result.timestamp.isEmpty()
            ? CsvExporter::timestampNow()
            : result.timestamp;
    row.finishTime = CsvExporter::timestampNow();
    row.positionText = CsvExporter::positionText(result.productId);
    row.productCode = productCode;
    row.channelText = info ? QString::fromStdString(info->sensorID) : "-";
    row.progressText = hasBase ? QString::number(info->baseInfo->DetectInProgressFlag) : "-";
    row.itemNo = itemNo;
    row.itemName = itemName;
    row.rawValue = rawValue;
    row.unit = unit;
    row.pass = pass;

    rows.append(row);
}

bool flagPass(bool valid, int flag)
{
    return valid && flag == 0;
}

QString boolText(bool value)
{
    return value ? "PASS" : "NG";
}
}

bool CsvExporter::exportStaticResults(const QVector<StaticTestResult> &results,
                                      const QString &filePath,
                                      QString *errorMessage)
{
    if (filePath.trimmed().isEmpty()) {
        setError(errorMessage, "CSV文件路径为空。");
        return false;
    }

    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        setError(errorMessage, QString("阻容CSV打开失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);
#endif

    out << "测试类型,"
        << "产品编码,"
        << "测试位置,"
        << "测试项,"
        << "测试方向,"
        << "M点,"
        << "测试标准,"
        << "电阻/kOhm,"
        << "电容/nF,"
        << "电阻结果,"
        << "电容结果,"
        << "总结果,"
        << "备注,"
        << "测试时间\n";

    for (const StaticTestResult &r : results) {
        out << quoteCsvField("阻容测试") << ","
            << quoteCsvField(r.productCode) << ","
            << quoteCsvField(positionText(r.position)) << ","
            << quoteCsvField(r.testName) << ","
            << quoteCsvField(r.directionName) << ","
            << quoteCsvField(r.mPointsText) << ","
            << quoteCsvField(r.standardText) << ","
            << quoteCsvField(formatValue(r.resistanceKOhm)) << ","
            << quoteCsvField(formatValue(r.capacitanceNf)) << ","
            << quoteCsvField(passText(r.resistancePass)) << ","
            << quoteCsvField(passText(r.capacitancePass)) << ","
            << quoteCsvField(passText(r.pass)) << ","
            << quoteCsvField(r.message) << ","
            << quoteCsvField(r.timestamp) << "\n";
    }

    return true;
}

bool CsvExporter::exportDynamicResults(const QVector<CsvDynamicResult> &results,
                                       const QString &filePath,
                                       QString *errorMessage)
{
    if (filePath.trimmed().isEmpty()) {
        setError(errorMessage, "CSV文件路径为空。");
        return false;
    }

    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        setError(errorMessage, QString("动态CSV打开失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);
#endif

    /*
     * 原手动导出接口保留，但字段改成和当前动态显示一致的简化明细。
     */
    out << "测试时间,完成时间,产品位置,产品编码,通道,检测进度,检测项编号,检测项名称,原始检测值,单位,单项结果\n";

    for (const CsvDynamicResult &result : results) {
        const QVector<CsvDynamicDisplayRow> rows = buildDynamicDisplayRows(result);

        for (const CsvDynamicDisplayRow &row : rows) {
            out << quoteCsvField(row.testTime) << ","
                << quoteCsvField(row.finishTime) << ","
                << quoteCsvField(row.positionText) << ","
                << quoteCsvField(row.productCode) << ","
                << quoteCsvField(row.channelText) << ","
                << quoteCsvField(row.progressText) << ","
                << quoteCsvField(QString::number(row.itemNo)) << ","
                << quoteCsvField(row.itemName) << ","
                << quoteCsvField(row.rawValue) << ","
                << quoteCsvField(row.unit) << ","
                << quoteCsvField(passText(row.pass)) << "\n";
        }
    }

    return true;
}

bool CsvExporter::autoSaveStaticResultsForPosition(const QVector<StaticTestResult> &allResults,
                                                   int position,
                                                   const QString &productCode,
                                                   QString *savedFilePath,
                                                   QString *errorMessage)
{
    QVector<StaticTestResult> rows;

    for (const StaticTestResult &r : allResults) {
        if (r.position == position) {
            rows.append(r);
        }
    }

    if (rows.isEmpty()) {
        setError(errorMessage, QString("位置%1没有阻容测试结果，未保存。").arg(position));
        return false;
    }

    const QString filePath = autoFilePath("D:/阻容测试结果",
                                          productCode,
                                          "阻容测试");

    QStringList recordLines;

    for (const StaticTestResult &r : rows) {
        QStringList cols;
        cols << quoteCsvField("阻容测试")
             << quoteCsvField(r.productCode)
             << quoteCsvField(positionText(r.position))
             << quoteCsvField(r.testName)
             << quoteCsvField(r.directionName)
             << quoteCsvField(r.mPointsText)
             << quoteCsvField(r.standardText)
             << quoteCsvField(formatValue(r.resistanceKOhm))
             << quoteCsvField(formatValue(r.capacitanceNf))
             << quoteCsvField(passText(r.resistancePass))
             << quoteCsvField(passText(r.capacitancePass))
             << quoteCsvField(passText(r.pass))
             << quoteCsvField(r.message)
             << quoteCsvField(r.timestamp);

        recordLines << cols.join(",");
    }

    const QString header =
            "测试类型,产品编码,测试位置,测试项,测试方向,M点,测试标准,电阻/kOhm,电容/nF,电阻结果,电容结果,总结果,备注,测试时间";

    const bool ok = appendTextFileGbk(filePath, header, recordLines, errorMessage);

    if (ok && savedFilePath) {
        *savedFilePath = filePath;
    }

    return ok;
}

bool CsvExporter::autoSaveDynamicResultForProduct(const CsvDynamicResult &result,
                                                  QString *savedFilePath,
                                                  QString *errorMessage)
{
    const QString productCode = result.allInfo && !result.allInfo->productCode.isEmpty()
            ? result.allInfo->productCode
            : result.productCode;

    const QString filePath = autoFilePath("D:/动态测试结果",
                                          productCode,
                                          "动态测试");

    const QVector<CsvDynamicDisplayRow> rows = buildDynamicDisplayRows(result);
    QStringList recordLines;

    for (const CsvDynamicDisplayRow &row : rows) {
        QStringList cols;
        cols << quoteCsvField(row.testTime)
             << quoteCsvField(row.finishTime)
             << quoteCsvField(row.positionText)
             << quoteCsvField(row.productCode)
             << quoteCsvField(row.channelText)
             << quoteCsvField(row.progressText)
             << quoteCsvField(QString::number(row.itemNo))
             << quoteCsvField(row.itemName)
             << quoteCsvField(row.rawValue)
             << quoteCsvField(row.unit)
             << quoteCsvField(passText(row.pass));

        recordLines << cols.join(",");
    }

    const QString header =
            "测试时间,完成时间,产品位置,产品编码,通道,检测进度,检测项编号,检测项名称,原始检测值,单位,单项结果";

    const bool ok = appendTextFileGbk(filePath, header, recordLines, errorMessage);

    if (ok && savedFilePath) {
        *savedFilePath = filePath;
    }

    return ok;
}

QVector<CsvDynamicDisplayRow> CsvExporter::buildDynamicDisplayRows(const CsvDynamicResult &result)
{
    QVector<CsvDynamicDisplayRow> rows;

    const std::shared_ptr<AllInfo> info = result.allInfo;

    if (!info || !info->baseInfo) {
        appendDynamicRow(rows, result, 0, "动态检测总结果", "-", "-", result.pass);
        return rows;
    }

    const BaseInfo *b = info->baseInfo.get();

    const SpeedRecord *speed = info->speedRecord ? info->speedRecord.get() : nullptr;
    const SignalRecord *signal = info->signalRecord ? info->signalRecord.get() : nullptr;
    const TrackErrRecord *track = info->trackErrRecord ? info->trackErrRecord.get() : nullptr;
    const SinRecord *sin = info->sinRecord ? info->sinRecord.get() : nullptr;
    const CosRecord *cos = info->cosRecord ? info->cosRecord.get() : nullptr;
    const SinMaxMinRecord *sinMm = info->sinMaxMinRecord ? info->sinMaxMinRecord.get() : nullptr;
    const CosMaxMinRecord *cosMm = info->cosMaxMinRecord ? info->cosMaxMinRecord.get() : nullptr;
    const SoftInfo *soft = info->softInfo ? info->softInfo.get() : nullptr;

    appendDynamicRow(rows, result, 1,  "RDCErrFlag",        "-", "-", flagPass(true, b->RDCErrFlag));
    appendDynamicRow(rows, result, 2,  "FailErrFlag",       "-", "-", flagPass(true, b->FailErrFlag));
    appendDynamicRow(rows, result, 3,  "DetectInProgressFlag", QString::number(b->DetectInProgressFlag), "%", b->DetectInProgressFlag == 100);
    appendDynamicRow(rows, result, 4,  "QualiFlag",         "-", "-", flagPass(true, b->QualiFlag));
    appendDynamicRow(rows, result, 5,  "SpeedInvalidFlag",  speed ? QString::number(speed->SpeedInvalidRecord) : "-", "-", flagPass(true, b->SpeedInvalidFlag));
    appendDynamicRow(rows, result, 6,  "SpeedFlucFlag",     speed ? QString::number(speed->SpdFlucRecord) : "-", "-", flagPass(true, b->SpeedFlucFlag));
    appendDynamicRow(rows, result, 7,  "RDCAccurFlag",      signal ? QString::number(signal->RDCAccurRecord) : "-", "-", flagPass(true, b->RDCAccurFlag));
    appendDynamicRow(rows, result, 8,  "VecFMaxFlag",       signal ? QString::number(signal->VecFMaxRecord) : "-", "-", flagPass(true, b->VecFMaxFlag));
    appendDynamicRow(rows, result, 9,  "VecFMinFlag",       signal ? QString::number(signal->VecFMinRecord) : "-", "-", flagPass(true, b->VecFMinFlag));
    appendDynamicRow(rows, result, 10, "VecFAvgFlag",       signal ? QString::number(signal->VecFAvgRecord) : "-", "-", flagPass(true, b->VecFAvgFlag));
    appendDynamicRow(rows, result, 11, "AmplMMaxFlag",      track ? QString::number(track->AmplMMaxRecord) : "-", "-", flagPass(true, b->AmplMMaxFlag));
    appendDynamicRow(rows, result, 12, "AmplMMinFlag",      track ? QString::number(track->AmplMMinRecord) : "-", "-", flagPass(true, b->AmplMMinFlag));
    appendDynamicRow(rows, result, 13, "TrackErrMaxFlag",   track ? QString::number(track->TrackErrMaxRecord) : "-", "-", flagPass(true, b->TrackErrMaxFlag));
    appendDynamicRow(rows, result, 14, "TrackErrMinFlag",   track ? QString::number(track->TrackErrMinRecord) : "-", "-", flagPass(true, b->TrackErrMinFlag));
    appendDynamicRow(rows, result, 15, "SinAmplMaxFlag",    sin ? QString::number(sin->SinAmplMaxRecord) : "-", "-", flagPass(true, b->SinAmplMaxFlag));
    appendDynamicRow(rows, result, 16, "SinAmplMinFlag",    sin ? QString::number(sin->SinAmplMinRecord) : "-", "-", flagPass(true, b->SinAmplMinFlag));
    appendDynamicRow(rows, result, 17, "SinAvgFlag",        sin ? QString::number(sin->SinAvgRecord) : "-", "-", flagPass(true, b->SinAvgFlag));
    appendDynamicRow(rows, result, 18, "SinAdjCoefFlag",    sin ? QString::number(sin->SinAdjCoefRecord) : "-", "-", flagPass(true, b->SinAdjCoefFlag));
    appendDynamicRow(rows, result, 19, "CosAmplMaxFlag",    cos ? QString::number(cos->CosAmplMaxRecord) : "-", "-", flagPass(true, b->CosAmplMaxFlag));
    appendDynamicRow(rows, result, 20, "CosAmplMinFlag",    cos ? QString::number(cos->CosAmplMinRecord) : "-", "-", flagPass(true, b->CosAmplMinFlag));
    appendDynamicRow(rows, result, 21, "CosAvgFlag",        cos ? QString::number(cos->CosAvgRecord) : "-", "-", flagPass(true, b->CosAvgFlag));
    appendDynamicRow(rows, result, 22, "CosAdjCoefFlag",    cos ? QString::number(cos->CosAdjCoefRecord) : "-", "-", flagPass(true, b->CosAdjCoefFlag));
    appendDynamicRow(rows, result, 23, "SinPosAmplMaxFlag", sinMm ? QString::number(sinMm->SinPosAmplMaxRecord) : "-", "-", flagPass(true, b->SinPosAmplMaxFlag));
    appendDynamicRow(rows, result, 24, "SinPosAmplMinFlag", sinMm ? QString::number(sinMm->SinPosAmplMinRecord) : "-", "-", flagPass(true, b->SinPosAmplMinFlag));
    appendDynamicRow(rows, result, 25, "SinNegAmplMaxFlag", sinMm ? QString::number(sinMm->SinNegAmplMaxRecord) : "-", "-", flagPass(true, b->SinNegAmplMaxFlag));
    appendDynamicRow(rows, result, 26, "SinNegAmplMinFlag", sinMm ? QString::number(sinMm->SinNegAmplMinRecord) : "-", "-", flagPass(true, b->SinNegAmplMinFlag));
    appendDynamicRow(rows, result, 27, "CosPosAmplMaxFlag", cosMm ? QString::number(cosMm->CosPosAmplMaxRecord) : "-", "-", flagPass(true, b->CosPosAmplMaxFlag));
    appendDynamicRow(rows, result, 28, "CosPosAmplMinFlag", cosMm ? QString::number(cosMm->CosPosAmplMinRecord) : "-", "-", flagPass(true, b->CosPosAmplMinFlag));
    appendDynamicRow(rows, result, 29, "CosNegAmplMaxFlag", cosMm ? QString::number(cosMm->CosNegAmplMaxRecord) : "-", "-", flagPass(true, b->CosNegAmplMaxFlag));
    appendDynamicRow(rows, result, 30, "CosNegAmplMinFlag", cosMm ? QString::number(cosMm->CosNegAmplMinRecord) : "-", "-", flagPass(true, b->CosNegAmplMinFlag));
    appendDynamicRow(rows, result, 31, "PowerSupFlag",      soft ? QString::number(soft->PowerSupRecord) : "-", "-", flagPass(true, b->PowerSupFlag));

    return rows;
}

QString CsvExporter::defaultResultDir()
{
    const QString baseDir = QCoreApplication::applicationDirPath();
    const QString resultDir = QDir(baseDir).filePath("results");

    QDir().mkpath(resultDir);

    return resultDir;
}

QString CsvExporter::buildStaticFileName(const QString &productCode1,
                                         const QString &productCode2)
{
    return QString("阻容测试结果_%1_%2_%3.csv")
            .arg(productCode1.trimmed().isEmpty() ? "位置1" : productCode1.trimmed())
            .arg(productCode2.trimmed().isEmpty() ? "位置2" : productCode2.trimmed())
            .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"));
}

QString CsvExporter::buildDynamicFileName(const QString &productCode1,
                                          const QString &productCode2)
{
    return QString("动态测试结果_%1_%2_%3.csv")
            .arg(productCode1.trimmed().isEmpty() ? "位置1" : productCode1.trimmed())
            .arg(productCode2.trimmed().isEmpty() ? "位置2" : productCode2.trimmed())
            .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss"));
}

QString CsvExporter::quoteCsvField(const QString &text)
{
    QString escaped = text;
    escaped.replace("\"", "\"\"");
    return "\"" + escaped + "\"";
}

QString CsvExporter::formatValue(double value, int precision)
{
    if (value < 0.0 || !std::isfinite(value)) {
        return "-";
    }

    return QString::number(value, 'f', precision);
}

QString CsvExporter::passText(bool pass)
{
    return pass ? "PASS" : "NG";
}

QString CsvExporter::positionText(int position)
{
    return position == 2 ? "位置2" : "位置1";
}

QString CsvExporter::timestampNow()
{
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
}

QString CsvExporter::monthlyDir(const QString &rootDir)
{
    const QDate now = QDate::currentDate();

    const QString monthDirName =
            QString("%1年%2月")
            .arg(now.year())
            .arg(now.month(), 2, 10, QLatin1Char('0'));

    return QDir(rootDir).filePath(monthDirName);
}

QString CsvExporter::autoFilePath(const QString &rootDir,
                                  const QString &productCode,
                                  const QString &testType)
{
    const QString dir = monthlyDir(rootDir);
    const QString dateText = QDate::currentDate().toString("yyyyMMdd");
    const QString fileName = QString("%1_%2_%3.csv")
                             .arg(safeProductCode(productCode))
                             .arg(testType)
                             .arg(dateText);

    return QDir(dir).filePath(fileName);
}

bool CsvExporter::ensureParentDir(const QString &filePath,
                                  QString *errorMessage)
{
    const QFileInfo fileInfo(filePath);
    const QString parentDir = fileInfo.absolutePath();

    if (parentDir.isEmpty()) {
        return true;
    }

    QDir dir;

    if (!dir.mkpath(parentDir)) {
        setError(errorMessage, QString("创建CSV目录失败：%1").arg(parentDir));
        return false;
    }

    return true;
}

bool CsvExporter::appendTextFileGbk(const QString &filePath,
                                    const QString &headerLine,
                                    const QStringList &recordLines,
                                    QString *errorMessage)
{
    if (filePath.trimmed().isEmpty()) {
        setError(errorMessage, "CSV文件路径为空。");
        return false;
    }

    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    const bool fileExists = QFile::exists(filePath);

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        setError(errorMessage, QString("CSV打开失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("GBK");
#endif

    if (!fileExists || file.size() == 0) {
        out << headerLine << "\n";
    }

    for (const QString &line : recordLines) {
        out << line << "\n";
    }

    return true;
}

void CsvExporter::setError(QString *errorMessage,
                           const QString &message)
{
    if (errorMessage) {
        *errorMessage = message;
    }
}
