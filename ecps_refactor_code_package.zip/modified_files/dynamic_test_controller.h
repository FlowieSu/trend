#ifndef DYNAMIC_TEST_CONTROLLER_H
#define DYNAMIC_TEST_CONTROLLER_H

#include <QObject>
#include <QString>
#include <memory>

class QThread;
class USBCanFd_200U;
class AllInfo;

/*
 * DynamicTestController
 *
 * 在原动态测试流程基础上做最小扩展：
 * 1. 原 startDynamicTest(productCode1, productCode2) 保留；
 * 2. 新增 startDynamicTestWithParams(...)，支持外部配置 110/112/114/116 和 thresholdFlag；
 * 3. 不修改 CAN 连接函数；
 * 4. 不修改动态测试完成信号。
 */
class DynamicTestController : public QObject
{
    Q_OBJECT

public:
    explicit DynamicTestController(QObject *parent = nullptr);
    ~DynamicTestController() override;

    bool isCanWorkerRunning() const;
    bool isDynamicRunning() const;

    void setUseNewProtocol(bool enabled);
    bool useNewProtocol() const;

public slots:
    void startCanWorker();
    void stopCanWorker();

    void startDynamicTest(const QString &productCode1,
                          const QString &productCode2);

    void startDynamicTestWithParams(const QString &productCode1,
                                    const QString &productCode2,
                                    const QString &position1TxId,
                                    int position1ThresholdFlag,
                                    const QString &position2TxId,
                                    int position2ThresholdFlag);

    void requestStop();

signals:
    void logMessage(const QString &message);

    void canWorkerStateChanged(bool running);
    void canDeviceConnected(bool connected);

    void dynamicProductFinished(int productId,
                                bool pass,
                                std::shared_ptr<AllInfo> allInfo);

    void dynamicAllFinished(bool allPass);

private slots:
    void onCanfdConnected(bool connected);

    void onWorkerDynamicProductFinished(int productId,
                                        bool pass,
                                        std::shared_ptr<AllInfo> allInfo);

    void onWorkerAllDynamicFinished(bool allPass);

private:
    void createWorkerIfNeeded();
    void resetDynamicState();

signals:
    void signal_prepareTwoProducts(const QString &productCode1,
                                   const QString &productCode2,
                                   bool useNewProtocol);

    void signal_prepareTwoProductsWithParams(const QString &productCode1,
                                             const QString &productCode2,
                                             const QString &position1TxId,
                                             int position1ThresholdFlag,
                                             const QString &position2TxId,
                                             int position2ThresholdFlag);

    void signal_startCheckingTwoProducts();

private:
    QThread *m_canThread = nullptr;
    USBCanFd_200U *m_canWorker = nullptr;

    bool m_canWorkerRunning = false;
    bool m_dynamicRunning = false;
    bool m_useNewProtocol = true;

    bool m_product1Done = false;
    bool m_product2Done = false;
    bool m_product1Pass = false;
    bool m_product2Pass = false;
};

#endif // DYNAMIC_TEST_CONTROLLER_H
