/*
 * mainwindow.h 增量修改片段
 *
 * 不建议盲目整文件覆盖；把下面内容合入你当前 MainWindow。
 */

#include <QElapsedTimer>
#include <QTimer>

#include "dynamicparamconfigdialog.h"

class DeviceConnectionDialog;
class DynamicParamConfigDialog;
class LogWindow;

/* private slots: 增加 */
void onActionDeviceConnectionTriggered();
void onActionDynamicParamConfigTriggered();
void onActionManualDynamicTestTriggered();
void onActionManualStaticTestTriggered();
void onActionPlcPointTestTriggered();
void onActionLogWindowTriggered();

void onDeviceDialogConnectRequested(QString plcPortName,
                                    QString visaAddress);

void updateTestDuration();
void onBarcode1Changed(const QString &text);

/* private: 增加 */
void initDebugMenu();
void initProductionUiState();
void setRowResultColor(QTableWidget *table, int row, bool pass);
void setOverallResultLabel(QLabel *label, bool pass);
void resetOverallResultLabel(QLabel *label, const QString &text);

void startTestDurationTimer();
void stopTestDurationTimer();
QString formatDuration(qint64 seconds) const;

bool connectDevicesByParams(const QString &portName,
                            const QString &visaAddress);

void autoSaveStaticResults();
void autoSaveDynamicResults();

/* private 成员增加 */
DeviceConnectionDialog *m_deviceConnectionDialog = nullptr;
DynamicParamConfigDialog *m_dynamicParamConfigDialog = nullptr;
LogWindow *m_logWindow = nullptr;

DynamicParamConfig m_dynamicParamConfig;

int m_connectorPlugCount = 0;
QElapsedTimer m_testElapsedTimer;
QTimer *m_testDurationTimer = nullptr;
