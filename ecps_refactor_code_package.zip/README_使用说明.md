# ECPS 界面重构与自动保存代码包

本代码包按你的最新约束生成：

- 不新增 `auto_result_saver`
- 不新增 `static_csv_exporter`
- 自动保存直接在 `CsvExporter` 中新增函数
- 手动动态测试采用方案 B：使用“动态检测参数配置”的全局参数
- 当前能跑的 PLC / 万用表 / CAN 连接函数不改
- 当前自动测试整体流程不改
- `thresholdFlag` 增加到动态检测参数配置窗口
- 110/112/114/116 默认 `thresholdFlag = 2`

## 1. 新增文件

把 `new_files/` 下文件加入工程：

```text
deviceconnectiondialog.h/.cpp/.ui
dynamicparamconfigdialog.h/.cpp/.ui
logwindow.h/.cpp/.ui
```

## 2. 替换或合并的文件

`modified_files/` 下文件包括：

```text
csv_exporter.h/.cpp
dynamic_test_controller.h/.cpp
manualdynamictestwindow.h/.cpp/.ui
mainwindow.ui
mainwindow_integration_snippets.h
mainwindow_integration_snippets.cpp
```

其中：

- `csv_exporter.h/.cpp` 可以直接替换旧文件；
- `dynamic_test_controller.h/.cpp` 是基于当前旧控制器做的最小扩展；
- `manualdynamictestwindow.h/.cpp/.ui` 是方案 B 的手动动态窗口；
- `mainwindow.ui` 是主界面布局建议替换版本；
- `mainwindow_integration_snippets.*` 是合并到你当前 `MainWindow` 的增量代码，不建议盲目整文件覆盖。

## 3. usbcanfd_200u 最小修改

查看：

```text
patches/usbcanfd_200u_threshold_support.patch.txt
```

该 patch 只增加：

- `prepareTwoProducts(...)`
- `prepareTwoProductsWithParams(...)`
- `startCheckingTwoProducts()`
- `m_thresholdOverrideMap`

不改设备打开、初始化、发送、接收函数。

## 4. 结果自动保存

阻容自动保存路径：

```text
D:/阻容测试结果/yyyy年MM月/条码_阻容测试_yyyyMMdd.csv
```

动态自动保存路径：

```text
D:/动态测试结果/yyyy年MM月/条码_动态测试_yyyyMMdd.csv
```

编码：

```text
GBK
```

重复测试：

```text
同名文件存在 -> append追加记录
不覆盖
不重复写表头
```

## 5. 主界面要求

主界面只保留量产操作：

```text
位置1条码
位置2条码
开始自动化测试
停止测试
红色紧急关闭伺服
接插件插拔次数
测试时长
当前测试
QProgressBar
阻容总结果
动态总结果
阻容结果表
动态结果表
```

调试菜单：

```text
调试
├── 设备连接
├── 动态检测参数配置
├── 手动动态测试
├── 手动阻容测试
├── PLC点位测试
└── 日志输出窗口
```

## 6. 合并顺序建议

1. 加入 `deviceconnectiondialog`、`dynamicparamconfigdialog`、`logwindow`
2. 替换 `csv_exporter.h/.cpp`
3. 替换或合并 `dynamic_test_controller.h/.cpp`
4. 按 patch 修改 `usbcanfd_200u.h/.cpp`
5. 替换 `manualdynamictestwindow.h/.cpp/.ui`
6. 根据 `mainwindow_integration_snippets.*` 合并 MainWindow
7. 替换或调整 `mainwindow.ui`
8. 修改 `.pro`
9. 编译，先验证设备连接，再验证手动动态，再验证自动化流程
