#ifndef DYNAMIC_PRODUCT_CONTEXT_H
#define DYNAMIC_PRODUCT_CONTEXT_H

#include <QString>
#include <QVector>
#include <QDateTime>

#include "dynamic_protocol.h"
#include "dynamic_result_types.h"
#include "dynamic_test_item_config.h"

/*
 * 单个产品的动态检测数据上下文。
 *
 * 一个 DynamicProductContext 对应一个产品：
 *   例如 txId=0x110，rxId=0x201；
 *   或 txId=0x112，rxId=0x301。
 *
 * 它只负责：
 * 1. 缓存 seq 0~60 数据；
 * 2. 做 seed 和单帧校验；
 * 3. 根据 DetectInProgressFlag == 100 判断检测完成；
 * 4. 生成 DynamicProductResult。
 */

class DynamicProductContext
{
public:
    DynamicProductContext();

    void setup(const DynamicProtocol::ChannelConfig &channelConfig,
               const QString &productCode,
               int seed,
               const QVector<DynamicTestItemMeta> &itemMetas);

    void reset();

    bool handleFrame(quint32 canId,
                     const QByteArray &data);

    bool isConfigured() const;
    bool isFinished() const;
    bool isReported() const;
    void markReported();

    int productId() const;
    QString productCode() const;

    quint32 txId() const;
    quint32 rxId() const;

    int seed() const;
    int thresholdFlag() const;

    int groupCnt() const;
    int detectProgress() const;

    int receivedCount() const;
    int checkOkCount() const;

    DynamicProductResult buildResult(const QString &message = QString()) const;

private:
    void resetCache();

    void applyNormalFrame(const DynamicProtocol::ParsedFrame &frame);
    void applyGroupCheckFrame(const DynamicProtocol::ParsedFrame &frame);

    DynamicItemResult buildItemResult(const DynamicTestItemMeta &meta) const;
    bool calcProductPass(const QVector<DynamicItemResult> &items) const;

    QString currentTimeText() const;

private:
    bool m_configured = false;

    DynamicProtocol::ChannelConfig m_channelConfig;

    QString m_productCode;

    int m_seed = 0;
    int m_groupCnt = 0;
    int m_detectProgress = 0;

    bool m_finished = false;
    bool m_reported = false;

    bool m_groupCheckReceived = false;
    bool m_groupCheckPassed = false;

    QString m_startTime;
    QString m_finishTime;

    int m_values[61];
    bool m_received[61];
    bool m_checkOk[61];

    QVector<DynamicTestItemMeta> m_itemMetas;
};

#endif // DYNAMIC_PRODUCT_CONTEXT_H
