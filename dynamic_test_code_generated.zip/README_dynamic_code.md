# 动态检测代码使用说明

## 1. 文件说明

- dynamic_protocol.h/.cpp  
  动态 CAN 协议：ID 映射、复位帧、开始检测帧、接收帧解析、校验。

- dynamic_test_item_config.h/.cpp  
  检测项配置：flagSeq、valueSeq、检测项名称、标准、单位。

- dynamic_product_context.h/.cpp  
  单个产品的数据处理：缓存 seq 0~60，DetectInProgressFlag==100 判定完成，生成 DynamicProductResult。

- dynamic_test_controller.h/.cpp  
  双产品动态检测控制：打开 CAN、发送复位帧/开始帧、分发接收帧、输出产品结果和总结果。

- dynamic_csv_exporter.h/.cpp  
  动态检测明细 CSV 保存。

- zlg_can_device.h/.cpp  
  ZLG CAN 设备统一通信层，支持 USBCANFD-200U / USBCAN-II+ 通过参数切换。

## 2. 主界面最小调用示例

```cpp
auto *controller = new DynamicTestController(this);

connect(controller, &DynamicTestController::logMessage,
        this, &MainWindow::appendLog);

connect(controller, &DynamicTestController::productProgressChanged,
        this, &MainWindow::onDynamicProductProgressChanged);

connect(controller, &DynamicTestController::productFinished,
        this, &MainWindow::onDynamicProductFinished);

connect(controller, &DynamicTestController::allFinished,
        this, &MainWindow::onDynamicAllFinished);

ZlgCanOpenConfig config;
config.deviceType = ZlgCanDeviceType::UsbCanFd200U; // 或 UsbCanIIPlus
config.deviceIndex = 0;
config.channelIndex = 0;
config.canBaudRate = 500000;
config.canFdAbitBaudRate = 500000;
config.canFdDbitBaudRate = 2000000;
config.sendAsCanFd = false;
config.receiveCanFd = false;
config.extendedFrame = true;

controller->openCanDevice(config);

controller->startDynamicTestWithChannels(productCode1,
                                         DynamicProtocol::DynamicChannel::Channel110,
                                         productCode2,
                                         DynamicProtocol::DynamicChannel::Channel112);
```

## 3. 保存 CSV 示例

```cpp
QString err;
QString path = DynamicCsvExporter::makeDefaultFileName("./results", "dynamic_result");
DynamicCsvExporter::exportResults(results, path, &err);
```

## 4. 注意事项

1. Excel 中 DetectInProgressFlag 的数据序号是 3，代码中按 seq=3、value=100 判定完成。
2. Excel 中合格标志位是 1~31，具体检测值是 32~60。
3. 当前检测项标准先用“标志位=0合格，1=不合格”，具体上下限可在 dynamic_test_item_config.cpp 中修改。
4. 如果现场 CAN 是标准帧，把 ZlgCanOpenConfig::extendedFrame 改为 false。
5. 如果 USBCAN-II+ 在当前 ZLG 头文件里设备类型宏不是 ZCAN_USBCAN2，可用 ZlgCanOpenConfig::deviceTypeOverride 覆盖。
