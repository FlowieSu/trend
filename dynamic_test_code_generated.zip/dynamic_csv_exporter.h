#ifndef DYNAMIC_CSV_EXPORTER_H
#define DYNAMIC_CSV_EXPORTER_H

#include <QString>
#include <QVector>

#include "dynamic_result_types.h"

class DynamicCsvExporter
{
public:
    static bool exportResults(const QVector<DynamicProductResult> &results,
                              const QString &filePath,
                              QString *errorMessage = nullptr);

    static QString makeDefaultFileName(const QString &directory,
                                       const QString &prefix = "dynamic_result");

private:
    static QString escapeCsv(const QString &text);
    static QString boolText(bool value);
    static QString passText(bool pass);
    static QString canIdText(quint32 canId);
};

#endif // DYNAMIC_CSV_EXPORTER_H
