#include "dynamic_test_item_config.h"

QVector<DynamicTestItemMeta> createDefaultDynamicTestItemMetas()
{
    const QString flagStandard = "标志位=0合格，1=不合格";
    const QString valueStandard = "以检测板阈值判定，显示当前实测值";

    QVector<DynamicTestItemMeta> metas;

    metas.append({1,  "RDCErrFlag",              flagStandard, "-", 1,  34, 1.0, true,  false, 100});
    metas.append({2,  "FailErrFlag",             flagStandard, "-", 2,  35, 1.0, true,  false, 100});
    metas.append({3,  "DetectInProgressFlag",    "检测进度=100表示完成", "%", 3, -1, 1.0, false, true, 100});
    metas.append({4,  "QualiFlag",               flagStandard, "-", 4,  -1, 1.0, true,  false, 100});

    metas.append({5,  "SpeedInvalidFlag",        flagStandard + "；" + valueStandard, "-", 5,  32, 1.0, true, false, 100});
    metas.append({6,  "SpeedFlucFlag",           flagStandard + "；" + valueStandard, "-", 6,  33, 1.0, true, false, 100});
    metas.append({7,  "RDCAccurFlag",            flagStandard + "；" + valueStandard, "-", 7,  36, 1.0, true, false, 100});
    metas.append({8,  "VecFMaxFlag",             flagStandard + "；" + valueStandard, "-", 8,  37, 1.0, true, false, 100});
    metas.append({9,  "VecFMinFlag",             flagStandard + "；" + valueStandard, "-", 9,  38, 1.0, true, false, 100});
    metas.append({10, "VecFAvgFlag",             flagStandard + "；" + valueStandard, "-", 10, 39, 1.0, true, false, 100});
    metas.append({11, "AmplMMaxFlag",            flagStandard + "；" + valueStandard, "-", 11, 40, 1.0, true, false, 100});
    metas.append({12, "AmplMMinFlag",            flagStandard + "；" + valueStandard, "-", 12, 41, 1.0, true, false, 100});
    metas.append({13, "TrackErrMaxFlag",         flagStandard + "；" + valueStandard, "-", 13, 42, 1.0, true, false, 100});
    metas.append({14, "TrackErrMinFlag",         flagStandard + "；" + valueStandard, "-", 14, 43, 1.0, true, false, 100});
    metas.append({15, "SinAmplMaxFlag",          flagStandard + "；" + valueStandard, "-", 15, 44, 1.0, true, false, 100});
    metas.append({16, "SinAmplMinFlag",          flagStandard + "；" + valueStandard, "-", 16, 45, 1.0, true, false, 100});
    metas.append({17, "SinAvgFlag",              flagStandard + "；" + valueStandard, "-", 17, 46, 1.0, true, false, 100});
    metas.append({18, "SinAdjCoefFlag",          flagStandard + "；" + valueStandard, "-", 18, 47, 1.0, true, false, 100});
    metas.append({19, "CosAmplMaxFlag",          flagStandard + "；" + valueStandard, "-", 19, 48, 1.0, true, false, 100});
    metas.append({20, "CosAmplMinFlag",          flagStandard + "；" + valueStandard, "-", 20, 49, 1.0, true, false, 100});
    metas.append({21, "CosAvgFlag",              flagStandard + "；" + valueStandard, "-", 21, 50, 1.0, true, false, 100});
    metas.append({22, "CosAdjCoefFlag",          flagStandard + "；" + valueStandard, "-", 22, 51, 1.0, true, false, 100});
    metas.append({23, "SinPosAmplMaxFlag",       flagStandard + "；" + valueStandard, "-", 23, 52, 1.0, true, false, 100});
    metas.append({24, "SinPosAmplMinFlag",       flagStandard + "；" + valueStandard, "-", 24, 53, 1.0, true, false, 100});
    metas.append({25, "SinNegAmplMaxFlag",       flagStandard + "；" + valueStandard, "-", 25, 54, 1.0, true, false, 100});
    metas.append({26, "SinNegAmplMinFlag",       flagStandard + "；" + valueStandard, "-", 26, 55, 1.0, true, false, 100});
    metas.append({27, "CosPosAmplMaxFlag",       flagStandard + "；" + valueStandard, "-", 27, 56, 1.0, true, false, 100});
    metas.append({28, "CosPosAmplMinFlag",       flagStandard + "；" + valueStandard, "-", 28, 57, 1.0, true, false, 100});
    metas.append({29, "CosNegAmplMaxFlag",       flagStandard + "；" + valueStandard, "-", 29, 58, 1.0, true, false, 100});
    metas.append({30, "CosNegAmplMinFlag",       flagStandard + "；" + valueStandard, "-", 30, 59, 1.0, true, false, 100});
    metas.append({31, "PowerSupFlag",            flagStandard + "；" + valueStandard, "-", 31, 60, 1.0, true, false, 100});

    return metas;
}
