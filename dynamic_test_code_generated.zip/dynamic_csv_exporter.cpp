#include "dynamic_csv_exporter.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>

bool DynamicCsvExporter::exportResults(const QVector<DynamicProductResult> &results,
                                        const QString &filePath,
                                        QString *errorMessage)
{
    QFileInfo info(filePath);
    QDir dir = info.dir();

    if (!dir.exists()) {
        if (!dir.mkpath(".")) {
            if (errorMessage) {
                *errorMessage = QString("创建目录失败：%1").arg(dir.absolutePath());
            }
            return false;
        }
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QString("打开 CSV 文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream stream(&file);
    stream.setCodec("UTF-8");

    /*
     * UTF-8 BOM，方便 Excel 直接打开中文。
     */
    stream << QChar(0xFEFF);

    QStringList header;
    header << "测试时间"
           << "完成时间"
           << "产品位置"
           << "产品编码"
           << "通道"
           << "发送ID"
           << "接收ID"
           << "seed"
           << "groupCnt"
           << "检测进度"
           << "产品总结果"
           << "产品备注"
           << "检测项编号"
           << "检测项名称"
           << "合格标志seq"
           << "合格标志值"
           << "标志是否收到"
           << "标志校验"
           << "单项结果"
           << "检测值seq"
           << "原始检测值"
           << "显示检测值"
           << "单位"
           << "合格标准"
           << "单项备注";

    stream << header.join(",") << "\n";

    for (const DynamicProductResult &product : results) {
        for (const DynamicItemResult &item : product.itemResults) {
            QStringList row;

            row << escapeCsv(product.startTime)
                << escapeCsv(product.finishTime)
                << escapeCsv(QString("位置%1").arg(product.productId))
                << escapeCsv(product.productCode)
                << escapeCsv(product.channelName)
                << escapeCsv(canIdText(product.txId))
                << escapeCsv(canIdText(product.rxId))
                << QString::number(product.seed)
                << QString::number(product.groupCnt)
                << QString::number(product.detectProgress)
                << escapeCsv(passText(product.pass))
                << escapeCsv(product.message)
                << QString::number(item.itemNo)
                << escapeCsv(item.itemName)
                << QString::number(item.flagSeq)
                << QString::number(item.flagValue)
                << escapeCsv(boolText(item.flagReceived))
                << escapeCsv(boolText(item.flagCheckOk))
                << escapeCsv(passText(item.pass))
                << QString::number(item.valueSeq)
                << QString::number(item.rawValue)
                << QString::number(item.displayValue, 'f', 3)
                << escapeCsv(item.unit)
                << escapeCsv(item.standardText)
                << escapeCsv(item.message);

            stream << row.join(",") << "\n";
        }
    }

    file.close();
    return true;
}

QString DynamicCsvExporter::makeDefaultFileName(const QString &directory,
                                                const QString &prefix)
{
    QDir dir(directory);
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    const QString timeText =
            QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");

    return dir.filePath(QString("%1_%2.csv").arg(prefix, timeText));
}

QString DynamicCsvExporter::escapeCsv(const QString &text)
{
    QString escaped = text;
    escaped.replace("\"", "\"\"");

    if (escaped.contains(",")
            || escaped.contains("\"")
            || escaped.contains("\n")
            || escaped.contains("\r")) {
        escaped = "\"" + escaped + "\"";
    }

    return escaped;
}

QString DynamicCsvExporter::boolText(bool value)
{
    return value ? "是" : "否";
}

QString DynamicCsvExporter::passText(bool pass)
{
    return pass ? "PASS" : "NG";
}

QString DynamicCsvExporter::canIdText(quint32 canId)
{
    return QString("0x%1").arg(canId, 3, 16, QLatin1Char('0')).toUpper();
}
