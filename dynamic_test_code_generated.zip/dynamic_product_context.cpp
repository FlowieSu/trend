#include "dynamic_product_context.h"

DynamicProductContext::DynamicProductContext()
{
    resetCache();
}

void DynamicProductContext::setup(const DynamicProtocol::ChannelConfig &channelConfig,
                                  const QString &productCode,
                                  int seed,
                                  const QVector<DynamicTestItemMeta> &itemMetas)
{
    reset();

    m_channelConfig = channelConfig;
    m_productCode = productCode;
    m_seed = seed & 0xFF;
    m_itemMetas = itemMetas;
    m_startTime = currentTimeText();
    m_configured = true;
}

void DynamicProductContext::reset()
{
    m_configured = false;
    m_channelConfig = DynamicProtocol::ChannelConfig();
    m_productCode.clear();

    m_seed = 0;
    m_groupCnt = 0;
    m_detectProgress = 0;

    m_finished = false;
    m_reported = false;

    m_groupCheckReceived = false;
    m_groupCheckPassed = false;

    m_startTime.clear();
    m_finishTime.clear();

    resetCache();
}

bool DynamicProductContext::handleFrame(quint32 canId,
                                        const QByteArray &data)
{
    if (!m_configured) {
        return false;
    }

    if (canId != m_channelConfig.rxId) {
        return false;
    }

    if (m_reported) {
        /*
         * 测试板在开始检测后会持续轮询发送数据。
         * 结果已上报后继续收到同 ID 数据，不再更新最终结果。
         */
        return true;
    }

    DynamicProtocol::ParsedFrame frame =
            DynamicProtocol::parseFrame(canId, data, m_seed);

    if (!frame.valid) {
        return true;
    }

    if (!frame.seedOk) {
        return true;
    }

    if (DynamicProtocol::isNormalDataSeq(frame.seq)) {
        applyNormalFrame(frame);
        return true;
    }

    if (DynamicProtocol::isGroupCheckSeq(frame.seq)) {
        applyGroupCheckFrame(frame);
        return true;
    }

    return true;
}

bool DynamicProductContext::isConfigured() const
{
    return m_configured;
}

bool DynamicProductContext::isFinished() const
{
    return m_finished;
}

bool DynamicProductContext::isReported() const
{
    return m_reported;
}

void DynamicProductContext::markReported()
{
    m_reported = true;
}

int DynamicProductContext::productId() const
{
    return m_channelConfig.productId;
}

QString DynamicProductContext::productCode() const
{
    return m_productCode;
}

quint32 DynamicProductContext::txId() const
{
    return m_channelConfig.txId;
}

quint32 DynamicProductContext::rxId() const
{
    return m_channelConfig.rxId;
}

int DynamicProductContext::seed() const
{
    return m_seed;
}

int DynamicProductContext::thresholdFlag() const
{
    return m_channelConfig.thresholdFlag;
}

int DynamicProductContext::groupCnt() const
{
    return m_groupCnt;
}

int DynamicProductContext::detectProgress() const
{
    return m_detectProgress;
}

int DynamicProductContext::receivedCount() const
{
    int count = 0;
    for (int i = 0; i <= 60; ++i) {
        if (m_received[i]) {
            ++count;
        }
    }
    return count;
}

int DynamicProductContext::checkOkCount() const
{
    int count = 0;
    for (int i = 0; i <= 60; ++i) {
        if (m_checkOk[i]) {
            ++count;
        }
    }
    return count;
}

DynamicProductResult DynamicProductContext::buildResult(const QString &message) const
{
    DynamicProductResult result;

    result.productId = m_channelConfig.productId;
    result.productCode = m_productCode;
    result.channelName = m_channelConfig.name;

    result.txId = m_channelConfig.txId;
    result.rxId = m_channelConfig.rxId;

    result.seed = m_seed;
    result.groupCnt = m_groupCnt;
    result.detectProgress = m_detectProgress;

    result.receivedCount = receivedCount();
    result.checkOkCount = checkOkCount();

    result.finished = m_finished;

    result.groupCheckReceived = m_groupCheckReceived;
    result.groupCheckPassed = m_groupCheckPassed;

    result.startTime = m_startTime;
    result.finishTime = m_finishTime.isEmpty() ? currentTimeText() : m_finishTime;

    for (const DynamicTestItemMeta &meta : m_itemMetas) {
        result.itemResults.append(buildItemResult(meta));
    }

    result.pass = calcProductPass(result.itemResults);

    if (!message.isEmpty()) {
        result.message = message;
    } else if (!result.finished) {
        result.message = "检测未完成";
    } else if (result.pass) {
        result.message = "动态检测合格";
    } else {
        result.message = "动态检测不合格";
    }

    return result;
}

void DynamicProductContext::resetCache()
{
    for (int i = 0; i <= 60; ++i) {
        m_values[i] = 0;
        m_received[i] = false;
        m_checkOk[i] = false;
    }

    /*
     * 协议：合格标志位默认 1，1 代表不合格。
     * 这里按 Excel 的 1~31 标志位初始化。
     * 如果现场确实存在 seq=0 标志位，也不会影响接收，收到后会覆盖。
     */
    for (int i = 1; i <= 31; ++i) {
        m_values[i] = 1;
    }
}

void DynamicProductContext::applyNormalFrame(const DynamicProtocol::ParsedFrame &frame)
{
    if (!frame.checkOk) {
        if (frame.seq >= 0 && frame.seq <= 60) {
            m_checkOk[frame.seq] = false;
        }
        return;
    }

    if (frame.seq >= 0 && frame.seq <= 60) {
        m_values[frame.seq] = frame.value;
        m_received[frame.seq] = true;
        m_checkOk[frame.seq] = true;
    }

    m_groupCnt = frame.groupCnt;

    if (DynamicProtocol::isDetectInProgressSeq(frame.seq)) {
        m_detectProgress = frame.value;

        if (m_detectProgress == DynamicProtocol::kDetectFinishedValue) {
            m_finished = true;

            if (m_finishTime.isEmpty()) {
                m_finishTime = currentTimeText();
            }
        }
    }
}

void DynamicProductContext::applyGroupCheckFrame(const DynamicProtocol::ParsedFrame &frame)
{
    m_groupCheckReceived = true;
    m_groupCnt = frame.groupCnt;

    const int calc = DynamicProtocol::calcGroupCheck(m_values,
                                                     m_seed,
                                                     frame.groupCnt);

    m_groupCheckPassed = (calc == frame.checkValue);
}

DynamicItemResult DynamicProductContext::buildItemResult(const DynamicTestItemMeta &meta) const
{
    DynamicItemResult item;

    item.itemNo = meta.itemNo;
    item.itemName = meta.itemName;
    item.standardText = meta.standardText;
    item.unit = meta.unit;

    item.flagSeq = meta.flagSeq;
    item.valueSeq = meta.valueSeq;

    if (meta.flagSeq >= 0 && meta.flagSeq <= 60) {
        item.flagValue = m_values[meta.flagSeq];
        item.flagReceived = m_received[meta.flagSeq];
        item.flagCheckOk = m_checkOk[meta.flagSeq];
    }

    if (meta.valueSeq >= 0 && meta.valueSeq <= 60) {
        item.rawValue = m_values[meta.valueSeq];
        item.valueReceived = m_received[meta.valueSeq];
        item.valueCheckOk = m_checkOk[meta.valueSeq];
        item.displayValue = static_cast<double>(item.rawValue) * meta.scale;
    }

    if (meta.isProgressItem) {
        item.pass = item.flagReceived
                    && item.flagCheckOk
                    && item.flagValue == meta.progressFinishedValue;

        if (!item.flagReceived) {
            item.message = "进度数据未收到";
        } else if (!item.flagCheckOk) {
            item.message = "进度数据校验失败";
        } else if (item.flagValue != meta.progressFinishedValue) {
            item.message = QString("检测未完成，当前进度=%1").arg(item.flagValue);
        } else {
            item.message = "检测完成";
        }

        item.rawValue = item.flagValue;
        item.displayValue = item.flagValue;
        return item;
    }

    const bool flagOk = item.flagReceived
                        && item.flagCheckOk
                        && item.flagValue == 0;

    bool valueOk = true;

    if (meta.valueSeq >= 0) {
        valueOk = item.valueReceived && item.valueCheckOk;
    }

    item.pass = flagOk && valueOk;

    if (!item.flagReceived) {
        item.message = "合格标志未收到";
    } else if (!item.flagCheckOk) {
        item.message = "合格标志校验失败";
    } else if (item.flagValue != 0) {
        item.message = "检测项不合格";
    } else if (meta.valueSeq >= 0 && !item.valueReceived) {
        item.message = "检测值未收到";
    } else if (meta.valueSeq >= 0 && !item.valueCheckOk) {
        item.message = "检测值校验失败";
    } else {
        item.message = "OK";
    }

    return item;
}

bool DynamicProductContext::calcProductPass(const QVector<DynamicItemResult> &items) const
{
    if (!m_finished) {
        return false;
    }

    for (const DynamicTestItemMeta &meta : m_itemMetas) {
        if (!meta.affectsProductPass) {
            continue;
        }

        for (const DynamicItemResult &item : items) {
            if (item.itemNo == meta.itemNo) {
                if (!item.pass) {
                    return false;
                }
                break;
            }
        }
    }

    return true;
}

QString DynamicProductContext::currentTimeText() const
{
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
}
