#include "daily_test_statistics.h"

#include <QDate>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QXmlStreamReader>

#include <algorithm>

DailyTestStatistics::DailyTestStatistics()
{
}

void DailyTestStatistics::loadToday()
{
    m_records.clear();

    /*
     * 从当天本地统计文件恢复记录。
     * 这样软件重启后，仍然可以识别当天已经测试过的条码。
     */
    QString error;
    loadFromExcelXml(&error);
}

void DailyTestStatistics::updateProduct(const QString &productCode,
                                        bool staticPass,
                                        bool dynamicPass,
                                        const QDateTime &time)
{
    const QString code = productCode.trimmed();

    if (code.isEmpty()) {
        return;
    }

    ProductDailyRecord record;
    record.time = time;
    record.productCode = code;
    record.staticPass = staticPass;
    record.dynamicPass = dynamicPass;
    record.finalPass = staticPass && dynamicPass;

    /*
     * 核心去重逻辑：
     * key = 产品编码。
     * 同一条码重复自动化测试，直接覆盖旧记录。
     */
    m_records[code] = record;
}

DailyTestSummary DailyTestStatistics::summary() const
{
    DailyTestSummary s;

    for (auto it = m_records.constBegin(); it != m_records.constEnd(); ++it) {
        const ProductDailyRecord &r = it.value();

        s.totalCount++;

        if (r.finalPass) {
            s.passCount++;
        } else {
            s.ngCount++;
        }

        if (r.staticPass) {
            s.staticPassCount++;
        } else {
            s.staticNgCount++;
        }

        if (r.dynamicPass) {
            s.dynamicPassCount++;
        } else {
            s.dynamicNgCount++;
        }
    }

    return s;
}

QVector<ProductDailyRecord> DailyTestStatistics::records() const
{
    QVector<ProductDailyRecord> list;

    for (auto it = m_records.constBegin(); it != m_records.constEnd(); ++it) {
        list.append(it.value());
    }

    std::sort(list.begin(), list.end(), [](const ProductDailyRecord &a,
                                           const ProductDailyRecord &b) {
        return a.time < b.time;
    });

    return list;
}

QString DailyTestStatistics::makeMonthDirPath() const
{
    const QDate today = QDate::currentDate();

    return QString("D:/电涡流测试结果/%1年%2月")
            .arg(today.year())
            .arg(today.month(), 2, 10, QChar('0'));
}

QString DailyTestStatistics::todayFilePath() const
{
    const QDate today = QDate::currentDate();

    /*
     * 使用 Excel XML 格式。
     * 扩展名 .xls，可以被 Excel/WPS 打开，并支持多个 Worksheet。
     */
    return QString("%1/%2测试结果.xls")
            .arg(makeMonthDirPath())
            .arg(today.toString("yyyyMMdd"));
}

QString DailyTestStatistics::escapeXml(const QString &text) const
{
    QString value = text;
    value.replace("&", "&amp;");
    value.replace("<", "&lt;");
    value.replace(">", "&gt;");
    value.replace("\"", "&quot;");
    value.replace("'", "&apos;");
    return value;
}

QString DailyTestStatistics::resultText(bool pass) const
{
    return pass ? "PASS" : "NG";
}

bool DailyTestStatistics::parseBoolResultText(const QString &text) const
{
    const QString value = text.trimmed().toUpper();

    return value == "PASS"
            || value == "OK"
            || value == "合格";
}

bool DailyTestStatistics::loadFromExcelXml(QString *errorMessage)
{
    const QString filePath = todayFilePath();

    QFile file(filePath);

    if (!file.exists()) {
        /*
         * 当天第一次启动软件，还没有统计文件，这是正常情况。
         */
        return true;
    }

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QString("打开当天统计文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QXmlStreamReader xml(&file);

    bool inProductSheet = false;
    bool inData = false;
    bool firstRowIsHeader = true;

    QString currentData;
    QStringList currentRowCells;

    auto commitRow = [&]() {
        if (!inProductSheet) {
            currentRowCells.clear();
            return;
        }

        if (currentRowCells.isEmpty()) {
            return;
        }

        /*
         * 第一行是表头：
         * 时间、产品编码、测试结果、阻容测试结果、动态测试结果
         */
        if (firstRowIsHeader) {
            firstRowIsHeader = false;
            currentRowCells.clear();
            return;
        }

        if (currentRowCells.size() < 5) {
            currentRowCells.clear();
            return;
        }

        ProductDailyRecord record;

        record.time = QDateTime::fromString(currentRowCells.value(0).trimmed(),
                                            "yyyy-MM-dd HH:mm:ss");

        if (!record.time.isValid()) {
            record.time = QDateTime::currentDateTime();
        }

        record.productCode = currentRowCells.value(1).trimmed();
        record.finalPass = parseBoolResultText(currentRowCells.value(2));
        record.staticPass = parseBoolResultText(currentRowCells.value(3));
        record.dynamicPass = parseBoolResultText(currentRowCells.value(4));

        if (!record.productCode.isEmpty()) {
            /*
             * 如果文件中意外存在重复条码，以最后读到的记录为准。
             */
            m_records[record.productCode] = record;
        }

        currentRowCells.clear();
    };

    while (!xml.atEnd()) {
        xml.readNext();

        if (xml.isStartElement()) {
            const QString name = xml.name().toString();

            if (name == "Worksheet") {
                QString worksheetName;

                const QXmlStreamAttributes attributes = xml.attributes();

                for (const QXmlStreamAttribute &attribute : attributes) {
                    if (attribute.name().toString() == "Name") {
                        worksheetName = attribute.value().toString();
                        break;
                    }
                }

                inProductSheet = worksheetName == "当日测试产品信息";
                firstRowIsHeader = true;
            } else if (name == "Row") {
                currentRowCells.clear();
            } else if (name == "Data") {
                inData = true;
                currentData.clear();
            }
        } else if (xml.isCharacters()) {
            if (inData) {
                currentData += xml.text().toString();
            }
        } else if (xml.isEndElement()) {
            const QString name = xml.name().toString();

            if (name == "Data") {
                inData = false;
                currentRowCells << currentData;
                currentData.clear();
            } else if (name == "Row") {
                commitRow();
            } else if (name == "Worksheet") {
                inProductSheet = false;
            }
        }
    }

    if (xml.hasError()) {
        if (errorMessage) {
            *errorMessage = QString("解析当天统计文件失败：%1").arg(xml.errorString());
        }
        return false;
    }

    return true;
}

bool DailyTestStatistics::save(QString *errorMessage) const
{
    const QString dirPath = makeMonthDirPath();

    QDir dir;
    if (!dir.mkpath(dirPath)) {
        if (errorMessage) {
            *errorMessage = QString("创建统计目录失败：%1").arg(dirPath);
        }
        return false;
    }

    QFile file(todayFilePath());

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        if (errorMessage) {
            *errorMessage = QString("打开统计文件失败：%1").arg(file.errorString());
        }
        return false;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");

    const DailyTestSummary s = summary();
    const QVector<ProductDailyRecord> list = records();

    out << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    out << "<?mso-application progid=\"Excel.Sheet\"?>\n";
    out << "<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\n";
    out << " xmlns:o=\"urn:schemas-microsoft-com:office:office\"\n";
    out << " xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\n";
    out << " xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">\n";

    /*
     * sheet1：当日测试情况
     */
    out << "<Worksheet ss:Name=\"当日测试情况\">\n";
    out << "<Table>\n";

    out << "<Row>"
        << "<Cell><Data ss:Type=\"String\">日期</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">总测试数</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">PASS数量</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">NG数量</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">阻容PASS数量</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">阻容NG数量</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">动态PASS数量</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">动态NG数量</Data></Cell>"
        << "</Row>\n";

    out << "<Row>"
        << "<Cell><Data ss:Type=\"String\">" << QDate::currentDate().toString("yyyy-MM-dd") << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.totalCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.passCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.ngCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.staticPassCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.staticNgCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.dynamicPassCount << "</Data></Cell>"
        << "<Cell><Data ss:Type=\"Number\">" << s.dynamicNgCount << "</Data></Cell>"
        << "</Row>\n";

    out << "</Table>\n";
    out << "</Worksheet>\n";

    /*
     * sheet2：当日测试产品信息
     */
    out << "<Worksheet ss:Name=\"当日测试产品信息\">\n";
    out << "<Table>\n";

    out << "<Row>"
        << "<Cell><Data ss:Type=\"String\">时间</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">产品编码</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">测试结果</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">阻容测试结果</Data></Cell>"
        << "<Cell><Data ss:Type=\"String\">动态测试结果</Data></Cell>"
        << "</Row>\n";

    for (const ProductDailyRecord &r : list) {
        out << "<Row>"
            << "<Cell><Data ss:Type=\"String\">" << r.time.toString("yyyy-MM-dd HH:mm:ss") << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << escapeXml(r.productCode) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << resultText(r.finalPass) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << resultText(r.staticPass) << "</Data></Cell>"
            << "<Cell><Data ss:Type=\"String\">" << resultText(r.dynamicPass) << "</Data></Cell>"
            << "</Row>\n";
    }

    out << "</Table>\n";
    out << "</Worksheet>\n";

    out << "</Workbook>\n";

    file.close();
    return true;
}
