# mainwindow.ui 直接替换版

这个 `mainwindow.ui` 基于当前量产主界面布局生成，已包含：

1. 固定写在 UI 里的当日统计 QLabel：
   - lblDailyTotalCount
   - lblDailyPassCount
   - lblDailyNgCount
   - lblDailyStaticPassCount
   - lblDailyStaticNgCount
   - lblDailyDynamicPassCount
   - lblDailyDynamicNgCount

2. 接插件插拔次数：
   - lblConnectorPlugCount
   已移动到进度条 progressTest 下方。

3. 三个量产按钮：
   - btnStartAutoTest
   - btnStopTest
   - btnEmergencyStop
   已设置为跨两行，minimumHeight=78，视觉上与位置1/位置2产品编码框总高度对齐。

4. 保留原有对象名：
   - groupBoxDevice / groupBoxCan / groupBoxProduct
   - editProductCode1 / editProductCode2
   - progressTest
   - lblCurrentTestStage
   - lblStaticOverallResult / lblDynamicOverallResult
   - tableStaticResults / tableDynamicResults
   - textLog

使用方式：
直接用本文件覆盖工程里的 `mainwindow.ui`，然后重新运行 qmake，清理并重新构建。

注意：
如果你的 `mainwindow.cpp` 里还在调用旧的 `initDailyCounterUi()`，需要改成调用：
`initDailyStatisticsUi()`。
