# MainWindow 单圈测试 + 固定UI计数 + 按条码去重统计整合补丁

基于你上传的 `daily_counter_overall_label_manual_standard_patch` 生成。

## 修改文件

```text
modified_files/mainwindow.h
modified_files/mainwindow.cpp
modified_files/mainwindow.ui
```

## 本次改动

### 1. 删除旧的动态计数 QLabel

删除/不再使用：

```text
initDailyCounterUi()
loadDailyCounters()
saveDailyCounters()
resetDailyCountersForToday()
checkDailyCounterDate()
refreshDailyCounterLabel()
updateDailyCountersAfterAutoTest()
m_dailyCounterLabel
m_dailyCounterTimer
m_dailyTotalCount / m_dailyGoodCount / m_dailyBadCount ...
```

### 2. 改为 UI 固定 QLabel

`mainwindow.ui` 中已固定增加：

```text
lblDailyTotalCount
lblDailyPassCount
lblDailyNgCount
lblDailyStaticPassCount
lblDailyStaticNgCount
lblDailyDynamicPassCount
lblDailyDynamicNgCount
```

`mainwindow.cpp` 使用：

```text
initDailyStatisticsUi()
refreshDailyStatisticsUi()
updateDailyStatisticsAfterAutoTest(...)
```

### 3. 按条码唯一性去重计数

使用你已加入工程的 `DailyTestStatistics`：

```cpp
m_dailyStatistics.updateProduct(code, staticPass, dynamicPass, now);
```

同一条码重复测试时覆盖旧记录，所以：

```text
同一条码多次 NG：NG 数量只算 1
同一条码最后 PASS：NG -1，PASS +1
```

### 4. 只统计自动化测试

只有自动化测试链路 `onDynamicAllFinished()` 中会调用：

```cpp
updateDailyStatisticsAfterAutoTest(m_dynamicResults);
```

手动阻容、手动动态不会增加统计计数。

### 5. 单圈/双圈兼容

```text
位置2条码为空：单圈模式
位置1、位置2都有条码：双圈模式
```

单圈模式：

```text
阻容只测位置1
动态调用 startSingleProductTest(... Channel110 ...)
阻容CSV只保存位置1
统计只统计位置1
```

注意：本补丁假设你的 `DynamicTestController` 已经按前面方案增加了：

```cpp
startSingleProductTest(...)
```

你的 `TestRunner` 已经有：

```cpp
runStaticTestsForProduct(...)
```

### 6. UI 里直接调整按钮高度

`mainwindow.ui` 中三个按钮已跨两行：

```text
btnStartAutoTest
btnStopTest
btnEmergencyStop
```

不需要 `setupProductionButtonGeometry()` 函数。

## 使用方式

1. 用 `modified_files` 中三个文件覆盖工程同名文件；
2. 确认 `.pro` 中已加入：
   ```text
   daily_test_statistics.cpp
   daily_test_statistics.h
   ```
3. 重新运行 qmake；
4. 清理项目；
5. 重新构建。

如果编译报 `startSingleProductTest` 不存在，说明你的 `DynamicTestController` 还没有合并单圈动态测试接口。
