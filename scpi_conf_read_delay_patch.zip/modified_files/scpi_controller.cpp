#include "scpi_controller.h"

#include <QElapsedTimer>
#include <QRegularExpression>
#include <QThread>
#include <QtGlobal>
#include <cmath>

namespace
{
constexpr int SCPI_WRITE_TIMEOUT_MS = 1000;
constexpr int SCPI_BUFFER_CLEAR_WAIT_MS = 50;
constexpr int RESISTANCE_MODE_SETTLE_DELAY_MS = 300;
constexpr int CAPACITANCE_MODE_SETTLE_DELAY_MS = 1000;

const char *SCPI_CONF_RESISTANCE = "CONF:RES";
const char *SCPI_CONF_CAPACITANCE = "CONF:CAP";
const char *SCPI_READ = "READ?";
}

SCPIController::SCPIController(QObject *parent)
    : QObject(parent),
      m_socket(new QTcpSocket(this))
{
}

SCPIController::~SCPIController()
{
    disconnectInstrument();
}

bool SCPIController::connectInstrument(const QString &visaAddress)
{
    clearLastError();

    disconnectInstrument();

    m_address = visaAddress.trimmed();

    if (m_address.isEmpty()) {
        setLastError("万用表/电桥地址为空。");
        return false;
    }

    if (m_address.compare("SIM", Qt::CaseInsensitive) == 0 ||
            m_address.compare("DEMO", Qt::CaseInsensitive) == 0) {
        m_simulationMode = true;
        emit logMessage("SCPI 仿真模式已连接。");
        emit connectedChanged(true);
        return true;
    }

    m_simulationMode = false;

    if (!connectTcpip(m_address)) {
        emit connectedChanged(false);
        return false;
    }

    emit connectedChanged(true);
    return true;
}

void SCPIController::disconnectInstrument()
{
    m_simulationMode = false;

    if (m_socket) {
        if (m_socket->state() != QAbstractSocket::UnconnectedState) {
            m_socket->disconnectFromHost();
            m_socket->waitForDisconnected(100);
        }
    }

    emit connectedChanged(false);
}

bool SCPIController::isConnected() const
{
    if (m_simulationMode) {
        return true;
    }

    return m_socket &&
            m_socket->state() == QAbstractSocket::ConnectedState;
}

bool SCPIController::ping()
{
    clearLastError();

    if (m_simulationMode) {
        emit logMessage("SCPI 仿真模式 ping 成功。");
        return true;
    }

    QString response;

    if (!query("*IDN?", &response, 1000)) {
        return false;
    }

    emit logMessage(QString("SCPI 设备响应：%1").arg(response.trimmed()));
    return true;
}

double SCPIController::measureResistance(int timeoutMs)
{
    clearLastError();

    if (m_simulationMode) {
        return 10000.0;
    }

    /*
     * 采用“配置模式 + 等待稳定 + READ?”的方式，避免 MEAS:RES? 直接返回旧值。
     * timeoutMs 只表示 READ? 最长等待回复时间，不表示强制延时。
     */
    if (!configureMeasurementMode(SCPI_CONF_RESISTANCE,
                                  RESISTANCE_MODE_SETTLE_DELAY_MS,
                                  SCPI_WRITE_TIMEOUT_MS)) {
        return qQNaN();
    }

    QString response;

    if (!query(SCPI_READ, &response, timeoutMs)) {
        return qQNaN();
    }

    emit logMessage(QString("电阻 READ? 原始返回：%1").arg(response));

    bool ok = false;
    const double value = parseDoubleResponse(response, &ok);

    if (!ok) {
        setLastError(QString("电阻测量响应无法解析：%1").arg(response));
        return qQNaN();
    }

    return value;
}

double SCPIController::measureCapacitance(int timeoutMs)
{
    clearLastError();

    if (m_simulationMode) {
        return 2.2e-9;
    }

    /*
     * 采用“配置模式 + 等待稳定 + READ?”的方式，避免 MEAS:CAP? 直接返回旧值。
     * timeoutMs 只表示 READ? 最长等待回复时间，不表示强制延时。
     */
    if (!configureMeasurementMode(SCPI_CONF_CAPACITANCE,
                                  CAPACITANCE_MODE_SETTLE_DELAY_MS,
                                  SCPI_WRITE_TIMEOUT_MS)) {
        return qQNaN();
    }

    QString response;

    if (!query(SCPI_READ, &response, timeoutMs)) {
        return qQNaN();
    }

    emit logMessage(QString("电容 READ? 原始返回：%1").arg(response));

    bool ok = false;
    const double value = parseDoubleResponse(response, &ok);

    if (!ok) {
        setLastError(QString("电容测量响应无法解析：%1").arg(response));
        return qQNaN();
    }

    return value;
}

QString SCPIController::lastError() const
{
    return m_lastError;
}

bool SCPIController::connectTcpip(const QString &address)
{
    const QString host = parseTcpipHost(address);

    if (host.isEmpty()) {
        setLastError(QString("当前 SCPIController 仅支持 TCPIP/LAN 或 SIM 地址，当前地址：%1").arg(address));
        return false;
    }

    m_socket->connectToHost(host, 5025);

    if (!m_socket->waitForConnected(2000)) {
        setLastError(QString("SCPI TCP连接失败：host=%1，error=%2")
                     .arg(host)
                     .arg(m_socket->errorString()));
        return false;
    }

    emit logMessage(QString("SCPI TCP已连接：%1:5025").arg(host));
    return true;
}

QString SCPIController::parseTcpipHost(const QString &address) const
{
    const QString text = address.trimmed();

    /*
     * VISA TCPIP 格式：
     *   TCPIP0::192.168.1.100::inst0::INSTR
     *   TCPIP::192.168.1.100::5025::SOCKET
     */
    QRegularExpression visaRegex("^TCPIP\\d*::([^:]+)(::.*)?$",
                                 QRegularExpression::CaseInsensitiveOption);
    QRegularExpressionMatch match = visaRegex.match(text);

    if (match.hasMatch()) {
        return match.captured(1);
    }

    /*
     * 直接 IP 或主机名。
     */
    QRegularExpression ipOrHostRegex("^[A-Za-z0-9_.-]+$");

    if (ipOrHostRegex.match(text).hasMatch()) {
        return text;
    }

    return QString();
}

bool SCPIController::sendCommand(const QString &command, int timeoutMs)
{
    if (!isConnected()) {
        setLastError("SCPI 设备未连接。");
        return false;
    }

    QByteArray data = command.trimmed().toLatin1();
    data.append('\n');

    const qint64 written = m_socket->write(data);

    if (written != data.size()) {
        setLastError(QString("SCPI 命令写入失败：%1").arg(command));
        return false;
    }

    if (!m_socket->waitForBytesWritten(timeoutMs)) {
        setLastError(QString("SCPI 命令发送超时：%1").arg(command));
        return false;
    }

    return true;
}

bool SCPIController::query(const QString &command,
                           QString *response,
                           int timeoutMs)
{
    if (response) {
        response->clear();
    }

    /*
     * 查询前清一次输入缓存，避免读到上一条 READ?/MEAS? 的残留响应。
     */
    clearReadBuffer(SCPI_BUFFER_CLEAR_WAIT_MS);

    if (!sendCommand(command, timeoutMs)) {
        return false;
    }

    QByteArray buffer;

    while (true) {
        if (!m_socket->waitForReadyRead(timeoutMs)) {
            break;
        }

        buffer.append(m_socket->readAll());

        if (buffer.contains('\n')) {
            break;
        }
    }

    if (buffer.isEmpty()) {
        setLastError(QString("SCPI 查询无响应：%1").arg(command));
        return false;
    }

    if (response) {
        *response = QString::fromLatin1(buffer).trimmed();
    }

    return true;
}

bool SCPIController::clearReadBuffer(int maxWaitMs)
{
    if (m_simulationMode) {
        return true;
    }

    if (!m_socket ||
            m_socket->state() != QAbstractSocket::ConnectedState) {
        return false;
    }

    QElapsedTimer timer;
    timer.start();

    while (timer.elapsed() < maxWaitMs) {
        if (m_socket->bytesAvailable() > 0) {
            const QByteArray dropped = m_socket->readAll();

            if (!dropped.isEmpty()) {
                emit logMessage(QString("已清空SCPI残留响应：%1")
                                .arg(QString::fromLatin1(dropped).trimmed()));
            }

            continue;
        }

        if (!m_socket->waitForReadyRead(10)) {
            break;
        }
    }

    return true;
}

bool SCPIController::configureMeasurementMode(const QString &command,
                                              int settleDelayMs,
                                              int timeoutMs)
{
    /*
     * 顺序：
     * 1. 清空仪器输入缓存；
     * 2. 发送 CONF:RES / CONF:CAP；
     * 3. 等待仪器模式和内部采样稳定；
     * 4. 后续由 READ? 触发读取。
     */
    clearReadBuffer(SCPI_BUFFER_CLEAR_WAIT_MS);

    if (!sendCommand(command, timeoutMs)) {
        return false;
    }

    emit logMessage(QString("已发送SCPI配置命令：%1，等待%2 ms后读取。")
                    .arg(command)
                    .arg(settleDelayMs));

    if (settleDelayMs > 0) {
        QThread::msleep(static_cast<unsigned long>(settleDelayMs));
    }

    return true;
}

double SCPIController::parseDoubleResponse(const QString &response,
                                           bool *ok) const
{
    QString text = response.trimmed();

    const int commaIndex = text.indexOf(',');

    if (commaIndex >= 0) {
        text = text.left(commaIndex).trimmed();
    }

    bool localOk = false;
    const double value = text.toDouble(&localOk);

    if (ok) {
        *ok = localOk;
    }

    return value;
}

void SCPIController::setLastError(const QString &error)
{
    m_lastError = error;

    if (!error.isEmpty()) {
        emit logMessage(error);
    }
}

void SCPIController::clearLastError()
{
    m_lastError.clear();
}
