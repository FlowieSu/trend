#ifndef SCPI_CONTROLLER_H
#define SCPI_CONTROLLER_H

#include <QObject>
#include <QString>
#include <QTcpSocket>

/*
 * SCPIController
 *
 * 当前项目的万用表/电桥 SCPI 控制类。
 *
 * 为了不强依赖 NI-VISA / Keysight VISA SDK，本版本实现：
 *   1. TCPIP/LAN SCPI：例如 TCPIP0::192.168.1.100::inst0::INSTR
 *   2. 直接 IP：例如 192.168.1.100
 *   3. SIM / DEMO 仿真地址：用于无仪器编译和流程调试
 *
 * 如果现场使用 USBTMC/GPIB VISA 地址，建议用你本地原 VISA 版本替换本文件，
 * 或在本类中增加 visa.h / viOpen / viPrintf / viScanf 实现。
 */

class SCPIController : public QObject
{
    Q_OBJECT

public:
    explicit SCPIController(QObject *parent = nullptr);
    ~SCPIController() override;

    bool connectInstrument(const QString &visaAddress);
    void disconnectInstrument();

    bool isConnected() const;
    bool ping();

    double measureResistance(int timeoutMs);
    double measureCapacitance(int timeoutMs);

    QString lastError() const;

signals:
    void logMessage(const QString &message);
    void connectedChanged(bool connected);

private:
    bool connectTcpip(const QString &address);
    QString parseTcpipHost(const QString &address) const;

    bool sendCommand(const QString &command, int timeoutMs);
    bool query(const QString &command, QString *response, int timeoutMs);

    bool clearReadBuffer(int maxWaitMs = 50);
    bool configureMeasurementMode(const QString &command,
                                  int settleDelayMs,
                                  int timeoutMs);

    double parseDoubleResponse(const QString &response, bool *ok) const;

    void setLastError(const QString &error);
    void clearLastError();

private:
    QTcpSocket *m_socket = nullptr;

    QString m_address;
    QString m_lastError;

    bool m_simulationMode = false;
};

#endif // SCPI_CONTROLLER_H
