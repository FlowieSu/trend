#include "manualstatictestwindow.h"
#include "ui_manualstatictestwindow.h"

#include "mitsubishi_plc.h"
#include "scpi_controller.h"

#include <QCloseEvent>
#include <QDateTime>
#include <QMessageBox>
#include <QTableWidgetItem>
#include <QHeaderView>
#include <QThread>

#include <cmath>

namespace
{
constexpr int M_RES_CAP_ENABLE = 19;
constexpr int M_POSITION_SELECT = 20;
constexpr int M_RESET_CHANNEL = 100;

constexpr int Y_DYNAMIC_MODE = 26;
constexpr int Y_SERVO_POWER = 27;

constexpr int STATIC_RESET_DELAY_MS = 150;
constexpr int RELAY_ACTION_DELAY_MS = 50;
constexpr int RELAY_STABLE_DELAY_MS = 500;

enum ResultColumn
{
    COL_TIME = 0,
    COL_POSITION,
    COL_TEST_ITEM,
    COL_DIRECTION,
    COL_M_POINTS,
    COL_MEASURE_TYPE,
    COL_VALUE,
    COL_MESSAGE,
    COL_COUNT
};
}

ManualStaticTestWindow::ManualStaticTestWindow(MitsubishiPLC *plc,
                                               SCPIController *dmm,
                                               QWidget *parent)
    : QWidget(parent),
      ui(new Ui::ManualStaticTestWindow),
      m_plc(plc),
      m_dmm(dmm)
{
    ui->setupUi(this);

    initTestItems();
    initUiState();
    initResultTable();
    initConnections();

    appendLog("手动阻容测试窗口已打开。");

    /*
     * 打开手动阻容测试窗口时，先强制进入阻容测试安全状态。
     */
    prepareStaticMode();
}

ManualStaticTestWindow::~ManualStaticTestWindow()
{
    delete ui;
}

void ManualStaticTestWindow::initTestItems()
{
    m_testItems.clear();

    /*
     * 方向说明：
     * 红黑：按红表笔/黑表笔方向接通；
     * 黑红：红黑反向。
     *
     * 若现场 5V->GND 的黑红方向与这里不同，只需要修改最后一项的
     * blackRed.mPoints。
     */
    m_testItems.append({
        "sin+ -> sin-",
        {"红黑", {3, 6}},
        {"黑红", {4, 5}}
    });

    m_testItems.append({
        "cos+ -> cos-",
        {"红黑", {7, 12}},
        {"黑红", {10, 11}}
    });

    m_testItems.append({
        "GND -> sin+",
        {"红黑", {1, 4}},
        {"黑红", {2, 3}}
    });

    m_testItems.append({
        "GND -> sin-",
        {"红黑", {1, 6}},
        {"黑红", {2, 5}}
    });

    m_testItems.append({
        "GND -> cos+",
        {"红黑", {1, 10}},
        {"黑红", {2, 7}}
    });

    m_testItems.append({
        "GND -> cos-",
        {"红黑", {1, 12}},
        {"黑红", {2, 11}}
    });

    m_testItems.append({
        "5V -> GND",
        {"红黑", {0, 1}},
        {"黑红", {0, 2}}
    });
}

void ManualStaticTestWindow::initUiState()
{
    setWindowTitle("手动阻容测试");

    ui->comboTestItem->clear();

    for (const TestItem &item : m_testItems) {
        ui->comboTestItem->addItem(item.name);
    }

    ui->radioPos1->setChecked(true);
    ui->radioRedBlack->setChecked(true);

    ui->lblCurrentMPoints->setText("-");
    ui->lblResistanceValue->setText("-");
    ui->lblCapacitanceValue->setText("-");
    ui->lblStatus->setText("待接通");

    setChannelReady(false);
}

void ManualStaticTestWindow::initResultTable()
{
    ui->tableResults->clear();
    ui->tableResults->setColumnCount(COL_COUNT);
    ui->tableResults->setRowCount(0);

    QStringList headers;
    headers << "时间"
            << "位置"
            << "测试项"
            << "方向"
            << "M点"
            << "测量类型"
            << "测量值"
            << "备注";

    ui->tableResults->setHorizontalHeaderLabels(headers);
    ui->tableResults->horizontalHeader()->setStretchLastSection(true);
    ui->tableResults->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableResults->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableResults->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableResults->setAlternatingRowColors(true);
}

void ManualStaticTestWindow::initConnections()
{
    connect(ui->btnApplyChannel,
            &QPushButton::clicked,
            this,
            &ManualStaticTestWindow::onApplyChannel);

    connect(ui->btnMeasureResistance,
            &QPushButton::clicked,
            this,
            &ManualStaticTestWindow::onMeasureResistance);

    connect(ui->btnMeasureCapacitance,
            &QPushButton::clicked,
            this,
            &ManualStaticTestWindow::onMeasureCapacitance);

    connect(ui->btnResetChannel,
            &QPushButton::clicked,
            this,
            &ManualStaticTestWindow::onResetChannel);

    connect(ui->btnClearLog,
            &QPushButton::clicked,
            this,
            &ManualStaticTestWindow::onClearLog);

    connect(ui->btnClose,
            &QPushButton::clicked,
            this,
            &ManualStaticTestWindow::onCloseClicked);

    connect(ui->comboTestItem,
            QOverload<int>::of(&QComboBox::currentIndexChanged),
            this,
            &ManualStaticTestWindow::onSelectionChanged);

    connect(ui->radioPos1,
            &QRadioButton::toggled,
            this,
            &ManualStaticTestWindow::onSelectionChanged);

    connect(ui->radioPos2,
            &QRadioButton::toggled,
            this,
            &ManualStaticTestWindow::onSelectionChanged);

    connect(ui->radioRedBlack,
            &QRadioButton::toggled,
            this,
            &ManualStaticTestWindow::onSelectionChanged);

    connect(ui->radioBlackRed,
            &QRadioButton::toggled,
            this,
            &ManualStaticTestWindow::onSelectionChanged);
}

bool ManualStaticTestWindow::checkReady()
{
    if (!m_plc) {
        QMessageBox::warning(this, "提示", "PLC对象为空，无法执行手动阻容测试。");
        return false;
    }

    if (!m_plc->isConnected()) {
        QMessageBox::warning(this, "提示", "PLC未连接，请先在主界面连接PLC。");
        return false;
    }

    if (!m_dmm) {
        QMessageBox::warning(this, "提示", "万用表/电桥对象为空，无法测量。");
        return false;
    }

    if (!m_dmm->isConnected()) {
        QMessageBox::warning(this, "提示", "万用表/电桥未连接，请先在主界面连接设备。");
        return false;
    }

    return true;
}

bool ManualStaticTestWindow::prepareStaticMode()
{
    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法切换到阻容测试模式。");
        return false;
    }

    appendLog("准备阻容测试模式：Y27 OFF，Y26 OFF，M19 OFF，M100复位。");

    /*
     * 手动阻容测试前，必须先关伺服，再切回阻容线路。
     */
    if (!setServoPower(false)) {
        return false;
    }

    if (!setDynamicMode(false)) {
        return false;
    }

    return resetStaticChannels();
}

bool ManualStaticTestWindow::resetStaticChannels()
{
    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法复位阻容通道。");
        return false;
    }

    appendLog("复位阻容测试通道：M19 OFF，M100 脉冲。");

    if (!m_plc->setMRelay(M_RES_CAP_ENABLE, false)) {
        appendLog(QString("M19 OFF 失败：%1").arg(m_plc->lastError()));
        return false;
    }

    if (!m_plc->pulseMRelay(M_RESET_CHANNEL, 100)) {
        appendLog(QString("M100 脉冲复位失败：%1").arg(m_plc->lastError()));
        return false;
    }

    QThread::msleep(STATIC_RESET_DELAY_MS);

    setChannelReady(false);
    ui->lblStatus->setText("已复位");
    ui->lblCurrentMPoints->setText("-");

    return true;
}

bool ManualStaticTestWindow::applySelectedChannel()
{
    if (!checkReady()) {
        return false;
    }

    if (!prepareStaticMode()) {
        return false;
    }

    const int position = selectedPosition();
    const DirectionConfig direction = selectedDirection();

    appendLog(QString("准备接通通道：%1，%2，%3，M点=%4。")
              .arg(positionText(position))
              .arg(ui->comboTestItem->currentText())
              .arg(direction.name)
              .arg(mPointsText(direction.mPoints)));

    /*
     * M20 选择测试位置：
     * OFF = 位置1
     * ON  = 位置2
     */
    if (!m_plc->setMRelay(M_POSITION_SELECT, position == 2)) {
        appendLog(QString("M20 设置失败：%1").arg(m_plc->lastError()));
        return false;
    }

    QThread::msleep(RELAY_ACTION_DELAY_MS);

    /*
     * 先接通具体 M 点，最后打开 M19 总使能。
     */
    for (int mNumber : direction.mPoints) {
        if (!m_plc->setMRelay(mNumber, true)) {
            appendLog(QString("M%1 ON 失败：%2")
                      .arg(mNumber)
                      .arg(m_plc->lastError()));
            return false;
        }

        QThread::msleep(RELAY_ACTION_DELAY_MS);
    }

    if (!m_plc->setMRelay(M_RES_CAP_ENABLE, true)) {
        appendLog(QString("M19 ON 失败：%1").arg(m_plc->lastError()));
        return false;
    }

    appendLog(QString("继电器通道已接通，等待%1 ms稳定。").arg(RELAY_STABLE_DELAY_MS));
    QThread::msleep(RELAY_STABLE_DELAY_MS);

    setChannelReady(true);

    ui->lblStatus->setText("通道已接通");
    ui->lblCurrentMPoints->setText(mPointsText(direction.mPoints));

    appendLog("通道接通完成，可以测电阻或测电容。");
    return true;
}

bool ManualStaticTestWindow::setDynamicMode(bool on)
{
    appendLog(QString("设置 Y26 = %1，%2。")
              .arg(on ? "ON" : "OFF")
              .arg(on ? "切换到动态测试线路" : "切换回阻容测试线路"));

    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法设置 Y26。");
        return false;
    }

    if (!m_plc->setYRelay(Y_DYNAMIC_MODE, on)) {
        appendLog(QString("Y26 设置失败：%1").arg(m_plc->lastError()));
        return false;
    }

    return true;
}

bool ManualStaticTestWindow::setServoPower(bool on)
{
    appendLog(QString("设置 Y27 = %1，%2。")
              .arg(on ? "ON" : "OFF")
              .arg(on ? "打开伺服电机" : "关闭伺服电机"));

    if (!m_plc || !m_plc->isConnected()) {
        appendLog("PLC未连接，无法设置 Y27。");
        return false;
    }

    if (!m_plc->setYRelay(Y_SERVO_POWER, on)) {
        appendLog(QString("Y27 设置失败：%1").arg(m_plc->lastError()));
        return false;
    }

    return true;
}

void ManualStaticTestWindow::onApplyChannel()
{
    applySelectedChannel();
}

void ManualStaticTestWindow::onMeasureResistance()
{
    if (!checkReady()) {
        return;
    }

    /*
     * 手动测量时也重新接通一次当前选择的通道，避免用户改了选择但未重新接通。
     */
    if (!applySelectedChannel()) {
        return;
    }

    appendLog("开始测量电阻。");

    const double resistanceOhm = m_dmm->measureResistance(10000);

    if (resistanceOhm < 0.0 || !std::isfinite(resistanceOhm)) {
        ui->lblResistanceValue->setText("测量失败");
        appendLog("电阻测量失败。");
        appendResultRow("电阻", -1.0, "kOhm", "测量失败");
        return;
    }

    const double resistanceKOhm = resistanceOhm / 1000.0;

    appendLog(QString("电阻换算：原始=%1 Ohm，显示=%2 kOhm。")
              .arg(resistanceOhm, 0, 'E', 8)
              .arg(resistanceKOhm, 0, 'f', 6));

    ui->lblResistanceValue->setText(QString("%1 kOhm")
                                    .arg(resistanceKOhm, 0, 'f', 6));

    appendLog(QString("电阻测量完成：%1 kOhm。")
              .arg(resistanceKOhm, 0, 'f', 6));

    appendResultRow("电阻", resistanceKOhm, "kOhm", "OK");
}

void ManualStaticTestWindow::onMeasureCapacitance()
{
    if (!checkReady()) {
        return;
    }

    /*
     * 手动测量时也重新接通一次当前选择的通道，避免用户改了选择但未重新接通。
     */
    if (!applySelectedChannel()) {
        return;
    }

    appendLog("开始测量电容。");

    const double capacitanceF = m_dmm->measureCapacitance(10000);

    if (capacitanceF < 0.0 || !std::isfinite(capacitanceF)) {
        ui->lblCapacitanceValue->setText("测量失败");
        appendLog("电容测量失败。");
        appendResultRow("电容", -1.0, "nF", "测量失败");
        return;
    }

    const double capacitanceNf = capacitanceF * 1000000000.0;

    appendLog(QString("电容换算：原始=%1 F，显示=%2 nF。")
              .arg(capacitanceF, 0, 'E', 8)
              .arg(capacitanceNf, 0, 'f', 6));

    ui->lblCapacitanceValue->setText(QString("%1 nF")
                                     .arg(capacitanceNf, 0, 'f', 6));

    appendLog(QString("电容测量完成：%1 nF。")
              .arg(capacitanceNf, 0, 'f', 6));

    appendResultRow("电容", capacitanceNf, "nF", "OK");
}

void ManualStaticTestWindow::onResetChannel()
{
    resetStaticChannels();
}

void ManualStaticTestWindow::onClearLog()
{
    ui->textLog->clear();
}

void ManualStaticTestWindow::onCloseClicked()
{
    close();
}

void ManualStaticTestWindow::onSelectionChanged()
{
    setChannelReady(false);

    const DirectionConfig direction = selectedDirection();
    ui->lblCurrentMPoints->setText(mPointsText(direction.mPoints));
    ui->lblStatus->setText("选择已变化，需重新接通");
}

int ManualStaticTestWindow::selectedPosition() const
{
    return ui->radioPos2->isChecked() ? 2 : 1;
}

int ManualStaticTestWindow::selectedTestIndex() const
{
    const int index = ui->comboTestItem->currentIndex();

    if (index < 0 || index >= m_testItems.size()) {
        return 0;
    }

    return index;
}

ManualStaticTestWindow::DirectionConfig ManualStaticTestWindow::selectedDirection() const
{
    const int index = selectedTestIndex();
    const TestItem &item = m_testItems[index];

    return ui->radioBlackRed->isChecked() ? item.blackRed : item.redBlack;
}

QString ManualStaticTestWindow::positionText(int position) const
{
    return position == 2 ? "位置2" : "位置1";
}

QString ManualStaticTestWindow::mPointsText(const QVector<int> &mPoints) const
{
    QStringList list;

    for (int mNumber : mPoints) {
        list << QString("M%1").arg(mNumber);
    }

    return list.join(" + ");
}

QString ManualStaticTestWindow::formatValue(double value, int precision) const
{
    if (value < 0.0 || !std::isfinite(value)) {
        return "-";
    }

    return QString::number(value, 'f', precision);
}

void ManualStaticTestWindow::appendResultRow(const QString &measureType,
                                             double displayValue,
                                             const QString &unit,
                                             const QString &message)
{
    const int row = ui->tableResults->rowCount();
    ui->tableResults->insertRow(row);

    const int position = selectedPosition();
    const DirectionConfig direction = selectedDirection();

    const QString timeText = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    const QString valueText = displayValue >= 0.0
            ? QString("%1 %2").arg(displayValue, 0, 'f', 6).arg(unit)
            : "-";

    ui->tableResults->setItem(row, COL_TIME, new QTableWidgetItem(timeText));
    ui->tableResults->setItem(row, COL_POSITION, new QTableWidgetItem(positionText(position)));
    ui->tableResults->setItem(row, COL_TEST_ITEM, new QTableWidgetItem(ui->comboTestItem->currentText()));
    ui->tableResults->setItem(row, COL_DIRECTION, new QTableWidgetItem(direction.name));
    ui->tableResults->setItem(row, COL_M_POINTS, new QTableWidgetItem(mPointsText(direction.mPoints)));
    ui->tableResults->setItem(row, COL_MEASURE_TYPE, new QTableWidgetItem(measureType));
    ui->tableResults->setItem(row, COL_VALUE, new QTableWidgetItem(valueText));
    ui->tableResults->setItem(row, COL_MESSAGE, new QTableWidgetItem(message));

    ui->tableResults->scrollToBottom();
}

void ManualStaticTestWindow::appendLog(const QString &message)
{
    const QString timeText = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    ui->textLog->append(QString("[%1] %2").arg(timeText, message));
}

void ManualStaticTestWindow::setChannelReady(bool ready)
{
    m_channelReady = ready;
}

void ManualStaticTestWindow::closeEvent(QCloseEvent *event)
{
    appendLog("手动阻容测试窗口关闭，执行安全复位。");

    if (m_plc && m_plc->isConnected()) {
        resetStaticChannels();

        /*
         * 手动阻容窗口关闭时，保证伺服关闭，并保持阻容测试线路。
         */
        setServoPower(false);
        setDynamicMode(false);
    }

    QWidget::closeEvent(event);
}
