# SCPI 阻容测量流程补丁：继电器稳定 + 清缓存 + CONF + READ

## 修改文件

```text
modified_files/scpi_controller.h
modified_files/scpi_controller.cpp
modified_files/test_runner.cpp
modified_files/manualstatictestwindow.cpp
```

直接用 `modified_files` 里的文件覆盖工程同名文件即可。

## 本补丁实现的流程

```text
1. PLC / 继电器 M 点切换；
2. 等待继电器稳定；
3. 清空万用表通信缓存；
4. 发送 CONF:RES 或 CONF:CAP；
5. 等待测量模式稳定；
6. 发送 READ? 获取新测量值；
8. 原始值换算后显示：
   电阻：Ohm -> kOhm
   电容：F -> nF
```

按你的要求，本补丁没有实现第 7 点，也就是没有把 `9.9E37` 这类超量程/开路值单独拦截掉。

## 关键行为

### 电阻

```text
CONF:RES
等待 300 ms
READ?
```

返回值按 Ohm 处理，显示时除以 1000，得到 kOhm。

### 电容

```text
CONF:CAP
等待 1000 ms
READ?
```

返回值按 F 处理，显示时乘以 1e9，得到 nF。

### timeoutMs

手动测试和自动测试的 READ? 超时均改为 10000 ms。

注意：timeoutMs 仍然只是“最长等待仪器回复时间”，不是强制延时。强制延时由：

```text
继电器稳定等待：500 ms
电阻配置模式等待：300 ms
电容配置模式等待：1000 ms
```

负责。

## 如果仪器不支持命令

如果日志出现：

```text
Undefined header
```

说明仪器不支持 `CONF:RES` 或 `CONF:CAP`，需要按该仪器手册替换成对应命令，例如：

```text
FUNC "RES"
FUNC "CAP"
READ?
```

或其他型号专用命令。
