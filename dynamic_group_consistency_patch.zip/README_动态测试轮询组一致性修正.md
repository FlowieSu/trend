# 动态测试轮询组一致性修正

## 修正目的

当前怀疑问题：

```text
同一个产品的动态结果缓存是按 seq 直接覆盖的；
如果检测板持续轮询，上一组的 flag 可能和下一组的 rec 被拼到同一个 item 里；
QualiFlag=0 时，产品仍可能因为混组、Rec未收到、旧数据残留而显示 NG。
```

本次修正目标：

```text
1. 一个 DynamicProductContext 只缓存当前一个 groupCnt 的数据；
2. groupCnt 变化时，如果上一组没有完成，直接清空上一组；
3. DetectInProgressFlag==100 时，不立即上报；
4. 只有同一个 groupCnt 的组校验通过后，才锁定并存储结果；
5. 结果锁定后，不再接收后续轮询组覆盖最终结果。
```

## 修改文件

```text
dynamic_product_context.h
dynamic_product_context.cpp
```

## 关键逻辑

### 修改前

```text
m_values[seq] = value;
m_received[seq] = true;
```

只按 `seq` 存储，未强制同一个 `groupCnt`。

### 修改后

```text
当前缓存只对应 m_activeGroupCnt。

收到普通帧：
    如果 groupCnt 与当前组一致 -> 存入缓存
    如果 groupCnt 变化 -> 清空旧缓存，开启新组

收到组校验帧：
    只有 groupCnt 与当前组一致才处理
    只有 DetectInProgressFlag==100 且组校验通过才 m_finished=true
```

## 为什么不能在 DetectInProgressFlag==100 时立即完成

因为 DetectInProgressFlag 本身是一个普通序号，可能在一组轮询中较早出现。

如果此时立即：

```text
m_finished = true
buildResult()
markReported()
```

同一组后面的 rec 数据还没来得及存入，产品就被提前上报了。

所以本次改为：

```text
DetectInProgressFlag==100：
    只记录进度

组校验帧到达且校验通过：
    才锁定最终结果
```

## 注意

如果现场协议没有发送组校验帧，改完后产品不会完成，会等到超时。

但你当前协议代码里已经有：

```text
seq=255 组校验
calcGroupCheck()
m_groupCheckReceived
m_groupCheckPassed
```

所以推荐使用组校验作为“同组结果完成”的锁定点。
