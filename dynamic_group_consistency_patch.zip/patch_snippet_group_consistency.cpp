// dynamic_product_context.h 新增成员

bool m_hasActiveGroup = false;
int m_activeGroupCnt = 0;

void startNewGroup(int groupCnt);
bool ensureActiveGroup(const DynamicProtocol::ParsedFrame &frame);


// dynamic_product_context.cpp 核心原则

// 1. groupCnt 变化时清空缓存
void DynamicProductContext::startNewGroup(int groupCnt)
{
    resetCache();

    m_hasActiveGroup = true;
    m_activeGroupCnt = groupCnt;

    m_groupCnt = groupCnt;
    m_detectProgress = 0;

    m_groupCheckReceived = false;
    m_groupCheckPassed = false;
}

// 2. 普通帧必须进入当前 group
bool DynamicProductContext::ensureActiveGroup(const DynamicProtocol::ParsedFrame &frame)
{
    if (!m_hasActiveGroup) {
        startNewGroup(frame.groupCnt);
        return true;
    }

    if (frame.groupCnt != m_activeGroupCnt) {
        startNewGroup(frame.groupCnt);
        return true;
    }

    return true;
}

// 3. DetectInProgressFlag==100 不立即完成，只记录
if (DynamicProtocol::isDetectInProgressSeq(frame.seq)) {
    m_detectProgress = frame.value;
}

// 4. 组校验通过后才锁定结果
if (m_detectProgress == DynamicProtocol::kDetectFinishedValue &&
        m_groupCheckPassed) {
    m_finished = true;
    m_finishTime = currentTimeText();
}
