# csv_exporter 重新生成说明

本次重新生成的 `csv_exporter.h/.cpp` 只负责阻容测试 CSV 导出。

## 改动点

1. 删除了对 `sensor.h` 的依赖；
2. 删除了旧动态 `AllInfo` / `CsvDynamicResult` 导出逻辑；
3. 动态检测结果请使用 `dynamic_csv_exporter.h/.cpp`；
4. 阻容测试结果使用 `StaticTestResult` 导出；
5. 统一支持 UTF-8 BOM，Excel 打开中文不乱码；
6. 每个 `StaticTestResult` 导出一行。

## 主界面 saveStaticCsv 建议替换为

```cpp
bool MainWindow::saveStaticCsv(const QString &filePath)
{
    QString error;

    if (!CsvExporter::exportStaticResults(m_staticResults, filePath, &error)) {
        appendLog(QString("阻容CSV保存失败：%1").arg(error));
        return false;
    }

    return true;
}
```

## mainwindow.cpp 需要 include

```cpp
#include "csv_exporter.h"
```

## .pro 保持

```qmake
SOURCES += csv_exporter.cpp
HEADERS += csv_exporter.h
```

## 动态 CSV

动态检测结果仍然用：

```cpp
DynamicCsvExporter::exportResults(m_dynamicResults, filePath, &error);
```
