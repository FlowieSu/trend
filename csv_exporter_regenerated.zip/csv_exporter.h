#ifndef CSV_EXPORTER_H
#define CSV_EXPORTER_H

#include <QString>
#include <QVector>

#include "test_runner.h"

/*
 * CsvExporter
 *
 * 阻容测试 CSV 导出工具。
 *
 * 当前项目中：
 * 1. 阻容测试结果使用 CsvExporter 导出；
 * 2. 动态检测明细使用 DynamicCsvExporter 导出；
 * 3. CsvExporter 不再包含 sensor.h，也不再依赖 AllInfo；
 * 4. 旧动态 Sensor / AllInfo 结果不再通过本类保存。
 *
 * 推荐使用：
 *
 * QString error;
 * QString path = CsvExporter::buildStaticFileName(productCode1, productCode2);
 *
 * if (!CsvExporter::exportStaticResults(staticResults, path, &error)) {
 *     // 显示 error
 * }
 */

class CsvExporter
{
public:
    /*
     * 导出阻容测试明细。
     * 每个 StaticTestResult 一行。
     */
    static bool exportStaticResults(const QVector<StaticTestResult> &results,
                                    const QString &filePath,
                                    QString *errorMessage = nullptr);

    /*
     * 生成默认结果目录：
     * applicationDirPath()/results
     */
    static QString defaultResultDir();

    /*
     * 生成阻容测试默认文件名。
     */
    static QString buildStaticFileName(const QString &productCode1,
                                       const QString &productCode2,
                                       const QString &dirPath = QString());

    /*
     * 通用文件名生成函数。
     */
    static QString buildFileName(const QString &prefix,
                                 const QString &productCode1 = QString(),
                                 const QString &productCode2 = QString(),
                                 const QString &dirPath = QString());

    /*
     * 工具函数。
     */
    static QString quoteCsvField(const QString &text);
    static QString formatValue(double value,
                               int precision = 6);
    static QString passText(bool pass);
    static QString boolText(bool value);
    static QString positionText(int position);
    static QString timestampNow();

private:
    static bool validateStaticResults(const QVector<StaticTestResult> &results,
                                      QString *errorMessage);

    static bool ensureParentDir(const QString &filePath,
                                QString *errorMessage);

    static QString safeFilePart(const QString &text);

    static void setError(QString *errorMessage,
                         const QString &message);
};

#endif // CSV_EXPORTER_H
