#include "csv_exporter.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>

#include <cmath>

bool CsvExporter::exportStaticResults(const QVector<StaticTestResult> &results,
                                      const QString &filePath,
                                      QString *errorMessage)
{
    if (filePath.trimmed().isEmpty()) {
        setError(errorMessage, "CSV 文件路径为空。");
        return false;
    }

    if (!validateStaticResults(results, errorMessage)) {
        return false;
    }

    if (!ensureParentDir(filePath, errorMessage)) {
        return false;
    }

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        setError(errorMessage,
                 QString("阻容 CSV 打开失败：%1").arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    out.setCodec("UTF-8");
#endif

    /*
     * 写 UTF-8 BOM，方便 Windows Excel 直接打开中文不乱码。
     */
    out << QChar(0xFEFF);

    out << "测试类型,"
        << "产品编码,"
        << "测试位置,"
        << "测试项,"
        << "测试方向,"
        << "M点,"
        << "测试标准,"
        << "电阻/kOhm,"
        << "电容/nF,"
        << "电阻结果,"
        << "电容结果,"
        << "总结果,"
        << "备注,"
        << "测试时间\n";

    for (const StaticTestResult &r : results) {
        const QString timestamp = r.timestamp.trimmed().isEmpty()
                ? timestampNow()
                : r.timestamp;

        out << quoteCsvField("阻容测试") << ","
            << quoteCsvField(r.productCode) << ","
            << quoteCsvField(positionText(r.position)) << ","
            << quoteCsvField(r.testName) << ","
            << quoteCsvField(r.directionName) << ","
            << quoteCsvField(r.mPointsText) << ","
            << quoteCsvField(r.standardText) << ","
            << quoteCsvField(formatValue(r.resistanceKOhm)) << ","
            << quoteCsvField(formatValue(r.capacitanceNf)) << ","
            << quoteCsvField(passText(r.resistancePass)) << ","
            << quoteCsvField(passText(r.capacitancePass)) << ","
            << quoteCsvField(passText(r.pass)) << ","
            << quoteCsvField(r.message) << ","
            << quoteCsvField(timestamp) << "\n";
    }

    file.close();
    return true;
}

QString CsvExporter::defaultResultDir()
{
    QDir dir(QCoreApplication::applicationDirPath());

    if (!dir.exists("results")) {
        dir.mkdir("results");
    }

    return dir.filePath("results");
}

QString CsvExporter::buildStaticFileName(const QString &productCode1,
                                         const QString &productCode2,
                                         const QString &dirPath)
{
    return buildFileName("阻容测试结果",
                         productCode1,
                         productCode2,
                         dirPath);
}

QString CsvExporter::buildFileName(const QString &prefix,
                                   const QString &productCode1,
                                   const QString &productCode2,
                                   const QString &dirPath)
{
    const QString dir = dirPath.trimmed().isEmpty()
            ? defaultResultDir()
            : dirPath;

    QDir qdir(dir);

    if (!qdir.exists()) {
        qdir.mkpath(".");
    }

    QStringList parts;
    parts << safeFilePart(prefix);

    if (!productCode1.trimmed().isEmpty()) {
        parts << safeFilePart(productCode1);
    }

    if (!productCode2.trimmed().isEmpty()) {
        parts << safeFilePart(productCode2);
    }

    parts << QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");

    return qdir.filePath(parts.join("_") + ".csv");
}

QString CsvExporter::quoteCsvField(const QString &text)
{
    QString value = text;
    value.replace("\"", "\"\"");

    if (value.contains(',')
            || value.contains('"')
            || value.contains('\n')
            || value.contains('\r')) {
        value = "\"" + value + "\"";
    }

    return value;
}

QString CsvExporter::formatValue(double value,
                                 int precision)
{
    if (std::isnan(value) || std::isinf(value) || value < 0.0) {
        return "-";
    }

    return QString::number(value, 'f', precision);
}

QString CsvExporter::passText(bool pass)
{
    return pass ? "PASS" : "NG";
}

QString CsvExporter::boolText(bool value)
{
    return value ? "是" : "否";
}

QString CsvExporter::positionText(int position)
{
    if (position == 1) {
        return "位置1";
    }

    if (position == 2) {
        return "位置2";
    }

    return QString("位置%1").arg(position);
}

QString CsvExporter::timestampNow()
{
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
}

bool CsvExporter::validateStaticResults(const QVector<StaticTestResult> &results,
                                        QString *errorMessage)
{
    if (results.isEmpty()) {
        setError(errorMessage, "阻容测试结果为空，无法导出 CSV。");
        return false;
    }

    return true;
}

bool CsvExporter::ensureParentDir(const QString &filePath,
                                  QString *errorMessage)
{
    const QFileInfo info(filePath);
    const QDir dir = info.dir();

    if (dir.exists()) {
        return true;
    }

    if (!QDir().mkpath(dir.absolutePath())) {
        setError(errorMessage,
                 QString("创建 CSV 目录失败：%1").arg(dir.absolutePath()));
        return false;
    }

    return true;
}

QString CsvExporter::safeFilePart(const QString &text)
{
    QString value = text.trimmed();

    if (value.isEmpty()) {
        value = "未命名";
    }

    const QString invalid = "\\/:*?\"<>|";

    for (const QChar &ch : invalid) {
        value.replace(ch, "_");
    }

    value.replace(" ", "_");

    return value;
}

void CsvExporter::setError(QString *errorMessage,
                           const QString &message)
{
    if (errorMessage) {
        *errorMessage = message;
    }
}
